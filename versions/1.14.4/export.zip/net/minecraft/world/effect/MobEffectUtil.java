package net.minecraft.world.effect;

import net.minecraft.util.*;
import net.minecraft.world.entity.*;

public final class MobEffectUtil
{
    public static String formatDuration(final MobEffectInstance mobEffectInstance, final float var1) {
        if (mobEffectInstance.isNoCounter()) {
            return "**:**";
        }
        final int var2 = Mth.floor(mobEffectInstance.getDuration() * var1);
        return StringUtil.formatTickDuration(var2);
    }
    
    public static boolean hasDigSpeed(final LivingEntity livingEntity) {
        return livingEntity.hasEffect(MobEffects.DIG_SPEED) || livingEntity.hasEffect(MobEffects.CONDUIT_POWER);
    }
    
    public static int getDigSpeedAmplification(final LivingEntity livingEntity) {
        int var1 = 0;
        int var2 = 0;
        if (livingEntity.hasEffect(MobEffects.DIG_SPEED)) {
            var1 = livingEntity.getEffect(MobEffects.DIG_SPEED).getAmplifier();
        }
        if (livingEntity.hasEffect(MobEffects.CONDUIT_POWER)) {
            var2 = livingEntity.getEffect(MobEffects.CONDUIT_POWER).getAmplifier();
        }
        return Math.max(var1, var2);
    }
    
    public static boolean hasWaterBreathing(final LivingEntity livingEntity) {
        return livingEntity.hasEffect(MobEffects.WATER_BREATHING) || livingEntity.hasEffect(MobEffects.CONDUIT_POWER);
    }
}
