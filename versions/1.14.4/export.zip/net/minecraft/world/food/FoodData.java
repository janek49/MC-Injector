package net.minecraft.world.food;

import net.minecraft.world.item.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.world.level.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.nbt.*;

public class FoodData
{
    private int foodLevel;
    private float saturationLevel;
    private float exhaustionLevel;
    private int tickTimer;
    private int lastFoodLevel;
    
    public FoodData() {
        this.foodLevel = 20;
        this.lastFoodLevel = 20;
        this.saturationLevel = 5.0f;
    }
    
    public void eat(final int var1, final float var2) {
        this.foodLevel = Math.min(var1 + this.foodLevel, 20);
        this.saturationLevel = Math.min(this.saturationLevel + var1 * var2 * 2.0f, (float)this.foodLevel);
    }
    
    public void eat(final Item item, final ItemStack itemStack) {
        if (item.isEdible()) {
            final FoodProperties var3 = item.getFoodProperties();
            this.eat(var3.getNutrition(), var3.getSaturationModifier());
        }
    }
    
    public void tick(final Player player) {
        final Difficulty var2 = player.level.getDifficulty();
        this.lastFoodLevel = this.foodLevel;
        if (this.exhaustionLevel > 4.0f) {
            this.exhaustionLevel -= 4.0f;
            if (this.saturationLevel > 0.0f) {
                this.saturationLevel = Math.max(this.saturationLevel - 1.0f, 0.0f);
            }
            else if (var2 != Difficulty.PEACEFUL) {
                this.foodLevel = Math.max(this.foodLevel - 1, 0);
            }
        }
        final boolean var3 = player.level.getGameRules().getBoolean(GameRules.RULE_NATURAL_REGENERATION);
        if (var3 && this.saturationLevel > 0.0f && player.isHurt() && this.foodLevel >= 20) {
            ++this.tickTimer;
            if (this.tickTimer >= 10) {
                final float var4 = Math.min(this.saturationLevel, 6.0f);
                player.heal(var4 / 6.0f);
                this.addExhaustion(var4);
                this.tickTimer = 0;
            }
        }
        else if (var3 && this.foodLevel >= 18 && player.isHurt()) {
            ++this.tickTimer;
            if (this.tickTimer >= 80) {
                player.heal(1.0f);
                this.addExhaustion(6.0f);
                this.tickTimer = 0;
            }
        }
        else if (this.foodLevel <= 0) {
            ++this.tickTimer;
            if (this.tickTimer >= 80) {
                if (player.getHealth() > 10.0f || var2 == Difficulty.HARD || (player.getHealth() > 1.0f && var2 == Difficulty.NORMAL)) {
                    player.hurt(DamageSource.STARVE, 1.0f);
                }
                this.tickTimer = 0;
            }
        }
        else {
            this.tickTimer = 0;
        }
    }
    
    public void readAdditionalSaveData(final CompoundTag compoundTag) {
        if (compoundTag.contains("foodLevel", 99)) {
            this.foodLevel = compoundTag.getInt("foodLevel");
            this.tickTimer = compoundTag.getInt("foodTickTimer");
            this.saturationLevel = compoundTag.getFloat("foodSaturationLevel");
            this.exhaustionLevel = compoundTag.getFloat("foodExhaustionLevel");
        }
    }
    
    public void addAdditionalSaveData(final CompoundTag compoundTag) {
        compoundTag.putInt("foodLevel", this.foodLevel);
        compoundTag.putInt("foodTickTimer", this.tickTimer);
        compoundTag.putFloat("foodSaturationLevel", this.saturationLevel);
        compoundTag.putFloat("foodExhaustionLevel", this.exhaustionLevel);
    }
    
    public int getFoodLevel() {
        return this.foodLevel;
    }
    
    public boolean needsFood() {
        return this.foodLevel < 20;
    }
    
    public void addExhaustion(final float f) {
        this.exhaustionLevel = Math.min(this.exhaustionLevel + f, 40.0f);
    }
    
    public float getSaturationLevel() {
        return this.saturationLevel;
    }
    
    public void setFoodLevel(final int foodLevel) {
        this.foodLevel = foodLevel;
    }
    
    public void setSaturation(final float saturation) {
        this.saturationLevel = saturation;
    }
}
