package net.minecraft.world.inventory;

import net.minecraft.world.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.item.*;

public class HopperMenu extends AbstractContainerMenu
{
    private final Container hopper;
    
    public HopperMenu(final int var1, final Inventory inventory) {
        this(var1, inventory, new SimpleContainer(5));
    }
    
    public HopperMenu(final int var1, final Inventory inventory, final Container hopper) {
        super(MenuType.HOPPER, var1);
        AbstractContainerMenu.checkContainerSize(this.hopper = hopper, 5);
        hopper.startOpen(inventory.player);
        final int var2 = 51;
        for (int var3 = 0; var3 < 5; ++var3) {
            this.addSlot(new Slot(hopper, var3, 44 + var3 * 18, 20));
        }
        for (int var3 = 0; var3 < 3; ++var3) {
            for (int var4 = 0; var4 < 9; ++var4) {
                this.addSlot(new Slot(inventory, var4 + var3 * 9 + 9, 8 + var4 * 18, var3 * 18 + 51));
            }
        }
        for (int var3 = 0; var3 < 9; ++var3) {
            this.addSlot(new Slot(inventory, var3, 8 + var3 * 18, 109));
        }
    }
    
    @Override
    public boolean stillValid(final Player player) {
        return this.hopper.stillValid(player);
    }
    
    @Override
    public ItemStack quickMoveStack(final Player player, final int var2) {
        ItemStack itemStack = ItemStack.EMPTY;
        final Slot var3 = this.slots.get(var2);
        if (var3 != null && var3.hasItem()) {
            final ItemStack var4 = var3.getItem();
            itemStack = var4.copy();
            if (var2 < this.hopper.getContainerSize()) {
                if (!this.moveItemStackTo(var4, this.hopper.getContainerSize(), this.slots.size(), true)) {
                    return ItemStack.EMPTY;
                }
            }
            else if (!this.moveItemStackTo(var4, 0, this.hopper.getContainerSize(), false)) {
                return ItemStack.EMPTY;
            }
            if (var4.isEmpty()) {
                var3.set(ItemStack.EMPTY);
            }
            else {
                var3.setChanged();
            }
        }
        return itemStack;
    }
    
    @Override
    public void removed(final Player player) {
        super.removed(player);
        this.hopper.stopOpen(player);
    }
}
