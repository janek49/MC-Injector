package net.minecraft.world;

import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.*;
import net.minecraft.core.*;

public interface WorldlyContainerHolder
{
    WorldlyContainer getContainer(final BlockState p0, final LevelAccessor p1, final BlockPos p2);
}
