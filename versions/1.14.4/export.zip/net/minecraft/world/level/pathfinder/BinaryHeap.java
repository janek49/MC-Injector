package net.minecraft.world.level.pathfinder;

public class BinaryHeap
{
    private Node[] heap;
    private int size;
    
    public BinaryHeap() {
        this.heap = new Node[128];
    }
    
    public Node insert(final Node node) {
        if (node.heapIdx >= 0) {
            throw new IllegalStateException("OW KNOWS!");
        }
        if (this.size == this.heap.length) {
            final Node[] vars2 = new Node[this.size << 1];
            System.arraycopy(this.heap, 0, vars2, 0, this.size);
            this.heap = vars2;
        }
        this.heap[this.size] = node;
        node.heapIdx = this.size;
        this.upHeap(this.size++);
        return node;
    }
    
    public void clear() {
        this.size = 0;
    }
    
    public Node pop() {
        final Node node = this.heap[0];
        final Node[] heap = this.heap;
        final int n = 0;
        final Node[] heap2 = this.heap;
        final int size = this.size - 1;
        this.size = size;
        heap[n] = heap2[size];
        this.heap[this.size] = null;
        if (this.size > 0) {
            this.downHeap(0);
        }
        node.heapIdx = -1;
        return node;
    }
    
    public void changeCost(final Node node, final float var2) {
        final float var3 = node.f;
        node.f = var2;
        if (var2 < var3) {
            this.upHeap(node.heapIdx);
        }
        else {
            this.downHeap(node.heapIdx);
        }
    }
    
    private void upHeap(int i) {
        final Node var2 = this.heap[i];
        final float var3 = var2.f;
        while (i > 0) {
            final int var4 = i - 1 >> 1;
            final Node var5 = this.heap[var4];
            if (var3 >= var5.f) {
                break;
            }
            this.heap[i] = var5;
            var5.heapIdx = i;
            i = var4;
        }
        this.heap[i] = var2;
        var2.heapIdx = i;
    }
    
    private void downHeap(int i) {
        final Node var2 = this.heap[i];
        final float var3 = var2.f;
        while (true) {
            final int var4 = 1 + (i << 1);
            final int var5 = var4 + 1;
            if (var4 >= this.size) {
                break;
            }
            final Node var6 = this.heap[var4];
            final float var7 = var6.f;
            Node var8;
            float var9;
            if (var5 >= this.size) {
                var8 = null;
                var9 = Float.POSITIVE_INFINITY;
            }
            else {
                var8 = this.heap[var5];
                var9 = var8.f;
            }
            if (var7 < var9) {
                if (var7 >= var3) {
                    break;
                }
                this.heap[i] = var6;
                var6.heapIdx = i;
                i = var4;
            }
            else {
                if (var9 >= var3) {
                    break;
                }
                this.heap[i] = var8;
                var8.heapIdx = i;
                i = var5;
            }
        }
        this.heap[i] = var2;
        var2.heapIdx = i;
    }
    
    public boolean isEmpty() {
        return this.size == 0;
    }
}
