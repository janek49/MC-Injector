package net.minecraft.world.level.lighting;

import net.minecraft.server.level.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.chunk.*;
import javax.annotation.*;
import net.minecraft.core.*;
import it.unimi.dsi.fastutil.longs.*;
import it.unimi.dsi.fastutil.objects.*;

public abstract class LayerLightSectionStorage<M extends DataLayerStorageMap<M>> extends SectionTracker
{
    protected static final DataLayer EMPTY_DATA;
    private static final Direction[] DIRECTIONS;
    private final LightLayer layer;
    private final LightChunkGetter chunkSource;
    protected final LongSet dataSectionSet;
    protected final LongSet toMarkNoData;
    protected final LongSet toMarkData;
    protected volatile M visibleSectionData;
    protected final M updatingSectionData;
    protected final LongSet changedSections;
    protected final LongSet sectionsAffectedByLightUpdates;
    protected final Long2ObjectMap<DataLayer> queuedSections;
    private final LongSet columnsToRetainQueuedDataFor;
    private final LongSet toRemove;
    protected volatile boolean hasToRemove;
    
    protected LayerLightSectionStorage(final LightLayer layer, final LightChunkGetter chunkSource, final M updatingSectionData) {
        super(3, 16, 256);
        this.dataSectionSet = (LongSet)new LongOpenHashSet();
        this.toMarkNoData = (LongSet)new LongOpenHashSet();
        this.toMarkData = (LongSet)new LongOpenHashSet();
        this.changedSections = (LongSet)new LongOpenHashSet();
        this.sectionsAffectedByLightUpdates = (LongSet)new LongOpenHashSet();
        this.queuedSections = (Long2ObjectMap<DataLayer>)new Long2ObjectOpenHashMap();
        this.columnsToRetainQueuedDataFor = (LongSet)new LongOpenHashSet();
        this.toRemove = (LongSet)new LongOpenHashSet();
        this.layer = layer;
        this.chunkSource = chunkSource;
        this.updatingSectionData = updatingSectionData;
        (this.visibleSectionData = updatingSectionData.copy()).disableCache();
    }
    
    protected boolean storingLightForSection(final long l) {
        return this.getDataLayer(l, true) != null;
    }
    
    @Nullable
    protected DataLayer getDataLayer(final long var1, final boolean var3) {
        return this.getDataLayer(var3 ? this.updatingSectionData : this.visibleSectionData, var1);
    }
    
    @Nullable
    protected DataLayer getDataLayer(final M dataLayerStorageMap, final long var2) {
        return dataLayerStorageMap.getLayer(var2);
    }
    
    @Nullable
    public DataLayer getDataLayerData(final long l) {
        final DataLayer dataLayer = (DataLayer)this.queuedSections.get(l);
        if (dataLayer != null) {
            return dataLayer;
        }
        return this.getDataLayer(l, false);
    }
    
    protected abstract int getLightValue(final long p0);
    
    protected int getStoredLevel(final long l) {
        final long var3 = SectionPos.blockToSection(l);
        final DataLayer var4 = this.getDataLayer(var3, true);
        return var4.get(SectionPos.sectionRelative(BlockPos.getX(l)), SectionPos.sectionRelative(BlockPos.getY(l)), SectionPos.sectionRelative(BlockPos.getZ(l)));
    }
    
    protected void setStoredLevel(final long var1, final int var3) {
        final long var4 = SectionPos.blockToSection(var1);
        if (this.changedSections.add(var4)) {
            this.updatingSectionData.copyDataLayer(var4);
        }
        final DataLayer var5 = this.getDataLayer(var4, true);
        var5.set(SectionPos.sectionRelative(BlockPos.getX(var1)), SectionPos.sectionRelative(BlockPos.getY(var1)), SectionPos.sectionRelative(BlockPos.getZ(var1)), var3);
        for (int var6 = -1; var6 <= 1; ++var6) {
            for (int var7 = -1; var7 <= 1; ++var7) {
                for (int var8 = -1; var8 <= 1; ++var8) {
                    this.sectionsAffectedByLightUpdates.add(SectionPos.blockToSection(BlockPos.offset(var1, var7, var8, var6)));
                }
            }
        }
    }
    
    @Override
    protected int getLevel(final long l) {
        if (l == Long.MAX_VALUE) {
            return 2;
        }
        if (this.dataSectionSet.contains(l)) {
            return 0;
        }
        if (!this.toRemove.contains(l) && this.updatingSectionData.hasLayer(l)) {
            return 1;
        }
        return 2;
    }
    
    @Override
    protected int getLevelFromSource(final long l) {
        if (this.toMarkNoData.contains(l)) {
            return 2;
        }
        if (this.dataSectionSet.contains(l) || this.toMarkData.contains(l)) {
            return 0;
        }
        return 2;
    }
    
    @Override
    protected void setLevel(final long var1, final int var3) {
        final int var4 = this.getLevel(var1);
        if (var4 != 0 && var3 == 0) {
            this.dataSectionSet.add(var1);
            this.toMarkData.remove(var1);
        }
        if (var4 == 0 && var3 != 0) {
            this.dataSectionSet.remove(var1);
            this.toMarkNoData.remove(var1);
        }
        if (var4 >= 2 && var3 != 2) {
            if (this.toRemove.contains(var1)) {
                this.toRemove.remove(var1);
            }
            else {
                this.updatingSectionData.setLayer(var1, this.createDataLayer(var1));
                this.changedSections.add(var1);
                this.onNodeAdded(var1);
                for (int var5 = -1; var5 <= 1; ++var5) {
                    for (int var6 = -1; var6 <= 1; ++var6) {
                        for (int var7 = -1; var7 <= 1; ++var7) {
                            this.sectionsAffectedByLightUpdates.add(SectionPos.blockToSection(BlockPos.offset(var1, var6, var7, var5)));
                        }
                    }
                }
            }
        }
        if (var4 != 2 && var3 >= 2) {
            this.toRemove.add(var1);
        }
        this.hasToRemove = !this.toRemove.isEmpty();
    }
    
    protected DataLayer createDataLayer(final long l) {
        final DataLayer dataLayer = (DataLayer)this.queuedSections.get(l);
        if (dataLayer != null) {
            return dataLayer;
        }
        return new DataLayer();
    }
    
    protected void clearQueuedSectionBlocks(final LayerLightEngine<?, ?> layerLightEngine, final long var2) {
        final int var3 = SectionPos.sectionToBlockCoord(SectionPos.x(var2));
        final int var4 = SectionPos.sectionToBlockCoord(SectionPos.y(var2));
        final int var5 = SectionPos.sectionToBlockCoord(SectionPos.z(var2));
        for (int var6 = 0; var6 < 16; ++var6) {
            for (int var7 = 0; var7 < 16; ++var7) {
                for (int var8 = 0; var8 < 16; ++var8) {
                    final long var9 = BlockPos.asLong(var3 + var6, var4 + var7, var5 + var8);
                    layerLightEngine.removeFromQueue(var9);
                }
            }
        }
    }
    
    protected boolean hasInconsistencies() {
        return this.hasToRemove;
    }
    
    protected void markNewInconsistencies(final LayerLightEngine<M, ?> layerLightEngine, final boolean var2, final boolean var3) {
        if (!this.hasInconsistencies() && this.queuedSections.isEmpty()) {
            return;
        }
        for (final long var4 : this.toRemove) {
            this.clearQueuedSectionBlocks(layerLightEngine, var4);
            final DataLayer var5 = (DataLayer)this.queuedSections.remove(var4);
            final DataLayer var6 = this.updatingSectionData.removeLayer(var4);
            if (this.columnsToRetainQueuedDataFor.contains(SectionPos.getZeroNode(var4))) {
                if (var5 != null) {
                    this.queuedSections.put(var4, (Object)var5);
                }
                else {
                    if (var6 == null) {
                        continue;
                    }
                    this.queuedSections.put(var4, (Object)var6);
                }
            }
        }
        this.updatingSectionData.clearCache();
        for (final long var4 : this.toRemove) {
            this.onNodeRemoved(var4);
        }
        this.toRemove.clear();
        this.hasToRemove = false;
        for (final Long2ObjectMap.Entry<DataLayer> var7 : this.queuedSections.long2ObjectEntrySet()) {
            final long var8 = var7.getLongKey();
            if (!this.storingLightForSection(var8)) {
                continue;
            }
            final DataLayer var6 = (DataLayer)var7.getValue();
            if (this.updatingSectionData.getLayer(var8) == var6) {
                continue;
            }
            this.clearQueuedSectionBlocks(layerLightEngine, var8);
            this.updatingSectionData.setLayer(var8, var6);
            this.changedSections.add(var8);
        }
        this.updatingSectionData.clearCache();
        if (!var3) {
            for (final long var4 : this.queuedSections.keySet()) {
                if (!this.storingLightForSection(var4)) {
                    continue;
                }
                final int var9 = SectionPos.sectionToBlockCoord(SectionPos.x(var4));
                final int var10 = SectionPos.sectionToBlockCoord(SectionPos.y(var4));
                final int var11 = SectionPos.sectionToBlockCoord(SectionPos.z(var4));
                for (final Direction var12 : LayerLightSectionStorage.DIRECTIONS) {
                    final long var13 = SectionPos.offset(var4, var12);
                    if (!this.queuedSections.containsKey(var13)) {
                        if (this.storingLightForSection(var13)) {
                            for (int var14 = 0; var14 < 16; ++var14) {
                                for (int var15 = 0; var15 < 16; ++var15) {
                                    long var16 = 0L;
                                    long var17 = 0L;
                                    switch (var12) {
                                        case DOWN: {
                                            var16 = BlockPos.asLong(var9 + var15, var10, var11 + var14);
                                            var17 = BlockPos.asLong(var9 + var15, var10 - 1, var11 + var14);
                                            break;
                                        }
                                        case UP: {
                                            var16 = BlockPos.asLong(var9 + var15, var10 + 16 - 1, var11 + var14);
                                            var17 = BlockPos.asLong(var9 + var15, var10 + 16, var11 + var14);
                                            break;
                                        }
                                        case NORTH: {
                                            var16 = BlockPos.asLong(var9 + var14, var10 + var15, var11);
                                            var17 = BlockPos.asLong(var9 + var14, var10 + var15, var11 - 1);
                                            break;
                                        }
                                        case SOUTH: {
                                            var16 = BlockPos.asLong(var9 + var14, var10 + var15, var11 + 16 - 1);
                                            var17 = BlockPos.asLong(var9 + var14, var10 + var15, var11 + 16);
                                            break;
                                        }
                                        case WEST: {
                                            var16 = BlockPos.asLong(var9, var10 + var14, var11 + var15);
                                            var17 = BlockPos.asLong(var9 - 1, var10 + var14, var11 + var15);
                                            break;
                                        }
                                        default: {
                                            var16 = BlockPos.asLong(var9 + 16 - 1, var10 + var14, var11 + var15);
                                            var17 = BlockPos.asLong(var9 + 16, var10 + var14, var11 + var15);
                                            break;
                                        }
                                    }
                                    layerLightEngine.checkEdge(var16, var17, layerLightEngine.computeLevelFromNeighbor(var16, var17, layerLightEngine.getLevel(var16)), false);
                                    layerLightEngine.checkEdge(var17, var16, layerLightEngine.computeLevelFromNeighbor(var17, var16, layerLightEngine.getLevel(var17)), false);
                                }
                            }
                        }
                    }
                }
            }
        }
        final ObjectIterator<Long2ObjectMap.Entry<DataLayer>> var18 = (ObjectIterator<Long2ObjectMap.Entry<DataLayer>>)this.queuedSections.long2ObjectEntrySet().iterator();
        while (var18.hasNext()) {
            final Long2ObjectMap.Entry<DataLayer> var7 = (Long2ObjectMap.Entry<DataLayer>)var18.next();
            final long var8 = var7.getLongKey();
            if (this.storingLightForSection(var8)) {
                var18.remove();
            }
        }
    }
    
    protected void onNodeAdded(final long l) {
    }
    
    protected void onNodeRemoved(final long l) {
    }
    
    protected void enableLightSources(final long var1, final boolean var3) {
    }
    
    public void retainData(final long var1, final boolean var3) {
        if (var3) {
            this.columnsToRetainQueuedDataFor.add(var1);
        }
        else {
            this.columnsToRetainQueuedDataFor.remove(var1);
        }
    }
    
    protected void queueSectionData(final long var1, @Nullable final DataLayer dataLayer) {
        if (dataLayer != null) {
            this.queuedSections.put(var1, (Object)dataLayer);
        }
        else {
            this.queuedSections.remove(var1);
        }
    }
    
    protected void updateSectionStatus(final long var1, final boolean var3) {
        final boolean var4 = this.dataSectionSet.contains(var1);
        if (!var4 && !var3) {
            this.toMarkData.add(var1);
            this.checkEdge(Long.MAX_VALUE, var1, 0, true);
        }
        if (var4 && var3) {
            this.toMarkNoData.add(var1);
            this.checkEdge(Long.MAX_VALUE, var1, 2, false);
        }
    }
    
    protected void runAllUpdates() {
        if (this.hasWork()) {
            this.runUpdates(Integer.MAX_VALUE);
        }
    }
    
    protected void swapSectionMap() {
        if (!this.changedSections.isEmpty()) {
            final M var1 = this.updatingSectionData.copy();
            var1.disableCache();
            this.visibleSectionData = var1;
            this.changedSections.clear();
        }
        if (!this.sectionsAffectedByLightUpdates.isEmpty()) {
            final LongIterator var2 = this.sectionsAffectedByLightUpdates.iterator();
            while (var2.hasNext()) {
                final long var3 = var2.nextLong();
                this.chunkSource.onLightUpdate(this.layer, SectionPos.of(var3));
            }
            this.sectionsAffectedByLightUpdates.clear();
        }
    }
    
    static {
        EMPTY_DATA = new DataLayer();
        DIRECTIONS = Direction.values();
    }
}
