package net.minecraft.world.level.lighting;

import net.minecraft.world.level.*;
import net.minecraft.world.level.chunk.*;
import net.minecraft.core.*;
import java.util.*;
import it.unimi.dsi.fastutil.longs.*;

public class SkyLightSectionStorage extends LayerLightSectionStorage<SkyDataLayerStorageMap>
{
    private static final Direction[] HORIZONTALS;
    private final LongSet sectionsWithSources;
    private final LongSet sectionsToAddSourcesTo;
    private final LongSet sectionsToRemoveSourcesFrom;
    private final LongSet columnsWithSkySources;
    private volatile boolean hasSourceInconsistencies;
    
    protected SkyLightSectionStorage(final LightChunkGetter lightChunkGetter) {
        super(LightLayer.SKY, lightChunkGetter, new SkyDataLayerStorageMap((Long2ObjectOpenHashMap<DataLayer>)new Long2ObjectOpenHashMap(), new Long2IntOpenHashMap(), Integer.MAX_VALUE));
        this.sectionsWithSources = (LongSet)new LongOpenHashSet();
        this.sectionsToAddSourcesTo = (LongSet)new LongOpenHashSet();
        this.sectionsToRemoveSourcesFrom = (LongSet)new LongOpenHashSet();
        this.columnsWithSkySources = (LongSet)new LongOpenHashSet();
    }
    
    @Override
    protected int getLightValue(long l) {
        long var3 = SectionPos.blockToSection(l);
        int var4 = SectionPos.y(var3);
        final SkyDataLayerStorageMap var5 = (SkyDataLayerStorageMap)this.visibleSectionData;
        final int var6 = var5.topSections.get(SectionPos.getZeroNode(var3));
        if (var6 == var5.currentLowestY || var4 >= var6) {
            return 15;
        }
        DataLayer var7 = this.getDataLayer(var5, var3);
        if (var7 == null) {
            l = BlockPos.getFlatIndex(l);
            while (var7 == null) {
                var3 = SectionPos.offset(var3, Direction.UP);
                if (++var4 >= var6) {
                    return 15;
                }
                l = BlockPos.offset(l, 0, 16, 0);
                var7 = this.getDataLayer(var5, var3);
            }
        }
        return var7.get(SectionPos.sectionRelative(BlockPos.getX(l)), SectionPos.sectionRelative(BlockPos.getY(l)), SectionPos.sectionRelative(BlockPos.getZ(l)));
    }
    
    @Override
    protected void onNodeAdded(final long l) {
        final int var3 = SectionPos.y(l);
        if (((SkyDataLayerStorageMap)this.updatingSectionData).currentLowestY > var3) {
            ((SkyDataLayerStorageMap)this.updatingSectionData).currentLowestY = var3;
            ((SkyDataLayerStorageMap)this.updatingSectionData).topSections.defaultReturnValue(((SkyDataLayerStorageMap)this.updatingSectionData).currentLowestY);
        }
        final long var4 = SectionPos.getZeroNode(l);
        final int var5 = ((SkyDataLayerStorageMap)this.updatingSectionData).topSections.get(var4);
        if (var5 < var3 + 1) {
            ((SkyDataLayerStorageMap)this.updatingSectionData).topSections.put(var4, var3 + 1);
            if (this.columnsWithSkySources.contains(var4)) {
                this.queueAddSource(l);
                if (var5 > ((SkyDataLayerStorageMap)this.updatingSectionData).currentLowestY) {
                    final long var6 = SectionPos.asLong(SectionPos.x(l), var5 - 1, SectionPos.z(l));
                    this.queueRemoveSource(var6);
                }
                this.recheckInconsistencyFlag();
            }
        }
    }
    
    private void queueRemoveSource(final long l) {
        this.sectionsToRemoveSourcesFrom.add(l);
        this.sectionsToAddSourcesTo.remove(l);
    }
    
    private void queueAddSource(final long l) {
        this.sectionsToAddSourcesTo.add(l);
        this.sectionsToRemoveSourcesFrom.remove(l);
    }
    
    private void recheckInconsistencyFlag() {
        this.hasSourceInconsistencies = (!this.sectionsToAddSourcesTo.isEmpty() || !this.sectionsToRemoveSourcesFrom.isEmpty());
    }
    
    @Override
    protected void onNodeRemoved(final long l) {
        final long var3 = SectionPos.getZeroNode(l);
        final boolean var4 = this.columnsWithSkySources.contains(var3);
        if (var4) {
            this.queueRemoveSource(l);
        }
        int var5 = SectionPos.y(l);
        if (((SkyDataLayerStorageMap)this.updatingSectionData).topSections.get(var3) == var5 + 1) {
            long var6;
            for (var6 = l; !this.storingLightForSection(var6) && this.hasSectionsBelow(var5); --var5, var6 = SectionPos.offset(var6, Direction.DOWN)) {}
            if (this.storingLightForSection(var6)) {
                ((SkyDataLayerStorageMap)this.updatingSectionData).topSections.put(var3, var5 + 1);
                if (var4) {
                    this.queueAddSource(var6);
                }
            }
            else {
                ((SkyDataLayerStorageMap)this.updatingSectionData).topSections.remove(var3);
            }
        }
        if (var4) {
            this.recheckInconsistencyFlag();
        }
    }
    
    @Override
    protected void enableLightSources(final long var1, final boolean var3) {
        if (var3 && this.columnsWithSkySources.add(var1)) {
            final int var4 = ((SkyDataLayerStorageMap)this.updatingSectionData).topSections.get(var1);
            if (var4 != ((SkyDataLayerStorageMap)this.updatingSectionData).currentLowestY) {
                final long var5 = SectionPos.asLong(SectionPos.x(var1), var4 - 1, SectionPos.z(var1));
                this.queueAddSource(var5);
                this.recheckInconsistencyFlag();
            }
        }
        else if (!var3) {
            this.columnsWithSkySources.remove(var1);
        }
    }
    
    @Override
    protected boolean hasInconsistencies() {
        return super.hasInconsistencies() || this.hasSourceInconsistencies;
    }
    
    @Override
    protected DataLayer createDataLayer(final long l) {
        final DataLayer dataLayer = (DataLayer)this.queuedSections.get(l);
        if (dataLayer != null) {
            return dataLayer;
        }
        long var4 = SectionPos.offset(l, Direction.UP);
        final int var5 = ((SkyDataLayerStorageMap)this.updatingSectionData).topSections.get(SectionPos.getZeroNode(l));
        if (var5 == ((SkyDataLayerStorageMap)this.updatingSectionData).currentLowestY || SectionPos.y(var4) >= var5) {
            return new DataLayer();
        }
        DataLayer var6;
        while ((var6 = this.getDataLayer(var4, true)) == null) {
            var4 = SectionPos.offset(var4, Direction.UP);
        }
        return new DataLayer(new FlatDataLayer(var6, 0).getData());
    }
    
    @Override
    protected void markNewInconsistencies(final LayerLightEngine<SkyDataLayerStorageMap, ?> layerLightEngine, final boolean var2, final boolean var3) {
        super.markNewInconsistencies(layerLightEngine, var2, var3);
        if (!var2) {
            return;
        }
        if (!this.sectionsToAddSourcesTo.isEmpty()) {
            for (final long var4 : this.sectionsToAddSourcesTo) {
                final int var5 = this.getLevel(var4);
                if (var5 == 2) {
                    continue;
                }
                if (this.sectionsToRemoveSourcesFrom.contains(var4) || !this.sectionsWithSources.add(var4)) {
                    continue;
                }
                if (var5 == 1) {
                    this.clearQueuedSectionBlocks(layerLightEngine, var4);
                    if (this.changedSections.add(var4)) {
                        ((SkyDataLayerStorageMap)this.updatingSectionData).copyDataLayer(var4);
                    }
                    Arrays.fill(this.getDataLayer(var4, true).getData(), (byte)(-1));
                    final int var6 = SectionPos.sectionToBlockCoord(SectionPos.x(var4));
                    final int var7 = SectionPos.sectionToBlockCoord(SectionPos.y(var4));
                    final int var8 = SectionPos.sectionToBlockCoord(SectionPos.z(var4));
                    for (final Direction var9 : SkyLightSectionStorage.HORIZONTALS) {
                        final long var10 = SectionPos.offset(var4, var9);
                        if (this.sectionsToRemoveSourcesFrom.contains(var10) || (!this.sectionsWithSources.contains(var10) && !this.sectionsToAddSourcesTo.contains(var10))) {
                            if (this.storingLightForSection(var10)) {
                                for (int var11 = 0; var11 < 16; ++var11) {
                                    for (int var12 = 0; var12 < 16; ++var12) {
                                        long var13 = 0L;
                                        long var14 = 0L;
                                        switch (var9) {
                                            case NORTH: {
                                                var13 = BlockPos.asLong(var6 + var11, var7 + var12, var8);
                                                var14 = BlockPos.asLong(var6 + var11, var7 + var12, var8 - 1);
                                                break;
                                            }
                                            case SOUTH: {
                                                var13 = BlockPos.asLong(var6 + var11, var7 + var12, var8 + 16 - 1);
                                                var14 = BlockPos.asLong(var6 + var11, var7 + var12, var8 + 16);
                                                break;
                                            }
                                            case WEST: {
                                                var13 = BlockPos.asLong(var6, var7 + var11, var8 + var12);
                                                var14 = BlockPos.asLong(var6 - 1, var7 + var11, var8 + var12);
                                                break;
                                            }
                                            default: {
                                                var13 = BlockPos.asLong(var6 + 16 - 1, var7 + var11, var8 + var12);
                                                var14 = BlockPos.asLong(var6 + 16, var7 + var11, var8 + var12);
                                                break;
                                            }
                                        }
                                        layerLightEngine.checkEdge(var13, var14, layerLightEngine.computeLevelFromNeighbor(var13, var14, 0), true);
                                    }
                                }
                            }
                        }
                    }
                    for (int var15 = 0; var15 < 16; ++var15) {
                        for (int var16 = 0; var16 < 16; ++var16) {
                            final long var17 = BlockPos.asLong(SectionPos.sectionToBlockCoord(SectionPos.x(var4)) + var15, SectionPos.sectionToBlockCoord(SectionPos.y(var4)), SectionPos.sectionToBlockCoord(SectionPos.z(var4)) + var16);
                            final long var10 = BlockPos.asLong(SectionPos.sectionToBlockCoord(SectionPos.x(var4)) + var15, SectionPos.sectionToBlockCoord(SectionPos.y(var4)) - 1, SectionPos.sectionToBlockCoord(SectionPos.z(var4)) + var16);
                            layerLightEngine.checkEdge(var17, var10, layerLightEngine.computeLevelFromNeighbor(var17, var10, 0), true);
                        }
                    }
                }
                else {
                    for (int var6 = 0; var6 < 16; ++var6) {
                        for (int var7 = 0; var7 < 16; ++var7) {
                            final long var18 = BlockPos.asLong(SectionPos.sectionToBlockCoord(SectionPos.x(var4)) + var6, SectionPos.sectionToBlockCoord(SectionPos.y(var4)) + 16 - 1, SectionPos.sectionToBlockCoord(SectionPos.z(var4)) + var7);
                            layerLightEngine.checkEdge(Long.MAX_VALUE, var18, 0, true);
                        }
                    }
                }
            }
        }
        this.sectionsToAddSourcesTo.clear();
        if (!this.sectionsToRemoveSourcesFrom.isEmpty()) {
            for (final long var4 : this.sectionsToRemoveSourcesFrom) {
                if (this.sectionsWithSources.remove(var4)) {
                    if (!this.storingLightForSection(var4)) {
                        continue;
                    }
                    for (int var5 = 0; var5 < 16; ++var5) {
                        for (int var6 = 0; var6 < 16; ++var6) {
                            final long var19 = BlockPos.asLong(SectionPos.sectionToBlockCoord(SectionPos.x(var4)) + var5, SectionPos.sectionToBlockCoord(SectionPos.y(var4)) + 16 - 1, SectionPos.sectionToBlockCoord(SectionPos.z(var4)) + var6);
                            layerLightEngine.checkEdge(Long.MAX_VALUE, var19, 15, false);
                        }
                    }
                }
            }
        }
        this.sectionsToRemoveSourcesFrom.clear();
        this.hasSourceInconsistencies = false;
    }
    
    protected boolean hasSectionsBelow(final int i) {
        return i >= ((SkyDataLayerStorageMap)this.updatingSectionData).currentLowestY;
    }
    
    protected boolean hasLightSource(final long l) {
        final int var3 = BlockPos.getY(l);
        if ((var3 & 0xF) != 0xF) {
            return false;
        }
        final long var4 = SectionPos.blockToSection(l);
        final long var5 = SectionPos.getZeroNode(var4);
        if (!this.columnsWithSkySources.contains(var5)) {
            return false;
        }
        final int var6 = ((SkyDataLayerStorageMap)this.updatingSectionData).topSections.get(var5);
        return SectionPos.sectionToBlockCoord(var6) == var3 + 16;
    }
    
    protected boolean isAboveData(final long l) {
        final long var3 = SectionPos.getZeroNode(l);
        final int var4 = ((SkyDataLayerStorageMap)this.updatingSectionData).topSections.get(var3);
        return var4 == ((SkyDataLayerStorageMap)this.updatingSectionData).currentLowestY || SectionPos.y(l) >= var4;
    }
    
    protected boolean lightOnInSection(final long l) {
        final long var3 = SectionPos.getZeroNode(l);
        return this.columnsWithSkySources.contains(var3);
    }
    
    static {
        HORIZONTALS = new Direction[] { Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST };
    }
    
    public static final class SkyDataLayerStorageMap extends DataLayerStorageMap<SkyDataLayerStorageMap>
    {
        private int currentLowestY;
        private final Long2IntOpenHashMap topSections;
        
        public SkyDataLayerStorageMap(final Long2ObjectOpenHashMap<DataLayer> long2ObjectOpenHashMap, final Long2IntOpenHashMap topSections, final int currentLowestY) {
            super(long2ObjectOpenHashMap);
            (this.topSections = topSections).defaultReturnValue(currentLowestY);
            this.currentLowestY = currentLowestY;
        }
        
        @Override
        public SkyDataLayerStorageMap copy() {
            return new SkyDataLayerStorageMap((Long2ObjectOpenHashMap<DataLayer>)this.map.clone(), this.topSections.clone(), this.currentLowestY);
        }
    }
}
