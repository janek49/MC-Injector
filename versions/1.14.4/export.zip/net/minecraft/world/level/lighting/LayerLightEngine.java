package net.minecraft.world.level.lighting;

import net.minecraft.core.*;
import net.minecraft.world.level.*;
import javax.annotation.*;
import java.util.*;
import java.util.concurrent.atomic.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraft.world.level.chunk.*;

public abstract class LayerLightEngine<M extends DataLayerStorageMap<M>, S extends LayerLightSectionStorage<M>> extends DynamicGraphMinFixedPoint implements LayerLightEventListener
{
    private static final Direction[] DIRECTIONS;
    protected final LightChunkGetter chunkSource;
    protected final LightLayer layer;
    protected final S storage;
    private boolean runningLightUpdates;
    protected final BlockPos.MutableBlockPos pos;
    private final long[] lastChunkPos;
    private final BlockGetter[] lastChunk;
    
    public LayerLightEngine(final LightChunkGetter chunkSource, final LightLayer layer, final S storage) {
        super(16, 256, 8192);
        this.pos = new BlockPos.MutableBlockPos();
        this.lastChunkPos = new long[2];
        this.lastChunk = new BlockGetter[2];
        this.chunkSource = chunkSource;
        this.layer = layer;
        this.storage = storage;
        this.clearCache();
    }
    
    @Override
    protected void checkNode(final long l) {
        this.storage.runAllUpdates();
        if (this.storage.storingLightForSection(SectionPos.blockToSection(l))) {
            super.checkNode(l);
        }
    }
    
    @Nullable
    private BlockGetter getChunk(final int var1, final int var2) {
        final long var3 = ChunkPos.asLong(var1, var2);
        for (int var4 = 0; var4 < 2; ++var4) {
            if (var3 == this.lastChunkPos[var4]) {
                return this.lastChunk[var4];
            }
        }
        final BlockGetter var5 = this.chunkSource.getChunkForLighting(var1, var2);
        for (int var6 = 1; var6 > 0; --var6) {
            this.lastChunkPos[var6] = this.lastChunkPos[var6 - 1];
            this.lastChunk[var6] = this.lastChunk[var6 - 1];
        }
        this.lastChunkPos[0] = var3;
        return this.lastChunk[0] = var5;
    }
    
    private void clearCache() {
        Arrays.fill(this.lastChunkPos, ChunkPos.INVALID_CHUNK_POS);
        Arrays.fill(this.lastChunk, null);
    }
    
    protected BlockState getStateAndOpacity(final long var1, @Nullable final AtomicInteger atomicInteger) {
        if (var1 == Long.MAX_VALUE) {
            if (atomicInteger != null) {
                atomicInteger.set(0);
            }
            return Blocks.AIR.defaultBlockState();
        }
        final int var2 = SectionPos.blockToSectionCoord(BlockPos.getX(var1));
        final int var3 = SectionPos.blockToSectionCoord(BlockPos.getZ(var1));
        final BlockGetter var4 = this.getChunk(var2, var3);
        if (var4 == null) {
            if (atomicInteger != null) {
                atomicInteger.set(16);
            }
            return Blocks.BEDROCK.defaultBlockState();
        }
        this.pos.set(var1);
        final BlockState var5 = var4.getBlockState(this.pos);
        final boolean var6 = var5.canOcclude() && var5.useShapeForLightOcclusion();
        if (atomicInteger != null) {
            atomicInteger.set(var5.getLightBlock(this.chunkSource.getLevel(), this.pos));
        }
        return var6 ? var5 : Blocks.AIR.defaultBlockState();
    }
    
    protected VoxelShape getShape(final BlockState blockState, final long var2, final Direction direction) {
        return blockState.canOcclude() ? blockState.getFaceOcclusionShape(this.chunkSource.getLevel(), this.pos.set(var2), direction) : Shapes.empty();
    }
    
    public static int getLightBlockInto(final BlockGetter blockGetter, final BlockState var1, final BlockPos var2, final BlockState var3, final BlockPos var4, final Direction direction, final int var6) {
        final boolean var7 = var1.canOcclude() && var1.useShapeForLightOcclusion();
        final boolean var8 = var3.canOcclude() && var3.useShapeForLightOcclusion();
        if (!var7 && !var8) {
            return var6;
        }
        final VoxelShape var9 = var7 ? var1.getOcclusionShape(blockGetter, var2) : Shapes.empty();
        final VoxelShape var10 = var8 ? var3.getOcclusionShape(blockGetter, var4) : Shapes.empty();
        if (Shapes.mergedFaceOccludes(var9, var10, direction)) {
            return 16;
        }
        return var6;
    }
    
    @Override
    protected boolean isSource(final long l) {
        return l == Long.MAX_VALUE;
    }
    
    @Override
    protected int getComputedLevel(final long var1, final long var3, final int var5) {
        return 0;
    }
    
    @Override
    protected int getLevel(final long l) {
        if (l == Long.MAX_VALUE) {
            return 0;
        }
        return 15 - this.storage.getStoredLevel(l);
    }
    
    protected int getLevel(final DataLayer dataLayer, final long var2) {
        return 15 - dataLayer.get(SectionPos.sectionRelative(BlockPos.getX(var2)), SectionPos.sectionRelative(BlockPos.getY(var2)), SectionPos.sectionRelative(BlockPos.getZ(var2)));
    }
    
    @Override
    protected void setLevel(final long var1, final int var3) {
        this.storage.setStoredLevel(var1, Math.min(15, 15 - var3));
    }
    
    @Override
    protected int computeLevelFromNeighbor(final long var1, final long var3, final int var5) {
        return 0;
    }
    
    public boolean hasLightWork() {
        return this.hasWork() || this.storage.hasWork() || this.storage.hasInconsistencies();
    }
    
    public int runUpdates(int var1, final boolean var2, final boolean var3) {
        if (!this.runningLightUpdates) {
            if (this.storage.hasWork()) {
                var1 = this.storage.runUpdates(var1);
                if (var1 == 0) {
                    return var1;
                }
            }
            this.storage.markNewInconsistencies(this, var2, var3);
        }
        this.runningLightUpdates = true;
        if (this.hasWork()) {
            var1 = this.runUpdates(var1);
            this.clearCache();
            if (var1 == 0) {
                return var1;
            }
        }
        this.runningLightUpdates = false;
        this.storage.swapSectionMap();
        return var1;
    }
    
    protected void queueSectionData(final long var1, @Nullable final DataLayer dataLayer) {
        this.storage.queueSectionData(var1, dataLayer);
    }
    
    @Nullable
    @Override
    public DataLayer getDataLayerData(final SectionPos sectionPos) {
        return this.storage.getDataLayerData(sectionPos.asLong());
    }
    
    @Override
    public int getLightValue(final BlockPos blockPos) {
        return this.storage.getLightValue(blockPos.asLong());
    }
    
    public String getDebugData(final long l) {
        return "" + this.storage.getLevel(l);
    }
    
    public void checkBlock(final BlockPos blockPos) {
        final long var2 = blockPos.asLong();
        this.checkNode(var2);
        for (final Direction var3 : LayerLightEngine.DIRECTIONS) {
            this.checkNode(BlockPos.offset(var2, var3));
        }
    }
    
    public void onBlockEmissionIncrease(final BlockPos blockPos, final int var2) {
    }
    
    @Override
    public void updateSectionStatus(final SectionPos sectionPos, final boolean var2) {
        this.storage.updateSectionStatus(sectionPos.asLong(), var2);
    }
    
    public void enableLightSources(final ChunkPos chunkPos, final boolean var2) {
        final long var3 = SectionPos.getZeroNode(SectionPos.asLong(chunkPos.x, 0, chunkPos.z));
        this.storage.runAllUpdates();
        this.storage.enableLightSources(var3, var2);
    }
    
    public void retainData(final ChunkPos chunkPos, final boolean var2) {
        final long var3 = SectionPos.getZeroNode(SectionPos.asLong(chunkPos.x, 0, chunkPos.z));
        this.storage.retainData(var3, var2);
    }
    
    static {
        DIRECTIONS = Direction.values();
    }
}
