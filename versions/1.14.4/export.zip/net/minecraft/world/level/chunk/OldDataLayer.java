package net.minecraft.world.level.chunk;

public class OldDataLayer
{
    public final byte[] data;
    private final int depthBits;
    private final int depthBitsPlusFour;
    
    public OldDataLayer(final byte[] data, final int depthBits) {
        this.data = data;
        this.depthBits = depthBits;
        this.depthBitsPlusFour = depthBits + 4;
    }
    
    public int get(final int var1, final int var2, final int var3) {
        final int var4 = var1 << this.depthBitsPlusFour | var3 << this.depthBits | var2;
        final int var5 = var4 >> 1;
        final int var6 = var4 & 0x1;
        if (var6 == 0) {
            return this.data[var5] & 0xF;
        }
        return this.data[var5] >> 4 & 0xF;
    }
}
