package net.minecraft.world.level.chunk;

import net.minecraft.core.*;
import net.minecraft.world.level.block.state.*;
import javax.annotation.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.lighting.*;
import net.minecraft.world.level.levelgen.structure.*;
import net.minecraft.world.level.biome.*;
import org.apache.logging.log4j.*;
import net.minecraft.nbt.*;
import java.util.stream.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.material.*;
import net.minecraft.world.level.levelgen.*;
import java.util.*;
import it.unimi.dsi.fastutil.shorts.*;

public interface ChunkAccess extends FeatureAccess
{
    @Nullable
    BlockState setBlockState(final BlockPos p0, final BlockState p1, final boolean p2);
    
    void setBlockEntity(final BlockPos p0, final BlockEntity p1);
    
    void addEntity(final Entity p0);
    
    @Nullable
    default LevelChunkSection getHighestSection() {
        final LevelChunkSection[] vars1 = this.getSections();
        for (int var2 = vars1.length - 1; var2 >= 0; --var2) {
            final LevelChunkSection var3 = vars1[var2];
            if (!LevelChunkSection.isEmpty(var3)) {
                return var3;
            }
        }
        return null;
    }
    
    default int getHighestSectionPosition() {
        final LevelChunkSection var1 = this.getHighestSection();
        return (var1 == null) ? 0 : var1.bottomBlockY();
    }
    
    Set<BlockPos> getBlockEntitiesPos();
    
    LevelChunkSection[] getSections();
    
    @Nullable
    LevelLightEngine getLightEngine();
    
    default int getRawBrightness(final BlockPos blockPos, final int var2, final boolean var3) {
        final LevelLightEngine var4 = this.getLightEngine();
        if (var4 == null || !this.getStatus().isOrAfter(ChunkStatus.LIGHT)) {
            return 0;
        }
        final int var5 = var3 ? (var4.getLayerListener(LightLayer.SKY).getLightValue(blockPos) - var2) : 0;
        final int var6 = var4.getLayerListener(LightLayer.BLOCK).getLightValue(blockPos);
        return Math.max(var6, var5);
    }
    
    Collection<Map.Entry<Heightmap.Types, Heightmap>> getHeightmaps();
    
    void setHeightmap(final Heightmap.Types p0, final long[] p1);
    
    Heightmap getOrCreateHeightmapUnprimed(final Heightmap.Types p0);
    
    int getHeight(final Heightmap.Types p0, final int p1, final int p2);
    
    ChunkPos getPos();
    
    void setLastSaveTime(final long p0);
    
    Map<String, StructureStart> getAllStarts();
    
    void setAllStarts(final Map<String, StructureStart> p0);
    
    default Biome getBiome(final BlockPos blockPos) {
        final int var2 = blockPos.getX() & 0xF;
        final int var3 = blockPos.getZ() & 0xF;
        return this.getBiomes()[var3 << 4 | var2];
    }
    
    default boolean isYSpaceEmpty(int var1, int var2) {
        if (var1 < 0) {
            var1 = 0;
        }
        if (var2 >= 256) {
            var2 = 255;
        }
        for (int var3 = var1; var3 <= var2; var3 += 16) {
            if (!LevelChunkSection.isEmpty(this.getSections()[var3 >> 4])) {
                return false;
            }
        }
        return true;
    }
    
    Biome[] getBiomes();
    
    void setUnsaved(final boolean p0);
    
    boolean isUnsaved();
    
    ChunkStatus getStatus();
    
    void removeBlockEntity(final BlockPos p0);
    
    void setLightEngine(final LevelLightEngine p0);
    
    default void markPosForPostprocessing(final BlockPos blockPos) {
        LogManager.getLogger().warn("Trying to mark a block for PostProcessing @ {}, but this operation is not supported.", (Object)blockPos);
    }
    
    ShortList[] getPostProcessing();
    
    default void addPackedPostProcess(final short var1, final int var2) {
        getOrCreateOffsetList(this.getPostProcessing(), var2).add(var1);
    }
    
    default void setBlockEntityNbt(final CompoundTag blockEntityNbt) {
        LogManager.getLogger().warn("Trying to set a BlockEntity, but this operation is not supported.");
    }
    
    @Nullable
    CompoundTag getBlockEntityNbt(final BlockPos p0);
    
    @Nullable
    CompoundTag getBlockEntityNbtForSaving(final BlockPos p0);
    
    default void setBiomes(final Biome[] biomes) {
        throw new UnsupportedOperationException();
    }
    
    Stream<BlockPos> getLights();
    
    TickList<Block> getBlockTicks();
    
    TickList<Fluid> getLiquidTicks();
    
    default BitSet getCarvingMask(final GenerationStep.Carving generationStep$Carving) {
        throw new RuntimeException("Meaningless in this context");
    }
    
    UpgradeData getUpgradeData();
    
    void setInhabitedTime(final long p0);
    
    long getInhabitedTime();
    
    default ShortList getOrCreateOffsetList(final ShortList[] shortLists, final int var1) {
        if (shortLists[var1] == null) {
            shortLists[var1] = (ShortList)new ShortArrayList();
        }
        return shortLists[var1];
    }
    
    boolean isLightCorrect();
    
    void setLightCorrect(final boolean p0);
}
