package net.minecraft.world.level.chunk;

import net.minecraft.world.level.biome.*;
import net.minecraft.nbt.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.levelgen.structure.*;
import javax.annotation.*;
import net.minecraft.world.entity.*;
import com.google.common.collect.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.*;
import net.minecraft.world.level.material.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.lighting.*;
import net.minecraft.util.*;
import net.minecraft.world.phys.*;
import java.util.function.*;
import net.minecraft.world.entity.boss.enderdragon.*;
import net.minecraft.world.entity.boss.*;
import net.minecraft.network.*;
import net.minecraft.core.*;
import java.util.*;
import java.util.stream.*;
import it.unimi.dsi.fastutil.longs.*;
import it.unimi.dsi.fastutil.shorts.*;
import net.minecraft.world.level.*;
import net.minecraft.server.level.*;
import org.apache.logging.log4j.*;

public class LevelChunk implements ChunkAccess
{
    private static final Logger LOGGER;
    public static final LevelChunkSection EMPTY_SECTION;
    private final LevelChunkSection[] sections;
    private final Biome[] biomes;
    private final Map<BlockPos, CompoundTag> pendingBlockEntities;
    private boolean loaded;
    private final Level level;
    private final Map<Heightmap.Types, Heightmap> heightmaps;
    private final UpgradeData upgradeData;
    private final Map<BlockPos, BlockEntity> blockEntities;
    private final ClassInstanceMultiMap<Entity>[] entitySections;
    private final Map<String, StructureStart> structureStarts;
    private final Map<String, LongSet> structuresRefences;
    private final ShortList[] postProcessing;
    private TickList<Block> blockTicks;
    private TickList<Fluid> liquidTicks;
    private boolean lastSaveHadEntities;
    private long lastSaveTime;
    private volatile boolean unsaved;
    private long inhabitedTime;
    @Nullable
    private Supplier<ChunkHolder.FullChunkStatus> fullStatus;
    @Nullable
    private Consumer<LevelChunk> postLoad;
    private final ChunkPos chunkPos;
    private volatile boolean isLightCorrect;
    
    public LevelChunk(final Level level, final ChunkPos chunkPos, final Biome[] biomes) {
        this(level, chunkPos, biomes, UpgradeData.EMPTY, (TickList<Block>)EmptyTickList.empty(), (TickList<Fluid>)EmptyTickList.empty(), 0L, null, null);
    }
    
    public LevelChunk(final Level level, final ChunkPos chunkPos, final Biome[] biomes, final UpgradeData upgradeData, final TickList<Block> blockTicks, final TickList<Fluid> liquidTicks, final long inhabitedTime, @Nullable final LevelChunkSection[] levelChunkSections, @Nullable final Consumer<LevelChunk> postLoad) {
        this.sections = new LevelChunkSection[16];
        this.pendingBlockEntities = (Map<BlockPos, CompoundTag>)Maps.newHashMap();
        this.heightmaps = (Map<Heightmap.Types, Heightmap>)Maps.newEnumMap((Class)Heightmap.Types.class);
        this.blockEntities = (Map<BlockPos, BlockEntity>)Maps.newHashMap();
        this.structureStarts = (Map<String, StructureStart>)Maps.newHashMap();
        this.structuresRefences = (Map<String, LongSet>)Maps.newHashMap();
        this.postProcessing = new ShortList[16];
        this.entitySections = (ClassInstanceMultiMap<Entity>[])new ClassInstanceMultiMap[16];
        this.level = level;
        this.chunkPos = chunkPos;
        this.upgradeData = upgradeData;
        for (final Heightmap.Types var14 : Heightmap.Types.values()) {
            if (ChunkStatus.FULL.heightmapsAfter().contains(var14)) {
                this.heightmaps.put(var14, new Heightmap(this, var14));
            }
        }
        for (int var15 = 0; var15 < this.entitySections.length; ++var15) {
            this.entitySections[var15] = new ClassInstanceMultiMap<Entity>(Entity.class);
        }
        this.biomes = biomes;
        this.blockTicks = blockTicks;
        this.liquidTicks = liquidTicks;
        this.inhabitedTime = inhabitedTime;
        this.postLoad = postLoad;
        if (levelChunkSections != null) {
            if (this.sections.length == levelChunkSections.length) {
                System.arraycopy(levelChunkSections, 0, this.sections, 0, this.sections.length);
            }
            else {
                LevelChunk.LOGGER.warn("Could not set level chunk sections, array length is {} instead of {}", (Object)levelChunkSections.length, (Object)this.sections.length);
            }
        }
    }
    
    public LevelChunk(final Level level, final ProtoChunk protoChunk) {
        this(level, protoChunk.getPos(), protoChunk.getBiomes(), protoChunk.getUpgradeData(), protoChunk.getBlockTicks(), protoChunk.getLiquidTicks(), protoChunk.getInhabitedTime(), protoChunk.getSections(), null);
        for (final CompoundTag var4 : protoChunk.getEntities()) {
            EntityType.loadEntityRecursive(var4, level, entity -> {
                this.addEntity(entity);
                return entity;
            });
        }
        for (final BlockEntity var5 : protoChunk.getBlockEntities().values()) {
            this.addBlockEntity(var5);
        }
        this.pendingBlockEntities.putAll(protoChunk.getBlockEntityNbts());
        for (int var6 = 0; var6 < protoChunk.getPostProcessing().length; ++var6) {
            this.postProcessing[var6] = protoChunk.getPostProcessing()[var6];
        }
        this.setAllStarts(protoChunk.getAllStarts());
        this.setAllReferences(protoChunk.getAllReferences());
        for (final Map.Entry<Heightmap.Types, Heightmap> var7 : protoChunk.getHeightmaps()) {
            if (ChunkStatus.FULL.heightmapsAfter().contains(var7.getKey())) {
                this.getOrCreateHeightmapUnprimed(var7.getKey()).setRawData(var7.getValue().getRawData());
            }
        }
        this.setLightCorrect(protoChunk.isLightCorrect());
        this.unsaved = true;
    }
    
    @Override
    public Heightmap getOrCreateHeightmapUnprimed(final Heightmap.Types heightmap$Types) {
        return this.heightmaps.computeIfAbsent(heightmap$Types, heightmap$Types -> new Heightmap(this, heightmap$Types));
    }
    
    @Override
    public Set<BlockPos> getBlockEntitiesPos() {
        final Set<BlockPos> set = (Set<BlockPos>)Sets.newHashSet((Iterable)this.pendingBlockEntities.keySet());
        set.addAll(this.blockEntities.keySet());
        return set;
    }
    
    @Override
    public LevelChunkSection[] getSections() {
        return this.sections;
    }
    
    @Override
    public BlockState getBlockState(final BlockPos blockPos) {
        final int var2 = blockPos.getX();
        final int var3 = blockPos.getY();
        final int var4 = blockPos.getZ();
        if (this.level.getGeneratorType() == LevelType.DEBUG_ALL_BLOCK_STATES) {
            BlockState var5 = null;
            if (var3 == 60) {
                var5 = Blocks.BARRIER.defaultBlockState();
            }
            if (var3 == 70) {
                var5 = DebugLevelSource.getBlockStateFor(var2, var4);
            }
            return (var5 == null) ? Blocks.AIR.defaultBlockState() : var5;
        }
        try {
            if (var3 >= 0 && var3 >> 4 < this.sections.length) {
                final LevelChunkSection var6 = this.sections[var3 >> 4];
                if (!LevelChunkSection.isEmpty(var6)) {
                    return var6.getBlockState(var2 & 0xF, var3 & 0xF, var4 & 0xF);
                }
            }
            return Blocks.AIR.defaultBlockState();
        }
        catch (Throwable var8) {
            final CrashReport var7 = CrashReport.forThrowable(var8, "Getting block state");
            final CrashReportCategory var9 = var7.addCategory("Block being got");
            var9.setDetail("Location", () -> CrashReportCategory.formatLocation(var2, var3, var4));
            throw new ReportedException(var7);
        }
    }
    
    @Override
    public FluidState getFluidState(final BlockPos blockPos) {
        return this.getFluidState(blockPos.getX(), blockPos.getY(), blockPos.getZ());
    }
    
    public FluidState getFluidState(final int var1, final int var2, final int var3) {
        try {
            if (var2 >= 0 && var2 >> 4 < this.sections.length) {
                final LevelChunkSection var4 = this.sections[var2 >> 4];
                if (!LevelChunkSection.isEmpty(var4)) {
                    return var4.getFluidState(var1 & 0xF, var2 & 0xF, var3 & 0xF);
                }
            }
            return Fluids.EMPTY.defaultFluidState();
        }
        catch (Throwable var6) {
            final CrashReport var5 = CrashReport.forThrowable(var6, "Getting fluid state");
            final CrashReportCategory var7 = var5.addCategory("Block being got");
            var7.setDetail("Location", () -> CrashReportCategory.formatLocation(var1, var2, var3));
            throw new ReportedException(var5);
        }
    }
    
    @Nullable
    @Override
    public BlockState setBlockState(final BlockPos blockPos, final BlockState var2, final boolean var3) {
        final int var4 = blockPos.getX() & 0xF;
        final int var5 = blockPos.getY();
        final int var6 = blockPos.getZ() & 0xF;
        LevelChunkSection var7 = this.sections[var5 >> 4];
        if (var7 == LevelChunk.EMPTY_SECTION) {
            if (var2.isAir()) {
                return null;
            }
            var7 = new LevelChunkSection(var5 >> 4 << 4);
            this.sections[var5 >> 4] = var7;
        }
        final boolean var8 = var7.isEmpty();
        final BlockState var9 = var7.setBlockState(var4, var5 & 0xF, var6, var2);
        if (var9 == var2) {
            return null;
        }
        final Block var10 = var2.getBlock();
        final Block var11 = var9.getBlock();
        this.heightmaps.get(Heightmap.Types.MOTION_BLOCKING).update(var4, var5, var6, var2);
        this.heightmaps.get(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES).update(var4, var5, var6, var2);
        this.heightmaps.get(Heightmap.Types.OCEAN_FLOOR).update(var4, var5, var6, var2);
        this.heightmaps.get(Heightmap.Types.WORLD_SURFACE).update(var4, var5, var6, var2);
        final boolean var12 = var7.isEmpty();
        if (var8 != var12) {
            this.level.getChunkSource().getLightEngine().updateSectionStatus(blockPos, var12);
        }
        if (!this.level.isClientSide) {
            var9.onRemove(this.level, blockPos, var2, var3);
        }
        else if (var11 != var10 && var11 instanceof EntityBlock) {
            this.level.removeBlockEntity(blockPos);
        }
        if (var7.getBlockState(var4, var5 & 0xF, var6).getBlock() != var10) {
            return null;
        }
        if (var11 instanceof EntityBlock) {
            final BlockEntity var13 = this.getBlockEntity(blockPos, EntityCreationType.CHECK);
            if (var13 != null) {
                var13.clearCache();
            }
        }
        if (!this.level.isClientSide) {
            var2.onPlace(this.level, blockPos, var9, var3);
        }
        if (var10 instanceof EntityBlock) {
            BlockEntity var13 = this.getBlockEntity(blockPos, EntityCreationType.CHECK);
            if (var13 == null) {
                var13 = ((EntityBlock)var10).newBlockEntity(this.level);
                this.level.setBlockEntity(blockPos, var13);
            }
            else {
                var13.clearCache();
            }
        }
        this.unsaved = true;
        return var9;
    }
    
    @Nullable
    @Override
    public LevelLightEngine getLightEngine() {
        return this.level.getChunkSource().getLightEngine();
    }
    
    public int getRawBrightness(final BlockPos blockPos, final int var2) {
        return this.getRawBrightness(blockPos, var2, this.level.getDimension().isHasSkyLight());
    }
    
    @Override
    public void addEntity(final Entity entity) {
        this.lastSaveHadEntities = true;
        final int var2 = Mth.floor(entity.x / 16.0);
        final int var3 = Mth.floor(entity.z / 16.0);
        if (var2 != this.chunkPos.x || var3 != this.chunkPos.z) {
            LevelChunk.LOGGER.warn("Wrong location! ({}, {}) should be ({}, {}), {}", (Object)var2, (Object)var3, (Object)this.chunkPos.x, (Object)this.chunkPos.z, (Object)entity);
            entity.removed = true;
        }
        int var4 = Mth.floor(entity.y / 16.0);
        if (var4 < 0) {
            var4 = 0;
        }
        if (var4 >= this.entitySections.length) {
            var4 = this.entitySections.length - 1;
        }
        entity.inChunk = true;
        entity.xChunk = this.chunkPos.x;
        entity.yChunk = var4;
        entity.zChunk = this.chunkPos.z;
        this.entitySections[var4].add(entity);
    }
    
    @Override
    public void setHeightmap(final Heightmap.Types heightmap$Types, final long[] longs) {
        this.heightmaps.get(heightmap$Types).setRawData(longs);
    }
    
    public void removeEntity(final Entity entity) {
        this.removeEntity(entity, entity.yChunk);
    }
    
    public void removeEntity(final Entity entity, int var2) {
        if (var2 < 0) {
            var2 = 0;
        }
        if (var2 >= this.entitySections.length) {
            var2 = this.entitySections.length - 1;
        }
        this.entitySections[var2].remove(entity);
    }
    
    @Override
    public int getHeight(final Heightmap.Types heightmap$Types, final int var2, final int var3) {
        return this.heightmaps.get(heightmap$Types).getFirstAvailable(var2 & 0xF, var3 & 0xF) - 1;
    }
    
    @Nullable
    private BlockEntity createBlockEntity(final BlockPos blockPos) {
        final BlockState var2 = this.getBlockState(blockPos);
        final Block var3 = var2.getBlock();
        if (!var3.isEntityBlock()) {
            return null;
        }
        return ((EntityBlock)var3).newBlockEntity(this.level);
    }
    
    @Nullable
    @Override
    public BlockEntity getBlockEntity(final BlockPos blockPos) {
        return this.getBlockEntity(blockPos, EntityCreationType.CHECK);
    }
    
    @Nullable
    public BlockEntity getBlockEntity(final BlockPos blockPos, final EntityCreationType levelChunk$EntityCreationType) {
        BlockEntity blockEntity = this.blockEntities.get(blockPos);
        if (blockEntity == null) {
            final CompoundTag var4 = this.pendingBlockEntities.remove(blockPos);
            if (var4 != null) {
                final BlockEntity var5 = this.promotePendingBlockEntity(blockPos, var4);
                if (var5 != null) {
                    return var5;
                }
            }
        }
        if (blockEntity == null) {
            if (levelChunk$EntityCreationType == EntityCreationType.IMMEDIATE) {
                blockEntity = this.createBlockEntity(blockPos);
                this.level.setBlockEntity(blockPos, blockEntity);
            }
        }
        else if (blockEntity.isRemoved()) {
            this.blockEntities.remove(blockPos);
            return null;
        }
        return blockEntity;
    }
    
    public void addBlockEntity(final BlockEntity blockEntity) {
        this.setBlockEntity(blockEntity.getBlockPos(), blockEntity);
        if (this.loaded || this.level.isClientSide()) {
            this.level.setBlockEntity(blockEntity.getBlockPos(), blockEntity);
        }
    }
    
    @Override
    public void setBlockEntity(final BlockPos blockPos, final BlockEntity blockEntity) {
        if (!(this.getBlockState(blockPos).getBlock() instanceof EntityBlock)) {
            return;
        }
        blockEntity.setLevel(this.level);
        blockEntity.setPosition(blockPos);
        blockEntity.clearRemoved();
        final BlockEntity blockEntity2 = this.blockEntities.put(blockPos.immutable(), blockEntity);
        if (blockEntity2 != null && blockEntity2 != blockEntity) {
            blockEntity2.setRemoved();
        }
    }
    
    @Override
    public void setBlockEntityNbt(final CompoundTag blockEntityNbt) {
        this.pendingBlockEntities.put(new BlockPos(blockEntityNbt.getInt("x"), blockEntityNbt.getInt("y"), blockEntityNbt.getInt("z")), blockEntityNbt);
    }
    
    @Nullable
    @Override
    public CompoundTag getBlockEntityNbtForSaving(final BlockPos blockPos) {
        final BlockEntity var2 = this.getBlockEntity(blockPos);
        if (var2 != null && !var2.isRemoved()) {
            final CompoundTag var3 = var2.save(new CompoundTag());
            var3.putBoolean("keepPacked", false);
            return var3;
        }
        CompoundTag var3 = this.pendingBlockEntities.get(blockPos);
        if (var3 != null) {
            var3 = var3.copy();
            var3.putBoolean("keepPacked", true);
        }
        return var3;
    }
    
    @Override
    public void removeBlockEntity(final BlockPos blockPos) {
        if (this.loaded || this.level.isClientSide()) {
            final BlockEntity var2 = this.blockEntities.remove(blockPos);
            if (var2 != null) {
                var2.setRemoved();
            }
        }
    }
    
    public void runPostLoad() {
        if (this.postLoad != null) {
            this.postLoad.accept(this);
            this.postLoad = null;
        }
    }
    
    public void markUnsaved() {
        this.unsaved = true;
    }
    
    public void getEntities(@Nullable final Entity entity, final AABB aABB, final List<Entity> list, @Nullable final Predicate<? super Entity> predicate) {
        int var5 = Mth.floor((aABB.minY - 2.0) / 16.0);
        int var6 = Mth.floor((aABB.maxY + 2.0) / 16.0);
        var5 = Mth.clamp(var5, 0, this.entitySections.length - 1);
        var6 = Mth.clamp(var6, 0, this.entitySections.length - 1);
        for (int var7 = var5; var7 <= var6; ++var7) {
            if (!this.entitySections[var7].isEmpty()) {
                for (final Entity var8 : this.entitySections[var7]) {
                    if (var8.getBoundingBox().intersects(aABB) && var8 != entity) {
                        if (predicate == null || predicate.test(var8)) {
                            list.add(var8);
                        }
                        if (!(var8 instanceof EnderDragon)) {
                            continue;
                        }
                        for (final EnderDragonPart var9 : ((EnderDragon)var8).getSubEntities()) {
                            if (var9 != entity && var9.getBoundingBox().intersects(aABB) && (predicate == null || predicate.test(var9))) {
                                list.add(var9);
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void getEntities(@Nullable final EntityType<?> entityType, final AABB aABB, final List<Entity> list, final Predicate<? super Entity> predicate) {
        int var5 = Mth.floor((aABB.minY - 2.0) / 16.0);
        int var6 = Mth.floor((aABB.maxY + 2.0) / 16.0);
        var5 = Mth.clamp(var5, 0, this.entitySections.length - 1);
        var6 = Mth.clamp(var6, 0, this.entitySections.length - 1);
        for (int var7 = var5; var7 <= var6; ++var7) {
            for (final Entity var8 : this.entitySections[var7].find(Entity.class)) {
                if (entityType != null && var8.getType() != entityType) {
                    continue;
                }
                if (!var8.getBoundingBox().intersects(aABB) || !predicate.test(var8)) {
                    continue;
                }
                list.add(var8);
            }
        }
    }
    
    public <T extends Entity> void getEntitiesOfClass(final Class<? extends T> class, final AABB aABB, final List<T> list, @Nullable final Predicate<? super T> predicate) {
        int var5 = Mth.floor((aABB.minY - 2.0) / 16.0);
        int var6 = Mth.floor((aABB.maxY + 2.0) / 16.0);
        var5 = Mth.clamp(var5, 0, this.entitySections.length - 1);
        var6 = Mth.clamp(var6, 0, this.entitySections.length - 1);
        for (int var7 = var5; var7 <= var6; ++var7) {
            for (final T var8 : this.entitySections[var7].find(class)) {
                if (var8.getBoundingBox().intersects(aABB) && (predicate == null || predicate.test((Object)var8))) {
                    list.add(var8);
                }
            }
        }
    }
    
    public boolean isEmpty() {
        return false;
    }
    
    @Override
    public ChunkPos getPos() {
        return this.chunkPos;
    }
    
    public void replaceWithPacketData(final FriendlyByteBuf friendlyByteBuf, final CompoundTag compoundTag, final int var3, final boolean var4) {
        final Predicate<BlockPos> var5 = var4 ? (blockPos -> true) : (blockPos -> (var3 & 1 << (blockPos.getY() >> 4)) != 0x0);
        Sets.newHashSet((Iterable)this.blockEntities.keySet()).stream().filter(var5).forEach(this.level::removeBlockEntity);
        for (int var6 = 0; var6 < this.sections.length; ++var6) {
            LevelChunkSection var7 = this.sections[var6];
            if ((var3 & 1 << var6) == 0x0) {
                if (var4 && var7 != LevelChunk.EMPTY_SECTION) {
                    this.sections[var6] = LevelChunk.EMPTY_SECTION;
                }
            }
            else {
                if (var7 == LevelChunk.EMPTY_SECTION) {
                    var7 = new LevelChunkSection(var6 << 4);
                    this.sections[var6] = var7;
                }
                var7.read(friendlyByteBuf);
            }
        }
        if (var4) {
            for (int var6 = 0; var6 < this.biomes.length; ++var6) {
                this.biomes[var6] = Registry.BIOME.byId(friendlyByteBuf.readInt());
            }
        }
        for (final Heightmap.Types var8 : Heightmap.Types.values()) {
            final String var9 = var8.getSerializationKey();
            if (compoundTag.contains(var9, 12)) {
                this.setHeightmap(var8, compoundTag.getLongArray(var9));
            }
        }
        for (final BlockEntity var10 : this.blockEntities.values()) {
            var10.clearCache();
        }
    }
    
    @Override
    public Biome[] getBiomes() {
        return this.biomes;
    }
    
    public void setLoaded(final boolean loaded) {
        this.loaded = loaded;
    }
    
    public Level getLevel() {
        return this.level;
    }
    
    @Override
    public Collection<Map.Entry<Heightmap.Types, Heightmap>> getHeightmaps() {
        return (Collection<Map.Entry<Heightmap.Types, Heightmap>>)Collections.unmodifiableSet((Set<?>)this.heightmaps.entrySet());
    }
    
    public Map<BlockPos, BlockEntity> getBlockEntities() {
        return this.blockEntities;
    }
    
    public ClassInstanceMultiMap<Entity>[] getEntitySections() {
        return this.entitySections;
    }
    
    @Override
    public CompoundTag getBlockEntityNbt(final BlockPos blockPos) {
        return this.pendingBlockEntities.get(blockPos);
    }
    
    @Override
    public Stream<BlockPos> getLights() {
        return StreamSupport.stream(BlockPos.betweenClosed(this.chunkPos.getMinBlockX(), 0, this.chunkPos.getMinBlockZ(), this.chunkPos.getMaxBlockX(), 255, this.chunkPos.getMaxBlockZ()).spliterator(), false).filter(blockPos -> this.getBlockState(blockPos).getLightEmission() != 0);
    }
    
    @Override
    public TickList<Block> getBlockTicks() {
        return this.blockTicks;
    }
    
    @Override
    public TickList<Fluid> getLiquidTicks() {
        return this.liquidTicks;
    }
    
    @Override
    public void setUnsaved(final boolean unsaved) {
        this.unsaved = unsaved;
    }
    
    @Override
    public boolean isUnsaved() {
        return this.unsaved || (this.lastSaveHadEntities && this.level.getGameTime() != this.lastSaveTime);
    }
    
    public void setLastSaveHadEntities(final boolean lastSaveHadEntities) {
        this.lastSaveHadEntities = lastSaveHadEntities;
    }
    
    @Override
    public void setLastSaveTime(final long lastSaveTime) {
        this.lastSaveTime = lastSaveTime;
    }
    
    @Nullable
    @Override
    public StructureStart getStartForFeature(final String string) {
        return this.structureStarts.get(string);
    }
    
    @Override
    public void setStartForFeature(final String string, final StructureStart structureStart) {
        this.structureStarts.put(string, structureStart);
    }
    
    @Override
    public Map<String, StructureStart> getAllStarts() {
        return this.structureStarts;
    }
    
    @Override
    public void setAllStarts(final Map<String, StructureStart> allStarts) {
        this.structureStarts.clear();
        this.structureStarts.putAll(allStarts);
    }
    
    @Override
    public LongSet getReferencesForFeature(final String string) {
        return this.structuresRefences.computeIfAbsent(string, string -> new LongOpenHashSet());
    }
    
    @Override
    public void addReferenceForFeature(final String string, final long var2) {
        this.structuresRefences.computeIfAbsent(string, string -> new LongOpenHashSet()).add(var2);
    }
    
    @Override
    public Map<String, LongSet> getAllReferences() {
        return this.structuresRefences;
    }
    
    @Override
    public void setAllReferences(final Map<String, LongSet> allReferences) {
        this.structuresRefences.clear();
        this.structuresRefences.putAll(allReferences);
    }
    
    @Override
    public long getInhabitedTime() {
        return this.inhabitedTime;
    }
    
    @Override
    public void setInhabitedTime(final long inhabitedTime) {
        this.inhabitedTime = inhabitedTime;
    }
    
    public void postProcessGeneration() {
        final ChunkPos var1 = this.getPos();
        for (int var2 = 0; var2 < this.postProcessing.length; ++var2) {
            if (this.postProcessing[var2] != null) {
                for (final Short var3 : this.postProcessing[var2]) {
                    final BlockPos var4 = ProtoChunk.unpackOffsetCoordinates(var3, var2, var1);
                    final BlockState var5 = this.getBlockState(var4);
                    final BlockState var6 = Block.updateFromNeighbourShapes(var5, this.level, var4);
                    this.level.setBlock(var4, var6, 20);
                }
                this.postProcessing[var2].clear();
            }
        }
        this.unpackTicks();
        for (final BlockPos var7 : Sets.newHashSet((Iterable)this.pendingBlockEntities.keySet())) {
            this.getBlockEntity(var7);
        }
        this.pendingBlockEntities.clear();
        this.upgradeData.upgrade(this);
    }
    
    @Nullable
    private BlockEntity promotePendingBlockEntity(final BlockPos blockPos, final CompoundTag compoundTag) {
        BlockEntity blockEntity;
        if ("DUMMY".equals(compoundTag.getString("id"))) {
            final Block var4 = this.getBlockState(blockPos).getBlock();
            if (var4 instanceof EntityBlock) {
                blockEntity = ((EntityBlock)var4).newBlockEntity(this.level);
            }
            else {
                blockEntity = null;
                LevelChunk.LOGGER.warn("Tried to load a DUMMY block entity @ {} but found not block entity block {} at location", (Object)blockPos, (Object)this.getBlockState(blockPos));
            }
        }
        else {
            blockEntity = BlockEntity.loadStatic(compoundTag);
        }
        if (blockEntity != null) {
            blockEntity.setPosition(blockPos);
            this.addBlockEntity(blockEntity);
        }
        else {
            LevelChunk.LOGGER.warn("Tried to load a block entity for block {} but failed at location {}", (Object)this.getBlockState(blockPos), (Object)blockPos);
        }
        return blockEntity;
    }
    
    @Override
    public UpgradeData getUpgradeData() {
        return this.upgradeData;
    }
    
    @Override
    public ShortList[] getPostProcessing() {
        return this.postProcessing;
    }
    
    public void unpackTicks() {
        if (this.blockTicks instanceof ProtoTickList) {
            ((ProtoTickList)this.blockTicks).copyOut(this.level.getBlockTicks(), blockPos -> this.getBlockState(blockPos).getBlock());
            this.blockTicks = (TickList<Block>)EmptyTickList.empty();
        }
        else if (this.blockTicks instanceof ChunkTickList) {
            this.level.getBlockTicks().addAll(((ChunkTickList)this.blockTicks).ticks());
            this.blockTicks = (TickList<Block>)EmptyTickList.empty();
        }
        if (this.liquidTicks instanceof ProtoTickList) {
            ((ProtoTickList)this.liquidTicks).copyOut(this.level.getLiquidTicks(), blockPos -> this.getFluidState(blockPos).getType());
            this.liquidTicks = (TickList<Fluid>)EmptyTickList.empty();
        }
        else if (this.liquidTicks instanceof ChunkTickList) {
            this.level.getLiquidTicks().addAll(((ChunkTickList)this.liquidTicks).ticks());
            this.liquidTicks = (TickList<Fluid>)EmptyTickList.empty();
        }
    }
    
    public void packTicks(final ServerLevel serverLevel) {
        if (this.blockTicks == EmptyTickList.empty()) {
            this.blockTicks = new ChunkTickList<Block>(Registry.BLOCK::getKey, serverLevel.getBlockTicks().fetchTicksInChunk(this.chunkPos, true, false));
            this.setUnsaved(true);
        }
        if (this.liquidTicks == EmptyTickList.empty()) {
            this.liquidTicks = new ChunkTickList<Fluid>(Registry.FLUID::getKey, serverLevel.getLiquidTicks().fetchTicksInChunk(this.chunkPos, true, false));
            this.setUnsaved(true);
        }
    }
    
    @Override
    public ChunkStatus getStatus() {
        return ChunkStatus.FULL;
    }
    
    public ChunkHolder.FullChunkStatus getFullStatus() {
        if (this.fullStatus == null) {
            return ChunkHolder.FullChunkStatus.BORDER;
        }
        return this.fullStatus.get();
    }
    
    public void setFullStatus(final Supplier<ChunkHolder.FullChunkStatus> fullStatus) {
        this.fullStatus = fullStatus;
    }
    
    @Override
    public void setLightEngine(final LevelLightEngine lightEngine) {
    }
    
    @Override
    public boolean isLightCorrect() {
        return this.isLightCorrect;
    }
    
    @Override
    public void setLightCorrect(final boolean lightCorrect) {
        this.isLightCorrect = lightCorrect;
        this.setUnsaved(true);
    }
    
    static {
        LOGGER = LogManager.getLogger();
        EMPTY_SECTION = null;
    }
    
    public enum EntityCreationType
    {
        IMMEDIATE("IMMEDIATE", 0), 
        QUEUED("QUEUED", 1), 
        CHECK("CHECK", 2);
        
        private EntityCreationType(final String s, final int n) {
        }
    }
}
