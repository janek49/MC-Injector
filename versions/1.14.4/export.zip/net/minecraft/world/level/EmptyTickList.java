package net.minecraft.world.level;

import net.minecraft.core.*;
import java.util.stream.*;

public class EmptyTickList<T> implements TickList<T>
{
    private static final EmptyTickList<Object> INSTANCE;
    
    public static <T> EmptyTickList<T> empty() {
        return (EmptyTickList<T>)EmptyTickList.INSTANCE;
    }
    
    @Override
    public boolean hasScheduledTick(final BlockPos blockPos, final T object) {
        return false;
    }
    
    @Override
    public void scheduleTick(final BlockPos blockPos, final T object, final int var3) {
    }
    
    @Override
    public void scheduleTick(final BlockPos blockPos, final T object, final int var3, final TickPriority tickPriority) {
    }
    
    @Override
    public boolean willTickThisTick(final BlockPos blockPos, final T object) {
        return false;
    }
    
    @Override
    public void addAll(final Stream<TickNextTickData<T>> stream) {
    }
    
    static {
        INSTANCE = new EmptyTickList<Object>();
    }
}
