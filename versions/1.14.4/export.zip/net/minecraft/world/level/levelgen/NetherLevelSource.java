package net.minecraft.world.level.levelgen;

import net.minecraft.world.level.*;
import net.minecraft.world.entity.*;
import net.minecraft.core.*;
import java.util.*;
import net.minecraft.world.level.biome.*;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.block.*;

public class NetherLevelSource extends NoiseBasedChunkGenerator<NetherGeneratorSettings>
{
    private final double[] yOffsets;
    
    public NetherLevelSource(final Level level, final BiomeSource biomeSource, final NetherGeneratorSettings netherGeneratorSettings) {
        super(level, biomeSource, 4, 8, 128, netherGeneratorSettings, false);
        this.yOffsets = this.makeYOffsets();
    }
    
    @Override
    protected void fillNoiseColumn(final double[] doubles, final int var2, final int var3) {
        final double var4 = 684.412;
        final double var5 = 2053.236;
        final double var6 = 8.555150000000001;
        final double var7 = 34.2206;
        final int var8 = -10;
        final int var9 = 3;
        this.fillNoiseColumn(doubles, var2, var3, 684.412, 2053.236, 8.555150000000001, 34.2206, 3, -10);
    }
    
    @Override
    protected double[] getDepthAndScale(final int var1, final int var2) {
        return new double[] { 0.0, 0.0 };
    }
    
    @Override
    protected double getYOffset(final double var1, final double var3, final int var5) {
        return this.yOffsets[var5];
    }
    
    private double[] makeYOffsets() {
        final double[] doubles = new double[this.getNoiseSizeY()];
        for (int var2 = 0; var2 < this.getNoiseSizeY(); ++var2) {
            doubles[var2] = Math.cos(var2 * 3.141592653589793 * 6.0 / this.getNoiseSizeY()) * 2.0;
            double var3 = var2;
            if (var2 > this.getNoiseSizeY() / 2) {
                var3 = this.getNoiseSizeY() - 1 - var2;
            }
            if (var3 < 4.0) {
                var3 = 4.0 - var3;
                final double[] array = doubles;
                final int n = var2;
                array[n] -= var3 * var3 * var3 * 10.0;
            }
        }
        return doubles;
    }
    
    @Override
    public List<Biome.SpawnerData> getMobsAt(final MobCategory mobCategory, final BlockPos blockPos) {
        if (mobCategory == MobCategory.MONSTER) {
            if (Feature.NETHER_BRIDGE.isInsideFeature(this.level, blockPos)) {
                return Feature.NETHER_BRIDGE.getSpecialEnemies();
            }
            if (Feature.NETHER_BRIDGE.isInsideBoundingFeature(this.level, blockPos) && this.level.getBlockState(blockPos.below()).getBlock() == Blocks.NETHER_BRICKS) {
                return Feature.NETHER_BRIDGE.getSpecialEnemies();
            }
        }
        return super.getMobsAt(mobCategory, blockPos);
    }
    
    @Override
    public int getSpawnHeight() {
        return this.level.getSeaLevel() + 1;
    }
    
    @Override
    public int getGenDepth() {
        return 128;
    }
    
    @Override
    public int getSeaLevel() {
        return 32;
    }
}
