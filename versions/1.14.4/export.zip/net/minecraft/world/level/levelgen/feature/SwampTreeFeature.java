package net.minecraft.world.level.levelgen.feature;

import java.util.function.*;
import com.mojang.datafixers.*;
import net.minecraft.core.*;
import java.util.*;
import net.minecraft.world.level.levelgen.structure.*;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.level.block.state.*;

public class SwampTreeFeature extends AbstractTreeFeature<NoneFeatureConfiguration>
{
    private static final BlockState TRUNK;
    private static final BlockState LEAF;
    
    public SwampTreeFeature(final Function<Dynamic<?>, ? extends NoneFeatureConfiguration> function) {
        super(function, false);
    }
    
    public boolean doPlace(final Set<BlockPos> set, final LevelSimulatedRW levelSimulatedRW, final Random random, BlockPos blockPos, final BoundingBox boundingBox) {
        final int var6 = random.nextInt(4) + 5;
        blockPos = levelSimulatedRW.getHeightmapPos(Heightmap.Types.OCEAN_FLOOR, blockPos);
        boolean var7 = true;
        if (blockPos.getY() < 1 || blockPos.getY() + var6 + 1 > 256) {
            return false;
        }
        for (int var8 = blockPos.getY(); var8 <= blockPos.getY() + 1 + var6; ++var8) {
            int var9 = 1;
            if (var8 == blockPos.getY()) {
                var9 = 0;
            }
            if (var8 >= blockPos.getY() + 1 + var6 - 2) {
                var9 = 3;
            }
            final BlockPos.MutableBlockPos var10 = new BlockPos.MutableBlockPos();
            for (int var11 = blockPos.getX() - var9; var11 <= blockPos.getX() + var9 && var7; ++var11) {
                for (int var12 = blockPos.getZ() - var9; var12 <= blockPos.getZ() + var9 && var7; ++var12) {
                    if (var8 >= 0 && var8 < 256) {
                        var10.set(var11, var8, var12);
                        if (!AbstractTreeFeature.isAirOrLeaves(levelSimulatedRW, var10)) {
                            if (AbstractTreeFeature.isBlockWater(levelSimulatedRW, var10)) {
                                if (var8 > blockPos.getY()) {
                                    var7 = false;
                                }
                            }
                            else {
                                var7 = false;
                            }
                        }
                    }
                    else {
                        var7 = false;
                    }
                }
            }
        }
        if (!var7) {
            return false;
        }
        if (!AbstractTreeFeature.isGrassOrDirt(levelSimulatedRW, blockPos.below()) || blockPos.getY() >= 256 - var6 - 1) {
            return false;
        }
        this.setDirtAt(levelSimulatedRW, blockPos.below());
        for (int var8 = blockPos.getY() - 3 + var6; var8 <= blockPos.getY() + var6; ++var8) {
            final int var9 = var8 - (blockPos.getY() + var6);
            for (int var13 = 2 - var9 / 2, var11 = blockPos.getX() - var13; var11 <= blockPos.getX() + var13; ++var11) {
                final int var12 = var11 - blockPos.getX();
                for (int var14 = blockPos.getZ() - var13; var14 <= blockPos.getZ() + var13; ++var14) {
                    final int var15 = var14 - blockPos.getZ();
                    if (Math.abs(var12) == var13 && Math.abs(var15) == var13) {
                        if (random.nextInt(2) == 0) {
                            continue;
                        }
                        if (var9 == 0) {
                            continue;
                        }
                    }
                    final BlockPos var16 = new BlockPos(var11, var8, var14);
                    if (AbstractTreeFeature.isAirOrLeaves(levelSimulatedRW, var16) || AbstractTreeFeature.isReplaceablePlant(levelSimulatedRW, var16)) {
                        this.setBlock(set, levelSimulatedRW, var16, SwampTreeFeature.LEAF, boundingBox);
                    }
                }
            }
        }
        for (int var8 = 0; var8 < var6; ++var8) {
            final BlockPos var17 = blockPos.above(var8);
            if (AbstractTreeFeature.isAirOrLeaves(levelSimulatedRW, var17) || AbstractTreeFeature.isBlockWater(levelSimulatedRW, var17)) {
                this.setBlock(set, levelSimulatedRW, var17, SwampTreeFeature.TRUNK, boundingBox);
            }
        }
        for (int var8 = blockPos.getY() - 3 + var6; var8 <= blockPos.getY() + var6; ++var8) {
            final int var9 = var8 - (blockPos.getY() + var6);
            final int var13 = 2 - var9 / 2;
            final BlockPos.MutableBlockPos var18 = new BlockPos.MutableBlockPos();
            for (int var12 = blockPos.getX() - var13; var12 <= blockPos.getX() + var13; ++var12) {
                for (int var14 = blockPos.getZ() - var13; var14 <= blockPos.getZ() + var13; ++var14) {
                    var18.set(var12, var8, var14);
                    if (AbstractTreeFeature.isLeaves(levelSimulatedRW, var18)) {
                        final BlockPos var19 = var18.west();
                        final BlockPos var16 = var18.east();
                        final BlockPos var20 = var18.north();
                        final BlockPos var21 = var18.south();
                        if (random.nextInt(4) == 0 && AbstractTreeFeature.isAir(levelSimulatedRW, var19)) {
                            this.addVine(levelSimulatedRW, var19, VineBlock.EAST);
                        }
                        if (random.nextInt(4) == 0 && AbstractTreeFeature.isAir(levelSimulatedRW, var16)) {
                            this.addVine(levelSimulatedRW, var16, VineBlock.WEST);
                        }
                        if (random.nextInt(4) == 0 && AbstractTreeFeature.isAir(levelSimulatedRW, var20)) {
                            this.addVine(levelSimulatedRW, var20, VineBlock.SOUTH);
                        }
                        if (random.nextInt(4) == 0 && AbstractTreeFeature.isAir(levelSimulatedRW, var21)) {
                            this.addVine(levelSimulatedRW, var21, VineBlock.NORTH);
                        }
                    }
                }
            }
        }
        return true;
    }
    
    private void addVine(final LevelSimulatedRW levelSimulatedRW, BlockPos blockPos, final BooleanProperty booleanProperty) {
        final BlockState var4 = ((AbstractStateHolder<O, BlockState>)Blocks.VINE.defaultBlockState()).setValue((Property<Comparable>)booleanProperty, true);
        this.setBlock(levelSimulatedRW, blockPos, var4);
        int var5;
        for (var5 = 4, blockPos = blockPos.below(); AbstractTreeFeature.isAir(levelSimulatedRW, blockPos) && var5 > 0; blockPos = blockPos.below(), --var5) {
            this.setBlock(levelSimulatedRW, blockPos, var4);
        }
    }
    
    static {
        TRUNK = Blocks.OAK_LOG.defaultBlockState();
        LEAF = Blocks.OAK_LEAVES.defaultBlockState();
    }
}
