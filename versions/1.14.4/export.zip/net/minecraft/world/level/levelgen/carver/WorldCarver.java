package net.minecraft.world.level.levelgen.carver;

import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.block.state.*;
import java.util.function.*;
import com.mojang.datafixers.*;
import net.minecraft.world.level.block.*;
import com.google.common.collect.*;
import net.minecraft.world.level.material.*;
import net.minecraft.world.level.chunk.*;
import java.util.*;
import net.minecraft.util.*;
import java.util.concurrent.atomic.*;
import net.minecraft.core.*;
import net.minecraft.tags.*;

public abstract class WorldCarver<C extends CarverConfiguration>
{
    public static final WorldCarver<ProbabilityFeatureConfiguration> CAVE;
    public static final WorldCarver<ProbabilityFeatureConfiguration> HELL_CAVE;
    public static final WorldCarver<ProbabilityFeatureConfiguration> CANYON;
    public static final WorldCarver<ProbabilityFeatureConfiguration> UNDERWATER_CANYON;
    public static final WorldCarver<ProbabilityFeatureConfiguration> UNDERWATER_CAVE;
    protected static final BlockState AIR;
    protected static final BlockState CAVE_AIR;
    protected static final FluidState WATER;
    protected static final FluidState LAVA;
    protected Set<Block> replaceableBlocks;
    protected Set<Fluid> liquids;
    private final Function<Dynamic<?>, ? extends C> configurationFactory;
    protected final int genHeight;
    
    private static <C extends CarverConfiguration, F extends WorldCarver<C>> F register(final String string, final F var1) {
        return Registry.register(Registry.CARVER, string, var1);
    }
    
    public WorldCarver(final Function<Dynamic<?>, ? extends C> configurationFactory, final int genHeight) {
        this.replaceableBlocks = (Set<Block>)ImmutableSet.of((Object)Blocks.STONE, (Object)Blocks.GRANITE, (Object)Blocks.DIORITE, (Object)Blocks.ANDESITE, (Object)Blocks.DIRT, (Object)Blocks.COARSE_DIRT, (Object[])new Block[] { Blocks.PODZOL, Blocks.GRASS_BLOCK, Blocks.TERRACOTTA, Blocks.WHITE_TERRACOTTA, Blocks.ORANGE_TERRACOTTA, Blocks.MAGENTA_TERRACOTTA, Blocks.LIGHT_BLUE_TERRACOTTA, Blocks.YELLOW_TERRACOTTA, Blocks.LIME_TERRACOTTA, Blocks.PINK_TERRACOTTA, Blocks.GRAY_TERRACOTTA, Blocks.LIGHT_GRAY_TERRACOTTA, Blocks.CYAN_TERRACOTTA, Blocks.PURPLE_TERRACOTTA, Blocks.BLUE_TERRACOTTA, Blocks.BROWN_TERRACOTTA, Blocks.GREEN_TERRACOTTA, Blocks.RED_TERRACOTTA, Blocks.BLACK_TERRACOTTA, Blocks.SANDSTONE, Blocks.RED_SANDSTONE, Blocks.MYCELIUM, Blocks.SNOW, Blocks.PACKED_ICE });
        this.liquids = (Set<Fluid>)ImmutableSet.of((Object)Fluids.WATER);
        this.configurationFactory = configurationFactory;
        this.genHeight = genHeight;
    }
    
    public int getRange() {
        return 4;
    }
    
    protected boolean carveSphere(final ChunkAccess chunkAccess, final long var2, final int var4, final int var5, final int var6, final double var7, final double var9, final double var11, final double var13, final double var15, final BitSet bitSet) {
        final Random var16 = new Random(var2 + var5 + var6);
        final double var17 = var5 * 16 + 8;
        final double var18 = var6 * 16 + 8;
        if (var7 < var17 - 16.0 - var13 * 2.0 || var11 < var18 - 16.0 - var13 * 2.0 || var7 > var17 + 16.0 + var13 * 2.0 || var11 > var18 + 16.0 + var13 * 2.0) {
            return false;
        }
        final int var19 = Math.max(Mth.floor(var7 - var13) - var5 * 16 - 1, 0);
        final int var20 = Math.min(Mth.floor(var7 + var13) - var5 * 16 + 1, 16);
        final int var21 = Math.max(Mth.floor(var9 - var15) - 1, 1);
        final int var22 = Math.min(Mth.floor(var9 + var15) + 1, this.genHeight - 8);
        final int var23 = Math.max(Mth.floor(var11 - var13) - var6 * 16 - 1, 0);
        final int var24 = Math.min(Mth.floor(var11 + var13) - var6 * 16 + 1, 16);
        if (this.hasWater(chunkAccess, var5, var6, var19, var20, var21, var22, var23, var24)) {
            return false;
        }
        boolean var25 = false;
        final BlockPos.MutableBlockPos var26 = new BlockPos.MutableBlockPos();
        final BlockPos.MutableBlockPos var27 = new BlockPos.MutableBlockPos();
        final BlockPos.MutableBlockPos var28 = new BlockPos.MutableBlockPos();
        for (int var29 = var19; var29 < var20; ++var29) {
            final int var30 = var29 + var5 * 16;
            final double var31 = (var30 + 0.5 - var7) / var13;
            for (int var32 = var23; var32 < var24; ++var32) {
                final int var33 = var32 + var6 * 16;
                final double var34 = (var33 + 0.5 - var11) / var13;
                if (var31 * var31 + var34 * var34 < 1.0) {
                    final AtomicBoolean var35 = new AtomicBoolean(false);
                    for (int var36 = var22; var36 > var21; --var36) {
                        final double var37 = (var36 - 0.5 - var9) / var15;
                        if (!this.skip(var31, var37, var34, var36)) {
                            var25 |= this.carveBlock(chunkAccess, bitSet, var16, var26, var27, var28, var4, var5, var6, var30, var33, var29, var36, var32, var35);
                        }
                    }
                }
            }
        }
        return var25;
    }
    
    protected boolean carveBlock(final ChunkAccess chunkAccess, final BitSet bitSet, final Random random, final BlockPos.MutableBlockPos var4, final BlockPos.MutableBlockPos var5, final BlockPos.MutableBlockPos var6, final int var7, final int var8, final int var9, final int var10, final int var11, final int var12, final int var13, final int var14, final AtomicBoolean atomicBoolean) {
        final int var15 = var12 | var14 << 4 | var13 << 8;
        if (bitSet.get(var15)) {
            return false;
        }
        bitSet.set(var15);
        var4.set(var10, var13, var11);
        final BlockState var16 = chunkAccess.getBlockState(var4);
        final BlockState var17 = chunkAccess.getBlockState(var5.set(var4).move(Direction.UP));
        if (var16.getBlock() == Blocks.GRASS_BLOCK || var16.getBlock() == Blocks.MYCELIUM) {
            atomicBoolean.set(true);
        }
        if (!this.canReplaceBlock(var16, var17)) {
            return false;
        }
        if (var13 < 11) {
            chunkAccess.setBlockState(var4, WorldCarver.LAVA.createLegacyBlock(), false);
        }
        else {
            chunkAccess.setBlockState(var4, WorldCarver.CAVE_AIR, false);
            if (atomicBoolean.get()) {
                var6.set(var4).move(Direction.DOWN);
                if (chunkAccess.getBlockState(var6).getBlock() == Blocks.DIRT) {
                    chunkAccess.setBlockState(var6, chunkAccess.getBiome(var4).getSurfaceBuilderConfig().getTopMaterial(), false);
                }
            }
        }
        return true;
    }
    
    public abstract boolean carve(final ChunkAccess p0, final Random p1, final int p2, final int p3, final int p4, final int p5, final int p6, final BitSet p7, final C p8);
    
    public abstract boolean isStartChunk(final Random p0, final int p1, final int p2, final C p3);
    
    protected boolean canReplaceBlock(final BlockState blockState) {
        return this.replaceableBlocks.contains(blockState.getBlock());
    }
    
    protected boolean canReplaceBlock(final BlockState var1, final BlockState var2) {
        final Block var3 = var1.getBlock();
        return this.canReplaceBlock(var1) || ((var3 == Blocks.SAND || var3 == Blocks.GRAVEL) && !var2.getFluidState().is(FluidTags.WATER));
    }
    
    protected boolean hasWater(final ChunkAccess chunkAccess, final int var2, final int var3, final int var4, final int var5, final int var6, final int var7, final int var8, final int var9) {
        final BlockPos.MutableBlockPos var10 = new BlockPos.MutableBlockPos();
        for (int var11 = var4; var11 < var5; ++var11) {
            for (int var12 = var8; var12 < var9; ++var12) {
                for (int var13 = var6 - 1; var13 <= var7 + 1; ++var13) {
                    if (this.liquids.contains(chunkAccess.getFluidState(var10.set(var11 + var2 * 16, var13, var12 + var3 * 16)).getType())) {
                        return true;
                    }
                    if (var13 != var7 + 1 && !this.isEdge(var4, var5, var8, var9, var11, var12)) {
                        var13 = var7;
                    }
                }
            }
        }
        return false;
    }
    
    private boolean isEdge(final int var1, final int var2, final int var3, final int var4, final int var5, final int var6) {
        return var5 == var1 || var5 == var2 - 1 || var6 == var3 || var6 == var4 - 1;
    }
    
    protected boolean canReach(final int var1, final int var2, final double var3, final double var5, final int var7, final int var8, final float var9) {
        final double var10 = var1 * 16 + 8;
        final double var11 = var2 * 16 + 8;
        final double var12 = var3 - var10;
        final double var13 = var5 - var11;
        final double var14 = var8 - var7;
        final double var15 = var9 + 2.0f + 16.0f;
        return var12 * var12 + var13 * var13 - var14 * var14 <= var15 * var15;
    }
    
    protected abstract boolean skip(final double p0, final double p1, final double p2, final int p3);
    
    static {
        CAVE = register("cave", new CaveWorldCarver(ProbabilityFeatureConfiguration::deserialize, 256));
        HELL_CAVE = register("hell_cave", new HellCaveWorldCarver(ProbabilityFeatureConfiguration::deserialize));
        CANYON = register("canyon", new CanyonWorldCarver(ProbabilityFeatureConfiguration::deserialize));
        UNDERWATER_CANYON = register("underwater_canyon", new UnderwaterCanyonWorldCarver(ProbabilityFeatureConfiguration::deserialize));
        UNDERWATER_CAVE = register("underwater_cave", new UnderwaterCaveWorldCarver(ProbabilityFeatureConfiguration::deserialize));
        AIR = Blocks.AIR.defaultBlockState();
        CAVE_AIR = Blocks.CAVE_AIR.defaultBlockState();
        WATER = Fluids.WATER.defaultFluidState();
        LAVA = Fluids.LAVA.defaultFluidState();
    }
}
