package net.minecraft.world.level.levelgen.feature;

import java.util.function.*;
import com.mojang.datafixers.*;
import net.minecraft.world.level.chunk.*;
import java.util.*;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.core.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.level.biome.*;
import net.minecraft.world.level.block.state.*;

public class SnowAndFreezeFeature extends Feature<NoneFeatureConfiguration>
{
    public SnowAndFreezeFeature(final Function<Dynamic<?>, ? extends NoneFeatureConfiguration> function) {
        super(function);
    }
    
    @Override
    public boolean place(final LevelAccessor levelAccessor, final ChunkGenerator<? extends ChunkGeneratorSettings> chunkGenerator, final Random random, final BlockPos blockPos, final NoneFeatureConfiguration noneFeatureConfiguration) {
        final BlockPos.MutableBlockPos var6 = new BlockPos.MutableBlockPos();
        final BlockPos.MutableBlockPos var7 = new BlockPos.MutableBlockPos();
        for (int var8 = 0; var8 < 16; ++var8) {
            for (int var9 = 0; var9 < 16; ++var9) {
                final int var10 = blockPos.getX() + var8;
                final int var11 = blockPos.getZ() + var9;
                final int var12 = levelAccessor.getHeight(Heightmap.Types.MOTION_BLOCKING, var10, var11);
                var6.set(var10, var12, var11);
                var7.set(var6).move(Direction.DOWN, 1);
                final Biome var13 = levelAccessor.getBiome(var6);
                if (var13.shouldFreeze(levelAccessor, var7, false)) {
                    levelAccessor.setBlock(var7, Blocks.ICE.defaultBlockState(), 2);
                }
                if (var13.shouldSnow(levelAccessor, var6)) {
                    levelAccessor.setBlock(var6, Blocks.SNOW.defaultBlockState(), 2);
                    final BlockState var14 = levelAccessor.getBlockState(var7);
                    if (var14.hasProperty((Property<Comparable>)SnowyDirtBlock.SNOWY)) {
                        levelAccessor.setBlock(var7, ((AbstractStateHolder<O, BlockState>)var14).setValue((Property<Comparable>)SnowyDirtBlock.SNOWY, true), 2);
                    }
                }
            }
        }
        return true;
    }
}
