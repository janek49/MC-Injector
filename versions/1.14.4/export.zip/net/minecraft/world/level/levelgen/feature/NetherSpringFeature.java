package net.minecraft.world.level.levelgen.feature;

import net.minecraft.world.level.block.state.*;
import java.util.function.*;
import com.mojang.datafixers.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.levelgen.*;
import java.util.*;
import net.minecraft.core.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.material.*;

public class NetherSpringFeature extends Feature<HellSpringConfiguration>
{
    private static final BlockState NETHERRACK;
    
    public NetherSpringFeature(final Function<Dynamic<?>, ? extends HellSpringConfiguration> function) {
        super(function);
    }
    
    @Override
    public boolean place(final LevelAccessor levelAccessor, final ChunkGenerator<? extends ChunkGeneratorSettings> chunkGenerator, final Random random, final BlockPos blockPos, final HellSpringConfiguration hellSpringConfiguration) {
        if (levelAccessor.getBlockState(blockPos.above()) != NetherSpringFeature.NETHERRACK) {
            return false;
        }
        if (!levelAccessor.getBlockState(blockPos).isAir() && levelAccessor.getBlockState(blockPos) != NetherSpringFeature.NETHERRACK) {
            return false;
        }
        int var6 = 0;
        if (levelAccessor.getBlockState(blockPos.west()) == NetherSpringFeature.NETHERRACK) {
            ++var6;
        }
        if (levelAccessor.getBlockState(blockPos.east()) == NetherSpringFeature.NETHERRACK) {
            ++var6;
        }
        if (levelAccessor.getBlockState(blockPos.north()) == NetherSpringFeature.NETHERRACK) {
            ++var6;
        }
        if (levelAccessor.getBlockState(blockPos.south()) == NetherSpringFeature.NETHERRACK) {
            ++var6;
        }
        if (levelAccessor.getBlockState(blockPos.below()) == NetherSpringFeature.NETHERRACK) {
            ++var6;
        }
        int var7 = 0;
        if (levelAccessor.isEmptyBlock(blockPos.west())) {
            ++var7;
        }
        if (levelAccessor.isEmptyBlock(blockPos.east())) {
            ++var7;
        }
        if (levelAccessor.isEmptyBlock(blockPos.north())) {
            ++var7;
        }
        if (levelAccessor.isEmptyBlock(blockPos.south())) {
            ++var7;
        }
        if (levelAccessor.isEmptyBlock(blockPos.below())) {
            ++var7;
        }
        if ((!hellSpringConfiguration.insideRock && var6 == 4 && var7 == 1) || var6 == 5) {
            levelAccessor.setBlock(blockPos, Blocks.LAVA.defaultBlockState(), 2);
            levelAccessor.getLiquidTicks().scheduleTick(blockPos, Fluids.LAVA, 0);
        }
        return true;
    }
    
    static {
        NETHERRACK = Blocks.NETHERRACK.defaultBlockState();
    }
}
