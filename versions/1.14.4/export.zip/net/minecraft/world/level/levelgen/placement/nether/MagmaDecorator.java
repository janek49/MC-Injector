package net.minecraft.world.level.levelgen.placement.nether;

import net.minecraft.world.level.levelgen.placement.*;
import java.util.function.*;
import com.mojang.datafixers.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.levelgen.*;
import java.util.*;
import net.minecraft.core.*;
import java.util.stream.*;
import net.minecraft.world.level.levelgen.feature.*;

public class MagmaDecorator extends FeatureDecorator<DecoratorFrequency>
{
    public MagmaDecorator(final Function<Dynamic<?>, ? extends DecoratorFrequency> function) {
        super(function);
    }
    
    @Override
    public Stream<BlockPos> getPositions(final LevelAccessor levelAccessor, final ChunkGenerator<? extends ChunkGeneratorSettings> chunkGenerator, final Random random, final DecoratorFrequency decoratorFrequency, final BlockPos blockPos) {
        final int var6 = levelAccessor.getSeaLevel() / 2 + 1;
        final int var7;
        final int n;
        final int var8;
        final int var9;
        return IntStream.range(0, decoratorFrequency.count).mapToObj(var3 -> {
            var7 = random.nextInt(16);
            var8 = n - 5 + random.nextInt(10);
            var9 = random.nextInt(16);
            return blockPos.offset(var7, var8, var9);
        });
    }
}
