package net.minecraft.world.level.levelgen.feature;

import net.minecraft.world.level.block.state.*;
import java.util.function.*;
import com.mojang.datafixers.*;
import net.minecraft.core.*;
import java.util.*;
import net.minecraft.world.level.levelgen.structure.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;

public class BirchFeature extends AbstractTreeFeature<NoneFeatureConfiguration>
{
    private static final BlockState LOG;
    private static final BlockState LEAF;
    private final boolean superBirch;
    
    public BirchFeature(final Function<Dynamic<?>, ? extends NoneFeatureConfiguration> function, final boolean var2, final boolean superBirch) {
        super(function, var2);
        this.superBirch = superBirch;
    }
    
    public boolean doPlace(final Set<BlockPos> set, final LevelSimulatedRW levelSimulatedRW, final Random random, final BlockPos blockPos, final BoundingBox boundingBox) {
        int var6 = random.nextInt(3) + 5;
        if (this.superBirch) {
            var6 += random.nextInt(7);
        }
        boolean var7 = true;
        if (blockPos.getY() < 1 || blockPos.getY() + var6 + 1 > 256) {
            return false;
        }
        for (int var8 = blockPos.getY(); var8 <= blockPos.getY() + 1 + var6; ++var8) {
            int var9 = 1;
            if (var8 == blockPos.getY()) {
                var9 = 0;
            }
            if (var8 >= blockPos.getY() + 1 + var6 - 2) {
                var9 = 2;
            }
            final BlockPos.MutableBlockPos var10 = new BlockPos.MutableBlockPos();
            for (int var11 = blockPos.getX() - var9; var11 <= blockPos.getX() + var9 && var7; ++var11) {
                for (int var12 = blockPos.getZ() - var9; var12 <= blockPos.getZ() + var9 && var7; ++var12) {
                    if (var8 >= 0 && var8 < 256) {
                        if (!AbstractTreeFeature.isFree(levelSimulatedRW, var10.set(var11, var8, var12))) {
                            var7 = false;
                        }
                    }
                    else {
                        var7 = false;
                    }
                }
            }
        }
        if (!var7) {
            return false;
        }
        if (!AbstractTreeFeature.isGrassOrDirtOrFarmland(levelSimulatedRW, blockPos.below()) || blockPos.getY() >= 256 - var6 - 1) {
            return false;
        }
        this.setDirtAt(levelSimulatedRW, blockPos.below());
        for (int var8 = blockPos.getY() - 3 + var6; var8 <= blockPos.getY() + var6; ++var8) {
            final int var9 = var8 - (blockPos.getY() + var6);
            for (int var13 = 1 - var9 / 2, var11 = blockPos.getX() - var13; var11 <= blockPos.getX() + var13; ++var11) {
                final int var12 = var11 - blockPos.getX();
                for (int var14 = blockPos.getZ() - var13; var14 <= blockPos.getZ() + var13; ++var14) {
                    final int var15 = var14 - blockPos.getZ();
                    if (Math.abs(var12) == var13 && Math.abs(var15) == var13) {
                        if (random.nextInt(2) == 0) {
                            continue;
                        }
                        if (var9 == 0) {
                            continue;
                        }
                    }
                    final BlockPos var16 = new BlockPos(var11, var8, var14);
                    if (AbstractTreeFeature.isAirOrLeaves(levelSimulatedRW, var16)) {
                        this.setBlock(set, levelSimulatedRW, var16, BirchFeature.LEAF, boundingBox);
                    }
                }
            }
        }
        for (int var8 = 0; var8 < var6; ++var8) {
            if (AbstractTreeFeature.isAirOrLeaves(levelSimulatedRW, blockPos.above(var8))) {
                this.setBlock(set, levelSimulatedRW, blockPos.above(var8), BirchFeature.LOG, boundingBox);
            }
        }
        return true;
    }
    
    static {
        LOG = Blocks.BIRCH_LOG.defaultBlockState();
        LEAF = Blocks.BIRCH_LEAVES.defaultBlockState();
    }
}
