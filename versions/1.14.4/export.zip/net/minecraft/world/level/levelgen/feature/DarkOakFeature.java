package net.minecraft.world.level.levelgen.feature;

import net.minecraft.world.level.block.state.*;
import java.util.function.*;
import com.mojang.datafixers.*;
import java.util.*;
import net.minecraft.world.level.levelgen.structure.*;
import net.minecraft.core.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;

public class DarkOakFeature extends AbstractTreeFeature<NoneFeatureConfiguration>
{
    private static final BlockState LOG;
    private static final BlockState LEAVES;
    
    public DarkOakFeature(final Function<Dynamic<?>, ? extends NoneFeatureConfiguration> function, final boolean var2) {
        super(function, var2);
    }
    
    public boolean doPlace(final Set<BlockPos> set, final LevelSimulatedRW levelSimulatedRW, final Random random, final BlockPos blockPos, final BoundingBox boundingBox) {
        final int var6 = random.nextInt(3) + random.nextInt(2) + 6;
        final int var7 = blockPos.getX();
        final int var8 = blockPos.getY();
        final int var9 = blockPos.getZ();
        if (var8 < 1 || var8 + var6 + 1 >= 256) {
            return false;
        }
        final BlockPos var10 = blockPos.below();
        if (!AbstractTreeFeature.isGrassOrDirt(levelSimulatedRW, var10)) {
            return false;
        }
        if (!this.canPlaceTreeOfHeight(levelSimulatedRW, blockPos, var6)) {
            return false;
        }
        this.setDirtAt(levelSimulatedRW, var10);
        this.setDirtAt(levelSimulatedRW, var10.east());
        this.setDirtAt(levelSimulatedRW, var10.south());
        this.setDirtAt(levelSimulatedRW, var10.south().east());
        final Direction var11 = Direction.Plane.HORIZONTAL.getRandomDirection(random);
        final int var12 = var6 - random.nextInt(4);
        int var13 = 2 - random.nextInt(3);
        int var14 = var7;
        int var15 = var9;
        final int var16 = var8 + var6 - 1;
        for (int var17 = 0; var17 < var6; ++var17) {
            if (var17 >= var12 && var13 > 0) {
                var14 += var11.getStepX();
                var15 += var11.getStepZ();
                --var13;
            }
            final int var18 = var8 + var17;
            final BlockPos var19 = new BlockPos(var14, var18, var15);
            if (AbstractTreeFeature.isAirOrLeaves(levelSimulatedRW, var19)) {
                this.placeLogAt(set, levelSimulatedRW, var19, boundingBox);
                this.placeLogAt(set, levelSimulatedRW, var19.east(), boundingBox);
                this.placeLogAt(set, levelSimulatedRW, var19.south(), boundingBox);
                this.placeLogAt(set, levelSimulatedRW, var19.east().south(), boundingBox);
            }
        }
        for (int var17 = -2; var17 <= 0; ++var17) {
            for (int var18 = -2; var18 <= 0; ++var18) {
                int var20 = -1;
                this.placeLeafAt(levelSimulatedRW, var14 + var17, var16 + var20, var15 + var18, boundingBox, set);
                this.placeLeafAt(levelSimulatedRW, 1 + var14 - var17, var16 + var20, var15 + var18, boundingBox, set);
                this.placeLeafAt(levelSimulatedRW, var14 + var17, var16 + var20, 1 + var15 - var18, boundingBox, set);
                this.placeLeafAt(levelSimulatedRW, 1 + var14 - var17, var16 + var20, 1 + var15 - var18, boundingBox, set);
                if (var17 > -2 || var18 > -1) {
                    if (var17 != -1 || var18 != -2) {
                        var20 = 1;
                        this.placeLeafAt(levelSimulatedRW, var14 + var17, var16 + var20, var15 + var18, boundingBox, set);
                        this.placeLeafAt(levelSimulatedRW, 1 + var14 - var17, var16 + var20, var15 + var18, boundingBox, set);
                        this.placeLeafAt(levelSimulatedRW, var14 + var17, var16 + var20, 1 + var15 - var18, boundingBox, set);
                        this.placeLeafAt(levelSimulatedRW, 1 + var14 - var17, var16 + var20, 1 + var15 - var18, boundingBox, set);
                    }
                }
            }
        }
        if (random.nextBoolean()) {
            this.placeLeafAt(levelSimulatedRW, var14, var16 + 2, var15, boundingBox, set);
            this.placeLeafAt(levelSimulatedRW, var14 + 1, var16 + 2, var15, boundingBox, set);
            this.placeLeafAt(levelSimulatedRW, var14 + 1, var16 + 2, var15 + 1, boundingBox, set);
            this.placeLeafAt(levelSimulatedRW, var14, var16 + 2, var15 + 1, boundingBox, set);
        }
        for (int var17 = -3; var17 <= 4; ++var17) {
            for (int var18 = -3; var18 <= 4; ++var18) {
                if ((var17 != -3 || var18 != -3) && (var17 != -3 || var18 != 4) && (var17 != 4 || var18 != -3)) {
                    if (var17 != 4 || var18 != 4) {
                        if (Math.abs(var17) < 3 || Math.abs(var18) < 3) {
                            this.placeLeafAt(levelSimulatedRW, var14 + var17, var16, var15 + var18, boundingBox, set);
                        }
                    }
                }
            }
        }
        for (int var17 = -1; var17 <= 2; ++var17) {
            for (int var18 = -1; var18 <= 2; ++var18) {
                if (var17 < 0 || var17 > 1 || var18 < 0 || var18 > 1) {
                    if (random.nextInt(3) <= 0) {
                        for (int var20 = random.nextInt(3) + 2, var21 = 0; var21 < var20; ++var21) {
                            this.placeLogAt(set, levelSimulatedRW, new BlockPos(var7 + var17, var16 - var21 - 1, var9 + var18), boundingBox);
                        }
                        for (int var21 = -1; var21 <= 1; ++var21) {
                            for (int var22 = -1; var22 <= 1; ++var22) {
                                this.placeLeafAt(levelSimulatedRW, var14 + var17 + var21, var16, var15 + var18 + var22, boundingBox, set);
                            }
                        }
                        for (int var21 = -2; var21 <= 2; ++var21) {
                            for (int var22 = -2; var22 <= 2; ++var22) {
                                if (Math.abs(var21) != 2 || Math.abs(var22) != 2) {
                                    this.placeLeafAt(levelSimulatedRW, var14 + var17 + var21, var16 - 1, var15 + var18 + var22, boundingBox, set);
                                }
                            }
                        }
                    }
                }
            }
        }
        return true;
    }
    
    private boolean canPlaceTreeOfHeight(final LevelSimulatedReader levelSimulatedReader, final BlockPos blockPos, final int var3) {
        final int var4 = blockPos.getX();
        final int var5 = blockPos.getY();
        final int var6 = blockPos.getZ();
        final BlockPos.MutableBlockPos var7 = new BlockPos.MutableBlockPos();
        for (int var8 = 0; var8 <= var3 + 1; ++var8) {
            int var9 = 1;
            if (var8 == 0) {
                var9 = 0;
            }
            if (var8 >= var3 - 1) {
                var9 = 2;
            }
            for (int var10 = -var9; var10 <= var9; ++var10) {
                for (int var11 = -var9; var11 <= var9; ++var11) {
                    if (!AbstractTreeFeature.isFree(levelSimulatedReader, var7.set(var4 + var10, var5 + var8, var6 + var11))) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    private void placeLogAt(final Set<BlockPos> set, final LevelSimulatedRW levelSimulatedRW, final BlockPos blockPos, final BoundingBox boundingBox) {
        if (AbstractTreeFeature.isFree(levelSimulatedRW, blockPos)) {
            this.setBlock(set, levelSimulatedRW, blockPos, DarkOakFeature.LOG, boundingBox);
        }
    }
    
    private void placeLeafAt(final LevelSimulatedRW levelSimulatedRW, final int var2, final int var3, final int var4, final BoundingBox boundingBox, final Set<BlockPos> set) {
        final BlockPos var5 = new BlockPos(var2, var3, var4);
        if (AbstractTreeFeature.isAir(levelSimulatedRW, var5)) {
            this.setBlock(set, levelSimulatedRW, var5, DarkOakFeature.LEAVES, boundingBox);
        }
    }
    
    static {
        LOG = Blocks.DARK_OAK_LOG.defaultBlockState();
        LEAVES = Blocks.DARK_OAK_LEAVES.defaultBlockState();
    }
}
