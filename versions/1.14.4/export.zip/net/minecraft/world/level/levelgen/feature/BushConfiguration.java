package net.minecraft.world.level.levelgen.feature;

import net.minecraft.world.level.block.state.*;
import com.mojang.datafixers.types.*;
import com.mojang.datafixers.*;
import com.google.common.collect.*;
import java.util.*;
import java.util.function.*;
import net.minecraft.world.level.block.*;

public class BushConfiguration implements FeatureConfiguration
{
    public final BlockState state;
    
    public BushConfiguration(final BlockState state) {
        this.state = state;
    }
    
    @Override
    public <T> Dynamic<T> serialize(final DynamicOps<T> dynamicOps) {
        return (Dynamic<T>)new Dynamic((DynamicOps)dynamicOps, dynamicOps.createMap((Map)ImmutableMap.of(dynamicOps.createString("state"), BlockState.serialize(dynamicOps, this.state).getValue())));
    }
    
    public static <T> BushConfiguration deserialize(final Dynamic<T> dynamic) {
        final BlockState var1 = dynamic.get("state").map((Function)BlockState::deserialize).orElse(Blocks.AIR.defaultBlockState());
        return new BushConfiguration(var1);
    }
}
