package net.minecraft.world.level.levelgen.feature;

import com.mojang.datafixers.types.*;
import com.mojang.datafixers.*;
import java.util.stream.*;
import com.google.common.collect.*;
import java.util.*;
import java.util.function.*;

public class RandomRandomFeatureConfig implements FeatureConfiguration
{
    public final List<ConfiguredFeature<?>> features;
    public final int count;
    
    public RandomRandomFeatureConfig(final List<ConfiguredFeature<?>> features, final int count) {
        this.features = features;
        this.count = count;
    }
    
    public RandomRandomFeatureConfig(final Feature<?>[] features, final FeatureConfiguration[] featureConfigurations, final int var3) {
        this((List<ConfiguredFeature<?>>)IntStream.range(0, features.length).mapToObj(var2 -> getConfiguredFeature(features[var2], featureConfigurations[var2])).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()), var3);
    }
    
    private static <FC extends FeatureConfiguration> ConfiguredFeature<?> getConfiguredFeature(final Feature<FC> feature, final FeatureConfiguration featureConfiguration) {
        return new ConfiguredFeature<Object>(feature, featureConfiguration);
    }
    
    @Override
    public <T> Dynamic<T> serialize(final DynamicOps<T> dynamicOps) {
        return (Dynamic<T>)new Dynamic((DynamicOps)dynamicOps, dynamicOps.createMap((Map)ImmutableMap.of(dynamicOps.createString("features"), dynamicOps.createList((Stream)this.features.stream().map(configuredFeature -> configuredFeature.serialize(dynamicOps).getValue())), dynamicOps.createString("count"), dynamicOps.createInt(this.count))));
    }
    
    public static <T> RandomRandomFeatureConfig deserialize(final Dynamic<T> dynamic) {
        final List<ConfiguredFeature<?>> var1 = (List<ConfiguredFeature<?>>)dynamic.get("features").asList((Function)ConfiguredFeature::deserialize);
        final int var2 = dynamic.get("count").asInt(0);
        return new RandomRandomFeatureConfig(var1, var2);
    }
}
