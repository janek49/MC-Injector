package net.minecraft.world.level.levelgen.feature;

import java.util.function.*;
import com.mojang.datafixers.*;
import java.util.*;
import net.minecraft.core.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.*;

public class SwampFlowerFeature extends FlowerFeature
{
    public SwampFlowerFeature(final Function<Dynamic<?>, ? extends NoneFeatureConfiguration> function) {
        super(function);
    }
    
    @Override
    public BlockState getRandomFlower(final Random random, final BlockPos blockPos) {
        return Blocks.BLUE_ORCHID.defaultBlockState();
    }
}
