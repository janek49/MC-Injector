package net.minecraft.world.level.levelgen.feature;

import java.util.function.*;
import com.mojang.datafixers.*;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.biome.*;
import net.minecraft.world.level.levelgen.structure.templatesystem.*;
import com.google.common.collect.*;
import net.minecraft.world.level.levelgen.structure.*;
import java.util.*;
import net.minecraft.world.level.*;
import net.minecraft.core.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.levelgen.*;

public class WoodlandMansionFeature extends StructureFeature<NoneFeatureConfiguration>
{
    public WoodlandMansionFeature(final Function<Dynamic<?>, ? extends NoneFeatureConfiguration> function) {
        super(function);
    }
    
    @Override
    protected ChunkPos getPotentialFeatureChunkFromLocationWithOffset(final ChunkGenerator<?> chunkGenerator, final Random random, final int var3, final int var4, final int var5, final int var6) {
        final int var7 = ((ChunkGeneratorSettings)chunkGenerator.getSettings()).getWoodlandMansionSpacing();
        final int var8 = ((ChunkGeneratorSettings)chunkGenerator.getSettings()).getWoodlandMangionSeparation();
        final int var9 = var3 + var7 * var5;
        final int var10 = var4 + var7 * var6;
        final int var11 = (var9 < 0) ? (var9 - var7 + 1) : var9;
        final int var12 = (var10 < 0) ? (var10 - var7 + 1) : var10;
        int var13 = var11 / var7;
        int var14 = var12 / var7;
        ((WorldgenRandom)random).setLargeFeatureWithSalt(chunkGenerator.getSeed(), var13, var14, 10387319);
        var13 *= var7;
        var14 *= var7;
        var13 += (random.nextInt(var7 - var8) + random.nextInt(var7 - var8)) / 2;
        var14 += (random.nextInt(var7 - var8) + random.nextInt(var7 - var8)) / 2;
        return new ChunkPos(var13, var14);
    }
    
    @Override
    public boolean isFeatureChunk(final ChunkGenerator<?> chunkGenerator, final Random random, final int var3, final int var4) {
        final ChunkPos var5 = this.getPotentialFeatureChunkFromLocationWithOffset(chunkGenerator, random, var3, var4, 0, 0);
        if (var3 == var5.x && var4 == var5.z) {
            final Set<Biome> var6 = chunkGenerator.getBiomeSource().getBiomesWithin(var3 * 16 + 9, var4 * 16 + 9, 32);
            for (final Biome var7 : var6) {
                if (!chunkGenerator.isBiomeValidStartForStructure(var7, Feature.WOODLAND_MANSION)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    
    @Override
    public StructureStartFactory getStartFactory() {
        return WoodlandMansionStart::new;
    }
    
    @Override
    public String getFeatureName() {
        return "Mansion";
    }
    
    @Override
    public int getLookupRange() {
        return 8;
    }
    
    public static class WoodlandMansionStart extends StructureStart
    {
        public WoodlandMansionStart(final StructureFeature<?> structureFeature, final int var2, final int var3, final Biome biome, final BoundingBox boundingBox, final int var6, final long var7) {
            super(structureFeature, var2, var3, biome, boundingBox, var6, var7);
        }
        
        @Override
        public void generatePieces(final ChunkGenerator<?> chunkGenerator, final StructureManager structureManager, final int var3, final int var4, final Biome biome) {
            final Rotation var5 = Rotation.values()[this.random.nextInt(Rotation.values().length)];
            int var6 = 5;
            int var7 = 5;
            if (var5 == Rotation.CLOCKWISE_90) {
                var6 = -5;
            }
            else if (var5 == Rotation.CLOCKWISE_180) {
                var6 = -5;
                var7 = -5;
            }
            else if (var5 == Rotation.COUNTERCLOCKWISE_90) {
                var7 = -5;
            }
            final int var8 = (var3 << 4) + 7;
            final int var9 = (var4 << 4) + 7;
            final int var10 = chunkGenerator.getFirstOccupiedHeight(var8, var9, Heightmap.Types.WORLD_SURFACE_WG);
            final int var11 = chunkGenerator.getFirstOccupiedHeight(var8, var9 + var7, Heightmap.Types.WORLD_SURFACE_WG);
            final int var12 = chunkGenerator.getFirstOccupiedHeight(var8 + var6, var9, Heightmap.Types.WORLD_SURFACE_WG);
            final int var13 = chunkGenerator.getFirstOccupiedHeight(var8 + var6, var9 + var7, Heightmap.Types.WORLD_SURFACE_WG);
            final int var14 = Math.min(Math.min(var10, var11), Math.min(var12, var13));
            if (var14 < 60) {
                return;
            }
            final BlockPos var15 = new BlockPos(var3 * 16 + 8, var14 + 1, var4 * 16 + 8);
            final List<WoodlandMansionPieces.WoodlandMansionPiece> var16 = (List<WoodlandMansionPieces.WoodlandMansionPiece>)Lists.newLinkedList();
            WoodlandMansionPieces.generateMansion(structureManager, var15, var5, var16, this.random);
            this.pieces.addAll(var16);
            this.calculateBoundingBox();
        }
        
        @Override
        public void postProcess(final LevelAccessor levelAccessor, final Random random, final BoundingBox boundingBox, final ChunkPos chunkPos) {
            super.postProcess(levelAccessor, random, boundingBox, chunkPos);
            final int var5 = this.boundingBox.y0;
            for (int var6 = boundingBox.x0; var6 <= boundingBox.x1; ++var6) {
                for (int var7 = boundingBox.z0; var7 <= boundingBox.z1; ++var7) {
                    final BlockPos var8 = new BlockPos(var6, var5, var7);
                    if (!levelAccessor.isEmptyBlock(var8) && this.boundingBox.isInside(var8)) {
                        boolean var9 = false;
                        for (final StructurePiece var10 : this.pieces) {
                            if (var10.getBoundingBox().isInside(var8)) {
                                var9 = true;
                                break;
                            }
                        }
                        if (var9) {
                            for (int var11 = var5 - 1; var11 > 1; --var11) {
                                final BlockPos var12 = new BlockPos(var6, var11, var7);
                                if (!levelAccessor.isEmptyBlock(var12) && !levelAccessor.getBlockState(var12).getMaterial().isLiquid()) {
                                    break;
                                }
                                levelAccessor.setBlock(var12, Blocks.COBBLESTONE.defaultBlockState(), 2);
                            }
                        }
                    }
                }
            }
        }
    }
}
