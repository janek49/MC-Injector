package net.minecraft.world.level.levelgen.placement;

import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.*;
import com.mojang.datafixers.types.*;
import com.mojang.datafixers.*;
import com.google.common.collect.*;
import java.util.*;

public class DecoratorNoiseCountFactor implements DecoratorConfiguration
{
    public final int noiseToCountRatio;
    public final double noiseFactor;
    public final double noiseOffset;
    public final Heightmap.Types heightmap;
    
    public DecoratorNoiseCountFactor(final int noiseToCountRatio, final double noiseFactor, final double noiseOffset, final Heightmap.Types heightmap) {
        this.noiseToCountRatio = noiseToCountRatio;
        this.noiseFactor = noiseFactor;
        this.noiseOffset = noiseOffset;
        this.heightmap = heightmap;
    }
    
    @Override
    public <T> Dynamic<T> serialize(final DynamicOps<T> dynamicOps) {
        return (Dynamic<T>)new Dynamic((DynamicOps)dynamicOps, dynamicOps.createMap((Map)ImmutableMap.of(dynamicOps.createString("noise_to_count_ratio"), dynamicOps.createInt(this.noiseToCountRatio), dynamicOps.createString("noise_factor"), dynamicOps.createDouble(this.noiseFactor), dynamicOps.createString("noise_offset"), dynamicOps.createDouble(this.noiseOffset), dynamicOps.createString("heightmap"), dynamicOps.createString(this.heightmap.getSerializationKey()))));
    }
    
    public static DecoratorNoiseCountFactor deserialize(final Dynamic<?> dynamic) {
        final int var1 = dynamic.get("noise_to_count_ratio").asInt(10);
        final double var2 = dynamic.get("noise_factor").asDouble(80.0);
        final double var3 = dynamic.get("noise_offset").asDouble(0.0);
        final Heightmap.Types var4 = Heightmap.Types.getFromKey(dynamic.get("heightmap").asString("OCEAN_FLOOR_WG"));
        return new DecoratorNoiseCountFactor(var1, var2, var3, var4);
    }
}
