package net.minecraft.world.level.levelgen.feature;

import java.util.function.*;
import com.mojang.datafixers.*;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.levelgen.*;
import java.util.*;
import net.minecraft.core.*;
import net.minecraft.util.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.material.*;
import net.minecraft.world.level.*;

public class IcebergFeature extends Feature<IcebergConfiguration>
{
    public IcebergFeature(final Function<Dynamic<?>, ? extends IcebergConfiguration> function) {
        super(function);
    }
    
    @Override
    public boolean place(final LevelAccessor levelAccessor, final ChunkGenerator<? extends ChunkGeneratorSettings> chunkGenerator, final Random random, BlockPos blockPos, final IcebergConfiguration icebergConfiguration) {
        blockPos = new BlockPos(blockPos.getX(), levelAccessor.getSeaLevel(), blockPos.getZ());
        final boolean var6 = random.nextDouble() > 0.7;
        final BlockState var7 = icebergConfiguration.state;
        final double var8 = random.nextDouble() * 2.0 * 3.141592653589793;
        final int var9 = 11 - random.nextInt(5);
        final int var10 = 3 + random.nextInt(3);
        final boolean var11 = random.nextDouble() > 0.7;
        final int var12 = 11;
        int var13 = var11 ? (random.nextInt(6) + 6) : (random.nextInt(15) + 3);
        if (!var11 && random.nextDouble() > 0.9) {
            var13 += random.nextInt(19) + 7;
        }
        final int var14 = Math.min(var13 + random.nextInt(11), 18);
        final int var15 = Math.min(var13 + random.nextInt(7) - random.nextInt(5), 11);
        final int var16 = var11 ? var9 : 11;
        for (int var17 = -var16; var17 < var16; ++var17) {
            for (int var18 = -var16; var18 < var16; ++var18) {
                for (int var19 = 0; var19 < var13; ++var19) {
                    final int var20 = var11 ? this.heightDependentRadiusEllipse(var19, var13, var15) : this.heightDependentRadiusRound(random, var19, var13, var15);
                    if (var11 || var17 < var20) {
                        this.generateIcebergBlock(levelAccessor, random, blockPos, var13, var17, var19, var18, var20, var16, var11, var10, var8, var6, var7);
                    }
                }
            }
        }
        this.smooth(levelAccessor, blockPos, var15, var13, var11, var9);
        for (int var17 = -var16; var17 < var16; ++var17) {
            for (int var18 = -var16; var18 < var16; ++var18) {
                for (int var19 = -1; var19 > -var14; --var19) {
                    final int var20 = var11 ? Mth.ceil(var16 * (1.0f - (float)Math.pow(var19, 2.0) / (var14 * 8.0f))) : var16;
                    final int var21 = this.heightDependentRadiusSteep(random, -var19, var14, var15);
                    if (var17 < var21) {
                        this.generateIcebergBlock(levelAccessor, random, blockPos, var14, var17, var19, var18, var21, var20, var11, var10, var8, var6, var7);
                    }
                }
            }
        }
        final boolean var22 = var11 ? (random.nextDouble() > 0.1) : (random.nextDouble() > 0.7);
        if (var22) {
            this.generateCutOut(random, levelAccessor, var15, var13, blockPos, var11, var9, var8, var10);
        }
        return true;
    }
    
    private void generateCutOut(final Random random, final LevelAccessor levelAccessor, final int var3, final int var4, final BlockPos blockPos, final boolean var6, final int var7, final double var8, final int var10) {
        final int var11 = random.nextBoolean() ? -1 : 1;
        final int var12 = random.nextBoolean() ? -1 : 1;
        int var13 = random.nextInt(Math.max(var3 / 2 - 2, 1));
        if (random.nextBoolean()) {
            var13 = var3 / 2 + 1 - random.nextInt(Math.max(var3 - var3 / 2 - 1, 1));
        }
        int var14 = random.nextInt(Math.max(var3 / 2 - 2, 1));
        if (random.nextBoolean()) {
            var14 = var3 / 2 + 1 - random.nextInt(Math.max(var3 - var3 / 2 - 1, 1));
        }
        if (var6) {
            var14 = (var13 = random.nextInt(Math.max(var7 - 5, 1)));
        }
        final BlockPos var15 = new BlockPos(var11 * var13, 0, var12 * var14);
        final double var16 = var6 ? (var8 + 1.5707963267948966) : (random.nextDouble() * 2.0 * 3.141592653589793);
        for (int var17 = 0; var17 < var4 - 3; ++var17) {
            final int var18 = this.heightDependentRadiusRound(random, var17, var4, var3);
            this.carve(var18, var17, blockPos, levelAccessor, false, var16, var15, var7, var10);
        }
        for (int var17 = -1; var17 > -var4 + random.nextInt(5); --var17) {
            final int var18 = this.heightDependentRadiusSteep(random, -var17, var4, var3);
            this.carve(var18, var17, blockPos, levelAccessor, true, var16, var15, var7, var10);
        }
    }
    
    private void carve(final int var1, final int var2, final BlockPos var3, final LevelAccessor levelAccessor, final boolean var5, final double var6, final BlockPos var8, final int var9, final int var10) {
        final int var11 = var1 + 1 + var9 / 3;
        final int var12 = Math.min(var1 - 3, 3) + var10 / 2 - 1;
        for (int var13 = -var11; var13 < var11; ++var13) {
            for (int var14 = -var11; var14 < var11; ++var14) {
                final double var15 = this.signedDistanceEllipse(var13, var14, var8, var11, var12, var6);
                if (var15 < 0.0) {
                    final BlockPos var16 = var3.offset(var13, var2, var14);
                    final Block var17 = levelAccessor.getBlockState(var16).getBlock();
                    if (this.isIcebergBlock(var17) || var17 == Blocks.SNOW_BLOCK) {
                        if (var5) {
                            this.setBlock(levelAccessor, var16, Blocks.WATER.defaultBlockState());
                        }
                        else {
                            this.setBlock(levelAccessor, var16, Blocks.AIR.defaultBlockState());
                            this.removeFloatingSnowLayer(levelAccessor, var16);
                        }
                    }
                }
            }
        }
    }
    
    private void removeFloatingSnowLayer(final LevelAccessor levelAccessor, final BlockPos blockPos) {
        if (levelAccessor.getBlockState(blockPos.above()).getBlock() == Blocks.SNOW) {
            this.setBlock(levelAccessor, blockPos.above(), Blocks.AIR.defaultBlockState());
        }
    }
    
    private void generateIcebergBlock(final LevelAccessor levelAccessor, final Random random, final BlockPos blockPos, final int var4, final int var5, final int var6, final int var7, final int var8, final int var9, final boolean var10, final int var11, final double var12, final boolean var14, final BlockState blockState) {
        final double var15 = var10 ? this.signedDistanceEllipse(var5, var7, BlockPos.ZERO, var9, this.getEllipseC(var6, var4, var11), var12) : this.signedDistanceCircle(var5, var7, BlockPos.ZERO, var8, random);
        if (var15 < 0.0) {
            final BlockPos var16 = blockPos.offset(var5, var6, var7);
            final double var17 = var10 ? -0.5 : (-6 - random.nextInt(3));
            if (var15 > var17 && random.nextDouble() > 0.9) {
                return;
            }
            this.setIcebergBlock(var16, levelAccessor, random, var4 - var6, var4, var10, var14, blockState);
        }
    }
    
    private void setIcebergBlock(final BlockPos blockPos, final LevelAccessor levelAccessor, final Random random, final int var4, final int var5, final boolean var6, final boolean var7, final BlockState blockState) {
        final BlockState blockState2 = levelAccessor.getBlockState(blockPos);
        final Block var8 = blockState2.getBlock();
        if (blockState2.getMaterial() == Material.AIR || var8 == Blocks.SNOW_BLOCK || var8 == Blocks.ICE || var8 == Blocks.WATER) {
            final boolean var9 = !var6 || random.nextDouble() > 0.05;
            final int var10 = var6 ? 3 : 2;
            if (var7 && var8 != Blocks.WATER && var4 <= random.nextInt(Math.max(1, var5 / var10)) + var5 * 0.6 && var9) {
                this.setBlock(levelAccessor, blockPos, Blocks.SNOW_BLOCK.defaultBlockState());
            }
            else {
                this.setBlock(levelAccessor, blockPos, blockState);
            }
        }
    }
    
    private int getEllipseC(final int var1, final int var2, final int var3) {
        int var4 = var3;
        if (var1 > 0 && var2 - var1 <= 3) {
            var4 -= 4 - (var2 - var1);
        }
        return var4;
    }
    
    private double signedDistanceCircle(final int var1, final int var2, final BlockPos blockPos, final int var4, final Random random) {
        final float var5 = 10.0f * Mth.clamp(random.nextFloat(), 0.2f, 0.8f) / var4;
        return var5 + Math.pow(var1 - blockPos.getX(), 2.0) + Math.pow(var2 - blockPos.getZ(), 2.0) - Math.pow(var4, 2.0);
    }
    
    private double signedDistanceEllipse(final int var1, final int var2, final BlockPos blockPos, final int var4, final int var5, final double var6) {
        return Math.pow(((var1 - blockPos.getX()) * Math.cos(var6) - (var2 - blockPos.getZ()) * Math.sin(var6)) / var4, 2.0) + Math.pow(((var1 - blockPos.getX()) * Math.sin(var6) + (var2 - blockPos.getZ()) * Math.cos(var6)) / var5, 2.0) - 1.0;
    }
    
    private int heightDependentRadiusRound(final Random random, final int var2, final int var3, final int var4) {
        final float var5 = 3.5f - random.nextFloat();
        float var6 = (1.0f - (float)Math.pow(var2, 2.0) / (var3 * var5)) * var4;
        if (var3 > 15 + random.nextInt(5)) {
            final int var7 = (var2 < 3 + random.nextInt(6)) ? (var2 / 2) : var2;
            var6 = (1.0f - var7 / (var3 * var5 * 0.4f)) * var4;
        }
        return Mth.ceil(var6 / 2.0f);
    }
    
    private int heightDependentRadiusEllipse(final int var1, final int var2, final int var3) {
        final float var4 = 1.0f;
        final float var5 = (1.0f - (float)Math.pow(var1, 2.0) / (var2 * 1.0f)) * var3;
        return Mth.ceil(var5 / 2.0f);
    }
    
    private int heightDependentRadiusSteep(final Random random, final int var2, final int var3, final int var4) {
        final float var5 = 1.0f + random.nextFloat() / 2.0f;
        final float var6 = (1.0f - var2 / (var3 * var5)) * var4;
        return Mth.ceil(var6 / 2.0f);
    }
    
    private boolean isIcebergBlock(final Block block) {
        return block == Blocks.PACKED_ICE || block == Blocks.SNOW_BLOCK || block == Blocks.BLUE_ICE;
    }
    
    private boolean belowIsAir(final BlockGetter blockGetter, final BlockPos blockPos) {
        return blockGetter.getBlockState(blockPos.below()).getMaterial() == Material.AIR;
    }
    
    private void smooth(final LevelAccessor levelAccessor, final BlockPos blockPos, final int var3, final int var4, final boolean var5, final int var6) {
        for (int var7 = var5 ? var6 : (var3 / 2), var8 = -var7; var8 <= var7; ++var8) {
            for (int var9 = -var7; var9 <= var7; ++var9) {
                for (int var10 = 0; var10 <= var4; ++var10) {
                    final BlockPos var11 = blockPos.offset(var8, var10, var9);
                    final Block var12 = levelAccessor.getBlockState(var11).getBlock();
                    if (this.isIcebergBlock(var12) || var12 == Blocks.SNOW) {
                        if (this.belowIsAir(levelAccessor, var11)) {
                            this.setBlock(levelAccessor, var11, Blocks.AIR.defaultBlockState());
                            this.setBlock(levelAccessor, var11.above(), Blocks.AIR.defaultBlockState());
                        }
                        else if (this.isIcebergBlock(var12)) {
                            final Block[] vars13 = { levelAccessor.getBlockState(var11.west()).getBlock(), levelAccessor.getBlockState(var11.east()).getBlock(), levelAccessor.getBlockState(var11.north()).getBlock(), levelAccessor.getBlockState(var11.south()).getBlock() };
                            int var13 = 0;
                            for (final Block var14 : vars13) {
                                if (!this.isIcebergBlock(var14)) {
                                    ++var13;
                                }
                            }
                            if (var13 >= 3) {
                                this.setBlock(levelAccessor, var11, Blocks.AIR.defaultBlockState());
                            }
                        }
                    }
                }
            }
        }
    }
}
