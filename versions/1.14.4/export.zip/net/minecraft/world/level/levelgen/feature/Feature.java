package net.minecraft.world.level.levelgen.feature;

import java.util.function.*;
import com.mojang.datafixers.*;
import net.minecraft.core.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.biome.*;
import java.util.*;
import net.minecraft.world.level.levelgen.structure.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.*;
import com.google.common.collect.*;
import net.minecraft.world.level.block.state.*;

public abstract class Feature<FC extends FeatureConfiguration>
{
    public static final StructureFeature<PillagerOutpostConfiguration> PILLAGER_OUTPOST;
    public static final StructureFeature<MineshaftConfiguration> MINESHAFT;
    public static final StructureFeature<NoneFeatureConfiguration> WOODLAND_MANSION;
    public static final StructureFeature<NoneFeatureConfiguration> JUNGLE_TEMPLE;
    public static final StructureFeature<NoneFeatureConfiguration> DESERT_PYRAMID;
    public static final StructureFeature<NoneFeatureConfiguration> IGLOO;
    public static final StructureFeature<ShipwreckConfiguration> SHIPWRECK;
    public static final SwamplandHutFeature SWAMP_HUT;
    public static final StructureFeature<NoneFeatureConfiguration> STRONGHOLD;
    public static final StructureFeature<NoneFeatureConfiguration> OCEAN_MONUMENT;
    public static final StructureFeature<OceanRuinConfiguration> OCEAN_RUIN;
    public static final StructureFeature<NoneFeatureConfiguration> NETHER_BRIDGE;
    public static final StructureFeature<NoneFeatureConfiguration> END_CITY;
    public static final StructureFeature<BuriedTreasureConfiguration> BURIED_TREASURE;
    public static final StructureFeature<VillageConfiguration> VILLAGE;
    public static final Feature<NoneFeatureConfiguration> FANCY_TREE;
    public static final Feature<NoneFeatureConfiguration> BIRCH_TREE;
    public static final Feature<NoneFeatureConfiguration> SUPER_BIRCH_TREE;
    public static final Feature<NoneFeatureConfiguration> JUNGLE_GROUND_BUSH;
    public static final Feature<NoneFeatureConfiguration> JUNGLE_TREE;
    public static final Feature<NoneFeatureConfiguration> PINE_TREE;
    public static final Feature<NoneFeatureConfiguration> DARK_OAK_TREE;
    public static final Feature<NoneFeatureConfiguration> SAVANNA_TREE;
    public static final Feature<NoneFeatureConfiguration> SPRUCE_TREE;
    public static final Feature<NoneFeatureConfiguration> SWAMP_TREE;
    public static final Feature<NoneFeatureConfiguration> NORMAL_TREE;
    public static final Feature<NoneFeatureConfiguration> MEGA_JUNGLE_TREE;
    public static final Feature<NoneFeatureConfiguration> MEGA_PINE_TREE;
    public static final Feature<NoneFeatureConfiguration> MEGA_SPRUCE_TREE;
    public static final FlowerFeature DEFAULT_FLOWER;
    public static final FlowerFeature FOREST_FLOWER;
    public static final FlowerFeature PLAIN_FLOWER;
    public static final FlowerFeature SWAMP_FLOWER;
    public static final FlowerFeature GENERAL_FOREST_FLOWER;
    public static final Feature<NoneFeatureConfiguration> JUNGLE_GRASS;
    public static final Feature<NoneFeatureConfiguration> TAIGA_GRASS;
    public static final Feature<GrassConfiguration> GRASS;
    public static final Feature<NoneFeatureConfiguration> VOID_START_PLATFORM;
    public static final Feature<NoneFeatureConfiguration> CACTUS;
    public static final Feature<NoneFeatureConfiguration> DEAD_BUSH;
    public static final Feature<NoneFeatureConfiguration> DESERT_WELL;
    public static final Feature<NoneFeatureConfiguration> FOSSIL;
    public static final Feature<NoneFeatureConfiguration> HELL_FIRE;
    public static final Feature<HugeMushroomFeatureConfig> HUGE_RED_MUSHROOM;
    public static final Feature<HugeMushroomFeatureConfig> HUGE_BROWN_MUSHROOM;
    public static final Feature<NoneFeatureConfiguration> ICE_SPIKE;
    public static final Feature<NoneFeatureConfiguration> GLOWSTONE_BLOB;
    public static final Feature<NoneFeatureConfiguration> MELON;
    public static final Feature<NoneFeatureConfiguration> PUMPKIN;
    public static final Feature<NoneFeatureConfiguration> REED;
    public static final Feature<NoneFeatureConfiguration> FREEZE_TOP_LAYER;
    public static final Feature<NoneFeatureConfiguration> VINES;
    public static final Feature<NoneFeatureConfiguration> WATERLILY;
    public static final Feature<NoneFeatureConfiguration> MONSTER_ROOM;
    public static final Feature<NoneFeatureConfiguration> BLUE_ICE;
    public static final Feature<IcebergConfiguration> ICEBERG;
    public static final Feature<BlockBlobConfiguration> FOREST_ROCK;
    public static final Feature<NoneFeatureConfiguration> HAY_PILE;
    public static final Feature<NoneFeatureConfiguration> SNOW_PILE;
    public static final Feature<NoneFeatureConfiguration> ICE_PILE;
    public static final Feature<NoneFeatureConfiguration> MELON_PILE;
    public static final Feature<NoneFeatureConfiguration> PUMPKIN_PILE;
    public static final Feature<BushConfiguration> BUSH;
    public static final Feature<DiskConfiguration> DISK;
    public static final Feature<DoublePlantConfiguration> DOUBLE_PLANT;
    public static final Feature<HellSpringConfiguration> NETHER_SPRING;
    public static final Feature<FeatureRadius> ICE_PATCH;
    public static final Feature<LakeConfiguration> LAKE;
    public static final Feature<OreConfiguration> ORE;
    public static final Feature<RandomRandomFeatureConfig> RANDOM_RANDOM_SELECTOR;
    public static final Feature<RandomFeatureConfig> RANDOM_SELECTOR;
    public static final Feature<SimpleRandomFeatureConfig> SIMPLE_RANDOM_SELECTOR;
    public static final Feature<RandomBooleanFeatureConfig> RANDOM_BOOLEAN_SELECTOR;
    public static final Feature<ReplaceBlockConfiguration> EMERALD_ORE;
    public static final Feature<SpringConfiguration> SPRING;
    public static final Feature<SpikeConfiguration> END_SPIKE;
    public static final Feature<NoneFeatureConfiguration> END_ISLAND;
    public static final Feature<NoneFeatureConfiguration> CHORUS_PLANT;
    public static final Feature<EndGatewayConfiguration> END_GATEWAY;
    public static final Feature<SeagrassFeatureConfiguration> SEAGRASS;
    public static final Feature<NoneFeatureConfiguration> KELP;
    public static final Feature<NoneFeatureConfiguration> CORAL_TREE;
    public static final Feature<NoneFeatureConfiguration> CORAL_MUSHROOM;
    public static final Feature<NoneFeatureConfiguration> CORAL_CLAW;
    public static final Feature<CountFeatureConfiguration> SEA_PICKLE;
    public static final Feature<SimpleBlockConfiguration> SIMPLE_BLOCK;
    public static final Feature<ProbabilityFeatureConfiguration> BAMBOO;
    public static final Feature<DecoratedFeatureConfiguration> DECORATED;
    public static final Feature<DecoratedFeatureConfiguration> DECORATED_FLOWER;
    public static final Feature<NoneFeatureConfiguration> SWEET_BERRY_BUSH;
    public static final Feature<LayerConfiguration> FILL_LAYER;
    public static final BonusChestFeature BONUS_CHEST;
    public static final BiMap<String, StructureFeature<?>> STRUCTURES_REGISTRY;
    public static final List<StructureFeature<?>> NOISE_AFFECTING_FEATURES;
    private final Function<Dynamic<?>, ? extends FC> configurationFactory;
    protected final boolean doUpdate;
    
    private static <C extends FeatureConfiguration, F extends Feature<C>> F register(final String string, final F var1) {
        return Registry.register(Registry.FEATURE, string, var1);
    }
    
    public Feature(final Function<Dynamic<?>, ? extends FC> configurationFactory) {
        this.configurationFactory = configurationFactory;
        this.doUpdate = false;
    }
    
    public Feature(final Function<Dynamic<?>, ? extends FC> configurationFactory, final boolean doUpdate) {
        this.configurationFactory = configurationFactory;
        this.doUpdate = doUpdate;
    }
    
    public FC createSettings(final Dynamic<?> dynamic) {
        return (FC)this.configurationFactory.apply(dynamic);
    }
    
    protected void setBlock(final LevelWriter levelWriter, final BlockPos blockPos, final BlockState blockState) {
        if (this.doUpdate) {
            levelWriter.setBlock(blockPos, blockState, 3);
        }
        else {
            levelWriter.setBlock(blockPos, blockState, 2);
        }
    }
    
    public abstract boolean place(final LevelAccessor p0, final ChunkGenerator<? extends ChunkGeneratorSettings> p1, final Random p2, final BlockPos p3, final FC p4);
    
    public List<Biome.SpawnerData> getSpecialEnemies() {
        return Collections.emptyList();
    }
    
    public List<Biome.SpawnerData> getSpecialAnimals() {
        return Collections.emptyList();
    }
    
    static {
        PILLAGER_OUTPOST = register("pillager_outpost", new PillagerOutpostFeature(PillagerOutpostConfiguration::deserialize));
        MINESHAFT = register("mineshaft", new MineshaftFeature(MineshaftConfiguration::deserialize));
        WOODLAND_MANSION = register("woodland_mansion", new WoodlandMansionFeature(NoneFeatureConfiguration::deserialize));
        JUNGLE_TEMPLE = register("jungle_temple", new JunglePyramidFeature(NoneFeatureConfiguration::deserialize));
        DESERT_PYRAMID = register("desert_pyramid", new DesertPyramidFeature(NoneFeatureConfiguration::deserialize));
        IGLOO = register("igloo", new IglooFeature(NoneFeatureConfiguration::deserialize));
        SHIPWRECK = register("shipwreck", new ShipwreckFeature(ShipwreckConfiguration::deserialize));
        SWAMP_HUT = register("swamp_hut", new SwamplandHutFeature(NoneFeatureConfiguration::deserialize));
        STRONGHOLD = register("stronghold", new StrongholdFeature(NoneFeatureConfiguration::deserialize));
        OCEAN_MONUMENT = register("ocean_monument", new OceanMonumentFeature(NoneFeatureConfiguration::deserialize));
        OCEAN_RUIN = register("ocean_ruin", new OceanRuinFeature(OceanRuinConfiguration::deserialize));
        NETHER_BRIDGE = register("nether_bridge", new NetherFortressFeature(NoneFeatureConfiguration::deserialize));
        END_CITY = register("end_city", new EndCityFeature(NoneFeatureConfiguration::deserialize));
        BURIED_TREASURE = register("buried_treasure", new BuriedTreasureFeature(BuriedTreasureConfiguration::deserialize));
        VILLAGE = register("village", new VillageFeature(VillageConfiguration::deserialize));
        FANCY_TREE = register("fancy_tree", new BigTreeFeature(NoneFeatureConfiguration::deserialize, false));
        BIRCH_TREE = register("birch_tree", new BirchFeature(NoneFeatureConfiguration::deserialize, false, false));
        SUPER_BIRCH_TREE = register("super_birch_tree", new BirchFeature(NoneFeatureConfiguration::deserialize, false, true));
        JUNGLE_GROUND_BUSH = register("jungle_ground_bush", new GroundBushFeature(NoneFeatureConfiguration::deserialize, Blocks.JUNGLE_LOG.defaultBlockState(), Blocks.OAK_LEAVES.defaultBlockState()));
        JUNGLE_TREE = register("jungle_tree", new JungleTreeFeature(NoneFeatureConfiguration::deserialize, false, 4, Blocks.JUNGLE_LOG.defaultBlockState(), Blocks.JUNGLE_LEAVES.defaultBlockState(), true));
        PINE_TREE = register("pine_tree", new PineFeature(NoneFeatureConfiguration::deserialize));
        DARK_OAK_TREE = register("dark_oak_tree", new DarkOakFeature(NoneFeatureConfiguration::deserialize, false));
        SAVANNA_TREE = register("savanna_tree", new SavannaTreeFeature(NoneFeatureConfiguration::deserialize, false));
        SPRUCE_TREE = register("spruce_tree", new SpruceFeature(NoneFeatureConfiguration::deserialize, false));
        SWAMP_TREE = register("swamp_tree", new SwampTreeFeature(NoneFeatureConfiguration::deserialize));
        NORMAL_TREE = register("normal_tree", new TreeFeature(NoneFeatureConfiguration::deserialize, false));
        MEGA_JUNGLE_TREE = register("mega_jungle_tree", new MegaJungleTreeFeature(NoneFeatureConfiguration::deserialize, false, 10, 20, Blocks.JUNGLE_LOG.defaultBlockState(), Blocks.JUNGLE_LEAVES.defaultBlockState()));
        MEGA_PINE_TREE = register("mega_pine_tree", new MegaPineTreeFeature(NoneFeatureConfiguration::deserialize, false, false));
        MEGA_SPRUCE_TREE = register("mega_spruce_tree", new MegaPineTreeFeature(NoneFeatureConfiguration::deserialize, false, true));
        DEFAULT_FLOWER = register("default_flower", new DefaultFlowerFeature(NoneFeatureConfiguration::deserialize));
        FOREST_FLOWER = register("forest_flower", new ForestFlowerFeature(NoneFeatureConfiguration::deserialize));
        PLAIN_FLOWER = register("plain_flower", new PlainFlowerFeature(NoneFeatureConfiguration::deserialize));
        SWAMP_FLOWER = register("swamp_flower", new SwampFlowerFeature(NoneFeatureConfiguration::deserialize));
        GENERAL_FOREST_FLOWER = register("general_forest_flower", new GeneralForestFlowerFeature(NoneFeatureConfiguration::deserialize));
        JUNGLE_GRASS = register("jungle_grass", new JungleGrassFeature(NoneFeatureConfiguration::deserialize));
        TAIGA_GRASS = register("taiga_grass", new TaigaGrassFeature(NoneFeatureConfiguration::deserialize));
        GRASS = register("grass", new GrassFeature(GrassConfiguration::deserialize));
        VOID_START_PLATFORM = register("void_start_platform", new VoidStartPlatformFeature(NoneFeatureConfiguration::deserialize));
        CACTUS = register("cactus", new CactusFeature(NoneFeatureConfiguration::deserialize));
        DEAD_BUSH = register("dead_bush", new DeadBushFeature(NoneFeatureConfiguration::deserialize));
        DESERT_WELL = register("desert_well", new DesertWellFeature(NoneFeatureConfiguration::deserialize));
        FOSSIL = register("fossil", new FossilFeature(NoneFeatureConfiguration::deserialize));
        HELL_FIRE = register("hell_fire", new HellFireFeature(NoneFeatureConfiguration::deserialize));
        HUGE_RED_MUSHROOM = register("huge_red_mushroom", new HugeRedMushroomFeature(HugeMushroomFeatureConfig::deserialize));
        HUGE_BROWN_MUSHROOM = register("huge_brown_mushroom", new HugeBrownMushroomFeature(HugeMushroomFeatureConfig::deserialize));
        ICE_SPIKE = register("ice_spike", new IceSpikeFeature(NoneFeatureConfiguration::deserialize));
        GLOWSTONE_BLOB = register("glowstone_blob", new GlowstoneFeature(NoneFeatureConfiguration::deserialize));
        MELON = register("melon", new MelonFeature(NoneFeatureConfiguration::deserialize));
        PUMPKIN = register("pumpkin", new CentralSpikedFeature(NoneFeatureConfiguration::deserialize, Blocks.PUMPKIN.defaultBlockState()));
        REED = register("reed", new ReedsFeature(NoneFeatureConfiguration::deserialize));
        FREEZE_TOP_LAYER = register("freeze_top_layer", new SnowAndFreezeFeature(NoneFeatureConfiguration::deserialize));
        VINES = register("vines", new VinesFeature(NoneFeatureConfiguration::deserialize));
        WATERLILY = register("waterlily", new WaterlilyFeature(NoneFeatureConfiguration::deserialize));
        MONSTER_ROOM = register("monster_room", new MonsterRoomFeature(NoneFeatureConfiguration::deserialize));
        BLUE_ICE = register("blue_ice", new BlueIceFeature(NoneFeatureConfiguration::deserialize));
        ICEBERG = register("iceberg", new IcebergFeature(IcebergConfiguration::deserialize));
        FOREST_ROCK = register("forest_rock", new BlockBlobFeature(BlockBlobConfiguration::deserialize));
        HAY_PILE = register("hay_pile", new HayBlockPileFeature(NoneFeatureConfiguration::deserialize));
        SNOW_PILE = register("snow_pile", new SnowBlockPileFeature(NoneFeatureConfiguration::deserialize));
        ICE_PILE = register("ice_pile", new IceBlockPileFeature(NoneFeatureConfiguration::deserialize));
        MELON_PILE = register("melon_pile", new MelonBlockPileFeature(NoneFeatureConfiguration::deserialize));
        PUMPKIN_PILE = register("pumpkin_pile", new PumpkinBlockPileFeature(NoneFeatureConfiguration::deserialize));
        BUSH = register("bush", new BushFeature(BushConfiguration::deserialize));
        DISK = register("disk", new DiskReplaceFeature(DiskConfiguration::deserialize));
        DOUBLE_PLANT = register("double_plant", new DoublePlantFeature(DoublePlantConfiguration::deserialize));
        NETHER_SPRING = register("nether_spring", new NetherSpringFeature(HellSpringConfiguration::deserialize));
        ICE_PATCH = register("ice_patch", new IcePatchFeature(FeatureRadius::deserialize));
        LAKE = register("lake", new LakeFeature(LakeConfiguration::deserialize));
        ORE = register("ore", new OreFeature(OreConfiguration::deserialize));
        RANDOM_RANDOM_SELECTOR = register("random_random_selector", new RandomRandomFeature(RandomRandomFeatureConfig::deserialize));
        RANDOM_SELECTOR = register("random_selector", new RandomSelectorFeature(RandomFeatureConfig::deserialize));
        SIMPLE_RANDOM_SELECTOR = register("simple_random_selector", new SimpleRandomSelectorFeature(SimpleRandomFeatureConfig::deserialize));
        RANDOM_BOOLEAN_SELECTOR = register("random_boolean_selector", new RandomBooleanSelectorFeature(RandomBooleanFeatureConfig::deserialize));
        EMERALD_ORE = register("emerald_ore", new ReplaceBlockFeature(ReplaceBlockConfiguration::deserialize));
        SPRING = register("spring_feature", new SpringFeature(SpringConfiguration::deserialize));
        END_SPIKE = register("end_spike", new SpikeFeature(SpikeConfiguration::deserialize));
        END_ISLAND = register("end_island", new EndIslandFeature(NoneFeatureConfiguration::deserialize));
        CHORUS_PLANT = register("chorus_plant", new ChorusPlantFeature(NoneFeatureConfiguration::deserialize));
        END_GATEWAY = register("end_gateway", new EndGatewayFeature(EndGatewayConfiguration::deserialize));
        SEAGRASS = register("seagrass", new SeagrassFeature(SeagrassFeatureConfiguration::deserialize));
        KELP = register("kelp", new KelpFeature(NoneFeatureConfiguration::deserialize));
        CORAL_TREE = register("coral_tree", new CoralTreeFeature(NoneFeatureConfiguration::deserialize));
        CORAL_MUSHROOM = register("coral_mushroom", new CoralMushroomFeature(NoneFeatureConfiguration::deserialize));
        CORAL_CLAW = register("coral_claw", new CoralClawFeature(NoneFeatureConfiguration::deserialize));
        SEA_PICKLE = register("sea_pickle", new SeaPickleFeature(CountFeatureConfiguration::deserialize));
        SIMPLE_BLOCK = register("simple_block", new SimpleBlockFeature(SimpleBlockConfiguration::deserialize));
        BAMBOO = register("bamboo", new BambooFeature(ProbabilityFeatureConfiguration::deserialize));
        DECORATED = register("decorated", new DecoratedFeature(DecoratedFeatureConfiguration::deserialize));
        DECORATED_FLOWER = register("decorated_flower", new DecoratedFlowerFeature(DecoratedFeatureConfiguration::deserialize));
        SWEET_BERRY_BUSH = register("sweet_berry_bush", new CentralSpikedFeature(NoneFeatureConfiguration::deserialize, ((AbstractStateHolder<O, BlockState>)Blocks.SWEET_BERRY_BUSH.defaultBlockState()).setValue((Property<Comparable>)SweetBerryBushBlock.AGE, 3)));
        FILL_LAYER = register("fill_layer", new FillLayerFeature(LayerConfiguration::deserialize));
        BONUS_CHEST = register("bonus_chest", new BonusChestFeature(NoneFeatureConfiguration::deserialize));
        STRUCTURES_REGISTRY = Util.make((BiMap)HashBiMap.create(), hashBiMap -> {
            hashBiMap.put((Object)"Pillager_Outpost".toLowerCase(Locale.ROOT), (Object)Feature.PILLAGER_OUTPOST);
            hashBiMap.put((Object)"Mineshaft".toLowerCase(Locale.ROOT), (Object)Feature.MINESHAFT);
            hashBiMap.put((Object)"Mansion".toLowerCase(Locale.ROOT), (Object)Feature.WOODLAND_MANSION);
            hashBiMap.put((Object)"Jungle_Pyramid".toLowerCase(Locale.ROOT), (Object)Feature.JUNGLE_TEMPLE);
            hashBiMap.put((Object)"Desert_Pyramid".toLowerCase(Locale.ROOT), (Object)Feature.DESERT_PYRAMID);
            hashBiMap.put((Object)"Igloo".toLowerCase(Locale.ROOT), (Object)Feature.IGLOO);
            hashBiMap.put((Object)"Shipwreck".toLowerCase(Locale.ROOT), (Object)Feature.SHIPWRECK);
            hashBiMap.put((Object)"Swamp_Hut".toLowerCase(Locale.ROOT), (Object)Feature.SWAMP_HUT);
            hashBiMap.put((Object)"Stronghold".toLowerCase(Locale.ROOT), (Object)Feature.STRONGHOLD);
            hashBiMap.put((Object)"Monument".toLowerCase(Locale.ROOT), (Object)Feature.OCEAN_MONUMENT);
            hashBiMap.put((Object)"Ocean_Ruin".toLowerCase(Locale.ROOT), (Object)Feature.OCEAN_RUIN);
            hashBiMap.put((Object)"Fortress".toLowerCase(Locale.ROOT), (Object)Feature.NETHER_BRIDGE);
            hashBiMap.put((Object)"EndCity".toLowerCase(Locale.ROOT), (Object)Feature.END_CITY);
            hashBiMap.put((Object)"Buried_Treasure".toLowerCase(Locale.ROOT), (Object)Feature.BURIED_TREASURE);
            hashBiMap.put((Object)"Village".toLowerCase(Locale.ROOT), (Object)Feature.VILLAGE);
            return;
        });
        NOISE_AFFECTING_FEATURES = (List)ImmutableList.of((Object)Feature.PILLAGER_OUTPOST, (Object)Feature.VILLAGE);
    }
}
