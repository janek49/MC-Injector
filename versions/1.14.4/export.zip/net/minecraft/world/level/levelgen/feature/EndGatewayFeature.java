package net.minecraft.world.level.levelgen.feature;

import java.util.function.*;
import com.mojang.datafixers.*;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.core.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.*;
import java.util.*;
import net.minecraft.world.level.block.entity.*;

public class EndGatewayFeature extends Feature<EndGatewayConfiguration>
{
    public EndGatewayFeature(final Function<Dynamic<?>, ? extends EndGatewayConfiguration> function) {
        super(function);
    }
    
    @Override
    public boolean place(final LevelAccessor levelAccessor, final ChunkGenerator<? extends ChunkGeneratorSettings> chunkGenerator, final Random random, final BlockPos blockPos, final EndGatewayConfiguration endGatewayConfiguration) {
        for (final BlockPos var4 : BlockPos.betweenClosed(blockPos.offset(-1, -2, -1), blockPos.offset(1, 2, 1))) {
            final boolean var5 = var4.getX() == blockPos.getX();
            final boolean var6 = var4.getY() == blockPos.getY();
            final boolean var7 = var4.getZ() == blockPos.getZ();
            final boolean var8 = Math.abs(var4.getY() - blockPos.getY()) == 2;
            if (var5 && var6 && var7) {
                final BlockPos var9 = var4.immutable();
                this.setBlock(levelAccessor, var9, Blocks.END_GATEWAY.defaultBlockState());
                final BlockEntity var10;
                TheEndGatewayBlockEntity var11;
                endGatewayConfiguration.getExit().ifPresent(var3 -> {
                    var10 = levelAccessor.getBlockEntity(var9);
                    if (var10 instanceof TheEndGatewayBlockEntity) {
                        var11 = (TheEndGatewayBlockEntity)var10;
                        var11.setExitPosition(var3, endGatewayConfiguration.isExitExact());
                        var10.setChanged();
                    }
                    return;
                });
            }
            else if (var6) {
                this.setBlock(levelAccessor, var4, Blocks.AIR.defaultBlockState());
            }
            else if (var8 && var5 && var7) {
                this.setBlock(levelAccessor, var4, Blocks.BEDROCK.defaultBlockState());
            }
            else if ((!var5 && !var7) || var8) {
                this.setBlock(levelAccessor, var4, Blocks.AIR.defaultBlockState());
            }
            else {
                this.setBlock(levelAccessor, var4, Blocks.BEDROCK.defaultBlockState());
            }
        }
        return true;
    }
}
