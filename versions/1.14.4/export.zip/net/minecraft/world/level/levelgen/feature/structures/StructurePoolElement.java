package net.minecraft.world.level.levelgen.feature.structures;

import javax.annotation.*;
import com.mojang.datafixers.*;
import net.minecraft.world.level.block.*;
import java.util.*;
import net.minecraft.world.level.levelgen.structure.templatesystem.*;
import net.minecraft.world.level.levelgen.structure.*;
import net.minecraft.world.level.*;
import com.mojang.datafixers.types.*;
import net.minecraft.core.*;

public abstract class StructurePoolElement
{
    @Nullable
    private volatile StructureTemplatePool.Projection projection;
    
    protected StructurePoolElement(final StructureTemplatePool.Projection projection) {
        this.projection = projection;
    }
    
    protected StructurePoolElement(final Dynamic<?> dynamic) {
        this.projection = StructureTemplatePool.Projection.byName(dynamic.get("projection").asString(StructureTemplatePool.Projection.RIGID.getName()));
    }
    
    public abstract List<StructureTemplate.StructureBlockInfo> getShuffledJigsawBlocks(final StructureManager p0, final BlockPos p1, final Rotation p2, final Random p3);
    
    public abstract BoundingBox getBoundingBox(final StructureManager p0, final BlockPos p1, final Rotation p2);
    
    public abstract boolean place(final StructureManager p0, final LevelAccessor p1, final BlockPos p2, final Rotation p3, final BoundingBox p4, final Random p5);
    
    public abstract StructurePoolElementType getType();
    
    public void handleDataMarker(final LevelAccessor levelAccessor, final StructureTemplate.StructureBlockInfo structureTemplate$StructureBlockInfo, final BlockPos blockPos, final Rotation rotation, final Random random, final BoundingBox boundingBox) {
    }
    
    public StructurePoolElement setProjection(final StructureTemplatePool.Projection projection) {
        this.projection = projection;
        return this;
    }
    
    public StructureTemplatePool.Projection getProjection() {
        final StructureTemplatePool.Projection structureTemplatePool$Projection = this.projection;
        if (structureTemplatePool$Projection == null) {
            throw new IllegalStateException();
        }
        return structureTemplatePool$Projection;
    }
    
    protected abstract <T> Dynamic<T> getDynamic(final DynamicOps<T> p0);
    
    public <T> Dynamic<T> serialize(final DynamicOps<T> dynamicOps) {
        final T var2 = (T)this.getDynamic((com.mojang.datafixers.types.DynamicOps<Object>)dynamicOps).getValue();
        final T var3 = (T)dynamicOps.mergeInto((Object)var2, dynamicOps.createString("element_type"), dynamicOps.createString(Registry.STRUCTURE_POOL_ELEMENT.getKey(this.getType()).toString()));
        return (Dynamic<T>)new Dynamic((DynamicOps)dynamicOps, dynamicOps.mergeInto((Object)var3, dynamicOps.createString("projection"), dynamicOps.createString(this.projection.getName())));
    }
    
    public int getGroundLevelDelta() {
        return 1;
    }
}
