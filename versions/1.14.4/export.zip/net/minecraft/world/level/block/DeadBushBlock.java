package net.minecraft.world.level.block;

import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.*;
import net.minecraft.core.*;
import net.minecraft.world.phys.shapes.*;

public class DeadBushBlock extends BushBlock
{
    protected static final VoxelShape SHAPE;
    
    protected DeadBushBlock(final Properties block$Properties) {
        super(block$Properties);
    }
    
    @Override
    public VoxelShape getShape(final BlockState blockState, final BlockGetter blockGetter, final BlockPos blockPos, final CollisionContext collisionContext) {
        return DeadBushBlock.SHAPE;
    }
    
    @Override
    protected boolean mayPlaceOn(final BlockState blockState, final BlockGetter blockGetter, final BlockPos blockPos) {
        final Block var4 = blockState.getBlock();
        return var4 == Blocks.SAND || var4 == Blocks.RED_SAND || var4 == Blocks.TERRACOTTA || var4 == Blocks.WHITE_TERRACOTTA || var4 == Blocks.ORANGE_TERRACOTTA || var4 == Blocks.MAGENTA_TERRACOTTA || var4 == Blocks.LIGHT_BLUE_TERRACOTTA || var4 == Blocks.YELLOW_TERRACOTTA || var4 == Blocks.LIME_TERRACOTTA || var4 == Blocks.PINK_TERRACOTTA || var4 == Blocks.GRAY_TERRACOTTA || var4 == Blocks.LIGHT_GRAY_TERRACOTTA || var4 == Blocks.CYAN_TERRACOTTA || var4 == Blocks.PURPLE_TERRACOTTA || var4 == Blocks.BLUE_TERRACOTTA || var4 == Blocks.BROWN_TERRACOTTA || var4 == Blocks.GREEN_TERRACOTTA || var4 == Blocks.RED_TERRACOTTA || var4 == Blocks.BLACK_TERRACOTTA || var4 == Blocks.DIRT || var4 == Blocks.COARSE_DIRT || var4 == Blocks.PODZOL;
    }
    
    static {
        SHAPE = Block.box(2.0, 0.0, 2.0, 14.0, 13.0, 14.0);
    }
}
