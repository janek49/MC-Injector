package net.minecraft.world.level.block;

import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.*;
import net.minecraft.core.*;
import net.minecraft.world.phys.shapes.*;

public class BaseCoralPlantBlock extends BaseCoralPlantTypeBlock
{
    protected static final VoxelShape SHAPE;
    
    protected BaseCoralPlantBlock(final Properties block$Properties) {
        super(block$Properties);
    }
    
    @Override
    public VoxelShape getShape(final BlockState blockState, final BlockGetter blockGetter, final BlockPos blockPos, final CollisionContext collisionContext) {
        return BaseCoralPlantBlock.SHAPE;
    }
    
    static {
        SHAPE = Block.box(2.0, 0.0, 2.0, 14.0, 15.0, 14.0);
    }
}
