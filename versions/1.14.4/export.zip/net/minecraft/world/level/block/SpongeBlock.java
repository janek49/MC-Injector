package net.minecraft.world.level.block;

import net.minecraft.world.level.block.state.*;
import com.google.common.collect.*;
import net.minecraft.util.*;
import net.minecraft.core.*;
import net.minecraft.tags.*;
import net.minecraft.world.level.*;
import java.util.*;
import net.minecraft.world.level.material.*;
import net.minecraft.world.level.block.entity.*;

public class SpongeBlock extends Block
{
    protected SpongeBlock(final Properties block$Properties) {
        super(block$Properties);
    }
    
    @Override
    public void onPlace(final BlockState var1, final Level level, final BlockPos blockPos, final BlockState var4, final boolean var5) {
        if (var4.getBlock() == var1.getBlock()) {
            return;
        }
        this.tryAbsorbWater(level, blockPos);
    }
    
    @Override
    public void neighborChanged(final BlockState blockState, final Level level, final BlockPos var3, final Block block, final BlockPos var5, final boolean var6) {
        this.tryAbsorbWater(level, var3);
        super.neighborChanged(blockState, level, var3, block, var5, var6);
    }
    
    protected void tryAbsorbWater(final Level level, final BlockPos blockPos) {
        if (this.removeWaterBreadthFirstSearch(level, blockPos)) {
            level.setBlock(blockPos, Blocks.WET_SPONGE.defaultBlockState(), 2);
            level.levelEvent(2001, blockPos, Block.getId(Blocks.WATER.defaultBlockState()));
        }
    }
    
    private boolean removeWaterBreadthFirstSearch(final Level level, final BlockPos blockPos) {
        final Queue<Tuple<BlockPos, Integer>> var3 = (Queue<Tuple<BlockPos, Integer>>)Lists.newLinkedList();
        var3.add(new Tuple<BlockPos, Integer>(blockPos, 0));
        int var4 = 0;
        while (!var3.isEmpty()) {
            final Tuple<BlockPos, Integer> var5 = var3.poll();
            final BlockPos var6 = var5.getA();
            final int var7 = var5.getB();
            for (final Direction var8 : Direction.values()) {
                final BlockPos var9 = var6.relative(var8);
                final BlockState var10 = level.getBlockState(var9);
                final FluidState var11 = level.getFluidState(var9);
                final Material var12 = var10.getMaterial();
                if (var11.is(FluidTags.WATER)) {
                    if (var10.getBlock() instanceof BucketPickup && ((BucketPickup)var10.getBlock()).takeLiquid(level, var9, var10) != Fluids.EMPTY) {
                        ++var4;
                        if (var7 < 6) {
                            var3.add(new Tuple<BlockPos, Integer>(var9, var7 + 1));
                        }
                    }
                    else if (var10.getBlock() instanceof LiquidBlock) {
                        level.setBlock(var9, Blocks.AIR.defaultBlockState(), 3);
                        ++var4;
                        if (var7 < 6) {
                            var3.add(new Tuple<BlockPos, Integer>(var9, var7 + 1));
                        }
                    }
                    else if (var12 == Material.WATER_PLANT || var12 == Material.REPLACEABLE_WATER_PLANT) {
                        final BlockEntity var13 = var10.getBlock().isEntityBlock() ? level.getBlockEntity(var9) : null;
                        Block.dropResources(var10, level, var9, var13);
                        level.setBlock(var9, Blocks.AIR.defaultBlockState(), 3);
                        ++var4;
                        if (var7 < 6) {
                            var3.add(new Tuple<BlockPos, Integer>(var9, var7 + 1));
                        }
                    }
                }
            }
            if (var4 > 64) {
                break;
            }
        }
        return var4 > 0;
    }
}
