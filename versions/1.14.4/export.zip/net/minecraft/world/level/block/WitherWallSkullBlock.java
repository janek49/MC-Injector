package net.minecraft.world.level.block;

import net.minecraft.world.level.*;
import net.minecraft.core.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.entity.*;
import javax.annotation.*;
import net.minecraft.world.item.*;

public class WitherWallSkullBlock extends WallSkullBlock
{
    protected WitherWallSkullBlock(final Properties block$Properties) {
        super(SkullBlock.Types.WITHER_SKELETON, block$Properties);
    }
    
    @Override
    public void setPlacedBy(final Level level, final BlockPos blockPos, final BlockState blockState, @Nullable final LivingEntity livingEntity, final ItemStack itemStack) {
        Blocks.WITHER_SKELETON_SKULL.setPlacedBy(level, blockPos, blockState, livingEntity, itemStack);
    }
}
