package net.minecraft.world.level.block;

import net.minecraft.world.level.block.state.properties.*;

public abstract class DirectionalBlock extends Block
{
    public static final DirectionProperty FACING;
    
    protected DirectionalBlock(final Properties block$Properties) {
        super(block$Properties);
    }
    
    static {
        FACING = BlockStateProperties.FACING;
    }
}
