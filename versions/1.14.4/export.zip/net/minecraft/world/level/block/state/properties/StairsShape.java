package net.minecraft.world.level.block.state.properties;

import net.minecraft.util.*;

public enum StairsShape implements StringRepresentable
{
    STRAIGHT("STRAIGHT", 0, "straight"), 
    INNER_LEFT("INNER_LEFT", 1, "inner_left"), 
    INNER_RIGHT("INNER_RIGHT", 2, "inner_right"), 
    OUTER_LEFT("OUTER_LEFT", 3, "outer_left"), 
    OUTER_RIGHT("OUTER_RIGHT", 4, "outer_right");
    
    private final String name;
    
    private StairsShape(final String s, final int n, final String name) {
        this.name = name;
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    @Override
    public String getSerializedName() {
        return this.name;
    }
}
