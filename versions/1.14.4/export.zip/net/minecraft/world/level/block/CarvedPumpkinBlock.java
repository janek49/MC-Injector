package net.minecraft.world.level.block;

import javax.annotation.*;
import java.util.function.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.core.*;
import net.minecraft.world.level.*;
import net.minecraft.world.entity.*;
import net.minecraft.server.level.*;
import net.minecraft.advancements.*;
import net.minecraft.world.entity.animal.*;
import java.util.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.state.pattern.*;
import net.minecraft.world.level.material.*;
import net.minecraft.world.level.block.state.predicate.*;
import net.minecraft.world.level.block.state.*;

public class CarvedPumpkinBlock extends HorizontalDirectionalBlock
{
    public static final DirectionProperty FACING;
    @Nullable
    private BlockPattern snowGolemBase;
    @Nullable
    private BlockPattern snowGolemFull;
    @Nullable
    private BlockPattern ironGolemBase;
    @Nullable
    private BlockPattern ironGolemFull;
    private static final Predicate<BlockState> PUMPKINS_PREDICATE;
    
    protected CarvedPumpkinBlock(final Properties block$Properties) {
        super(block$Properties);
        this.registerDefaultState(((AbstractStateHolder<O, BlockState>)this.stateDefinition.any()).setValue((Property<Comparable>)CarvedPumpkinBlock.FACING, Direction.NORTH));
    }
    
    @Override
    public void onPlace(final BlockState var1, final Level level, final BlockPos blockPos, final BlockState var4, final boolean var5) {
        if (var4.getBlock() == var1.getBlock()) {
            return;
        }
        this.trySpawnGolem(level, blockPos);
    }
    
    public boolean canSpawnGolem(final LevelReader levelReader, final BlockPos blockPos) {
        return this.getOrCreateSnowGolemBase().find(levelReader, blockPos) != null || this.getOrCreateIronGolemBase().find(levelReader, blockPos) != null;
    }
    
    private void trySpawnGolem(final Level level, final BlockPos blockPos) {
        BlockPattern.BlockPatternMatch var3 = this.getOrCreateSnowGolemFull().find(level, blockPos);
        if (var3 != null) {
            for (int var4 = 0; var4 < this.getOrCreateSnowGolemFull().getHeight(); ++var4) {
                final BlockInWorld var5 = var3.getBlock(0, var4, 0);
                level.setBlock(var5.getPos(), Blocks.AIR.defaultBlockState(), 2);
                level.levelEvent(2001, var5.getPos(), Block.getId(var5.getState()));
            }
            final SnowGolem var6 = EntityType.SNOW_GOLEM.create(level);
            final BlockPos var7 = var3.getBlock(0, 2, 0).getPos();
            var6.moveTo(var7.getX() + 0.5, var7.getY() + 0.05, var7.getZ() + 0.5, 0.0f, 0.0f);
            level.addFreshEntity(var6);
            for (final ServerPlayer var8 : level.getEntitiesOfClass((Class<? extends ServerPlayer>)ServerPlayer.class, var6.getBoundingBox().inflate(5.0))) {
                CriteriaTriggers.SUMMONED_ENTITY.trigger(var8, var6);
            }
            for (int var9 = 0; var9 < this.getOrCreateSnowGolemFull().getHeight(); ++var9) {
                final BlockInWorld var10 = var3.getBlock(0, var9, 0);
                level.blockUpdated(var10.getPos(), Blocks.AIR);
            }
        }
        else {
            var3 = this.getOrCreateIronGolemFull().find(level, blockPos);
            if (var3 != null) {
                for (int var4 = 0; var4 < this.getOrCreateIronGolemFull().getWidth(); ++var4) {
                    for (int var11 = 0; var11 < this.getOrCreateIronGolemFull().getHeight(); ++var11) {
                        final BlockInWorld var12 = var3.getBlock(var4, var11, 0);
                        level.setBlock(var12.getPos(), Blocks.AIR.defaultBlockState(), 2);
                        level.levelEvent(2001, var12.getPos(), Block.getId(var12.getState()));
                    }
                }
                final BlockPos var13 = var3.getBlock(1, 2, 0).getPos();
                final IronGolem var14 = EntityType.IRON_GOLEM.create(level);
                var14.setPlayerCreated(true);
                var14.moveTo(var13.getX() + 0.5, var13.getY() + 0.05, var13.getZ() + 0.5, 0.0f, 0.0f);
                level.addFreshEntity(var14);
                for (final ServerPlayer var8 : level.getEntitiesOfClass((Class<? extends ServerPlayer>)ServerPlayer.class, var14.getBoundingBox().inflate(5.0))) {
                    CriteriaTriggers.SUMMONED_ENTITY.trigger(var8, var14);
                }
                for (int var9 = 0; var9 < this.getOrCreateIronGolemFull().getWidth(); ++var9) {
                    for (int var15 = 0; var15 < this.getOrCreateIronGolemFull().getHeight(); ++var15) {
                        final BlockInWorld var16 = var3.getBlock(var9, var15, 0);
                        level.blockUpdated(var16.getPos(), Blocks.AIR);
                    }
                }
            }
        }
    }
    
    @Override
    public BlockState getStateForPlacement(final BlockPlaceContext blockPlaceContext) {
        return ((AbstractStateHolder<O, BlockState>)this.defaultBlockState()).setValue((Property<Comparable>)CarvedPumpkinBlock.FACING, blockPlaceContext.getHorizontalDirection().getOpposite());
    }
    
    @Override
    protected void createBlockStateDefinition(final StateDefinition.Builder<Block, BlockState> stateDefinition$Builder) {
        stateDefinition$Builder.add(CarvedPumpkinBlock.FACING);
    }
    
    private BlockPattern getOrCreateSnowGolemBase() {
        if (this.snowGolemBase == null) {
            this.snowGolemBase = BlockPatternBuilder.start().aisle(" ", "#", "#").where('#', BlockInWorld.hasState(BlockStatePredicate.forBlock(Blocks.SNOW_BLOCK))).build();
        }
        return this.snowGolemBase;
    }
    
    private BlockPattern getOrCreateSnowGolemFull() {
        if (this.snowGolemFull == null) {
            this.snowGolemFull = BlockPatternBuilder.start().aisle("^", "#", "#").where('^', BlockInWorld.hasState(CarvedPumpkinBlock.PUMPKINS_PREDICATE)).where('#', BlockInWorld.hasState(BlockStatePredicate.forBlock(Blocks.SNOW_BLOCK))).build();
        }
        return this.snowGolemFull;
    }
    
    private BlockPattern getOrCreateIronGolemBase() {
        if (this.ironGolemBase == null) {
            this.ironGolemBase = BlockPatternBuilder.start().aisle("~ ~", "###", "~#~").where('#', BlockInWorld.hasState(BlockStatePredicate.forBlock(Blocks.IRON_BLOCK))).where('~', BlockInWorld.hasState(BlockMaterialPredicate.forMaterial(Material.AIR))).build();
        }
        return this.ironGolemBase;
    }
    
    private BlockPattern getOrCreateIronGolemFull() {
        if (this.ironGolemFull == null) {
            this.ironGolemFull = BlockPatternBuilder.start().aisle("~^~", "###", "~#~").where('^', BlockInWorld.hasState(CarvedPumpkinBlock.PUMPKINS_PREDICATE)).where('#', BlockInWorld.hasState(BlockStatePredicate.forBlock(Blocks.IRON_BLOCK))).where('~', BlockInWorld.hasState(BlockMaterialPredicate.forMaterial(Material.AIR))).build();
        }
        return this.ironGolemFull;
    }
    
    static {
        FACING = HorizontalDirectionalBlock.FACING;
        PUMPKINS_PREDICATE = (blockState -> blockState != null && (blockState.getBlock() == Blocks.CARVED_PUMPKIN || blockState.getBlock() == Blocks.JACK_O_LANTERN));
    }
}
