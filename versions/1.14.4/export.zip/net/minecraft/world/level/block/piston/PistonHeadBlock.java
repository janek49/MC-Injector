package net.minecraft.world.level.block.piston;

import net.minecraft.core.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.pathfinder.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.level.block.state.*;

public class PistonHeadBlock extends DirectionalBlock
{
    public static final EnumProperty<PistonType> TYPE;
    public static final BooleanProperty SHORT;
    protected static final VoxelShape EAST_AABB;
    protected static final VoxelShape WEST_AABB;
    protected static final VoxelShape SOUTH_AABB;
    protected static final VoxelShape NORTH_AABB;
    protected static final VoxelShape UP_AABB;
    protected static final VoxelShape DOWN_AABB;
    protected static final VoxelShape UP_ARM_AABB;
    protected static final VoxelShape DOWN_ARM_AABB;
    protected static final VoxelShape SOUTH_ARM_AABB;
    protected static final VoxelShape NORTH_ARM_AABB;
    protected static final VoxelShape EAST_ARM_AABB;
    protected static final VoxelShape WEST_ARM_AABB;
    protected static final VoxelShape SHORT_UP_ARM_AABB;
    protected static final VoxelShape SHORT_DOWN_ARM_AABB;
    protected static final VoxelShape SHORT_SOUTH_ARM_AABB;
    protected static final VoxelShape SHORT_NORTH_ARM_AABB;
    protected static final VoxelShape SHORT_EAST_ARM_AABB;
    protected static final VoxelShape SHORT_WEST_ARM_AABB;
    
    public PistonHeadBlock(final Properties block$Properties) {
        super(block$Properties);
        this.registerDefaultState(((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)this.stateDefinition.any()).setValue((Property<Comparable>)PistonHeadBlock.FACING, Direction.NORTH)).setValue(PistonHeadBlock.TYPE, PistonType.DEFAULT)).setValue((Property<Comparable>)PistonHeadBlock.SHORT, false));
    }
    
    private VoxelShape getBaseShape(final BlockState blockState) {
        switch (blockState.getValue((Property<Direction>)PistonHeadBlock.FACING)) {
            default: {
                return PistonHeadBlock.DOWN_AABB;
            }
            case UP: {
                return PistonHeadBlock.UP_AABB;
            }
            case NORTH: {
                return PistonHeadBlock.NORTH_AABB;
            }
            case SOUTH: {
                return PistonHeadBlock.SOUTH_AABB;
            }
            case WEST: {
                return PistonHeadBlock.WEST_AABB;
            }
            case EAST: {
                return PistonHeadBlock.EAST_AABB;
            }
        }
    }
    
    @Override
    public boolean useShapeForLightOcclusion(final BlockState blockState) {
        return true;
    }
    
    @Override
    public VoxelShape getShape(final BlockState blockState, final BlockGetter blockGetter, final BlockPos blockPos, final CollisionContext collisionContext) {
        return Shapes.or(this.getBaseShape(blockState), this.getArmShape(blockState));
    }
    
    private VoxelShape getArmShape(final BlockState blockState) {
        final boolean var2 = blockState.getValue((Property<Boolean>)PistonHeadBlock.SHORT);
        switch (blockState.getValue((Property<Direction>)PistonHeadBlock.FACING)) {
            default: {
                return var2 ? PistonHeadBlock.SHORT_DOWN_ARM_AABB : PistonHeadBlock.DOWN_ARM_AABB;
            }
            case UP: {
                return var2 ? PistonHeadBlock.SHORT_UP_ARM_AABB : PistonHeadBlock.UP_ARM_AABB;
            }
            case NORTH: {
                return var2 ? PistonHeadBlock.SHORT_NORTH_ARM_AABB : PistonHeadBlock.NORTH_ARM_AABB;
            }
            case SOUTH: {
                return var2 ? PistonHeadBlock.SHORT_SOUTH_ARM_AABB : PistonHeadBlock.SOUTH_ARM_AABB;
            }
            case WEST: {
                return var2 ? PistonHeadBlock.SHORT_WEST_ARM_AABB : PistonHeadBlock.WEST_ARM_AABB;
            }
            case EAST: {
                return var2 ? PistonHeadBlock.SHORT_EAST_ARM_AABB : PistonHeadBlock.EAST_ARM_AABB;
            }
        }
    }
    
    @Override
    public void playerWillDestroy(final Level level, final BlockPos blockPos, final BlockState blockState, final Player player) {
        if (!level.isClientSide && player.abilities.instabuild) {
            final BlockPos blockPos2 = blockPos.relative(blockState.getValue((Property<Direction>)PistonHeadBlock.FACING).getOpposite());
            final Block var6 = level.getBlockState(blockPos2).getBlock();
            if (var6 == Blocks.PISTON || var6 == Blocks.STICKY_PISTON) {
                level.removeBlock(blockPos2, false);
            }
        }
        super.playerWillDestroy(level, blockPos, blockState, player);
    }
    
    @Override
    public void onRemove(final BlockState var1, final Level level, BlockPos blockPos, final BlockState var4, final boolean var5) {
        if (var1.getBlock() == var4.getBlock()) {
            return;
        }
        super.onRemove(var1, level, blockPos, var4, var5);
        final Direction var6 = var1.getValue((Property<Direction>)PistonHeadBlock.FACING).getOpposite();
        blockPos = blockPos.relative(var6);
        final BlockState var7 = level.getBlockState(blockPos);
        if ((var7.getBlock() == Blocks.PISTON || var7.getBlock() == Blocks.STICKY_PISTON) && var7.getValue((Property<Boolean>)PistonBaseBlock.EXTENDED)) {
            Block.dropResources(var7, level, blockPos);
            level.removeBlock(blockPos, false);
        }
    }
    
    @Override
    public BlockState updateShape(final BlockState var1, final Direction direction, final BlockState var3, final LevelAccessor levelAccessor, final BlockPos var5, final BlockPos var6) {
        if (direction.getOpposite() == var1.getValue((Property<Direction>)PistonHeadBlock.FACING) && !var1.canSurvive(levelAccessor, var5)) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(var1, direction, var3, levelAccessor, var5, var6);
    }
    
    @Override
    public boolean canSurvive(final BlockState blockState, final LevelReader levelReader, final BlockPos blockPos) {
        final Block var4 = levelReader.getBlockState(blockPos.relative(blockState.getValue((Property<Direction>)PistonHeadBlock.FACING).getOpposite())).getBlock();
        return var4 == Blocks.PISTON || var4 == Blocks.STICKY_PISTON || var4 == Blocks.MOVING_PISTON;
    }
    
    @Override
    public void neighborChanged(final BlockState blockState, final Level level, final BlockPos var3, final Block block, final BlockPos var5, final boolean var6) {
        if (blockState.canSurvive(level, var3)) {
            final BlockPos var7 = var3.relative(blockState.getValue((Property<Direction>)PistonHeadBlock.FACING).getOpposite());
            level.getBlockState(var7).neighborChanged(level, var7, block, var5, false);
        }
    }
    
    @Override
    public ItemStack getCloneItemStack(final BlockGetter blockGetter, final BlockPos blockPos, final BlockState blockState) {
        return new ItemStack((blockState.getValue(PistonHeadBlock.TYPE) == PistonType.STICKY) ? Blocks.STICKY_PISTON : Blocks.PISTON);
    }
    
    @Override
    public BlockState rotate(final BlockState var1, final Rotation rotation) {
        return ((AbstractStateHolder<O, BlockState>)var1).setValue((Property<Comparable>)PistonHeadBlock.FACING, rotation.rotate(var1.getValue((Property<Direction>)PistonHeadBlock.FACING)));
    }
    
    @Override
    public BlockState mirror(final BlockState var1, final Mirror mirror) {
        return var1.rotate(mirror.getRotation(var1.getValue((Property<Direction>)PistonHeadBlock.FACING)));
    }
    
    @Override
    protected void createBlockStateDefinition(final StateDefinition.Builder<Block, BlockState> stateDefinition$Builder) {
        stateDefinition$Builder.add(PistonHeadBlock.FACING, PistonHeadBlock.TYPE, PistonHeadBlock.SHORT);
    }
    
    @Override
    public boolean isPathfindable(final BlockState blockState, final BlockGetter blockGetter, final BlockPos blockPos, final PathComputationType pathComputationType) {
        return false;
    }
    
    static {
        TYPE = BlockStateProperties.PISTON_TYPE;
        SHORT = BlockStateProperties.SHORT;
        EAST_AABB = Block.box(12.0, 0.0, 0.0, 16.0, 16.0, 16.0);
        WEST_AABB = Block.box(0.0, 0.0, 0.0, 4.0, 16.0, 16.0);
        SOUTH_AABB = Block.box(0.0, 0.0, 12.0, 16.0, 16.0, 16.0);
        NORTH_AABB = Block.box(0.0, 0.0, 0.0, 16.0, 16.0, 4.0);
        UP_AABB = Block.box(0.0, 12.0, 0.0, 16.0, 16.0, 16.0);
        DOWN_AABB = Block.box(0.0, 0.0, 0.0, 16.0, 4.0, 16.0);
        UP_ARM_AABB = Block.box(6.0, -4.0, 6.0, 10.0, 12.0, 10.0);
        DOWN_ARM_AABB = Block.box(6.0, 4.0, 6.0, 10.0, 20.0, 10.0);
        SOUTH_ARM_AABB = Block.box(6.0, 6.0, -4.0, 10.0, 10.0, 12.0);
        NORTH_ARM_AABB = Block.box(6.0, 6.0, 4.0, 10.0, 10.0, 20.0);
        EAST_ARM_AABB = Block.box(-4.0, 6.0, 6.0, 12.0, 10.0, 10.0);
        WEST_ARM_AABB = Block.box(4.0, 6.0, 6.0, 20.0, 10.0, 10.0);
        SHORT_UP_ARM_AABB = Block.box(6.0, 0.0, 6.0, 10.0, 12.0, 10.0);
        SHORT_DOWN_ARM_AABB = Block.box(6.0, 4.0, 6.0, 10.0, 16.0, 10.0);
        SHORT_SOUTH_ARM_AABB = Block.box(6.0, 6.0, 0.0, 10.0, 10.0, 12.0);
        SHORT_NORTH_ARM_AABB = Block.box(6.0, 6.0, 4.0, 10.0, 10.0, 16.0);
        SHORT_EAST_ARM_AABB = Block.box(0.0, 6.0, 6.0, 12.0, 10.0, 10.0);
        SHORT_WEST_ARM_AABB = Block.box(4.0, 6.0, 6.0, 16.0, 10.0, 10.0);
    }
}
