package net.minecraft.world.level.block;

import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.item.*;
import net.minecraft.core.*;
import net.minecraft.world.phys.*;
import net.minecraft.stats.*;
import net.minecraft.world.*;
import net.minecraft.network.chat.*;
import javax.annotation.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.pathfinder.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.level.block.state.*;

public class StonecutterBlock extends Block
{
    private static final TranslatableComponent CONTAINER_TITLE;
    public static final DirectionProperty FACING;
    protected static final VoxelShape SHAPE;
    
    public StonecutterBlock(final Properties block$Properties) {
        super(block$Properties);
        this.registerDefaultState(((AbstractStateHolder<O, BlockState>)this.stateDefinition.any()).setValue((Property<Comparable>)StonecutterBlock.FACING, Direction.NORTH));
    }
    
    @Override
    public BlockState getStateForPlacement(final BlockPlaceContext blockPlaceContext) {
        return ((AbstractStateHolder<O, BlockState>)this.defaultBlockState()).setValue((Property<Comparable>)StonecutterBlock.FACING, blockPlaceContext.getHorizontalDirection().getOpposite());
    }
    
    @Override
    public boolean use(final BlockState blockState, final Level level, final BlockPos blockPos, final Player player, final InteractionHand interactionHand, final BlockHitResult blockHitResult) {
        player.openMenu(blockState.getMenuProvider(level, blockPos));
        player.awardStat(Stats.INTERACT_WITH_STONECUTTER);
        return true;
    }
    
    @Nullable
    @Override
    public MenuProvider getMenuProvider(final BlockState blockState, final Level level, final BlockPos blockPos) {
        return new SimpleMenuProvider((var2, inventory, player) -> new StonecutterMenu(var2, inventory, ContainerLevelAccess.create(level, blockPos)), StonecutterBlock.CONTAINER_TITLE);
    }
    
    @Override
    public VoxelShape getShape(final BlockState blockState, final BlockGetter blockGetter, final BlockPos blockPos, final CollisionContext collisionContext) {
        return StonecutterBlock.SHAPE;
    }
    
    @Override
    public boolean useShapeForLightOcclusion(final BlockState blockState) {
        return true;
    }
    
    @Override
    public boolean canOcclude(final BlockState blockState) {
        return true;
    }
    
    @Override
    public RenderShape getRenderShape(final BlockState blockState) {
        return RenderShape.MODEL;
    }
    
    @Override
    public BlockLayer getRenderLayer() {
        return BlockLayer.CUTOUT;
    }
    
    @Override
    public BlockState rotate(final BlockState var1, final Rotation rotation) {
        return ((AbstractStateHolder<O, BlockState>)var1).setValue((Property<Comparable>)StonecutterBlock.FACING, rotation.rotate(var1.getValue((Property<Direction>)StonecutterBlock.FACING)));
    }
    
    @Override
    public BlockState mirror(final BlockState var1, final Mirror mirror) {
        return var1.rotate(mirror.getRotation(var1.getValue((Property<Direction>)StonecutterBlock.FACING)));
    }
    
    @Override
    protected void createBlockStateDefinition(final StateDefinition.Builder<Block, BlockState> stateDefinition$Builder) {
        stateDefinition$Builder.add(StonecutterBlock.FACING);
    }
    
    @Override
    public boolean isPathfindable(final BlockState blockState, final BlockGetter blockGetter, final BlockPos blockPos, final PathComputationType pathComputationType) {
        return false;
    }
    
    static {
        CONTAINER_TITLE = new TranslatableComponent("container.stonecutter", new Object[0]);
        FACING = HorizontalDirectionalBlock.FACING;
        SHAPE = Block.box(0.0, 0.0, 0.0, 16.0, 9.0, 16.0);
    }
}
