package net.minecraft.world.level.block;

import net.minecraft.world.phys.shapes.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.*;
import net.minecraft.core.*;
import net.minecraft.world.level.*;
import java.util.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.level.block.state.*;

public class TripWireBlock extends Block
{
    public static final BooleanProperty POWERED;
    public static final BooleanProperty ATTACHED;
    public static final BooleanProperty DISARMED;
    public static final BooleanProperty NORTH;
    public static final BooleanProperty EAST;
    public static final BooleanProperty SOUTH;
    public static final BooleanProperty WEST;
    private static final Map<Direction, BooleanProperty> PROPERTY_BY_DIRECTION;
    protected static final VoxelShape AABB;
    protected static final VoxelShape NOT_ATTACHED_AABB;
    private final TripWireHookBlock hook;
    
    public TripWireBlock(final TripWireHookBlock hook, final Properties block$Properties) {
        super(block$Properties);
        this.registerDefaultState(((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)this.stateDefinition.any()).setValue((Property<Comparable>)TripWireBlock.POWERED, false)).setValue((Property<Comparable>)TripWireBlock.ATTACHED, false)).setValue((Property<Comparable>)TripWireBlock.DISARMED, false)).setValue((Property<Comparable>)TripWireBlock.NORTH, false)).setValue((Property<Comparable>)TripWireBlock.EAST, false)).setValue((Property<Comparable>)TripWireBlock.SOUTH, false)).setValue((Property<Comparable>)TripWireBlock.WEST, false));
        this.hook = hook;
    }
    
    @Override
    public VoxelShape getShape(final BlockState blockState, final BlockGetter blockGetter, final BlockPos blockPos, final CollisionContext collisionContext) {
        return blockState.getValue((Property<Boolean>)TripWireBlock.ATTACHED) ? TripWireBlock.AABB : TripWireBlock.NOT_ATTACHED_AABB;
    }
    
    @Override
    public BlockState getStateForPlacement(final BlockPlaceContext blockPlaceContext) {
        final BlockGetter var2 = blockPlaceContext.getLevel();
        final BlockPos var3 = blockPlaceContext.getClickedPos();
        return ((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)this.defaultBlockState()).setValue((Property<Comparable>)TripWireBlock.NORTH, this.shouldConnectTo(var2.getBlockState(var3.north()), Direction.NORTH))).setValue((Property<Comparable>)TripWireBlock.EAST, this.shouldConnectTo(var2.getBlockState(var3.east()), Direction.EAST))).setValue((Property<Comparable>)TripWireBlock.SOUTH, this.shouldConnectTo(var2.getBlockState(var3.south()), Direction.SOUTH))).setValue((Property<Comparable>)TripWireBlock.WEST, this.shouldConnectTo(var2.getBlockState(var3.west()), Direction.WEST));
    }
    
    @Override
    public BlockState updateShape(final BlockState var1, final Direction direction, final BlockState var3, final LevelAccessor levelAccessor, final BlockPos var5, final BlockPos var6) {
        if (direction.getAxis().isHorizontal()) {
            return ((AbstractStateHolder<O, BlockState>)var1).setValue((Property<Comparable>)TripWireBlock.PROPERTY_BY_DIRECTION.get(direction), this.shouldConnectTo(var3, direction));
        }
        return super.updateShape(var1, direction, var3, levelAccessor, var5, var6);
    }
    
    @Override
    public BlockLayer getRenderLayer() {
        return BlockLayer.TRANSLUCENT;
    }
    
    @Override
    public void onPlace(final BlockState var1, final Level level, final BlockPos blockPos, final BlockState var4, final boolean var5) {
        if (var4.getBlock() == var1.getBlock()) {
            return;
        }
        this.updateSource(level, blockPos, var1);
    }
    
    @Override
    public void onRemove(final BlockState var1, final Level level, final BlockPos blockPos, final BlockState var4, final boolean var5) {
        if (var5 || var1.getBlock() == var4.getBlock()) {
            return;
        }
        this.updateSource(level, blockPos, ((AbstractStateHolder<O, BlockState>)var1).setValue((Property<Comparable>)TripWireBlock.POWERED, true));
    }
    
    @Override
    public void playerWillDestroy(final Level level, final BlockPos blockPos, final BlockState blockState, final Player player) {
        if (!level.isClientSide && !player.getMainHandItem().isEmpty() && player.getMainHandItem().getItem() == Items.SHEARS) {
            level.setBlock(blockPos, ((AbstractStateHolder<O, BlockState>)blockState).setValue((Property<Comparable>)TripWireBlock.DISARMED, true), 4);
        }
        super.playerWillDestroy(level, blockPos, blockState, player);
    }
    
    private void updateSource(final Level level, final BlockPos blockPos, final BlockState blockState) {
        for (final Direction var7 : new Direction[] { Direction.SOUTH, Direction.WEST }) {
            int var8 = 1;
            while (var8 < 42) {
                final BlockPos var9 = blockPos.relative(var7, var8);
                final BlockState var10 = level.getBlockState(var9);
                if (var10.getBlock() == this.hook) {
                    if (var10.getValue((Property<Comparable>)TripWireHookBlock.FACING) == var7.getOpposite()) {
                        this.hook.calculateState(level, var9, var10, false, true, var8, blockState);
                        break;
                    }
                    break;
                }
                else {
                    if (var10.getBlock() != this) {
                        break;
                    }
                    ++var8;
                }
            }
        }
    }
    
    @Override
    public void entityInside(final BlockState blockState, final Level level, final BlockPos blockPos, final Entity entity) {
        if (level.isClientSide) {
            return;
        }
        if (blockState.getValue((Property<Boolean>)TripWireBlock.POWERED)) {
            return;
        }
        this.checkPressed(level, blockPos);
    }
    
    @Override
    public void tick(final BlockState blockState, final Level level, final BlockPos blockPos, final Random random) {
        if (level.isClientSide) {
            return;
        }
        if (!level.getBlockState(blockPos).getValue((Property<Boolean>)TripWireBlock.POWERED)) {
            return;
        }
        this.checkPressed(level, blockPos);
    }
    
    private void checkPressed(final Level level, final BlockPos blockPos) {
        BlockState var3 = level.getBlockState(blockPos);
        final boolean var4 = var3.getValue((Property<Boolean>)TripWireBlock.POWERED);
        boolean var5 = false;
        final List<? extends Entity> var6 = level.getEntities(null, var3.getShape(level, blockPos).bounds().move(blockPos));
        if (!var6.isEmpty()) {
            for (final Entity var7 : var6) {
                if (!var7.isIgnoringBlockTriggers()) {
                    var5 = true;
                    break;
                }
            }
        }
        if (var5 != var4) {
            var3 = ((AbstractStateHolder<O, BlockState>)var3).setValue((Property<Comparable>)TripWireBlock.POWERED, var5);
            level.setBlock(blockPos, var3, 3);
            this.updateSource(level, blockPos, var3);
        }
        if (var5) {
            level.getBlockTicks().scheduleTick(new BlockPos(blockPos), this, this.getTickDelay(level));
        }
    }
    
    public boolean shouldConnectTo(final BlockState blockState, final Direction direction) {
        final Block var3 = blockState.getBlock();
        if (var3 == this.hook) {
            return blockState.getValue((Property<Comparable>)TripWireHookBlock.FACING) == direction.getOpposite();
        }
        return var3 == this;
    }
    
    @Override
    public BlockState rotate(final BlockState var1, final Rotation rotation) {
        switch (rotation) {
            case CLOCKWISE_180: {
                return ((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)var1).setValue((Property<Comparable>)TripWireBlock.NORTH, (Comparable)var1.getValue((Property<V>)TripWireBlock.SOUTH))).setValue((Property<Comparable>)TripWireBlock.EAST, (Comparable)var1.getValue((Property<V>)TripWireBlock.WEST))).setValue((Property<Comparable>)TripWireBlock.SOUTH, (Comparable)var1.getValue((Property<V>)TripWireBlock.NORTH))).setValue((Property<Comparable>)TripWireBlock.WEST, (Comparable)var1.getValue((Property<V>)TripWireBlock.EAST));
            }
            case COUNTERCLOCKWISE_90: {
                return ((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)var1).setValue((Property<Comparable>)TripWireBlock.NORTH, (Comparable)var1.getValue((Property<V>)TripWireBlock.EAST))).setValue((Property<Comparable>)TripWireBlock.EAST, (Comparable)var1.getValue((Property<V>)TripWireBlock.SOUTH))).setValue((Property<Comparable>)TripWireBlock.SOUTH, (Comparable)var1.getValue((Property<V>)TripWireBlock.WEST))).setValue((Property<Comparable>)TripWireBlock.WEST, (Comparable)var1.getValue((Property<V>)TripWireBlock.NORTH));
            }
            case CLOCKWISE_90: {
                return ((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)var1).setValue((Property<Comparable>)TripWireBlock.NORTH, (Comparable)var1.getValue((Property<V>)TripWireBlock.WEST))).setValue((Property<Comparable>)TripWireBlock.EAST, (Comparable)var1.getValue((Property<V>)TripWireBlock.NORTH))).setValue((Property<Comparable>)TripWireBlock.SOUTH, (Comparable)var1.getValue((Property<V>)TripWireBlock.EAST))).setValue((Property<Comparable>)TripWireBlock.WEST, (Comparable)var1.getValue((Property<V>)TripWireBlock.SOUTH));
            }
            default: {
                return var1;
            }
        }
    }
    
    @Override
    public BlockState mirror(final BlockState var1, final Mirror mirror) {
        switch (mirror) {
            case LEFT_RIGHT: {
                return ((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)var1).setValue((Property<Comparable>)TripWireBlock.NORTH, (Comparable)var1.getValue((Property<V>)TripWireBlock.SOUTH))).setValue((Property<Comparable>)TripWireBlock.SOUTH, (Comparable)var1.getValue((Property<V>)TripWireBlock.NORTH));
            }
            case FRONT_BACK: {
                return ((AbstractStateHolder<O, BlockState>)((AbstractStateHolder<O, BlockState>)var1).setValue((Property<Comparable>)TripWireBlock.EAST, (Comparable)var1.getValue((Property<V>)TripWireBlock.WEST))).setValue((Property<Comparable>)TripWireBlock.WEST, (Comparable)var1.getValue((Property<V>)TripWireBlock.EAST));
            }
            default: {
                return super.mirror(var1, mirror);
            }
        }
    }
    
    @Override
    protected void createBlockStateDefinition(final StateDefinition.Builder<Block, BlockState> stateDefinition$Builder) {
        stateDefinition$Builder.add(TripWireBlock.POWERED, TripWireBlock.ATTACHED, TripWireBlock.DISARMED, TripWireBlock.NORTH, TripWireBlock.EAST, TripWireBlock.WEST, TripWireBlock.SOUTH);
    }
    
    static {
        POWERED = BlockStateProperties.POWERED;
        ATTACHED = BlockStateProperties.ATTACHED;
        DISARMED = BlockStateProperties.DISARMED;
        NORTH = PipeBlock.NORTH;
        EAST = PipeBlock.EAST;
        SOUTH = PipeBlock.SOUTH;
        WEST = PipeBlock.WEST;
        PROPERTY_BY_DIRECTION = CrossCollisionBlock.PROPERTY_BY_DIRECTION;
        AABB = Block.box(0.0, 1.0, 0.0, 16.0, 2.5, 16.0);
        NOT_ATTACHED_AABB = Block.box(0.0, 0.0, 0.0, 16.0, 8.0, 16.0);
    }
}
