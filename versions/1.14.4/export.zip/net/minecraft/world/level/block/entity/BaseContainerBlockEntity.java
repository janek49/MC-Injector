package net.minecraft.world.level.block.entity;

import net.minecraft.world.*;
import net.minecraft.nbt.*;
import javax.annotation.*;
import net.minecraft.network.chat.*;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;

public abstract class BaseContainerBlockEntity extends BlockEntity implements Container, MenuProvider, Nameable
{
    private LockCode lockKey;
    private Component name;
    
    protected BaseContainerBlockEntity(final BlockEntityType<?> blockEntityType) {
        super(blockEntityType);
        this.lockKey = LockCode.NO_LOCK;
    }
    
    @Override
    public void load(final CompoundTag compoundTag) {
        super.load(compoundTag);
        this.lockKey = LockCode.fromTag(compoundTag);
        if (compoundTag.contains("CustomName", 8)) {
            this.name = Component.Serializer.fromJson(compoundTag.getString("CustomName"));
        }
    }
    
    @Override
    public CompoundTag save(final CompoundTag compoundTag) {
        super.save(compoundTag);
        this.lockKey.addToTag(compoundTag);
        if (this.name != null) {
            compoundTag.putString("CustomName", Component.Serializer.toJson(this.name));
        }
        return compoundTag;
    }
    
    public void setCustomName(final Component customName) {
        this.name = customName;
    }
    
    @Override
    public Component getName() {
        if (this.name != null) {
            return this.name;
        }
        return this.getDefaultName();
    }
    
    @Override
    public Component getDisplayName() {
        return this.getName();
    }
    
    @Nullable
    @Override
    public Component getCustomName() {
        return this.name;
    }
    
    protected abstract Component getDefaultName();
    
    public boolean canOpen(final Player player) {
        return canUnlock(player, this.lockKey, this.getDisplayName());
    }
    
    public static boolean canUnlock(final Player player, final LockCode lockCode, final Component component) {
        if (player.isSpectator() || lockCode.unlocksWith(player.getMainHandItem())) {
            return true;
        }
        player.displayClientMessage(new TranslatableComponent("container.isLocked", new Object[] { component }), true);
        player.playNotifySound(SoundEvents.CHEST_LOCKED, SoundSource.BLOCKS, 1.0f, 1.0f);
        return false;
    }
    
    @Nullable
    @Override
    public AbstractContainerMenu createMenu(final int var1, final Inventory inventory, final Player player) {
        if (this.canOpen(player)) {
            return this.createMenu(var1, inventory);
        }
        return null;
    }
    
    protected abstract AbstractContainerMenu createMenu(final int p0, final Inventory p1);
}
