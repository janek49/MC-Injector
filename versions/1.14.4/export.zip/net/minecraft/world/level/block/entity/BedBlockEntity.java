package net.minecraft.world.level.block.entity;

import net.minecraft.world.item.*;
import net.minecraft.network.protocol.game.*;
import net.minecraft.world.level.block.*;

public class BedBlockEntity extends BlockEntity
{
    private DyeColor color;
    
    public BedBlockEntity() {
        super(BlockEntityType.BED);
    }
    
    public BedBlockEntity(final DyeColor color) {
        this();
        this.setColor(color);
    }
    
    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return new ClientboundBlockEntityDataPacket(this.worldPosition, 11, this.getUpdateTag());
    }
    
    public DyeColor getColor() {
        if (this.color == null) {
            this.color = ((BedBlock)this.getBlockState().getBlock()).getColor();
        }
        return this.color;
    }
    
    public void setColor(final DyeColor color) {
        this.color = color;
    }
}
