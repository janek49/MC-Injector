package net.minecraft.world.level.block;

import net.minecraft.world.phys.shapes.*;
import net.minecraft.core.*;
import net.minecraft.tags.*;
import java.util.*;
import net.minecraft.world.level.material.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.pathfinder.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.level.block.state.*;

public class CactusBlock extends Block
{
    public static final IntegerProperty AGE;
    protected static final VoxelShape COLLISION_SHAPE;
    protected static final VoxelShape OUTLINE_SHAPE;
    
    protected CactusBlock(final Properties block$Properties) {
        super(block$Properties);
        this.registerDefaultState(((AbstractStateHolder<O, BlockState>)this.stateDefinition.any()).setValue((Property<Comparable>)CactusBlock.AGE, 0));
    }
    
    @Override
    public void tick(final BlockState blockState, final Level level, final BlockPos blockPos, final Random random) {
        if (!blockState.canSurvive(level, blockPos)) {
            level.destroyBlock(blockPos, true);
            return;
        }
        final BlockPos blockPos2 = blockPos.above();
        if (!level.isEmptyBlock(blockPos2)) {
            return;
        }
        int var6;
        for (var6 = 1; level.getBlockState(blockPos.below(var6)).getBlock() == this; ++var6) {}
        if (var6 >= 3) {
            return;
        }
        final int var7 = blockState.getValue((Property<Integer>)CactusBlock.AGE);
        if (var7 == 15) {
            level.setBlockAndUpdate(blockPos2, this.defaultBlockState());
            final BlockState var8 = ((AbstractStateHolder<O, BlockState>)blockState).setValue((Property<Comparable>)CactusBlock.AGE, 0);
            level.setBlock(blockPos, var8, 4);
            var8.neighborChanged(level, blockPos2, this, blockPos, false);
        }
        else {
            level.setBlock(blockPos, ((AbstractStateHolder<O, BlockState>)blockState).setValue((Property<Comparable>)CactusBlock.AGE, var7 + 1), 4);
        }
    }
    
    @Override
    public VoxelShape getCollisionShape(final BlockState blockState, final BlockGetter blockGetter, final BlockPos blockPos, final CollisionContext collisionContext) {
        return CactusBlock.COLLISION_SHAPE;
    }
    
    @Override
    public VoxelShape getShape(final BlockState blockState, final BlockGetter blockGetter, final BlockPos blockPos, final CollisionContext collisionContext) {
        return CactusBlock.OUTLINE_SHAPE;
    }
    
    @Override
    public boolean canOcclude(final BlockState blockState) {
        return true;
    }
    
    @Override
    public BlockState updateShape(final BlockState var1, final Direction direction, final BlockState var3, final LevelAccessor levelAccessor, final BlockPos var5, final BlockPos var6) {
        if (!var1.canSurvive(levelAccessor, var5)) {
            levelAccessor.getBlockTicks().scheduleTick(var5, this, 1);
        }
        return super.updateShape(var1, direction, var3, levelAccessor, var5, var6);
    }
    
    @Override
    public boolean canSurvive(final BlockState blockState, final LevelReader levelReader, final BlockPos blockPos) {
        for (final Direction var5 : Direction.Plane.HORIZONTAL) {
            final BlockState var6 = levelReader.getBlockState(blockPos.relative(var5));
            final Material var7 = var6.getMaterial();
            if (var7.isSolid() || levelReader.getFluidState(blockPos.relative(var5)).is(FluidTags.LAVA)) {
                return false;
            }
        }
        final Block var8 = levelReader.getBlockState(blockPos.below()).getBlock();
        return (var8 == Blocks.CACTUS || var8 == Blocks.SAND || var8 == Blocks.RED_SAND) && !levelReader.getBlockState(blockPos.above()).getMaterial().isLiquid();
    }
    
    @Override
    public void entityInside(final BlockState blockState, final Level level, final BlockPos blockPos, final Entity entity) {
        entity.hurt(DamageSource.CACTUS, 1.0f);
    }
    
    @Override
    public BlockLayer getRenderLayer() {
        return BlockLayer.CUTOUT;
    }
    
    @Override
    protected void createBlockStateDefinition(final StateDefinition.Builder<Block, BlockState> stateDefinition$Builder) {
        stateDefinition$Builder.add(CactusBlock.AGE);
    }
    
    @Override
    public boolean isPathfindable(final BlockState blockState, final BlockGetter blockGetter, final BlockPos blockPos, final PathComputationType pathComputationType) {
        return false;
    }
    
    static {
        AGE = BlockStateProperties.AGE_15;
        COLLISION_SHAPE = Block.box(1.0, 0.0, 1.0, 15.0, 15.0, 15.0);
        OUTLINE_SHAPE = Block.box(1.0, 0.0, 1.0, 15.0, 16.0, 15.0);
    }
}
