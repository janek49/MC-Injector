package net.minecraft.world.level.block.entity;

import net.minecraft.core.*;

public class TheEndPortalBlockEntity extends BlockEntity
{
    public TheEndPortalBlockEntity(final BlockEntityType<?> blockEntityType) {
        super(blockEntityType);
    }
    
    public TheEndPortalBlockEntity() {
        this(BlockEntityType.END_PORTAL);
    }
    
    public boolean shouldRenderFace(final Direction direction) {
        return direction == Direction.UP;
    }
}
