package net.minecraft.world.level.block;

import net.minecraft.sounds.*;

public class WoodButtonBlock extends ButtonBlock
{
    protected WoodButtonBlock(final Properties block$Properties) {
        super(true, block$Properties);
    }
    
    @Override
    protected SoundEvent getSound(final boolean b) {
        return b ? SoundEvents.WOODEN_BUTTON_CLICK_ON : SoundEvents.WOODEN_BUTTON_CLICK_OFF;
    }
}
