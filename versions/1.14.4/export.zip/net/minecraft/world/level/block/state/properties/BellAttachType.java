package net.minecraft.world.level.block.state.properties;

import net.minecraft.util.*;

public enum BellAttachType implements StringRepresentable
{
    FLOOR("FLOOR", 0, "floor"), 
    CEILING("CEILING", 1, "ceiling"), 
    SINGLE_WALL("SINGLE_WALL", 2, "single_wall"), 
    DOUBLE_WALL("DOUBLE_WALL", 3, "double_wall");
    
    private final String name;
    
    private BellAttachType(final String s, final int n, final String name) {
        this.name = name;
    }
    
    @Override
    public String getSerializedName() {
        return this.name;
    }
}
