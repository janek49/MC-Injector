package net.minecraft.world.level.block.entity;

import net.minecraft.network.chat.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.item.alchemy.*;
import net.minecraft.world.level.*;
import net.minecraft.nbt.*;
import java.util.*;
import net.minecraft.core.*;
import javax.annotation.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.*;
import net.minecraft.world.level.block.state.*;

public class BrewingStandBlockEntity extends BaseContainerBlockEntity implements WorldlyContainer, TickableBlockEntity
{
    private static final int[] SLOTS_FOR_UP;
    private static final int[] SLOTS_FOR_DOWN;
    private static final int[] SLOTS_FOR_SIDES;
    private NonNullList<ItemStack> items;
    private int brewTime;
    private boolean[] lastPotionCount;
    private Item ingredient;
    private int fuel;
    protected final ContainerData dataAccess;
    
    public BrewingStandBlockEntity() {
        super(BlockEntityType.BREWING_STAND);
        this.items = NonNullList.withSize(5, ItemStack.EMPTY);
        this.dataAccess = new ContainerData() {
            @Override
            public int get(final int i) {
                switch (i) {
                    case 0: {
                        return BrewingStandBlockEntity.this.brewTime;
                    }
                    case 1: {
                        return BrewingStandBlockEntity.this.fuel;
                    }
                    default: {
                        return 0;
                    }
                }
            }
            
            @Override
            public void set(final int var1, final int var2) {
                switch (var1) {
                    case 0: {
                        BrewingStandBlockEntity.this.brewTime = var2;
                        break;
                    }
                    case 1: {
                        BrewingStandBlockEntity.this.fuel = var2;
                        break;
                    }
                }
            }
            
            @Override
            public int getCount() {
                return 2;
            }
        };
    }
    
    @Override
    protected Component getDefaultName() {
        return new TranslatableComponent("container.brewing", new Object[0]);
    }
    
    @Override
    public int getContainerSize() {
        return this.items.size();
    }
    
    @Override
    public boolean isEmpty() {
        for (final ItemStack var2 : this.items) {
            if (!var2.isEmpty()) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public void tick() {
        final ItemStack var1 = this.items.get(4);
        if (this.fuel <= 0 && var1.getItem() == Items.BLAZE_POWDER) {
            this.fuel = 20;
            var1.shrink(1);
            this.setChanged();
        }
        final boolean var2 = this.isBrewable();
        final boolean var3 = this.brewTime > 0;
        final ItemStack var4 = this.items.get(3);
        if (var3) {
            --this.brewTime;
            final boolean var5 = this.brewTime == 0;
            if (var5 && var2) {
                this.doBrew();
                this.setChanged();
            }
            else if (!var2) {
                this.brewTime = 0;
                this.setChanged();
            }
            else if (this.ingredient != var4.getItem()) {
                this.brewTime = 0;
                this.setChanged();
            }
        }
        else if (var2 && this.fuel > 0) {
            --this.fuel;
            this.brewTime = 400;
            this.ingredient = var4.getItem();
            this.setChanged();
        }
        if (!this.level.isClientSide) {
            final boolean[] vars5 = this.getPotionBits();
            if (!Arrays.equals(vars5, this.lastPotionCount)) {
                this.lastPotionCount = vars5;
                BlockState var6 = this.level.getBlockState(this.getBlockPos());
                if (!(var6.getBlock() instanceof BrewingStandBlock)) {
                    return;
                }
                for (int var7 = 0; var7 < BrewingStandBlock.HAS_BOTTLE.length; ++var7) {
                    var6 = ((AbstractStateHolder<O, BlockState>)var6).setValue((Property<Comparable>)BrewingStandBlock.HAS_BOTTLE[var7], vars5[var7]);
                }
                this.level.setBlock(this.worldPosition, var6, 2);
            }
        }
    }
    
    public boolean[] getPotionBits() {
        final boolean[] booleans = new boolean[3];
        for (int var2 = 0; var2 < 3; ++var2) {
            if (!this.items.get(var2).isEmpty()) {
                booleans[var2] = true;
            }
        }
        return booleans;
    }
    
    private boolean isBrewable() {
        final ItemStack var1 = this.items.get(3);
        if (var1.isEmpty()) {
            return false;
        }
        if (!PotionBrewing.isIngredient(var1)) {
            return false;
        }
        for (int var2 = 0; var2 < 3; ++var2) {
            final ItemStack var3 = this.items.get(var2);
            if (!var3.isEmpty()) {
                if (PotionBrewing.hasMix(var3, var1)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private void doBrew() {
        ItemStack var1 = this.items.get(3);
        for (int var2 = 0; var2 < 3; ++var2) {
            this.items.set(var2, PotionBrewing.mix(var1, this.items.get(var2)));
        }
        var1.shrink(1);
        final BlockPos var3 = this.getBlockPos();
        if (var1.getItem().hasCraftingRemainingItem()) {
            final ItemStack var4 = new ItemStack(var1.getItem().getCraftingRemainingItem());
            if (var1.isEmpty()) {
                var1 = var4;
            }
            else if (!this.level.isClientSide) {
                Containers.dropItemStack(this.level, var3.getX(), var3.getY(), var3.getZ(), var4);
            }
        }
        this.items.set(3, var1);
        this.level.levelEvent(1035, var3, 0);
    }
    
    @Override
    public void load(final CompoundTag compoundTag) {
        super.load(compoundTag);
        ContainerHelper.loadAllItems(compoundTag, this.items = NonNullList.withSize(this.getContainerSize(), ItemStack.EMPTY));
        this.brewTime = compoundTag.getShort("BrewTime");
        this.fuel = compoundTag.getByte("Fuel");
    }
    
    @Override
    public CompoundTag save(final CompoundTag compoundTag) {
        super.save(compoundTag);
        compoundTag.putShort("BrewTime", (short)this.brewTime);
        ContainerHelper.saveAllItems(compoundTag, this.items);
        compoundTag.putByte("Fuel", (byte)this.fuel);
        return compoundTag;
    }
    
    @Override
    public ItemStack getItem(final int i) {
        if (i >= 0 && i < this.items.size()) {
            return this.items.get(i);
        }
        return ItemStack.EMPTY;
    }
    
    @Override
    public ItemStack removeItem(final int var1, final int var2) {
        return ContainerHelper.removeItem(this.items, var1, var2);
    }
    
    @Override
    public ItemStack removeItemNoUpdate(final int i) {
        return ContainerHelper.takeItem(this.items, i);
    }
    
    @Override
    public void setItem(final int var1, final ItemStack itemStack) {
        if (var1 >= 0 && var1 < this.items.size()) {
            this.items.set(var1, itemStack);
        }
    }
    
    @Override
    public boolean stillValid(final Player player) {
        return this.level.getBlockEntity(this.worldPosition) == this && player.distanceToSqr(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5) <= 64.0;
    }
    
    @Override
    public boolean canPlaceItem(final int var1, final ItemStack itemStack) {
        if (var1 == 3) {
            return PotionBrewing.isIngredient(itemStack);
        }
        final Item var2 = itemStack.getItem();
        if (var1 == 4) {
            return var2 == Items.BLAZE_POWDER;
        }
        return (var2 == Items.POTION || var2 == Items.SPLASH_POTION || var2 == Items.LINGERING_POTION || var2 == Items.GLASS_BOTTLE) && this.getItem(var1).isEmpty();
    }
    
    @Override
    public int[] getSlotsForFace(final Direction direction) {
        if (direction == Direction.UP) {
            return BrewingStandBlockEntity.SLOTS_FOR_UP;
        }
        if (direction == Direction.DOWN) {
            return BrewingStandBlockEntity.SLOTS_FOR_DOWN;
        }
        return BrewingStandBlockEntity.SLOTS_FOR_SIDES;
    }
    
    @Override
    public boolean canPlaceItemThroughFace(final int var1, final ItemStack itemStack, @Nullable final Direction direction) {
        return this.canPlaceItem(var1, itemStack);
    }
    
    @Override
    public boolean canTakeItemThroughFace(final int var1, final ItemStack itemStack, final Direction direction) {
        return var1 != 3 || itemStack.getItem() == Items.GLASS_BOTTLE;
    }
    
    @Override
    public void clearContent() {
        this.items.clear();
    }
    
    @Override
    protected AbstractContainerMenu createMenu(final int var1, final Inventory inventory) {
        return new BrewingStandMenu(var1, inventory, this, this.dataAccess);
    }
    
    static {
        SLOTS_FOR_UP = new int[] { 3 };
        SLOTS_FOR_DOWN = new int[] { 0, 1, 2, 3 };
        SLOTS_FOR_SIDES = new int[] { 0, 1, 2, 4 };
    }
}
