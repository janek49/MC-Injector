package net.minecraft.world.level.block;

import net.minecraft.world.level.block.state.*;
import java.util.*;
import net.minecraft.core.*;
import net.minecraft.world.level.*;
import net.minecraft.tags.*;
import net.minecraft.world.level.material.*;
import net.minecraft.world.item.*;
import javax.annotation.*;

public class CoralBlock extends Block
{
    private final Block deadBlock;
    
    public CoralBlock(final Block deadBlock, final Properties block$Properties) {
        super(block$Properties);
        this.deadBlock = deadBlock;
    }
    
    @Override
    public void tick(final BlockState blockState, final Level level, final BlockPos blockPos, final Random random) {
        if (!this.scanForWater(level, blockPos)) {
            level.setBlock(blockPos, this.deadBlock.defaultBlockState(), 2);
        }
    }
    
    @Override
    public BlockState updateShape(final BlockState var1, final Direction direction, final BlockState var3, final LevelAccessor levelAccessor, final BlockPos var5, final BlockPos var6) {
        if (!this.scanForWater(levelAccessor, var5)) {
            levelAccessor.getBlockTicks().scheduleTick(var5, this, 60 + levelAccessor.getRandom().nextInt(40));
        }
        return super.updateShape(var1, direction, var3, levelAccessor, var5, var6);
    }
    
    protected boolean scanForWater(final BlockGetter blockGetter, final BlockPos blockPos) {
        for (final Direction var6 : Direction.values()) {
            final FluidState var7 = blockGetter.getFluidState(blockPos.relative(var6));
            if (var7.is(FluidTags.WATER)) {
                return true;
            }
        }
        return false;
    }
    
    @Nullable
    @Override
    public BlockState getStateForPlacement(final BlockPlaceContext blockPlaceContext) {
        if (!this.scanForWater(blockPlaceContext.getLevel(), blockPlaceContext.getClickedPos())) {
            blockPlaceContext.getLevel().getBlockTicks().scheduleTick(blockPlaceContext.getClickedPos(), this, 60 + blockPlaceContext.getLevel().getRandom().nextInt(40));
        }
        return this.defaultBlockState();
    }
}
