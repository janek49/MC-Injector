package net.minecraft.world.level.block.entity;

import net.minecraft.world.level.block.*;
import net.minecraft.core.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.nbt.*;
import net.minecraft.network.protocol.game.*;
import javax.annotation.*;

public class SpawnerBlockEntity extends BlockEntity implements TickableBlockEntity
{
    private final BaseSpawner spawner;
    
    public SpawnerBlockEntity() {
        super(BlockEntityType.MOB_SPAWNER);
        this.spawner = new BaseSpawner() {
            @Override
            public void broadcastEvent(final int i) {
                SpawnerBlockEntity.this.level.blockEvent(SpawnerBlockEntity.this.worldPosition, Blocks.SPAWNER, i, 0);
            }
            
            @Override
            public Level getLevel() {
                return SpawnerBlockEntity.this.level;
            }
            
            @Override
            public BlockPos getPos() {
                return SpawnerBlockEntity.this.worldPosition;
            }
            
            @Override
            public void setNextSpawnData(final SpawnData nextSpawnData) {
                super.setNextSpawnData(nextSpawnData);
                if (this.getLevel() != null) {
                    final BlockState var2 = this.getLevel().getBlockState(this.getPos());
                    this.getLevel().sendBlockUpdated(SpawnerBlockEntity.this.worldPosition, var2, var2, 4);
                }
            }
        };
    }
    
    @Override
    public void load(final CompoundTag compoundTag) {
        super.load(compoundTag);
        this.spawner.load(compoundTag);
    }
    
    @Override
    public CompoundTag save(final CompoundTag compoundTag) {
        super.save(compoundTag);
        this.spawner.save(compoundTag);
        return compoundTag;
    }
    
    @Override
    public void tick() {
        this.spawner.tick();
    }
    
    @Nullable
    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return new ClientboundBlockEntityDataPacket(this.worldPosition, 1, this.getUpdateTag());
    }
    
    @Override
    public CompoundTag getUpdateTag() {
        final CompoundTag compoundTag = this.save(new CompoundTag());
        compoundTag.remove("SpawnPotentials");
        return compoundTag;
    }
    
    @Override
    public boolean triggerEvent(final int var1, final int var2) {
        return this.spawner.onEventTriggered(var1) || super.triggerEvent(var1, var2);
    }
    
    @Override
    public boolean onlyOpCanSetNbt() {
        return true;
    }
    
    public BaseSpawner getSpawner() {
        return this.spawner;
    }
}
