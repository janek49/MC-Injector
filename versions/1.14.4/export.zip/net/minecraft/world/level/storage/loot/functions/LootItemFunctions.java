package net.minecraft.world.level.storage.loot.functions;

import java.util.*;
import net.minecraft.resources.*;
import java.util.function.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.storage.loot.*;
import com.google.common.collect.*;
import java.lang.reflect.*;
import net.minecraft.util.*;
import com.google.gson.*;

public class LootItemFunctions
{
    private static final Map<ResourceLocation, LootItemFunction.Serializer<?>> FUNCTIONS_BY_NAME;
    private static final Map<Class<? extends LootItemFunction>, LootItemFunction.Serializer<?>> FUNCTIONS_BY_CLASS;
    public static final BiFunction<ItemStack, LootContext, ItemStack> IDENTITY;
    
    public static <T extends LootItemFunction> void register(final LootItemFunction.Serializer<? extends T> lootItemFunction$Serializer) {
        final ResourceLocation var1 = lootItemFunction$Serializer.getName();
        final Class<T> var2 = (Class<T>)lootItemFunction$Serializer.getFunctionClass();
        if (LootItemFunctions.FUNCTIONS_BY_NAME.containsKey(var1)) {
            throw new IllegalArgumentException("Can't re-register item function name " + var1);
        }
        if (LootItemFunctions.FUNCTIONS_BY_CLASS.containsKey(var2)) {
            throw new IllegalArgumentException("Can't re-register item function class " + var2.getName());
        }
        LootItemFunctions.FUNCTIONS_BY_NAME.put(var1, lootItemFunction$Serializer);
        LootItemFunctions.FUNCTIONS_BY_CLASS.put(var2, lootItemFunction$Serializer);
    }
    
    public static LootItemFunction.Serializer<?> getSerializer(final ResourceLocation resourceLocation) {
        final LootItemFunction.Serializer<?> lootItemFunction$Serializer = LootItemFunctions.FUNCTIONS_BY_NAME.get(resourceLocation);
        if (lootItemFunction$Serializer == null) {
            throw new IllegalArgumentException("Unknown loot item function '" + resourceLocation + "'");
        }
        return lootItemFunction$Serializer;
    }
    
    public static <T extends LootItemFunction> LootItemFunction.Serializer<T> getSerializer(final T lootItemFunction) {
        final LootItemFunction.Serializer<T> lootItemFunction$Serializer = (LootItemFunction.Serializer<T>)LootItemFunctions.FUNCTIONS_BY_CLASS.get(lootItemFunction.getClass());
        if (lootItemFunction$Serializer == null) {
            throw new IllegalArgumentException("Unknown loot item function " + lootItemFunction);
        }
        return lootItemFunction$Serializer;
    }
    
    public static BiFunction<ItemStack, LootContext, ItemStack> compose(final BiFunction<ItemStack, LootContext, ItemStack>[] biFunctions) {
        switch (biFunctions.length) {
            case 0: {
                return LootItemFunctions.IDENTITY;
            }
            case 1: {
                return biFunctions[0];
            }
            case 2: {
                final BiFunction<ItemStack, LootContext, ItemStack> var3 = biFunctions[0];
                final BiFunction<ItemStack, LootContext, ItemStack> var4 = biFunctions[1];
                return (BiFunction<ItemStack, LootContext, ItemStack>)((var2, lootContext) -> var4.apply(var3.apply(var2, lootContext), lootContext));
            }
            default: {
                int length;
                int i = 0;
                BiFunction<ItemStack, LootContext, ItemStack> var5;
                return (BiFunction<ItemStack, LootContext, ItemStack>)((var1, lootContext) -> {
                    for (length = biFunctions.length; i < length; ++i) {
                        var5 = biFunctions[i];
                        var1 = var5.apply(var1, lootContext);
                    }
                    return var1;
                });
            }
        }
    }
    
    static {
        FUNCTIONS_BY_NAME = Maps.newHashMap();
        FUNCTIONS_BY_CLASS = Maps.newHashMap();
        IDENTITY = ((var0, lootContext) -> var0);
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new SetItemCountFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new EnchantWithLevelsFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new EnchantRandomlyFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new SetNbtFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new SmeltItemFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new LootingEnchantFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new SetItemDamageFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new SetAttributesFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new SetNameFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new ExplorationMapFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new SetStewEffectFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new CopyNameFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new SetContainerContents.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new LimitCount.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new ApplyBonusCount.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new SetContainerLootTable.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new ApplyExplosionDecay.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new SetLoreFunction.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new FillPlayerHead.Serializer());
        register((LootItemFunction.Serializer<? extends LootItemFunction>)new CopyNbtFunction.Serializer());
    }
    
    public static class Serializer implements JsonDeserializer<LootItemFunction>, JsonSerializer<LootItemFunction>
    {
        public LootItemFunction deserialize(final JsonElement jsonElement, final Type type, final JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            final JsonObject var4 = GsonHelper.convertToJsonObject(jsonElement, "function");
            final ResourceLocation var5 = new ResourceLocation(GsonHelper.getAsString(var4, "function"));
            LootItemFunction.Serializer<?> var6;
            try {
                var6 = LootItemFunctions.getSerializer(var5);
            }
            catch (IllegalArgumentException var7) {
                throw new JsonSyntaxException("Unknown function '" + var5 + "'");
            }
            return (LootItemFunction)var6.deserialize(var4, jsonDeserializationContext);
        }
        
        public JsonElement serialize(final LootItemFunction lootItemFunction, final Type type, final JsonSerializationContext jsonSerializationContext) {
            final LootItemFunction.Serializer<LootItemFunction> var4 = LootItemFunctions.getSerializer(lootItemFunction);
            final JsonObject var5 = new JsonObject();
            var5.addProperty("function", var4.getName().toString());
            var4.serialize(var5, lootItemFunction, jsonSerializationContext);
            return (JsonElement)var5;
        }
    }
}
