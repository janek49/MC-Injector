package net.minecraft.world.level.storage.loot;

import net.minecraft.resources.*;
import net.minecraft.server.packs.resources.*;
import net.minecraft.util.profiling.*;
import java.util.function.*;
import com.google.common.collect.*;
import java.util.*;
import org.apache.logging.log4j.*;
import com.google.gson.*;
import java.lang.reflect.*;
import net.minecraft.world.level.storage.loot.entries.*;
import net.minecraft.world.level.storage.loot.functions.*;
import net.minecraft.world.level.storage.loot.predicates.*;

public class LootTables extends SimpleJsonResourceReloadListener
{
    private static final Logger LOGGER;
    private static final Gson GSON;
    private Map<ResourceLocation, LootTable> tables;
    
    public LootTables() {
        super(LootTables.GSON, "loot_tables");
        this.tables = (Map<ResourceLocation, LootTable>)ImmutableMap.of();
    }
    
    public LootTable get(final ResourceLocation resourceLocation) {
        return this.tables.getOrDefault(resourceLocation, LootTable.EMPTY);
    }
    
    @Override
    protected void apply(final Map<ResourceLocation, JsonObject> map, final ResourceManager resourceManager, final ProfilerFiller profilerFiller) {
        final ImmutableMap.Builder<ResourceLocation, LootTable> var2 = (ImmutableMap.Builder<ResourceLocation, LootTable>)ImmutableMap.builder();
        final JsonObject var3 = map.remove(BuiltInLootTables.EMPTY);
        if (var3 != null) {
            LootTables.LOGGER.warn("Datapack tried to redefine {} loot table, ignoring", (Object)BuiltInLootTables.EMPTY);
        }
        LootTable var4;
        final ImmutableMap.Builder builder;
        map.forEach((resourceLocation, jsonObject) -> {
            try {
                var4 = (LootTable)LootTables.GSON.fromJson(jsonObject, (Class)LootTable.class);
                builder.put((Object)resourceLocation, (Object)var4);
            }
            catch (Exception var5) {
                LootTables.LOGGER.error("Couldn't parse loot table {}", (Object)resourceLocation, (Object)var5);
            }
            return;
        });
        var2.put((Object)BuiltInLootTables.EMPTY, (Object)LootTable.EMPTY);
        final ImmutableMap<ResourceLocation, LootTable> var6 = (ImmutableMap<ResourceLocation, LootTable>)var2.build();
        final LootTableProblemCollector var7 = new LootTableProblemCollector();
        var6.forEach((resourceLocation, lootTable) -> validate(var7, resourceLocation, lootTable, var6::get));
        var7.getProblems().forEach((var0, var1) -> LootTables.LOGGER.warn("Found validation problem in " + var0 + ": " + var1));
        this.tables = (Map<ResourceLocation, LootTable>)var6;
    }
    
    public static void validate(final LootTableProblemCollector lootTableProblemCollector, final ResourceLocation resourceLocation, final LootTable lootTable, final Function<ResourceLocation, LootTable> function) {
        final Set<ResourceLocation> var4 = (Set<ResourceLocation>)ImmutableSet.of((Object)resourceLocation);
        lootTable.validate(lootTableProblemCollector.forChild("{" + resourceLocation.toString() + "}"), function, var4, lootTable.getParamSet());
    }
    
    public static JsonElement serialize(final LootTable lootTable) {
        return LootTables.GSON.toJsonTree((Object)lootTable);
    }
    
    public Set<ResourceLocation> getIds() {
        return this.tables.keySet();
    }
    
    static {
        LOGGER = LogManager.getLogger();
        GSON = new GsonBuilder().registerTypeAdapter((Type)RandomValueBounds.class, (Object)new RandomValueBounds.Serializer()).registerTypeAdapter((Type)BinomialDistributionGenerator.class, (Object)new BinomialDistributionGenerator.Serializer()).registerTypeAdapter((Type)ConstantIntValue.class, (Object)new ConstantIntValue.Serializer()).registerTypeAdapter((Type)IntLimiter.class, (Object)new IntLimiter.Serializer()).registerTypeAdapter((Type)LootPool.class, (Object)new LootPool.Serializer()).registerTypeAdapter((Type)LootTable.class, (Object)new LootTable.Serializer()).registerTypeHierarchyAdapter((Class)LootPoolEntryContainer.class, (Object)new LootPoolEntries.Serializer()).registerTypeHierarchyAdapter((Class)LootItemFunction.class, (Object)new LootItemFunctions.Serializer()).registerTypeHierarchyAdapter((Class)LootItemCondition.class, (Object)new LootItemConditions.Serializer()).registerTypeHierarchyAdapter((Class)LootContext.EntityTarget.class, (Object)new LootContext.EntityTarget.Serializer()).create();
    }
}
