package net.minecraft.world.level.storage;

import com.mojang.datafixers.*;
import java.util.*;
import net.minecraft.network.chat.*;
import com.google.common.collect.*;
import org.apache.commons.lang3.*;
import net.minecraft.server.*;
import javax.annotation.*;
import net.minecraft.util.*;
import net.minecraft.util.datafix.*;
import net.minecraft.nbt.*;
import java.time.*;
import net.minecraft.*;
import java.io.*;
import java.nio.file.attribute.*;
import java.util.zip.*;
import java.nio.file.*;
import org.apache.logging.log4j.*;
import java.time.format.*;
import java.time.temporal.*;

public class LevelStorageSource
{
    private static final Logger LOGGER;
    private static final DateTimeFormatter FORMATTER;
    private final Path baseDir;
    private final Path backupDir;
    private final DataFixer fixerUpper;
    
    public LevelStorageSource(final Path baseDir, final Path backupDir, final DataFixer fixerUpper) {
        this.fixerUpper = fixerUpper;
        try {
            Files.createDirectories(Files.exists(baseDir, new LinkOption[0]) ? baseDir.toRealPath(new LinkOption[0]) : baseDir, (FileAttribute<?>[])new FileAttribute[0]);
        }
        catch (IOException var4) {
            throw new RuntimeException(var4);
        }
        this.baseDir = baseDir;
        this.backupDir = backupDir;
    }
    
    public String getName() {
        return "Anvil";
    }
    
    public List<LevelSummary> getLevelList() throws LevelStorageException {
        if (!Files.isDirectory(this.baseDir, new LinkOption[0])) {
            throw new LevelStorageException(new TranslatableComponent("selectWorld.load_folder_access", new Object[0]).getString());
        }
        final List<LevelSummary> list = (List<LevelSummary>)Lists.newArrayList();
        final File[] listFiles;
        final File[] vars2 = listFiles = this.baseDir.toFile().listFiles();
        for (final File var6 : listFiles) {
            if (var6.isDirectory()) {
                final String var7 = var6.getName();
                final LevelData var8 = this.getDataTagFor(var7);
                if (var8 != null && (var8.getVersion() == 19132 || var8.getVersion() == 19133)) {
                    final boolean var9 = var8.getVersion() != this.getStorageVersion();
                    String var10 = var8.getLevelName();
                    if (StringUtils.isEmpty((CharSequence)var10)) {
                        var10 = var7;
                    }
                    final long var11 = 0L;
                    list.add(new LevelSummary(var8, var7, var10, 0L, var9));
                }
            }
        }
        return list;
    }
    
    private int getStorageVersion() {
        return 19133;
    }
    
    public LevelStorage selectLevel(final String string, @Nullable final MinecraftServer minecraftServer) {
        return selectLevel(this.baseDir, this.fixerUpper, string, minecraftServer);
    }
    
    protected static LevelStorage selectLevel(final Path path, final DataFixer dataFixer, final String string, @Nullable final MinecraftServer minecraftServer) {
        return new LevelStorage(path.toFile(), string, minecraftServer, dataFixer);
    }
    
    public boolean requiresConversion(final String string) {
        final LevelData var2 = this.getDataTagFor(string);
        return var2 != null && var2.getVersion() != this.getStorageVersion();
    }
    
    public boolean convertLevel(final String string, final ProgressListener progressListener) {
        return McRegionUpgrader.convertLevel(this.baseDir, this.fixerUpper, string, progressListener);
    }
    
    @Nullable
    public LevelData getDataTagFor(final String string) {
        return getDataTagFor(this.baseDir, this.fixerUpper, string);
    }
    
    @Nullable
    protected static LevelData getDataTagFor(final Path path, final DataFixer dataFixer, final String string) {
        final File var3 = new File(path.toFile(), string);
        if (!var3.exists()) {
            return null;
        }
        File var4 = new File(var3, "level.dat");
        if (var4.exists()) {
            final LevelData var5 = getLevelData(var4, dataFixer);
            if (var5 != null) {
                return var5;
            }
        }
        var4 = new File(var3, "level.dat_old");
        if (var4.exists()) {
            return getLevelData(var4, dataFixer);
        }
        return null;
    }
    
    @Nullable
    public static LevelData getLevelData(final File file, final DataFixer dataFixer) {
        try {
            final CompoundTag var2 = NbtIo.readCompressed(new FileInputStream(file));
            final CompoundTag var3 = var2.getCompound("Data");
            final CompoundTag var4 = var3.contains("Player", 10) ? var3.getCompound("Player") : null;
            var3.remove("Player");
            final int var5 = var3.contains("DataVersion", 99) ? var3.getInt("DataVersion") : -1;
            return new LevelData(NbtUtils.update(dataFixer, DataFixTypes.LEVEL, var3, var5), dataFixer, var5, var4);
        }
        catch (Exception var6) {
            LevelStorageSource.LOGGER.error("Exception reading {}", (Object)file, (Object)var6);
            return null;
        }
    }
    
    public void renameLevel(final String var1, final String var2) {
        final File var3 = new File(this.baseDir.toFile(), var1);
        if (!var3.exists()) {
            return;
        }
        final File var4 = new File(var3, "level.dat");
        if (var4.exists()) {
            try {
                final CompoundTag var5 = NbtIo.readCompressed(new FileInputStream(var4));
                final CompoundTag var6 = var5.getCompound("Data");
                var6.putString("LevelName", var2);
                NbtIo.writeCompressed(var5, new FileOutputStream(var4));
            }
            catch (Exception var7) {
                var7.printStackTrace();
            }
        }
    }
    
    public boolean isNewLevelIdAcceptable(final String string) {
        try {
            final Path var2 = this.baseDir.resolve(string);
            Files.createDirectory(var2, (FileAttribute<?>[])new FileAttribute[0]);
            Files.deleteIfExists(var2);
            return true;
        }
        catch (IOException var3) {
            return false;
        }
    }
    
    public boolean deleteLevel(final String string) {
        final File var2 = new File(this.baseDir.toFile(), string);
        if (!var2.exists()) {
            return true;
        }
        LevelStorageSource.LOGGER.info("Deleting level {}", (Object)string);
        for (int var3 = 1; var3 <= 5; ++var3) {
            LevelStorageSource.LOGGER.info("Attempt {}...", (Object)var3);
            if (deleteRecursive(var2.listFiles())) {
                break;
            }
            LevelStorageSource.LOGGER.warn("Unsuccessful in deleting contents.");
            if (var3 < 5) {
                try {
                    Thread.sleep(500L);
                }
                catch (InterruptedException ex) {}
            }
        }
        return var2.delete();
    }
    
    private static boolean deleteRecursive(final File[] files) {
        for (final File var4 : files) {
            LevelStorageSource.LOGGER.debug("Deleting {}", (Object)var4);
            if (var4.isDirectory() && !deleteRecursive(var4.listFiles())) {
                LevelStorageSource.LOGGER.warn("Couldn't delete directory {}", (Object)var4);
                return false;
            }
            if (!var4.delete()) {
                LevelStorageSource.LOGGER.warn("Couldn't delete file {}", (Object)var4);
                return false;
            }
        }
        return true;
    }
    
    public boolean levelExists(final String string) {
        return Files.isDirectory(this.baseDir.resolve(string), new LinkOption[0]);
    }
    
    public Path getBaseDir() {
        return this.baseDir;
    }
    
    public File getFile(final String var1, final String var2) {
        return this.baseDir.resolve(var1).resolve(var2).toFile();
    }
    
    private Path getLevelPath(final String string) {
        return this.baseDir.resolve(string);
    }
    
    public Path getBackupPath() {
        return this.backupDir;
    }
    
    public long makeWorldBackup(final String string) throws IOException {
        final Path var2 = this.getLevelPath(string);
        final String var3 = LocalDateTime.now().format(LevelStorageSource.FORMATTER) + "_" + string;
        final Path var4 = this.getBackupPath();
        try {
            Files.createDirectories(Files.exists(var4, new LinkOption[0]) ? var4.toRealPath(new LinkOption[0]) : var4, (FileAttribute<?>[])new FileAttribute[0]);
        }
        catch (IOException var5) {
            throw new RuntimeException(var5);
        }
        final Path var6 = var4.resolve(FileUtil.findAvailableName(var4, var3, ".zip"));
        try (final ZipOutputStream var7 = new ZipOutputStream(new BufferedOutputStream(Files.newOutputStream(var6, new OpenOption[0])))) {
            final Path var8 = Paths.get(string, new String[0]);
            Files.walkFileTree(var2, new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult visitFile(final Path path, final BasicFileAttributes basicFileAttributes) throws IOException {
                    final String var3 = var8.resolve(var2.relativize(path)).toString().replace('\\', '/');
                    final ZipEntry var4 = new ZipEntry(var3);
                    var7.putNextEntry(var4);
                    com.google.common.io.Files.asByteSource(path.toFile()).copyTo((OutputStream)var7);
                    var7.closeEntry();
                    return FileVisitResult.CONTINUE;
                }
            });
        }
        return Files.size(var6);
    }
    
    static {
        LOGGER = LogManager.getLogger();
        FORMATTER = new DateTimeFormatterBuilder().appendValue(ChronoField.YEAR, 4, 10, SignStyle.EXCEEDS_PAD).appendLiteral('-').appendValue(ChronoField.MONTH_OF_YEAR, 2).appendLiteral('-').appendValue(ChronoField.DAY_OF_MONTH, 2).appendLiteral('_').appendValue(ChronoField.HOUR_OF_DAY, 2).appendLiteral('-').appendValue(ChronoField.MINUTE_OF_HOUR, 2).appendLiteral('-').appendValue(ChronoField.SECOND_OF_MINUTE, 2).toFormatter();
    }
}
