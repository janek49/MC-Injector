package net.minecraft.world.level.storage.loot.functions;

import net.minecraft.world.level.storage.loot.*;
import javax.annotation.*;
import net.minecraft.world.level.storage.loot.predicates.*;
import java.util.*;
import net.minecraft.world.level.storage.loot.parameters.*;
import com.google.common.collect.*;
import java.util.function.*;
import net.minecraft.world.entity.*;
import net.minecraft.network.chat.*;
import com.mojang.brigadier.exceptions.*;
import net.minecraft.commands.*;
import net.minecraft.world.item.*;
import org.apache.logging.log4j.*;
import net.minecraft.resources.*;
import com.google.gson.*;
import net.minecraft.util.*;

public class SetNameFunction extends LootItemConditionalFunction
{
    private static final Logger LOGGER;
    private final Component name;
    @Nullable
    private final LootContext.EntityTarget resolutionContext;
    
    private SetNameFunction(final LootItemCondition[] lootItemConditions, @Nullable final Component name, @Nullable final LootContext.EntityTarget resolutionContext) {
        super(lootItemConditions);
        this.name = name;
        this.resolutionContext = resolutionContext;
    }
    
    @Override
    public Set<LootContextParam<?>> getReferencedContextParams() {
        return (Set<LootContextParam<?>>)((this.resolutionContext != null) ? ImmutableSet.of((Object)this.resolutionContext.getParam()) : ImmutableSet.of());
    }
    
    public static UnaryOperator<Component> createResolver(final LootContext lootContext, @Nullable final LootContext.EntityTarget lootContext$EntityTarget) {
        if (lootContext$EntityTarget != null) {
            final Entity var3 = lootContext.getParamOrNull(lootContext$EntityTarget.getParam());
            if (var3 != null) {
                final CommandSourceStack var4 = var3.createCommandSourceStack().withPermission(2);
                final CommandSourceStack commandSourceStack2;
                final Entity entity2;
                return (UnaryOperator<Component>)(var2 -> {
                    try {
                        return ComponentUtils.updateForEntity(commandSourceStack2, var2, entity2, 0);
                    }
                    catch (CommandSyntaxException var5) {
                        SetNameFunction.LOGGER.warn("Failed to resolve text component", (Throwable)var5);
                        return var2;
                    }
                });
            }
        }
        return (UnaryOperator<Component>)(component -> component);
    }
    
    public ItemStack run(final ItemStack var1, final LootContext lootContext) {
        if (this.name != null) {
            var1.setHoverName(createResolver(lootContext, this.resolutionContext).apply(this.name));
        }
        return var1;
    }
    
    static {
        LOGGER = LogManager.getLogger();
    }
    
    public static class Serializer extends LootItemConditionalFunction.Serializer<SetNameFunction>
    {
        public Serializer() {
            super(new ResourceLocation("set_name"), SetNameFunction.class);
        }
        
        @Override
        public void serialize(final JsonObject jsonObject, final SetNameFunction setNameFunction, final JsonSerializationContext jsonSerializationContext) {
            super.serialize(jsonObject, setNameFunction, jsonSerializationContext);
            if (setNameFunction.name != null) {
                jsonObject.add("name", Component.Serializer.toJsonTree(setNameFunction.name));
            }
            if (setNameFunction.resolutionContext != null) {
                jsonObject.add("entity", jsonSerializationContext.serialize((Object)setNameFunction.resolutionContext));
            }
        }
        
        @Override
        public SetNameFunction deserialize(final JsonObject jsonObject, final JsonDeserializationContext jsonDeserializationContext, final LootItemCondition[] lootItemConditions) {
            final Component var4 = Component.Serializer.fromJson(jsonObject.get("name"));
            final LootContext.EntityTarget var5 = GsonHelper.getAsObject(jsonObject, "entity", (LootContext.EntityTarget)null, jsonDeserializationContext, LootContext.EntityTarget.class);
            return new SetNameFunction(lootItemConditions, var4, var5, null);
        }
    }
}
