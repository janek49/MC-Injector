package net.minecraft.world;

import net.minecraft.world.item.*;
import net.minecraft.world.entity.player.*;

public class CompoundContainer implements Container
{
    private final Container container1;
    private final Container container2;
    
    public CompoundContainer(Container container1, Container container2) {
        if (container1 == null) {
            container1 = container2;
        }
        if (container2 == null) {
            container2 = container1;
        }
        this.container1 = container1;
        this.container2 = container2;
    }
    
    @Override
    public int getContainerSize() {
        return this.container1.getContainerSize() + this.container2.getContainerSize();
    }
    
    @Override
    public boolean isEmpty() {
        return this.container1.isEmpty() && this.container2.isEmpty();
    }
    
    public boolean contains(final Container container) {
        return this.container1 == container || this.container2 == container;
    }
    
    @Override
    public ItemStack getItem(final int i) {
        if (i >= this.container1.getContainerSize()) {
            return this.container2.getItem(i - this.container1.getContainerSize());
        }
        return this.container1.getItem(i);
    }
    
    @Override
    public ItemStack removeItem(final int var1, final int var2) {
        if (var1 >= this.container1.getContainerSize()) {
            return this.container2.removeItem(var1 - this.container1.getContainerSize(), var2);
        }
        return this.container1.removeItem(var1, var2);
    }
    
    @Override
    public ItemStack removeItemNoUpdate(final int i) {
        if (i >= this.container1.getContainerSize()) {
            return this.container2.removeItemNoUpdate(i - this.container1.getContainerSize());
        }
        return this.container1.removeItemNoUpdate(i);
    }
    
    @Override
    public void setItem(final int var1, final ItemStack itemStack) {
        if (var1 >= this.container1.getContainerSize()) {
            this.container2.setItem(var1 - this.container1.getContainerSize(), itemStack);
        }
        else {
            this.container1.setItem(var1, itemStack);
        }
    }
    
    @Override
    public int getMaxStackSize() {
        return this.container1.getMaxStackSize();
    }
    
    @Override
    public void setChanged() {
        this.container1.setChanged();
        this.container2.setChanged();
    }
    
    @Override
    public boolean stillValid(final Player player) {
        return this.container1.stillValid(player) && this.container2.stillValid(player);
    }
    
    @Override
    public void startOpen(final Player player) {
        this.container1.startOpen(player);
        this.container2.startOpen(player);
    }
    
    @Override
    public void stopOpen(final Player player) {
        this.container1.stopOpen(player);
        this.container2.stopOpen(player);
    }
    
    @Override
    public boolean canPlaceItem(final int var1, final ItemStack itemStack) {
        if (var1 >= this.container1.getContainerSize()) {
            return this.container2.canPlaceItem(var1 - this.container1.getContainerSize(), itemStack);
        }
        return this.container1.canPlaceItem(var1, itemStack);
    }
    
    @Override
    public void clearContent() {
        this.container1.clearContent();
        this.container2.clearContent();
    }
}
