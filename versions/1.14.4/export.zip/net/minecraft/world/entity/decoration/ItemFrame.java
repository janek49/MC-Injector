package net.minecraft.world.entity.decoration;

import net.minecraft.core.*;
import org.apache.commons.lang3.*;
import net.minecraft.world.phys.*;
import net.minecraft.world.entity.*;
import java.util.function.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.sounds.*;
import javax.annotation.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.level.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.saveddata.maps.*;
import net.minecraft.world.level.block.*;
import net.minecraft.nbt.*;
import net.minecraft.world.*;
import net.minecraft.network.protocol.*;
import net.minecraft.network.protocol.game.*;
import org.apache.logging.log4j.*;
import net.minecraft.network.syncher.*;

public class ItemFrame extends HangingEntity
{
    private static final Logger LOGGER;
    private static final EntityDataAccessor<ItemStack> DATA_ITEM;
    private static final EntityDataAccessor<Integer> DATA_ROTATION;
    private float dropChance;
    
    public ItemFrame(final EntityType<? extends ItemFrame> entityType, final Level level) {
        super(entityType, level);
        this.dropChance = 1.0f;
    }
    
    public ItemFrame(final Level level, final BlockPos blockPos, final Direction direction) {
        super(EntityType.ITEM_FRAME, level, blockPos);
        this.dropChance = 1.0f;
        this.setDirection(direction);
    }
    
    @Override
    protected float getEyeHeight(final Pose pose, final EntityDimensions entityDimensions) {
        return 0.0f;
    }
    
    @Override
    protected void defineSynchedData() {
        this.getEntityData().define(ItemFrame.DATA_ITEM, ItemStack.EMPTY);
        this.getEntityData().define(ItemFrame.DATA_ROTATION, 0);
    }
    
    @Override
    protected void setDirection(final Direction direction) {
        Validate.notNull((Object)direction);
        this.direction = direction;
        if (direction.getAxis().isHorizontal()) {
            this.xRot = 0.0f;
            this.yRot = (float)(this.direction.get2DDataValue() * 90);
        }
        else {
            this.xRot = (float)(-90 * direction.getAxisDirection().getStep());
            this.yRot = 0.0f;
        }
        this.xRotO = this.xRot;
        this.yRotO = this.yRot;
        this.recalculateBoundingBox();
    }
    
    @Override
    protected void recalculateBoundingBox() {
        if (this.direction == null) {
            return;
        }
        final double var1 = 0.46875;
        this.x = this.pos.getX() + 0.5 - this.direction.getStepX() * 0.46875;
        this.y = this.pos.getY() + 0.5 - this.direction.getStepY() * 0.46875;
        this.z = this.pos.getZ() + 0.5 - this.direction.getStepZ() * 0.46875;
        double var2 = this.getWidth();
        double var3 = this.getHeight();
        double var4 = this.getWidth();
        final Direction.Axis var5 = this.direction.getAxis();
        switch (var5) {
            case X: {
                var2 = 1.0;
                break;
            }
            case Y: {
                var3 = 1.0;
                break;
            }
            case Z: {
                var4 = 1.0;
                break;
            }
        }
        var2 /= 32.0;
        var3 /= 32.0;
        var4 /= 32.0;
        this.setBoundingBox(new AABB(this.x - var2, this.y - var3, this.z - var4, this.x + var2, this.y + var3, this.z + var4));
    }
    
    @Override
    public boolean survives() {
        if (!this.level.noCollision(this)) {
            return false;
        }
        final BlockState var1 = this.level.getBlockState(this.pos.relative(this.direction.getOpposite()));
        return (var1.getMaterial().isSolid() || (this.direction.getAxis().isHorizontal() && DiodeBlock.isDiode(var1))) && this.level.getEntities(this, this.getBoundingBox(), ItemFrame.HANGING_ENTITY).isEmpty();
    }
    
    @Override
    public float getPickRadius() {
        return 0.0f;
    }
    
    @Override
    public void kill() {
        this.removeFramedMap(this.getItem());
        super.kill();
    }
    
    @Override
    public boolean hurt(final DamageSource damageSource, final float var2) {
        if (this.isInvulnerableTo(damageSource)) {
            return false;
        }
        if (!damageSource.isExplosion() && !this.getItem().isEmpty()) {
            if (!this.level.isClientSide) {
                this.dropItem(damageSource.getEntity(), false);
                this.playSound(SoundEvents.ITEM_FRAME_REMOVE_ITEM, 1.0f, 1.0f);
            }
            return true;
        }
        return super.hurt(damageSource, var2);
    }
    
    @Override
    public int getWidth() {
        return 12;
    }
    
    @Override
    public int getHeight() {
        return 12;
    }
    
    @Override
    public boolean shouldRenderAtSqrDistance(final double d) {
        double var3 = 16.0;
        var3 *= 64.0 * getViewScale();
        return d < var3 * var3;
    }
    
    @Override
    public void dropItem(@Nullable final Entity entity) {
        this.playSound(SoundEvents.ITEM_FRAME_BREAK, 1.0f, 1.0f);
        this.dropItem(entity, true);
    }
    
    @Override
    public void playPlacementSound() {
        this.playSound(SoundEvents.ITEM_FRAME_PLACE, 1.0f, 1.0f);
    }
    
    private void dropItem(@Nullable final Entity entity, final boolean var2) {
        if (!this.level.getGameRules().getBoolean(GameRules.RULE_DOENTITYDROPS)) {
            if (entity == null) {
                this.removeFramedMap(this.getItem());
            }
            return;
        }
        ItemStack var3 = this.getItem();
        this.setItem(ItemStack.EMPTY);
        if (entity instanceof Player) {
            final Player var4 = (Player)entity;
            if (var4.abilities.instabuild) {
                this.removeFramedMap(var3);
                return;
            }
        }
        if (var2) {
            this.spawnAtLocation(Items.ITEM_FRAME);
        }
        if (!var3.isEmpty()) {
            var3 = var3.copy();
            this.removeFramedMap(var3);
            if (this.random.nextFloat() < this.dropChance) {
                this.spawnAtLocation(var3);
            }
        }
    }
    
    private void removeFramedMap(final ItemStack itemStack) {
        if (itemStack.getItem() == Items.FILLED_MAP) {
            final MapItemSavedData var2 = MapItem.getOrCreateSavedData(itemStack, this.level);
            var2.removedFromFrame(this.pos, this.getId());
            var2.setDirty(true);
        }
        itemStack.setFramed(null);
    }
    
    public ItemStack getItem() {
        return this.getEntityData().get(ItemFrame.DATA_ITEM);
    }
    
    public void setItem(final ItemStack item) {
        this.setItem(item, true);
    }
    
    public void setItem(ItemStack itemStack, final boolean var2) {
        if (!itemStack.isEmpty()) {
            itemStack = itemStack.copy();
            itemStack.setCount(1);
            itemStack.setFramed(this);
        }
        this.getEntityData().set(ItemFrame.DATA_ITEM, itemStack);
        if (!itemStack.isEmpty()) {
            this.playSound(SoundEvents.ITEM_FRAME_ADD_ITEM, 1.0f, 1.0f);
        }
        if (var2 && this.pos != null) {
            this.level.updateNeighbourForOutputSignal(this.pos, Blocks.AIR);
        }
    }
    
    @Override
    public boolean setSlot(final int var1, final ItemStack item) {
        if (var1 == 0) {
            this.setItem(item);
            return true;
        }
        return false;
    }
    
    @Override
    public void onSyncedDataUpdated(final EntityDataAccessor<?> entityDataAccessor) {
        if (entityDataAccessor.equals(ItemFrame.DATA_ITEM)) {
            final ItemStack var2 = this.getItem();
            if (!var2.isEmpty() && var2.getFrame() != this) {
                var2.setFramed(this);
            }
        }
    }
    
    public int getRotation() {
        return this.getEntityData().get(ItemFrame.DATA_ROTATION);
    }
    
    public void setRotation(final int rotation) {
        this.setRotation(rotation, true);
    }
    
    private void setRotation(final int var1, final boolean var2) {
        this.getEntityData().set(ItemFrame.DATA_ROTATION, var1 % 8);
        if (var2 && this.pos != null) {
            this.level.updateNeighbourForOutputSignal(this.pos, Blocks.AIR);
        }
    }
    
    @Override
    public void addAdditionalSaveData(final CompoundTag compoundTag) {
        super.addAdditionalSaveData(compoundTag);
        if (!this.getItem().isEmpty()) {
            compoundTag.put("Item", this.getItem().save(new CompoundTag()));
            compoundTag.putByte("ItemRotation", (byte)this.getRotation());
            compoundTag.putFloat("ItemDropChance", this.dropChance);
        }
        compoundTag.putByte("Facing", (byte)this.direction.get3DDataValue());
    }
    
    @Override
    public void readAdditionalSaveData(final CompoundTag compoundTag) {
        super.readAdditionalSaveData(compoundTag);
        final CompoundTag compoundTag2 = compoundTag.getCompound("Item");
        if (compoundTag2 != null && !compoundTag2.isEmpty()) {
            final ItemStack var3 = ItemStack.of(compoundTag2);
            if (var3.isEmpty()) {
                ItemFrame.LOGGER.warn("Unable to load item from: {}", (Object)compoundTag2);
            }
            final ItemStack var4 = this.getItem();
            if (!var4.isEmpty() && !ItemStack.matches(var3, var4)) {
                this.removeFramedMap(var4);
            }
            this.setItem(var3, false);
            this.setRotation(compoundTag.getByte("ItemRotation"), false);
            if (compoundTag.contains("ItemDropChance", 99)) {
                this.dropChance = compoundTag.getFloat("ItemDropChance");
            }
        }
        this.setDirection(Direction.from3DDataValue(compoundTag.getByte("Facing")));
    }
    
    @Override
    public boolean interact(final Player player, final InteractionHand interactionHand) {
        final ItemStack var3 = player.getItemInHand(interactionHand);
        if (!this.level.isClientSide) {
            if (this.getItem().isEmpty()) {
                if (!var3.isEmpty()) {
                    this.setItem(var3);
                    if (!player.abilities.instabuild) {
                        var3.shrink(1);
                    }
                }
            }
            else {
                this.playSound(SoundEvents.ITEM_FRAME_ROTATE_ITEM, 1.0f, 1.0f);
                this.setRotation(this.getRotation() + 1);
            }
        }
        return true;
    }
    
    public int getAnalogOutput() {
        if (this.getItem().isEmpty()) {
            return 0;
        }
        return this.getRotation() % 8 + 1;
    }
    
    @Override
    public Packet<?> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this, this.getType(), this.direction.get3DDataValue(), this.getPos());
    }
    
    static {
        LOGGER = LogManager.getLogger();
        DATA_ITEM = SynchedEntityData.defineId(ItemFrame.class, EntityDataSerializers.ITEM_STACK);
        DATA_ROTATION = SynchedEntityData.defineId(ItemFrame.class, EntityDataSerializers.INT);
    }
}
