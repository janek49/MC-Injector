package net.minecraft.world.entity.ai.goal;

import net.minecraft.world.level.*;
import java.util.*;
import net.minecraft.world.entity.*;

public class OcelotAttackGoal extends Goal
{
    private final BlockGetter level;
    private final Mob mob;
    private LivingEntity target;
    private int attackTime;
    
    public OcelotAttackGoal(final Mob mob) {
        this.mob = mob;
        this.level = mob.level;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }
    
    @Override
    public boolean canUse() {
        final LivingEntity var1 = this.mob.getTarget();
        if (var1 == null) {
            return false;
        }
        this.target = var1;
        return true;
    }
    
    @Override
    public boolean canContinueToUse() {
        return this.target.isAlive() && this.mob.distanceToSqr(this.target) <= 225.0 && (!this.mob.getNavigation().isDone() || this.canUse());
    }
    
    @Override
    public void stop() {
        this.target = null;
        this.mob.getNavigation().stop();
    }
    
    @Override
    public void tick() {
        this.mob.getLookControl().setLookAt(this.target, 30.0f, 30.0f);
        final double var1 = this.mob.getBbWidth() * 2.0f * (this.mob.getBbWidth() * 2.0f);
        final double var2 = this.mob.distanceToSqr(this.target.x, this.target.getBoundingBox().minY, this.target.z);
        double var3 = 0.8;
        if (var2 > var1 && var2 < 16.0) {
            var3 = 1.33;
        }
        else if (var2 < 225.0) {
            var3 = 0.6;
        }
        this.mob.getNavigation().moveTo(this.target, var3);
        this.attackTime = Math.max(this.attackTime - 1, 0);
        if (var2 > var1) {
            return;
        }
        if (this.attackTime > 0) {
            return;
        }
        this.attackTime = 20;
        this.mob.doHurtTarget(this.target);
    }
}
