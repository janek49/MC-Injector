package net.minecraft.world.entity.ai.goal;

import net.minecraft.world.entity.animal.horse.*;
import java.util.*;
import net.minecraft.world.entity.ai.util.*;
import net.minecraft.world.phys.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.*;

public class RunAroundLikeCrazyGoal extends Goal
{
    private final AbstractHorse horse;
    private final double speedModifier;
    private double posX;
    private double posY;
    private double posZ;
    
    public RunAroundLikeCrazyGoal(final AbstractHorse horse, final double speedModifier) {
        this.horse = horse;
        this.speedModifier = speedModifier;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }
    
    @Override
    public boolean canUse() {
        if (this.horse.isTamed() || !this.horse.isVehicle()) {
            return false;
        }
        final Vec3 var1 = RandomPos.getPos(this.horse, 5, 4);
        if (var1 == null) {
            return false;
        }
        this.posX = var1.x;
        this.posY = var1.y;
        this.posZ = var1.z;
        return true;
    }
    
    @Override
    public void start() {
        this.horse.getNavigation().moveTo(this.posX, this.posY, this.posZ, this.speedModifier);
    }
    
    @Override
    public boolean canContinueToUse() {
        return !this.horse.isTamed() && !this.horse.getNavigation().isDone() && this.horse.isVehicle();
    }
    
    @Override
    public void tick() {
        if (!this.horse.isTamed() && this.horse.getRandom().nextInt(50) == 0) {
            final Entity var1 = this.horse.getPassengers().get(0);
            if (var1 == null) {
                return;
            }
            if (var1 instanceof Player) {
                final int var2 = this.horse.getTemper();
                final int var3 = this.horse.getMaxTemper();
                if (var3 > 0 && this.horse.getRandom().nextInt(var3) < var2) {
                    this.horse.tameWithName((Player)var1);
                    return;
                }
                this.horse.modifyTemper(5);
            }
            this.horse.ejectPassengers();
            this.horse.makeMad();
            this.horse.level.broadcastEntityEvent(this.horse, (byte)6);
        }
    }
}
