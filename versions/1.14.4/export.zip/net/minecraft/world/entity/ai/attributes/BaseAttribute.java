package net.minecraft.world.entity.ai.attributes;

import javax.annotation.*;

public abstract class BaseAttribute implements Attribute
{
    private final Attribute parent;
    private final String name;
    private final double defaultValue;
    private boolean syncable;
    
    protected BaseAttribute(@Nullable final Attribute parent, final String name, final double defaultValue) {
        this.parent = parent;
        this.name = name;
        this.defaultValue = defaultValue;
        if (name == null) {
            throw new IllegalArgumentException("Name cannot be null!");
        }
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public double getDefaultValue() {
        return this.defaultValue;
    }
    
    @Override
    public boolean isClientSyncable() {
        return this.syncable;
    }
    
    public BaseAttribute setSyncable(final boolean syncable) {
        this.syncable = syncable;
        return this;
    }
    
    @Nullable
    @Override
    public Attribute getParentAttribute() {
        return this.parent;
    }
    
    @Override
    public int hashCode() {
        return this.name.hashCode();
    }
    
    @Override
    public boolean equals(final Object object) {
        return object instanceof Attribute && this.name.equals(((Attribute)object).getName());
    }
}
