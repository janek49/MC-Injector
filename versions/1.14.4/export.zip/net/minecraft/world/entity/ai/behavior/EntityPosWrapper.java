package net.minecraft.world.entity.ai.behavior;

import net.minecraft.core.*;
import net.minecraft.world.phys.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.memory.*;
import java.util.*;

public class EntityPosWrapper implements PositionWrapper
{
    private final Entity entity;
    
    public EntityPosWrapper(final Entity entity) {
        this.entity = entity;
    }
    
    @Override
    public BlockPos getPos() {
        return new BlockPos(this.entity);
    }
    
    @Override
    public Vec3 getLookAtPos() {
        return new Vec3(this.entity.x, this.entity.y + this.entity.getEyeHeight(), this.entity.z);
    }
    
    @Override
    public boolean isVisible(final LivingEntity livingEntity) {
        final Optional<List<LivingEntity>> var2 = livingEntity.getBrain().getMemory(MemoryModuleType.VISIBLE_LIVING_ENTITIES);
        return this.entity.isAlive() && var2.isPresent() && var2.get().contains(this.entity);
    }
    
    @Override
    public String toString() {
        return "EntityPosWrapper for " + this.entity;
    }
}
