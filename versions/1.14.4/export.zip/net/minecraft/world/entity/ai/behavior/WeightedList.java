package net.minecraft.world.entity.ai.behavior;

import com.google.common.collect.*;
import java.util.*;
import java.util.stream.*;
import java.util.function.*;

public class WeightedList<U>
{
    private final List<WeightedEntry<? extends U>> entries;
    private final Random random;
    
    public WeightedList() {
        this(new Random());
    }
    
    public WeightedList(final Random random) {
        this.entries = (List<WeightedEntry<? extends U>>)Lists.newArrayList();
        this.random = random;
    }
    
    public void add(final U object, final int var2) {
        this.entries.add((WeightedEntry<? extends U>)new WeightedEntry<U>((Object)object, var2));
    }
    
    public void shuffle() {
        this.entries.forEach(weightedList$WeightedEntry -> weightedList$WeightedEntry.setRandom(this.random.nextFloat()));
        this.entries.sort(Comparator.comparingDouble(WeightedEntry::getRandWeight));
    }
    
    public Stream<? extends U> stream() {
        return this.entries.stream().map((Function<? super Object, ? extends U>)WeightedEntry::getData);
    }
    
    @Override
    public String toString() {
        return "WeightedList[" + this.entries + "]";
    }
    
    class WeightedEntry<T>
    {
        private final T data;
        private final int weight;
        private double randWeight;
        
        private WeightedEntry(final Object data, final int weight) {
            this.weight = weight;
            this.data = (T)data;
        }
        
        public double getRandWeight() {
            return this.randWeight;
        }
        
        public void setRandom(final float random) {
            this.randWeight = -Math.pow(random, 1.0f / this.weight);
        }
        
        public T getData() {
            return this.data;
        }
        
        @Override
        public String toString() {
            return "" + this.weight + ":" + this.data;
        }
    }
}
