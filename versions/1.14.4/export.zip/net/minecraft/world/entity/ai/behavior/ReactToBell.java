package net.minecraft.world.entity.ai.behavior;

import net.minecraft.world.entity.ai.memory.*;
import com.google.common.collect.*;
import java.util.*;
import net.minecraft.server.level.*;
import net.minecraft.core.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.schedule.*;
import net.minecraft.world.entity.ai.*;
import net.minecraft.world.entity.raid.*;

public class ReactToBell extends Behavior<LivingEntity>
{
    public ReactToBell() {
        super((Map)ImmutableMap.of((Object)MemoryModuleType.HEARD_BELL_TIME, (Object)MemoryStatus.VALUE_PRESENT));
    }
    
    @Override
    protected void start(final ServerLevel serverLevel, final LivingEntity livingEntity, final long var3) {
        final Brain<?> var4 = livingEntity.getBrain();
        final Raid var5 = serverLevel.getRaidAt(new BlockPos(livingEntity));
        if (var5 == null) {
            var4.setActivity(Activity.HIDE);
        }
    }
}
