package net.minecraft.world.entity.monster;

import net.minecraft.nbt.*;
import javax.annotation.*;
import org.apache.logging.log4j.*;
import net.minecraft.world.entity.ai.attributes.*;
import java.util.*;

public class SharedMonsterAttributes
{
    private static final Logger LOGGER;
    public static final Attribute MAX_HEALTH;
    public static final Attribute FOLLOW_RANGE;
    public static final Attribute KNOCKBACK_RESISTANCE;
    public static final Attribute MOVEMENT_SPEED;
    public static final Attribute FLYING_SPEED;
    public static final Attribute ATTACK_DAMAGE;
    public static final Attribute ATTACK_KNOCKBACK;
    public static final Attribute ATTACK_SPEED;
    public static final Attribute ARMOR;
    public static final Attribute ARMOR_TOUGHNESS;
    public static final Attribute LUCK;
    
    public static ListTag saveAttributes(final BaseAttributeMap baseAttributeMap) {
        final ListTag listTag = new ListTag();
        for (final AttributeInstance var3 : baseAttributeMap.getAttributes()) {
            ((AbstractList<CompoundTag>)listTag).add(saveAttribute(var3));
        }
        return listTag;
    }
    
    private static CompoundTag saveAttribute(final AttributeInstance attributeInstance) {
        final CompoundTag compoundTag = new CompoundTag();
        final Attribute var2 = attributeInstance.getAttribute();
        compoundTag.putString("Name", var2.getName());
        compoundTag.putDouble("Base", attributeInstance.getBaseValue());
        final Collection<AttributeModifier> var3 = attributeInstance.getModifiers();
        if (var3 != null && !var3.isEmpty()) {
            final ListTag var4 = new ListTag();
            for (final AttributeModifier var5 : var3) {
                if (var5.isSerializable()) {
                    ((AbstractList<CompoundTag>)var4).add(saveAttributeModifier(var5));
                }
            }
            compoundTag.put("Modifiers", var4);
        }
        return compoundTag;
    }
    
    public static CompoundTag saveAttributeModifier(final AttributeModifier attributeModifier) {
        final CompoundTag compoundTag = new CompoundTag();
        compoundTag.putString("Name", attributeModifier.getName());
        compoundTag.putDouble("Amount", attributeModifier.getAmount());
        compoundTag.putInt("Operation", attributeModifier.getOperation().toValue());
        compoundTag.putUUID("UUID", attributeModifier.getId());
        return compoundTag;
    }
    
    public static void loadAttributes(final BaseAttributeMap baseAttributeMap, final ListTag listTag) {
        for (int var2 = 0; var2 < listTag.size(); ++var2) {
            final CompoundTag var3 = listTag.getCompound(var2);
            final AttributeInstance var4 = baseAttributeMap.getInstance(var3.getString("Name"));
            if (var4 == null) {
                SharedMonsterAttributes.LOGGER.warn("Ignoring unknown attribute '{}'", (Object)var3.getString("Name"));
            }
            else {
                loadAttribute(var4, var3);
            }
        }
    }
    
    private static void loadAttribute(final AttributeInstance attributeInstance, final CompoundTag compoundTag) {
        attributeInstance.setBaseValue(compoundTag.getDouble("Base"));
        if (compoundTag.contains("Modifiers", 9)) {
            final ListTag var2 = compoundTag.getList("Modifiers", 10);
            for (int var3 = 0; var3 < var2.size(); ++var3) {
                final AttributeModifier var4 = loadAttributeModifier(var2.getCompound(var3));
                if (var4 != null) {
                    final AttributeModifier var5 = attributeInstance.getModifier(var4.getId());
                    if (var5 != null) {
                        attributeInstance.removeModifier(var5);
                    }
                    attributeInstance.addModifier(var4);
                }
            }
        }
    }
    
    @Nullable
    public static AttributeModifier loadAttributeModifier(final CompoundTag compoundTag) {
        final UUID var1 = compoundTag.getUUID("UUID");
        try {
            final AttributeModifier.Operation var2 = AttributeModifier.Operation.fromValue(compoundTag.getInt("Operation"));
            return new AttributeModifier(var1, compoundTag.getString("Name"), compoundTag.getDouble("Amount"), var2);
        }
        catch (Exception var3) {
            SharedMonsterAttributes.LOGGER.warn("Unable to create attribute: {}", (Object)var3.getMessage());
            return null;
        }
    }
    
    static {
        LOGGER = LogManager.getLogger();
        MAX_HEALTH = new RangedAttribute(null, "generic.maxHealth", 20.0, 0.0, 1024.0).importLegacyName("Max Health").setSyncable(true);
        FOLLOW_RANGE = new RangedAttribute(null, "generic.followRange", 32.0, 0.0, 2048.0).importLegacyName("Follow Range");
        KNOCKBACK_RESISTANCE = new RangedAttribute(null, "generic.knockbackResistance", 0.0, 0.0, 1.0).importLegacyName("Knockback Resistance");
        MOVEMENT_SPEED = new RangedAttribute(null, "generic.movementSpeed", 0.699999988079071, 0.0, 1024.0).importLegacyName("Movement Speed").setSyncable(true);
        FLYING_SPEED = new RangedAttribute(null, "generic.flyingSpeed", 0.4000000059604645, 0.0, 1024.0).importLegacyName("Flying Speed").setSyncable(true);
        ATTACK_DAMAGE = new RangedAttribute(null, "generic.attackDamage", 2.0, 0.0, 2048.0);
        ATTACK_KNOCKBACK = new RangedAttribute(null, "generic.attackKnockback", 0.0, 0.0, 5.0);
        ATTACK_SPEED = new RangedAttribute(null, "generic.attackSpeed", 4.0, 0.0, 1024.0).setSyncable(true);
        ARMOR = new RangedAttribute(null, "generic.armor", 0.0, 0.0, 30.0).setSyncable(true);
        ARMOR_TOUGHNESS = new RangedAttribute(null, "generic.armorToughness", 0.0, 0.0, 20.0).setSyncable(true);
        LUCK = new RangedAttribute(null, "generic.luck", 0.0, -1024.0, 1024.0).setSyncable(true);
    }
}
