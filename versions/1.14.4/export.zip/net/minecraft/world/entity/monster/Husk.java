package net.minecraft.world.entity.monster;

import net.minecraft.world.level.*;
import net.minecraft.core.*;
import java.util.*;
import net.minecraft.sounds.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.item.*;

public class Husk extends Zombie
{
    public Husk(final EntityType<? extends Husk> entityType, final Level level) {
        super(entityType, level);
    }
    
    public static boolean checkHuskSpawnRules(final EntityType<Husk> entityType, final LevelAccessor levelAccessor, final MobSpawnType mobSpawnType, final BlockPos blockPos, final Random random) {
        return Monster.checkMonsterSpawnRules(entityType, levelAccessor, mobSpawnType, blockPos, random) && (mobSpawnType == MobSpawnType.SPAWNER || levelAccessor.canSeeSky(blockPos));
    }
    
    @Override
    protected boolean isSunSensitive() {
        return false;
    }
    
    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.HUSK_AMBIENT;
    }
    
    @Override
    protected SoundEvent getHurtSound(final DamageSource damageSource) {
        return SoundEvents.HUSK_HURT;
    }
    
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.HUSK_DEATH;
    }
    
    @Override
    protected SoundEvent getStepSound() {
        return SoundEvents.HUSK_STEP;
    }
    
    @Override
    public boolean doHurtTarget(final Entity entity) {
        final boolean var2 = super.doHurtTarget(entity);
        if (var2 && this.getMainHandItem().isEmpty() && entity instanceof LivingEntity) {
            final float var3 = this.level.getCurrentDifficultyAt(new BlockPos(this)).getEffectiveDifficulty();
            ((LivingEntity)entity).addEffect(new MobEffectInstance(MobEffects.HUNGER, 140 * (int)var3));
        }
        return var2;
    }
    
    @Override
    protected boolean convertsInWater() {
        return true;
    }
    
    @Override
    protected void doUnderWaterConversion() {
        this.convertTo(EntityType.ZOMBIE);
        this.level.levelEvent(null, 1041, new BlockPos(this), 0);
    }
    
    @Override
    protected ItemStack getSkull() {
        return ItemStack.EMPTY;
    }
}
