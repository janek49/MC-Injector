package net.minecraft.world.entity.monster;

public interface Enemy
{
}
