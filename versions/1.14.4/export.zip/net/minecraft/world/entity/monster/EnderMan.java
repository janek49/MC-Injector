package net.minecraft.world.entity.monster;

import net.minecraft.world.level.block.state.*;
import java.util.function.*;
import net.minecraft.world.level.pathfinder.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import javax.annotation.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.nbt.*;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.*;
import net.minecraft.core.particles.*;
import net.minecraft.core.*;
import net.minecraft.sounds.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.network.syncher.*;
import net.minecraft.world.entity.ai.targeting.*;
import net.minecraft.util.*;
import java.util.*;
import net.minecraft.world.level.*;
import net.minecraft.tags.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.*;

public class EnderMan extends Monster
{
    private static final UUID SPEED_MODIFIER_ATTACKING_UUID;
    private static final AttributeModifier SPEED_MODIFIER_ATTACKING;
    private static final EntityDataAccessor<Optional<BlockState>> DATA_CARRY_STATE;
    private static final EntityDataAccessor<Boolean> DATA_CREEPY;
    private static final Predicate<LivingEntity> ENDERMITE_SELECTOR;
    private int lastCreepySound;
    private int targetChangeTime;
    
    public EnderMan(final EntityType<? extends EnderMan> entityType, final Level level) {
        super(entityType, level);
        this.maxUpStep = 1.0f;
        this.setPathfindingMalus(BlockPathTypes.WATER, -1.0f);
    }
    
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new EndermanFreezeWhenLookedAt(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 1.0, 0.0f));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.goalSelector.addGoal(10, new EndermanLeaveBlockGoal(this));
        this.goalSelector.addGoal(11, new EndermanTakeBlockGoal(this));
        this.targetSelector.addGoal(1, new EndermanLookForPlayerGoal(this));
        this.targetSelector.addGoal(2, new HurtByTargetGoal(this, (Class<?>[])new Class[0]));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<Object>(this, Endermite.class, 10, true, false, EnderMan.ENDERMITE_SELECTOR));
    }
    
    @Override
    protected void registerAttributes() {
        super.registerAttributes();
        this.getAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(40.0);
        this.getAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.30000001192092896);
        this.getAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(7.0);
        this.getAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64.0);
    }
    
    @Override
    public void setTarget(@Nullable final LivingEntity target) {
        super.setTarget(target);
        final AttributeInstance var2 = this.getAttribute(SharedMonsterAttributes.MOVEMENT_SPEED);
        if (target == null) {
            this.targetChangeTime = 0;
            this.entityData.set(EnderMan.DATA_CREEPY, false);
            var2.removeModifier(EnderMan.SPEED_MODIFIER_ATTACKING);
        }
        else {
            this.targetChangeTime = this.tickCount;
            this.entityData.set(EnderMan.DATA_CREEPY, true);
            if (!var2.hasModifier(EnderMan.SPEED_MODIFIER_ATTACKING)) {
                var2.addModifier(EnderMan.SPEED_MODIFIER_ATTACKING);
            }
        }
    }
    
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(EnderMan.DATA_CARRY_STATE, Optional.empty());
        this.entityData.define(EnderMan.DATA_CREEPY, false);
    }
    
    public void playCreepySound() {
        if (this.tickCount >= this.lastCreepySound + 400) {
            this.lastCreepySound = this.tickCount;
            if (!this.isSilent()) {
                this.level.playLocalSound(this.x, this.y + this.getEyeHeight(), this.z, SoundEvents.ENDERMAN_STARE, this.getSoundSource(), 2.5f, 1.0f, false);
            }
        }
    }
    
    @Override
    public void onSyncedDataUpdated(final EntityDataAccessor<?> entityDataAccessor) {
        if (EnderMan.DATA_CREEPY.equals(entityDataAccessor) && this.isCreepy() && this.level.isClientSide) {
            this.playCreepySound();
        }
        super.onSyncedDataUpdated(entityDataAccessor);
    }
    
    @Override
    public void addAdditionalSaveData(final CompoundTag compoundTag) {
        super.addAdditionalSaveData(compoundTag);
        final BlockState var2 = this.getCarriedBlock();
        if (var2 != null) {
            compoundTag.put("carriedBlockState", NbtUtils.writeBlockState(var2));
        }
    }
    
    @Override
    public void readAdditionalSaveData(final CompoundTag compoundTag) {
        super.readAdditionalSaveData(compoundTag);
        BlockState var2 = null;
        if (compoundTag.contains("carriedBlockState", 10)) {
            var2 = NbtUtils.readBlockState(compoundTag.getCompound("carriedBlockState"));
            if (var2.isAir()) {
                var2 = null;
            }
        }
        this.setCarriedBlock(var2);
    }
    
    private boolean isLookingAtMe(final Player player) {
        final ItemStack var2 = player.inventory.armor.get(3);
        if (var2.getItem() == Blocks.CARVED_PUMPKIN.asItem()) {
            return false;
        }
        final Vec3 var3 = player.getViewVector(1.0f).normalize();
        Vec3 var4 = new Vec3(this.x - player.x, this.getBoundingBox().minY + this.getEyeHeight() - (player.y + player.getEyeHeight()), this.z - player.z);
        final double var5 = var4.length();
        var4 = var4.normalize();
        final double var6 = var3.dot(var4);
        return var6 > 1.0 - 0.025 / var5 && player.canSee(this);
    }
    
    @Override
    protected float getStandingEyeHeight(final Pose pose, final EntityDimensions entityDimensions) {
        return 2.55f;
    }
    
    @Override
    public void aiStep() {
        if (this.level.isClientSide) {
            for (int var1 = 0; var1 < 2; ++var1) {
                this.level.addParticle(ParticleTypes.PORTAL, this.x + (this.random.nextDouble() - 0.5) * this.getBbWidth(), this.y + this.random.nextDouble() * this.getBbHeight() - 0.25, this.z + (this.random.nextDouble() - 0.5) * this.getBbWidth(), (this.random.nextDouble() - 0.5) * 2.0, -this.random.nextDouble(), (this.random.nextDouble() - 0.5) * 2.0);
            }
        }
        this.jumping = false;
        super.aiStep();
    }
    
    @Override
    protected void customServerAiStep() {
        if (this.isInWaterRainOrBubble()) {
            this.hurt(DamageSource.DROWN, 1.0f);
        }
        if (this.level.isDay() && this.tickCount >= this.targetChangeTime + 600) {
            final float var1 = this.getBrightness();
            if (var1 > 0.5f && this.level.canSeeSky(new BlockPos(this)) && this.random.nextFloat() * 30.0f < (var1 - 0.4f) * 2.0f) {
                this.setTarget(null);
                this.teleport();
            }
        }
        super.customServerAiStep();
    }
    
    protected boolean teleport() {
        final double var1 = this.x + (this.random.nextDouble() - 0.5) * 64.0;
        final double var2 = this.y + (this.random.nextInt(64) - 32);
        final double var3 = this.z + (this.random.nextDouble() - 0.5) * 64.0;
        return this.teleport(var1, var2, var3);
    }
    
    private boolean teleportTowards(final Entity entity) {
        Vec3 var2 = new Vec3(this.x - entity.x, this.getBoundingBox().minY + this.getBbHeight() / 2.0f - entity.y + entity.getEyeHeight(), this.z - entity.z);
        var2 = var2.normalize();
        final double var3 = 16.0;
        final double var4 = this.x + (this.random.nextDouble() - 0.5) * 8.0 - var2.x * 16.0;
        final double var5 = this.y + (this.random.nextInt(16) - 8) - var2.y * 16.0;
        final double var6 = this.z + (this.random.nextDouble() - 0.5) * 8.0 - var2.z * 16.0;
        return this.teleport(var4, var5, var6);
    }
    
    private boolean teleport(final double var1, final double var3, final double var5) {
        final BlockPos.MutableBlockPos var6 = new BlockPos.MutableBlockPos(var1, var3, var5);
        while (var6.getY() > 0 && !this.level.getBlockState(var6).getMaterial().blocksMotion()) {
            var6.move(Direction.DOWN);
        }
        if (!this.level.getBlockState(var6).getMaterial().blocksMotion()) {
            return false;
        }
        final boolean var7 = this.randomTeleport(var1, var3, var5, true);
        if (var7) {
            this.level.playSound(null, this.xo, this.yo, this.zo, SoundEvents.ENDERMAN_TELEPORT, this.getSoundSource(), 1.0f, 1.0f);
            this.playSound(SoundEvents.ENDERMAN_TELEPORT, 1.0f, 1.0f);
        }
        return var7;
    }
    
    @Override
    protected SoundEvent getAmbientSound() {
        return this.isCreepy() ? SoundEvents.ENDERMAN_SCREAM : SoundEvents.ENDERMAN_AMBIENT;
    }
    
    @Override
    protected SoundEvent getHurtSound(final DamageSource damageSource) {
        return SoundEvents.ENDERMAN_HURT;
    }
    
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENDERMAN_DEATH;
    }
    
    @Override
    protected void dropCustomDeathLoot(final DamageSource damageSource, final int var2, final boolean var3) {
        super.dropCustomDeathLoot(damageSource, var2, var3);
        final BlockState var4 = this.getCarriedBlock();
        if (var4 != null) {
            this.spawnAtLocation(var4.getBlock());
        }
    }
    
    public void setCarriedBlock(@Nullable final BlockState carriedBlock) {
        this.entityData.set(EnderMan.DATA_CARRY_STATE, Optional.ofNullable(carriedBlock));
    }
    
    @Nullable
    public BlockState getCarriedBlock() {
        return this.entityData.get(EnderMan.DATA_CARRY_STATE).orElse(null);
    }
    
    @Override
    public boolean hurt(final DamageSource damageSource, final float var2) {
        if (this.isInvulnerableTo(damageSource)) {
            return false;
        }
        if (damageSource instanceof IndirectEntityDamageSource || damageSource == DamageSource.FIREWORKS) {
            for (int var3 = 0; var3 < 64; ++var3) {
                if (this.teleport()) {
                    return true;
                }
            }
            return false;
        }
        final boolean var4 = super.hurt(damageSource, var2);
        if (damageSource.isBypassArmor() && this.random.nextInt(10) != 0) {
            this.teleport();
        }
        return var4;
    }
    
    public boolean isCreepy() {
        return this.entityData.get(EnderMan.DATA_CREEPY);
    }
    
    static {
        SPEED_MODIFIER_ATTACKING_UUID = UUID.fromString("020E0DFB-87AE-4653-9556-831010E291A0");
        SPEED_MODIFIER_ATTACKING = new AttributeModifier(EnderMan.SPEED_MODIFIER_ATTACKING_UUID, "Attacking speed boost", 0.15000000596046448, AttributeModifier.Operation.ADDITION).setSerialize(false);
        DATA_CARRY_STATE = SynchedEntityData.defineId(EnderMan.class, EntityDataSerializers.BLOCK_STATE);
        DATA_CREEPY = SynchedEntityData.defineId(EnderMan.class, EntityDataSerializers.BOOLEAN);
        ENDERMITE_SELECTOR = (livingEntity -> livingEntity instanceof Endermite && livingEntity.isPlayerSpawned());
    }
    
    static class EndermanLookForPlayerGoal extends NearestAttackableTargetGoal<Player>
    {
        private final EnderMan enderman;
        private Player pendingTarget;
        private int aggroTime;
        private int teleportTime;
        private final TargetingConditions startAggroTargetConditions;
        private final TargetingConditions continueAggroTargetConditions;
        
        public EndermanLookForPlayerGoal(final EnderMan enderman) {
            super(enderman, Player.class, false);
            this.continueAggroTargetConditions = new TargetingConditions().allowUnseeable();
            this.enderman = enderman;
            this.startAggroTargetConditions = new TargetingConditions().range(this.getFollowDistance()).selector(livingEntity -> enderman.isLookingAtMe(livingEntity));
        }
        
        @Override
        public boolean canUse() {
            this.pendingTarget = this.enderman.level.getNearestPlayer(this.startAggroTargetConditions, this.enderman);
            return this.pendingTarget != null;
        }
        
        @Override
        public void start() {
            this.aggroTime = 5;
            this.teleportTime = 0;
        }
        
        @Override
        public void stop() {
            this.pendingTarget = null;
            super.stop();
        }
        
        @Override
        public boolean canContinueToUse() {
            if (this.pendingTarget == null) {
                return (this.target != null && this.continueAggroTargetConditions.test(this.enderman, this.target)) || super.canContinueToUse();
            }
            if (!this.enderman.isLookingAtMe(this.pendingTarget)) {
                return false;
            }
            this.enderman.lookAt(this.pendingTarget, 10.0f, 10.0f);
            return true;
        }
        
        @Override
        public void tick() {
            if (this.pendingTarget != null) {
                if (--this.aggroTime <= 0) {
                    this.target = this.pendingTarget;
                    this.pendingTarget = null;
                    super.start();
                }
            }
            else {
                if (this.target != null && !this.enderman.isPassenger()) {
                    if (this.enderman.isLookingAtMe((Player)this.target)) {
                        if (this.target.distanceToSqr(this.enderman) < 16.0) {
                            this.enderman.teleport();
                        }
                        this.teleportTime = 0;
                    }
                    else if (this.target.distanceToSqr(this.enderman) > 256.0 && this.teleportTime++ >= 30 && this.enderman.teleportTowards(this.target)) {
                        this.teleportTime = 0;
                    }
                }
                super.tick();
            }
        }
    }
    
    static class EndermanFreezeWhenLookedAt extends Goal
    {
        private final EnderMan enderman;
        
        public EndermanFreezeWhenLookedAt(final EnderMan enderman) {
            this.enderman = enderman;
            this.setFlags(EnumSet.of(Flag.JUMP, Flag.MOVE));
        }
        
        @Override
        public boolean canUse() {
            final LivingEntity var1 = this.enderman.getTarget();
            if (!(var1 instanceof Player)) {
                return false;
            }
            final double var2 = var1.distanceToSqr(this.enderman);
            return var2 <= 256.0 && this.enderman.isLookingAtMe((Player)var1);
        }
        
        @Override
        public void start() {
            this.enderman.getNavigation().stop();
        }
    }
    
    static class EndermanLeaveBlockGoal extends Goal
    {
        private final EnderMan enderman;
        
        public EndermanLeaveBlockGoal(final EnderMan enderman) {
            this.enderman = enderman;
        }
        
        @Override
        public boolean canUse() {
            return this.enderman.getCarriedBlock() != null && this.enderman.level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING) && this.enderman.getRandom().nextInt(2000) == 0;
        }
        
        @Override
        public void tick() {
            final Random var1 = this.enderman.getRandom();
            final LevelAccessor var2 = this.enderman.level;
            final int var3 = Mth.floor(this.enderman.x - 1.0 + var1.nextDouble() * 2.0);
            final int var4 = Mth.floor(this.enderman.y + var1.nextDouble() * 2.0);
            final int var5 = Mth.floor(this.enderman.z - 1.0 + var1.nextDouble() * 2.0);
            final BlockPos var6 = new BlockPos(var3, var4, var5);
            final BlockState var7 = var2.getBlockState(var6);
            final BlockPos var8 = var6.below();
            final BlockState var9 = var2.getBlockState(var8);
            final BlockState var10 = this.enderman.getCarriedBlock();
            if (var10 != null && this.canPlaceBlock(var2, var6, var10, var7, var9, var8)) {
                var2.setBlock(var6, var10, 3);
                this.enderman.setCarriedBlock(null);
            }
        }
        
        private boolean canPlaceBlock(final LevelReader levelReader, final BlockPos var2, final BlockState var3, final BlockState var4, final BlockState var5, final BlockPos var6) {
            return var4.isAir() && !var5.isAir() && var5.isCollisionShapeFullBlock(levelReader, var6) && var3.canSurvive(levelReader, var2);
        }
    }
    
    static class EndermanTakeBlockGoal extends Goal
    {
        private final EnderMan enderman;
        
        public EndermanTakeBlockGoal(final EnderMan enderman) {
            this.enderman = enderman;
        }
        
        @Override
        public boolean canUse() {
            return this.enderman.getCarriedBlock() == null && this.enderman.level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING) && this.enderman.getRandom().nextInt(20) == 0;
        }
        
        @Override
        public void tick() {
            final Random var1 = this.enderman.getRandom();
            final Level var2 = this.enderman.level;
            final int var3 = Mth.floor(this.enderman.x - 2.0 + var1.nextDouble() * 4.0);
            final int var4 = Mth.floor(this.enderman.y + var1.nextDouble() * 3.0);
            final int var5 = Mth.floor(this.enderman.z - 2.0 + var1.nextDouble() * 4.0);
            final BlockPos var6 = new BlockPos(var3, var4, var5);
            final BlockState var7 = var2.getBlockState(var6);
            final Block var8 = var7.getBlock();
            final Vec3 var9 = new Vec3(Mth.floor(this.enderman.x) + 0.5, var4 + 0.5, Mth.floor(this.enderman.z) + 0.5);
            final Vec3 var10 = new Vec3(var3 + 0.5, var4 + 0.5, var5 + 0.5);
            final BlockHitResult var11 = var2.clip(new ClipContext(var9, var10, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this.enderman));
            final boolean var12 = var11.getType() != HitResult.Type.MISS && var11.getBlockPos().equals(var6);
            if (var8.is(BlockTags.ENDERMAN_HOLDABLE) && var12) {
                this.enderman.setCarriedBlock(var7);
                var2.removeBlock(var6, false);
            }
        }
    }
}
