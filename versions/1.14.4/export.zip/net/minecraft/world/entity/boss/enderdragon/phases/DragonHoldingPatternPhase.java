package net.minecraft.world.entity.boss.enderdragon.phases;

import net.minecraft.world.entity.ai.targeting.*;
import net.minecraft.world.phys.*;
import javax.annotation.*;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.core.*;
import net.minecraft.util.*;
import net.minecraft.world.level.pathfinder.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.boss.enderdragon.*;
import net.minecraft.world.damagesource.*;

public class DragonHoldingPatternPhase extends AbstractDragonPhaseInstance
{
    private static final TargetingConditions NEW_TARGET_TARGETING;
    private Path currentPath;
    private Vec3 targetLocation;
    private boolean clockwise;
    
    public DragonHoldingPatternPhase(final EnderDragon enderDragon) {
        super(enderDragon);
    }
    
    @Override
    public EnderDragonPhase<DragonHoldingPatternPhase> getPhase() {
        return EnderDragonPhase.HOLDING_PATTERN;
    }
    
    @Override
    public void doServerTick() {
        final double var1 = (this.targetLocation == null) ? 0.0 : this.targetLocation.distanceToSqr(this.dragon.x, this.dragon.y, this.dragon.z);
        if (var1 < 100.0 || var1 > 22500.0 || this.dragon.horizontalCollision || this.dragon.verticalCollision) {
            this.findNewTarget();
        }
    }
    
    @Override
    public void begin() {
        this.currentPath = null;
        this.targetLocation = null;
    }
    
    @Nullable
    @Override
    public Vec3 getFlyTargetLocation() {
        return this.targetLocation;
    }
    
    private void findNewTarget() {
        if (this.currentPath != null && this.currentPath.isDone()) {
            final BlockPos var1 = this.dragon.level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(EndPodiumFeature.END_PODIUM_LOCATION));
            final int var2 = (this.dragon.getDragonFight() == null) ? 0 : this.dragon.getDragonFight().getCrystalsAlive();
            if (this.dragon.getRandom().nextInt(var2 + 3) == 0) {
                this.dragon.getPhaseManager().setPhase(EnderDragonPhase.LANDING_APPROACH);
                return;
            }
            double var3 = 64.0;
            final Player var4 = this.dragon.level.getNearestPlayer(DragonHoldingPatternPhase.NEW_TARGET_TARGETING, var1.getX(), var1.getY(), var1.getZ());
            if (var4 != null) {
                var3 = var1.distSqr(var4.position(), true) / 512.0;
            }
            if (var4 != null && !var4.abilities.invulnerable && (this.dragon.getRandom().nextInt(Mth.abs((int)var3) + 2) == 0 || this.dragon.getRandom().nextInt(var2 + 2) == 0)) {
                this.strafePlayer(var4);
                return;
            }
        }
        if (this.currentPath == null || this.currentPath.isDone()) {
            int var2;
            final int var5 = var2 = this.dragon.findClosestNode();
            if (this.dragon.getRandom().nextInt(8) == 0) {
                this.clockwise = !this.clockwise;
                var2 += 6;
            }
            if (this.clockwise) {
                ++var2;
            }
            else {
                --var2;
            }
            if (this.dragon.getDragonFight() == null || this.dragon.getDragonFight().getCrystalsAlive() < 0) {
                var2 -= 12;
                var2 &= 0x7;
                var2 += 12;
            }
            else {
                var2 %= 12;
                if (var2 < 0) {
                    var2 += 12;
                }
            }
            this.currentPath = this.dragon.findPath(var5, var2, null);
            if (this.currentPath != null) {
                this.currentPath.next();
            }
        }
        this.navigateToNextPathNode();
    }
    
    private void strafePlayer(final Player player) {
        this.dragon.getPhaseManager().setPhase(EnderDragonPhase.STRAFE_PLAYER);
        this.dragon.getPhaseManager().getPhase(EnderDragonPhase.STRAFE_PLAYER).setTarget(player);
    }
    
    private void navigateToNextPathNode() {
        if (this.currentPath != null && !this.currentPath.isDone()) {
            final Vec3 var1 = this.currentPath.currentPos();
            this.currentPath.next();
            final double var2 = var1.x;
            final double var3 = var1.z;
            double var4;
            do {
                var4 = var1.y + this.dragon.getRandom().nextFloat() * 20.0f;
            } while (var4 < var1.y);
            this.targetLocation = new Vec3(var2, var4, var3);
        }
    }
    
    @Override
    public void onCrystalDestroyed(final EndCrystal endCrystal, final BlockPos blockPos, final DamageSource damageSource, @Nullable final Player player) {
        if (player != null && !player.abilities.invulnerable) {
            this.strafePlayer(player);
        }
    }
    
    static {
        NEW_TARGET_TARGETING = new TargetingConditions().range(64.0);
    }
}
