package net.minecraft.world.entity.boss.enderdragon;

import net.minecraft.world.entity.ai.targeting.*;
import net.minecraft.world.entity.boss.*;
import net.minecraft.world.level.dimension.end.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.util.*;
import net.minecraft.core.particles.*;
import java.util.function.*;
import net.minecraft.world.entity.boss.enderdragon.phases.*;
import java.util.*;
import net.minecraft.world.phys.*;
import net.minecraft.world.level.material.*;
import net.minecraft.world.level.*;
import net.minecraft.tags.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.levelgen.*;
import javax.annotation.*;
import net.minecraft.world.level.pathfinder.*;
import com.google.common.collect.*;
import net.minecraft.nbt.*;
import net.minecraft.sounds.*;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.core.*;
import net.minecraft.world.effect.*;
import org.apache.logging.log4j.*;
import net.minecraft.network.syncher.*;

public class EnderDragon extends Mob implements Enemy
{
    private static final Logger LOGGER;
    public static final EntityDataAccessor<Integer> DATA_PHASE;
    private static final TargetingConditions CRYSTAL_DESTROY_TARGETING;
    public final double[][] positions;
    public int posPointer;
    public final EnderDragonPart[] subEntities;
    public final EnderDragonPart head;
    public final EnderDragonPart neck;
    public final EnderDragonPart body;
    public final EnderDragonPart tail1;
    public final EnderDragonPart tail2;
    public final EnderDragonPart tail3;
    public final EnderDragonPart wing1;
    public final EnderDragonPart wing2;
    public float oFlapTime;
    public float flapTime;
    public boolean inWall;
    public int dragonDeathTime;
    public EndCrystal nearestCrystal;
    private final EndDragonFight dragonFight;
    private final EnderDragonPhaseManager phaseManager;
    private int growlTime;
    private int sittingDamageReceived;
    private final Node[] nodes;
    private final int[] nodeAdjacency;
    private final BinaryHeap openSet;
    
    public EnderDragon(final EntityType<? extends EnderDragon> entityType, final Level level) {
        super(EntityType.ENDER_DRAGON, level);
        this.positions = new double[64][3];
        this.posPointer = -1;
        this.growlTime = 100;
        this.nodes = new Node[24];
        this.nodeAdjacency = new int[24];
        this.openSet = new BinaryHeap();
        this.head = new EnderDragonPart(this, "head", 1.0f, 1.0f);
        this.neck = new EnderDragonPart(this, "neck", 3.0f, 3.0f);
        this.body = new EnderDragonPart(this, "body", 5.0f, 3.0f);
        this.tail1 = new EnderDragonPart(this, "tail", 2.0f, 2.0f);
        this.tail2 = new EnderDragonPart(this, "tail", 2.0f, 2.0f);
        this.tail3 = new EnderDragonPart(this, "tail", 2.0f, 2.0f);
        this.wing1 = new EnderDragonPart(this, "wing", 4.0f, 2.0f);
        this.wing2 = new EnderDragonPart(this, "wing", 4.0f, 2.0f);
        this.subEntities = new EnderDragonPart[] { this.head, this.neck, this.body, this.tail1, this.tail2, this.tail3, this.wing1, this.wing2 };
        this.setHealth(this.getMaxHealth());
        this.noPhysics = true;
        this.noCulling = true;
        if (!level.isClientSide && level.dimension instanceof TheEndDimension) {
            this.dragonFight = ((TheEndDimension)level.dimension).getDragonFight();
        }
        else {
            this.dragonFight = null;
        }
        this.phaseManager = new EnderDragonPhaseManager(this);
    }
    
    @Override
    protected void registerAttributes() {
        super.registerAttributes();
        this.getAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(200.0);
    }
    
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.getEntityData().define(EnderDragon.DATA_PHASE, EnderDragonPhase.HOVERING.getId());
    }
    
    public double[] getLatencyPos(final int var1, float var2) {
        if (this.getHealth() <= 0.0f) {
            var2 = 0.0f;
        }
        var2 = 1.0f - var2;
        final int var3 = this.posPointer - var1 & 0x3F;
        final int var4 = this.posPointer - var1 - 1 & 0x3F;
        final double[] vars5 = new double[3];
        double var5 = this.positions[var3][0];
        double var6 = Mth.wrapDegrees(this.positions[var4][0] - var5);
        vars5[0] = var5 + var6 * var2;
        var5 = this.positions[var3][1];
        var6 = this.positions[var4][1] - var5;
        vars5[1] = var5 + var6 * var2;
        vars5[2] = Mth.lerp(var2, this.positions[var3][2], this.positions[var4][2]);
        return vars5;
    }
    
    @Override
    public void aiStep() {
        if (this.level.isClientSide) {
            this.setHealth(this.getHealth());
            if (!this.isSilent()) {
                final float var1 = Mth.cos(this.flapTime * 6.2831855f);
                final float var2 = Mth.cos(this.oFlapTime * 6.2831855f);
                if (var2 <= -0.3f && var1 >= -0.3f) {
                    this.level.playLocalSound(this.x, this.y, this.z, SoundEvents.ENDER_DRAGON_FLAP, this.getSoundSource(), 5.0f, 0.8f + this.random.nextFloat() * 0.3f, false);
                }
                if (!this.phaseManager.getCurrentPhase().isSitting() && --this.growlTime < 0) {
                    this.level.playLocalSound(this.x, this.y, this.z, SoundEvents.ENDER_DRAGON_GROWL, this.getSoundSource(), 2.5f, 0.8f + this.random.nextFloat() * 0.3f, false);
                    this.growlTime = 200 + this.random.nextInt(200);
                }
            }
        }
        this.oFlapTime = this.flapTime;
        if (this.getHealth() <= 0.0f) {
            final float var1 = (this.random.nextFloat() - 0.5f) * 8.0f;
            final float var2 = (this.random.nextFloat() - 0.5f) * 4.0f;
            final float var3 = (this.random.nextFloat() - 0.5f) * 8.0f;
            this.level.addParticle(ParticleTypes.EXPLOSION, this.x + var1, this.y + 2.0 + var2, this.z + var3, 0.0, 0.0, 0.0);
            return;
        }
        this.checkCrystals();
        final Vec3 var4 = this.getDeltaMovement();
        float var2 = 0.2f / (Mth.sqrt(Entity.getHorizontalDistanceSqr(var4)) * 10.0f + 1.0f);
        var2 *= (float)Math.pow(2.0, var4.y);
        if (this.phaseManager.getCurrentPhase().isSitting()) {
            this.flapTime += 0.1f;
        }
        else if (this.inWall) {
            this.flapTime += var2 * 0.5f;
        }
        else {
            this.flapTime += var2;
        }
        this.yRot = Mth.wrapDegrees(this.yRot);
        if (this.isNoAi()) {
            this.flapTime = 0.5f;
            return;
        }
        if (this.posPointer < 0) {
            for (int var5 = 0; var5 < this.positions.length; ++var5) {
                this.positions[var5][0] = this.yRot;
                this.positions[var5][1] = this.y;
            }
        }
        if (++this.posPointer == this.positions.length) {
            this.posPointer = 0;
        }
        this.positions[this.posPointer][0] = this.yRot;
        this.positions[this.posPointer][1] = this.y;
        if (this.level.isClientSide) {
            if (this.lerpSteps > 0) {
                final double var6 = this.x + (this.lerpX - this.x) / this.lerpSteps;
                final double var7 = this.y + (this.lerpY - this.y) / this.lerpSteps;
                final double var8 = this.z + (this.lerpZ - this.z) / this.lerpSteps;
                final double var9 = Mth.wrapDegrees(this.lerpYRot - this.yRot);
                this.yRot += (float)(var9 / this.lerpSteps);
                this.xRot += (float)((this.lerpXRot - this.xRot) / this.lerpSteps);
                --this.lerpSteps;
                this.setPos(var6, var7, var8);
                this.setRot(this.yRot, this.xRot);
            }
            this.phaseManager.getCurrentPhase().doClientTick();
        }
        else {
            DragonPhaseInstance var10 = this.phaseManager.getCurrentPhase();
            var10.doServerTick();
            if (this.phaseManager.getCurrentPhase() != var10) {
                var10 = this.phaseManager.getCurrentPhase();
                var10.doServerTick();
            }
            final Vec3 var11 = var10.getFlyTargetLocation();
            if (var11 != null) {
                final double var7 = var11.x - this.x;
                double var8 = var11.y - this.y;
                final double var9 = var11.z - this.z;
                final double var12 = var7 * var7 + var8 * var8 + var9 * var9;
                final float var13 = var10.getFlySpeed();
                final double var14 = Mth.sqrt(var7 * var7 + var9 * var9);
                if (var14 > 0.0) {
                    var8 = Mth.clamp(var8 / var14, -var13, var13);
                }
                this.setDeltaMovement(this.getDeltaMovement().add(0.0, var8 * 0.01, 0.0));
                this.yRot = Mth.wrapDegrees(this.yRot);
                final double var15 = Mth.clamp(Mth.wrapDegrees(180.0 - Mth.atan2(var7, var9) * 57.2957763671875 - this.yRot), -50.0, 50.0);
                final Vec3 var16 = var11.subtract(this.x, this.y, this.z).normalize();
                final Vec3 var17 = new Vec3(Mth.sin(this.yRot * 0.017453292f), this.getDeltaMovement().y, -Mth.cos(this.yRot * 0.017453292f)).normalize();
                final float var18 = Math.max(((float)var17.dot(var16) + 0.5f) / 1.5f, 0.0f);
                this.yRotA *= 0.8f;
                this.yRotA += (float)(var15 * var10.getTurnSpeed());
                this.yRot += this.yRotA * 0.1f;
                final float var19 = (float)(2.0 / (var12 + 1.0));
                final float var20 = 0.06f;
                this.moveRelative(0.06f * (var18 * var19 + (1.0f - var19)), new Vec3(0.0, 0.0, -1.0));
                if (this.inWall) {
                    this.move(MoverType.SELF, this.getDeltaMovement().scale(0.800000011920929));
                }
                else {
                    this.move(MoverType.SELF, this.getDeltaMovement());
                }
                final Vec3 var21 = this.getDeltaMovement().normalize();
                final double var22 = 0.8 + 0.15 * (var21.dot(var17) + 1.0) / 2.0;
                this.setDeltaMovement(this.getDeltaMovement().multiply(var22, 0.9100000262260437, var22));
            }
        }
        this.yBodyRot = this.yRot;
        final Vec3[] vars3 = new Vec3[this.subEntities.length];
        for (int var23 = 0; var23 < this.subEntities.length; ++var23) {
            vars3[var23] = new Vec3(this.subEntities[var23].x, this.subEntities[var23].y, this.subEntities[var23].z);
        }
        final float var24 = (float)(this.getLatencyPos(5, 1.0f)[1] - this.getLatencyPos(10, 1.0f)[1]) * 10.0f * 0.017453292f;
        final float var25 = Mth.cos(var24);
        final float var26 = Mth.sin(var24);
        final float var27 = this.yRot * 0.017453292f;
        final float var28 = Mth.sin(var27);
        final float var29 = Mth.cos(var27);
        this.body.tick();
        this.body.moveTo(this.x + var28 * 0.5f, this.y, this.z - var29 * 0.5f, 0.0f, 0.0f);
        this.wing1.tick();
        this.wing1.moveTo(this.x + var29 * 4.5f, this.y + 2.0, this.z + var28 * 4.5f, 0.0f, 0.0f);
        this.wing2.tick();
        this.wing2.moveTo(this.x - var29 * 4.5f, this.y + 2.0, this.z - var28 * 4.5f, 0.0f, 0.0f);
        if (!this.level.isClientSide && this.hurtTime == 0) {
            this.knockBack(this.level.getEntities(this, this.wing1.getBoundingBox().inflate(4.0, 2.0, 4.0).move(0.0, -2.0, 0.0), EntitySelector.NO_CREATIVE_OR_SPECTATOR));
            this.knockBack(this.level.getEntities(this, this.wing2.getBoundingBox().inflate(4.0, 2.0, 4.0).move(0.0, -2.0, 0.0), EntitySelector.NO_CREATIVE_OR_SPECTATOR));
            this.hurt(this.level.getEntities(this, this.head.getBoundingBox().inflate(1.0), EntitySelector.NO_CREATIVE_OR_SPECTATOR));
            this.hurt(this.level.getEntities(this, this.neck.getBoundingBox().inflate(1.0), EntitySelector.NO_CREATIVE_OR_SPECTATOR));
        }
        final double[] vars4 = this.getLatencyPos(5, 1.0f);
        final float var30 = Mth.sin(this.yRot * 0.017453292f - this.yRotA * 0.01f);
        final float var31 = Mth.cos(this.yRot * 0.017453292f - this.yRotA * 0.01f);
        this.head.tick();
        this.neck.tick();
        final float var13 = this.getHeadYOffset(1.0f);
        this.head.moveTo(this.x + var30 * 6.5f * var25, this.y + var13 + var26 * 6.5f, this.z - var31 * 6.5f * var25, 0.0f, 0.0f);
        this.neck.moveTo(this.x + var30 * 5.5f * var25, this.y + var13 + var26 * 5.5f, this.z - var31 * 5.5f * var25, 0.0f, 0.0f);
        for (int var32 = 0; var32 < 3; ++var32) {
            EnderDragonPart var33 = null;
            if (var32 == 0) {
                var33 = this.tail1;
            }
            if (var32 == 1) {
                var33 = this.tail2;
            }
            if (var32 == 2) {
                var33 = this.tail3;
            }
            final double[] vars5 = this.getLatencyPos(12 + var32 * 2, 1.0f);
            final float var34 = this.yRot * 0.017453292f + this.rotWrap(vars5[0] - vars4[0]) * 0.017453292f;
            final float var35 = Mth.sin(var34);
            final float var36 = Mth.cos(var34);
            final float var37 = 1.5f;
            final float var38 = (var32 + 1) * 2.0f;
            var33.tick();
            var33.moveTo(this.x - (var28 * 1.5f + var35 * var38) * var25, this.y + (vars5[1] - vars4[1]) - (var38 + 1.5f) * var26 + 1.5, this.z + (var29 * 1.5f + var36 * var38) * var25, 0.0f, 0.0f);
        }
        if (!this.level.isClientSide) {
            this.inWall = (this.checkWalls(this.head.getBoundingBox()) | this.checkWalls(this.neck.getBoundingBox()) | this.checkWalls(this.body.getBoundingBox()));
            if (this.dragonFight != null) {
                this.dragonFight.updateDragon(this);
            }
        }
        for (int var32 = 0; var32 < this.subEntities.length; ++var32) {
            this.subEntities[var32].xo = vars3[var32].x;
            this.subEntities[var32].yo = vars3[var32].y;
            this.subEntities[var32].zo = vars3[var32].z;
        }
    }
    
    private float getHeadYOffset(final float f) {
        double var2;
        if (this.phaseManager.getCurrentPhase().isSitting()) {
            var2 = -1.0;
        }
        else {
            final double[] vars4 = this.getLatencyPos(5, 1.0f);
            final double[] vars5 = this.getLatencyPos(0, 1.0f);
            var2 = vars4[1] - vars5[1];
        }
        return (float)var2;
    }
    
    private void checkCrystals() {
        if (this.nearestCrystal != null) {
            if (this.nearestCrystal.removed) {
                this.nearestCrystal = null;
            }
            else if (this.tickCount % 10 == 0 && this.getHealth() < this.getMaxHealth()) {
                this.setHealth(this.getHealth() + 1.0f);
            }
        }
        if (this.random.nextInt(10) == 0) {
            final List<EndCrystal> var1 = this.level.getEntitiesOfClass((Class<? extends EndCrystal>)EndCrystal.class, this.getBoundingBox().inflate(32.0));
            EndCrystal var2 = null;
            double var3 = Double.MAX_VALUE;
            for (final EndCrystal var4 : var1) {
                final double var5 = var4.distanceToSqr(this);
                if (var5 < var3) {
                    var3 = var5;
                    var2 = var4;
                }
            }
            this.nearestCrystal = var2;
        }
    }
    
    private void knockBack(final List<Entity> list) {
        final double var2 = (this.body.getBoundingBox().minX + this.body.getBoundingBox().maxX) / 2.0;
        final double var3 = (this.body.getBoundingBox().minZ + this.body.getBoundingBox().maxZ) / 2.0;
        for (final Entity var4 : list) {
            if (var4 instanceof LivingEntity) {
                final double var5 = var4.x - var2;
                final double var6 = var4.z - var3;
                final double var7 = var5 * var5 + var6 * var6;
                var4.push(var5 / var7 * 4.0, 0.20000000298023224, var6 / var7 * 4.0);
                if (this.phaseManager.getCurrentPhase().isSitting() || ((LivingEntity)var4).getLastHurtByMobTimestamp() >= var4.tickCount - 2) {
                    continue;
                }
                var4.hurt(DamageSource.mobAttack(this), 5.0f);
                this.doEnchantDamageEffects(this, var4);
            }
        }
    }
    
    private void hurt(final List<Entity> list) {
        for (int var2 = 0; var2 < list.size(); ++var2) {
            final Entity var3 = list.get(var2);
            if (var3 instanceof LivingEntity) {
                var3.hurt(DamageSource.mobAttack(this), 10.0f);
                this.doEnchantDamageEffects(this, var3);
            }
        }
    }
    
    private float rotWrap(final double d) {
        return (float)Mth.wrapDegrees(d);
    }
    
    private boolean checkWalls(final AABB aABB) {
        final int var2 = Mth.floor(aABB.minX);
        final int var3 = Mth.floor(aABB.minY);
        final int var4 = Mth.floor(aABB.minZ);
        final int var5 = Mth.floor(aABB.maxX);
        final int var6 = Mth.floor(aABB.maxY);
        final int var7 = Mth.floor(aABB.maxZ);
        boolean var8 = false;
        boolean var9 = false;
        for (int var10 = var2; var10 <= var5; ++var10) {
            for (int var11 = var3; var11 <= var6; ++var11) {
                for (int var12 = var4; var12 <= var7; ++var12) {
                    final BlockPos var13 = new BlockPos(var10, var11, var12);
                    final BlockState var14 = this.level.getBlockState(var13);
                    final Block var15 = var14.getBlock();
                    if (!var14.isAir()) {
                        if (var14.getMaterial() != Material.FIRE) {
                            if (!this.level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING) || BlockTags.DRAGON_IMMUNE.contains(var15)) {
                                var8 = true;
                            }
                            else {
                                var9 = (this.level.removeBlock(var13, false) || var9);
                            }
                        }
                    }
                }
            }
        }
        if (var9) {
            final BlockPos var16 = new BlockPos(var2 + this.random.nextInt(var5 - var2 + 1), var3 + this.random.nextInt(var6 - var3 + 1), var4 + this.random.nextInt(var7 - var4 + 1));
            this.level.levelEvent(2008, var16, 0);
        }
        return var8;
    }
    
    public boolean hurt(final EnderDragonPart enderDragonPart, final DamageSource damageSource, float var3) {
        var3 = this.phaseManager.getCurrentPhase().onHurt(damageSource, var3);
        if (enderDragonPart != this.head) {
            var3 = var3 / 4.0f + Math.min(var3, 1.0f);
        }
        if (var3 < 0.01f) {
            return false;
        }
        if (damageSource.getEntity() instanceof Player || damageSource.isExplosion()) {
            final float var4 = this.getHealth();
            this.reallyHurt(damageSource, var3);
            if (this.getHealth() <= 0.0f && !this.phaseManager.getCurrentPhase().isSitting()) {
                this.setHealth(1.0f);
                this.phaseManager.setPhase(EnderDragonPhase.DYING);
            }
            if (this.phaseManager.getCurrentPhase().isSitting()) {
                this.sittingDamageReceived += (int)(var4 - this.getHealth());
                if (this.sittingDamageReceived > 0.25f * this.getMaxHealth()) {
                    this.sittingDamageReceived = 0;
                    this.phaseManager.setPhase(EnderDragonPhase.TAKEOFF);
                }
            }
        }
        return true;
    }
    
    @Override
    public boolean hurt(final DamageSource damageSource, final float var2) {
        if (damageSource instanceof EntityDamageSource && ((EntityDamageSource)damageSource).isThorns()) {
            this.hurt(this.body, damageSource, var2);
        }
        return false;
    }
    
    protected boolean reallyHurt(final DamageSource damageSource, final float var2) {
        return super.hurt(damageSource, var2);
    }
    
    @Override
    public void kill() {
        this.remove();
        if (this.dragonFight != null) {
            this.dragonFight.updateDragon(this);
            this.dragonFight.setDragonKilled(this);
        }
    }
    
    @Override
    protected void tickDeath() {
        if (this.dragonFight != null) {
            this.dragonFight.updateDragon(this);
        }
        ++this.dragonDeathTime;
        if (this.dragonDeathTime >= 180 && this.dragonDeathTime <= 200) {
            final float var1 = (this.random.nextFloat() - 0.5f) * 8.0f;
            final float var2 = (this.random.nextFloat() - 0.5f) * 4.0f;
            final float var3 = (this.random.nextFloat() - 0.5f) * 8.0f;
            this.level.addParticle(ParticleTypes.EXPLOSION_EMITTER, this.x + var1, this.y + 2.0 + var2, this.z + var3, 0.0, 0.0, 0.0);
        }
        final boolean var4 = this.level.getGameRules().getBoolean(GameRules.RULE_DOMOBLOOT);
        int var5 = 500;
        if (this.dragonFight != null && !this.dragonFight.hasPreviouslyKilledDragon()) {
            var5 = 12000;
        }
        if (!this.level.isClientSide) {
            if (this.dragonDeathTime > 150 && this.dragonDeathTime % 5 == 0 && var4) {
                this.dropExperience(Mth.floor(var5 * 0.08f));
            }
            if (this.dragonDeathTime == 1) {
                this.level.globalLevelEvent(1028, new BlockPos(this), 0);
            }
        }
        this.move(MoverType.SELF, new Vec3(0.0, 0.10000000149011612, 0.0));
        this.yRot += 20.0f;
        this.yBodyRot = this.yRot;
        if (this.dragonDeathTime == 200 && !this.level.isClientSide) {
            if (var4) {
                this.dropExperience(Mth.floor(var5 * 0.2f));
            }
            if (this.dragonFight != null) {
                this.dragonFight.setDragonKilled(this);
            }
            this.remove();
        }
    }
    
    private void dropExperience(int i) {
        while (i > 0) {
            final int var2 = ExperienceOrb.getExperienceValue(i);
            i -= var2;
            this.level.addFreshEntity(new ExperienceOrb(this.level, this.x, this.y, this.z, var2));
        }
    }
    
    public int findClosestNode() {
        if (this.nodes[0] == null) {
            for (int var1 = 0; var1 < 24; ++var1) {
                int var2 = 5;
                int var3;
                int var4;
                int var5;
                if ((var3 = var1) < 12) {
                    var4 = Mth.floor(60.0f * Mth.cos(2.0f * (-3.1415927f + 0.2617994f * var3)));
                    var5 = Mth.floor(60.0f * Mth.sin(2.0f * (-3.1415927f + 0.2617994f * var3)));
                }
                else if (var1 < 20) {
                    var3 -= 12;
                    var4 = Mth.floor(40.0f * Mth.cos(2.0f * (-3.1415927f + 0.3926991f * var3)));
                    var5 = Mth.floor(40.0f * Mth.sin(2.0f * (-3.1415927f + 0.3926991f * var3)));
                    var2 += 10;
                }
                else {
                    var3 -= 20;
                    var4 = Mth.floor(20.0f * Mth.cos(2.0f * (-3.1415927f + 0.7853982f * var3)));
                    var5 = Mth.floor(20.0f * Mth.sin(2.0f * (-3.1415927f + 0.7853982f * var3)));
                }
                final int var6 = Math.max(this.level.getSeaLevel() + 10, this.level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(var4, 0, var5)).getY() + var2);
                this.nodes[var1] = new Node(var4, var6, var5);
            }
            this.nodeAdjacency[0] = 6146;
            this.nodeAdjacency[1] = 8197;
            this.nodeAdjacency[2] = 8202;
            this.nodeAdjacency[3] = 16404;
            this.nodeAdjacency[4] = 32808;
            this.nodeAdjacency[5] = 32848;
            this.nodeAdjacency[6] = 65696;
            this.nodeAdjacency[7] = 131392;
            this.nodeAdjacency[8] = 131712;
            this.nodeAdjacency[9] = 263424;
            this.nodeAdjacency[10] = 526848;
            this.nodeAdjacency[11] = 525313;
            this.nodeAdjacency[12] = 1581057;
            this.nodeAdjacency[13] = 3166214;
            this.nodeAdjacency[14] = 2138120;
            this.nodeAdjacency[15] = 6373424;
            this.nodeAdjacency[16] = 4358208;
            this.nodeAdjacency[17] = 12910976;
            this.nodeAdjacency[18] = 9044480;
            this.nodeAdjacency[19] = 9706496;
            this.nodeAdjacency[20] = 15216640;
            this.nodeAdjacency[21] = 13688832;
            this.nodeAdjacency[22] = 11763712;
            this.nodeAdjacency[23] = 8257536;
        }
        return this.findClosestNode(this.x, this.y, this.z);
    }
    
    public int findClosestNode(final double var1, final double var3, final double var5) {
        float var6 = 10000.0f;
        int var7 = 0;
        final Node var8 = new Node(Mth.floor(var1), Mth.floor(var3), Mth.floor(var5));
        int var9 = 0;
        if (this.dragonFight == null || this.dragonFight.getCrystalsAlive() == 0) {
            var9 = 12;
        }
        for (int var10 = var9; var10 < 24; ++var10) {
            if (this.nodes[var10] != null) {
                final float var11 = this.nodes[var10].distanceToSqr(var8);
                if (var11 < var6) {
                    var6 = var11;
                    var7 = var10;
                }
            }
        }
        return var7;
    }
    
    @Nullable
    public Path findPath(final int var1, final int var2, @Nullable final Node node) {
        for (int var3 = 0; var3 < 24; ++var3) {
            final Node var4 = this.nodes[var3];
            var4.closed = false;
            var4.f = 0.0f;
            var4.g = 0.0f;
            var4.h = 0.0f;
            var4.cameFrom = null;
            var4.heapIdx = -1;
        }
        final Node node2 = this.nodes[var1];
        Node var4 = this.nodes[var2];
        node2.g = 0.0f;
        node2.h = node2.distanceTo(var4);
        node2.f = node2.h;
        this.openSet.clear();
        this.openSet.insert(node2);
        Node var5 = node2;
        int var6 = 0;
        if (this.dragonFight == null || this.dragonFight.getCrystalsAlive() == 0) {
            var6 = 12;
        }
        while (!this.openSet.isEmpty()) {
            final Node var7 = this.openSet.pop();
            if (var7.equals(var4)) {
                if (node != null) {
                    node.cameFrom = var4;
                    var4 = node;
                }
                return this.reconstructPath(node2, var4);
            }
            if (var7.distanceTo(var4) < var5.distanceTo(var4)) {
                var5 = var7;
            }
            var7.closed = true;
            int var8 = 0;
            for (int var9 = 0; var9 < 24; ++var9) {
                if (this.nodes[var9] == var7) {
                    var8 = var9;
                    break;
                }
            }
            for (int var9 = var6; var9 < 24; ++var9) {
                if ((this.nodeAdjacency[var8] & 1 << var9) > 0) {
                    final Node var10 = this.nodes[var9];
                    if (!var10.closed) {
                        final float var11 = var7.g + var7.distanceTo(var10);
                        if (!var10.inOpenSet() || var11 < var10.g) {
                            var10.cameFrom = var7;
                            var10.g = var11;
                            var10.h = var10.distanceTo(var4);
                            if (var10.inOpenSet()) {
                                this.openSet.changeCost(var10, var10.g + var10.h);
                            }
                            else {
                                var10.f = var10.g + var10.h;
                                this.openSet.insert(var10);
                            }
                        }
                    }
                }
            }
        }
        if (var5 == node2) {
            return null;
        }
        EnderDragon.LOGGER.debug("Failed to find path from {} to {}", (Object)var1, (Object)var2);
        if (node != null) {
            node.cameFrom = var5;
            var5 = node;
        }
        return this.reconstructPath(node2, var5);
    }
    
    private Path reconstructPath(final Node var1, final Node var2) {
        final List<Node> var3 = (List<Node>)Lists.newArrayList();
        Node var4 = var2;
        var3.add(0, var4);
        while (var4.cameFrom != null) {
            var4 = var4.cameFrom;
            var3.add(0, var4);
        }
        return new Path(var3, new BlockPos(var2.x, var2.y, var2.z), true);
    }
    
    @Override
    public void addAdditionalSaveData(final CompoundTag compoundTag) {
        super.addAdditionalSaveData(compoundTag);
        compoundTag.putInt("DragonPhase", this.phaseManager.getCurrentPhase().getPhase().getId());
    }
    
    @Override
    public void readAdditionalSaveData(final CompoundTag compoundTag) {
        super.readAdditionalSaveData(compoundTag);
        if (compoundTag.contains("DragonPhase")) {
            this.phaseManager.setPhase(EnderDragonPhase.getById(compoundTag.getInt("DragonPhase")));
        }
    }
    
    @Override
    protected void checkDespawn() {
    }
    
    public EnderDragonPart[] getSubEntities() {
        return this.subEntities;
    }
    
    @Override
    public boolean isPickable() {
        return false;
    }
    
    @Override
    public SoundSource getSoundSource() {
        return SoundSource.HOSTILE;
    }
    
    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENDER_DRAGON_AMBIENT;
    }
    
    @Override
    protected SoundEvent getHurtSound(final DamageSource damageSource) {
        return SoundEvents.ENDER_DRAGON_HURT;
    }
    
    @Override
    protected float getSoundVolume() {
        return 5.0f;
    }
    
    public float getHeadPartYOffset(final int var1, final double[] vars2, final double[] vars3) {
        final DragonPhaseInstance var2 = this.phaseManager.getCurrentPhase();
        final EnderDragonPhase<? extends DragonPhaseInstance> var3 = var2.getPhase();
        double var6;
        if (var3 == EnderDragonPhase.LANDING || var3 == EnderDragonPhase.TAKEOFF) {
            final BlockPos var4 = this.level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, EndPodiumFeature.END_PODIUM_LOCATION);
            final float var5 = Math.max(Mth.sqrt(var4.distSqr(this.position(), true)) / 4.0f, 1.0f);
            var6 = var1 / var5;
        }
        else if (var2.isSitting()) {
            var6 = var1;
        }
        else if (var1 == 6) {
            var6 = 0.0;
        }
        else {
            var6 = vars3[1] - vars2[1];
        }
        return (float)var6;
    }
    
    public Vec3 getHeadLookVector(final float f) {
        final DragonPhaseInstance var2 = this.phaseManager.getCurrentPhase();
        final EnderDragonPhase<? extends DragonPhaseInstance> var3 = var2.getPhase();
        Vec3 var9;
        if (var3 == EnderDragonPhase.LANDING || var3 == EnderDragonPhase.TAKEOFF) {
            final BlockPos var4 = this.level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, EndPodiumFeature.END_PODIUM_LOCATION);
            final float var5 = Math.max(Mth.sqrt(var4.distSqr(this.position(), true)) / 4.0f, 1.0f);
            final float var6 = 6.0f / var5;
            final float var7 = this.xRot;
            final float var8 = 1.5f;
            this.xRot = -var6 * 1.5f * 5.0f;
            var9 = this.getViewVector(f);
            this.xRot = var7;
        }
        else if (var2.isSitting()) {
            final float var10 = this.xRot;
            final float var5 = 1.5f;
            this.xRot = -45.0f;
            var9 = this.getViewVector(f);
            this.xRot = var10;
        }
        else {
            var9 = this.getViewVector(f);
        }
        return var9;
    }
    
    public void onCrystalDestroyed(final EndCrystal endCrystal, final BlockPos blockPos, final DamageSource damageSource) {
        Player var4;
        if (damageSource.getEntity() instanceof Player) {
            var4 = (Player)damageSource.getEntity();
        }
        else {
            var4 = this.level.getNearestPlayer(EnderDragon.CRYSTAL_DESTROY_TARGETING, blockPos.getX(), blockPos.getY(), blockPos.getZ());
        }
        if (endCrystal == this.nearestCrystal) {
            this.hurt(this.head, DamageSource.explosion(var4), 10.0f);
        }
        this.phaseManager.getCurrentPhase().onCrystalDestroyed(endCrystal, blockPos, damageSource, var4);
    }
    
    @Override
    public void onSyncedDataUpdated(final EntityDataAccessor<?> entityDataAccessor) {
        if (EnderDragon.DATA_PHASE.equals(entityDataAccessor) && this.level.isClientSide) {
            this.phaseManager.setPhase(EnderDragonPhase.getById(this.getEntityData().get(EnderDragon.DATA_PHASE)));
        }
        super.onSyncedDataUpdated(entityDataAccessor);
    }
    
    public EnderDragonPhaseManager getPhaseManager() {
        return this.phaseManager;
    }
    
    @Nullable
    public EndDragonFight getDragonFight() {
        return this.dragonFight;
    }
    
    @Override
    public boolean addEffect(final MobEffectInstance mobEffectInstance) {
        return false;
    }
    
    @Override
    protected boolean canRide(final Entity entity) {
        return false;
    }
    
    @Override
    public boolean canChangeDimensions() {
        return false;
    }
    
    static {
        LOGGER = LogManager.getLogger();
        DATA_PHASE = SynchedEntityData.defineId(EnderDragon.class, EntityDataSerializers.INT);
        CRYSTAL_DESTROY_TARGETING = new TargetingConditions().range(64.0);
    }
}
