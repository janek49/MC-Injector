package net.minecraft.world.entity.projectile;

import java.util.function.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.core.*;
import net.minecraft.world.item.alchemy.*;
import java.util.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.phys.*;
import javax.annotation.*;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.level.block.*;
import net.minecraft.nbt.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.network.syncher.*;
import org.apache.logging.log4j.*;
import net.minecraft.world.level.block.state.*;

public class ThrownPotion extends ThrowableProjectile implements ItemSupplier
{
    private static final EntityDataAccessor<ItemStack> DATA_ITEM_STACK;
    private static final Logger LOGGER;
    public static final Predicate<LivingEntity> WATER_SENSITIVE;
    
    public ThrownPotion(final EntityType<? extends ThrownPotion> entityType, final Level level) {
        super(entityType, level);
    }
    
    public ThrownPotion(final Level level, final LivingEntity livingEntity) {
        super(EntityType.POTION, livingEntity, level);
    }
    
    public ThrownPotion(final Level level, final double var2, final double var4, final double var6) {
        super(EntityType.POTION, var2, var4, var6, level);
    }
    
    @Override
    protected void defineSynchedData() {
        this.getEntityData().define(ThrownPotion.DATA_ITEM_STACK, ItemStack.EMPTY);
    }
    
    @Override
    public ItemStack getItem() {
        final ItemStack itemStack = this.getEntityData().get(ThrownPotion.DATA_ITEM_STACK);
        if (itemStack.getItem() != Items.SPLASH_POTION && itemStack.getItem() != Items.LINGERING_POTION) {
            if (this.level != null) {
                ThrownPotion.LOGGER.error("ThrownPotion entity {} has no item?!", (Object)this.getId());
            }
            return new ItemStack(Items.SPLASH_POTION);
        }
        return itemStack;
    }
    
    public void setItem(final ItemStack item) {
        this.getEntityData().set(ThrownPotion.DATA_ITEM_STACK, item.copy());
    }
    
    @Override
    protected float getGravity() {
        return 0.05f;
    }
    
    @Override
    protected void onHit(final HitResult hitResult) {
        if (this.level.isClientSide) {
            return;
        }
        final ItemStack var2 = this.getItem();
        final Potion var3 = PotionUtils.getPotion(var2);
        final List<MobEffectInstance> var4 = PotionUtils.getMobEffects(var2);
        final boolean var5 = var3 == Potions.WATER && var4.isEmpty();
        if (hitResult.getType() == HitResult.Type.BLOCK && var5) {
            final BlockHitResult var6 = (BlockHitResult)hitResult;
            final Direction var7 = var6.getDirection();
            final BlockPos var8 = var6.getBlockPos().relative(var7);
            this.dowseFire(var8, var7);
            this.dowseFire(var8.relative(var7.getOpposite()), var7);
            for (final Direction var9 : Direction.Plane.HORIZONTAL) {
                this.dowseFire(var8.relative(var9), var9);
            }
        }
        if (var5) {
            this.applyWater();
        }
        else if (!var4.isEmpty()) {
            if (this.isLingering()) {
                this.makeAreaOfEffectCloud(var2, var3);
            }
            else {
                this.applySplash(var4, (hitResult.getType() == HitResult.Type.ENTITY) ? ((EntityHitResult)hitResult).getEntity() : null);
            }
        }
        final int var10 = var3.hasInstantEffects() ? 2007 : 2002;
        this.level.levelEvent(var10, new BlockPos(this), PotionUtils.getColor(var2));
        this.remove();
    }
    
    private void applyWater() {
        final AABB var1 = this.getBoundingBox().inflate(4.0, 2.0, 4.0);
        final List<LivingEntity> var2 = this.level.getEntitiesOfClass((Class<? extends LivingEntity>)LivingEntity.class, var1, (Predicate<? super LivingEntity>)ThrownPotion.WATER_SENSITIVE);
        if (!var2.isEmpty()) {
            for (final LivingEntity var3 : var2) {
                final double var4 = this.distanceToSqr(var3);
                if (var4 < 16.0 && isWaterSensitiveEntity(var3)) {
                    var3.hurt(DamageSource.indirectMagic(var3, this.getOwner()), 1.0f);
                }
            }
        }
    }
    
    private void applySplash(final List<MobEffectInstance> list, @Nullable final Entity entity) {
        final AABB var3 = this.getBoundingBox().inflate(4.0, 2.0, 4.0);
        final List<LivingEntity> var4 = this.level.getEntitiesOfClass((Class<? extends LivingEntity>)LivingEntity.class, var3);
        if (!var4.isEmpty()) {
            for (final LivingEntity var5 : var4) {
                if (!var5.isAffectedByPotions()) {
                    continue;
                }
                final double var6 = this.distanceToSqr(var5);
                if (var6 >= 16.0) {
                    continue;
                }
                double var7 = 1.0 - Math.sqrt(var6) / 4.0;
                if (var5 == entity) {
                    var7 = 1.0;
                }
                for (final MobEffectInstance var8 : list) {
                    final MobEffect var9 = var8.getEffect();
                    if (var9.isInstantenous()) {
                        var9.applyInstantenousEffect(this, this.getOwner(), var5, var8.getAmplifier(), var7);
                    }
                    else {
                        final int var10 = (int)(var7 * var8.getDuration() + 0.5);
                        if (var10 <= 20) {
                            continue;
                        }
                        var5.addEffect(new MobEffectInstance(var9, var10, var8.getAmplifier(), var8.isAmbient(), var8.isVisible()));
                    }
                }
            }
        }
    }
    
    private void makeAreaOfEffectCloud(final ItemStack itemStack, final Potion potion) {
        final AreaEffectCloud var3 = new AreaEffectCloud(this.level, this.x, this.y, this.z);
        var3.setOwner(this.getOwner());
        var3.setRadius(3.0f);
        var3.setRadiusOnUse(-0.5f);
        var3.setWaitTime(10);
        var3.setRadiusPerTick(-var3.getRadius() / var3.getDuration());
        var3.setPotion(potion);
        for (final MobEffectInstance var4 : PotionUtils.getCustomEffects(itemStack)) {
            var3.addEffect(new MobEffectInstance(var4));
        }
        final CompoundTag var5 = itemStack.getTag();
        if (var5 != null && var5.contains("CustomPotionColor", 99)) {
            var3.setFixedColor(var5.getInt("CustomPotionColor"));
        }
        this.level.addFreshEntity(var3);
    }
    
    private boolean isLingering() {
        return this.getItem().getItem() == Items.LINGERING_POTION;
    }
    
    private void dowseFire(final BlockPos blockPos, final Direction direction) {
        final BlockState var3 = this.level.getBlockState(blockPos);
        final Block var4 = var3.getBlock();
        if (var4 == Blocks.FIRE) {
            this.level.extinguishFire(null, blockPos.relative(direction), direction.getOpposite());
        }
        else if (var4 == Blocks.CAMPFIRE && var3.getValue((Property<Boolean>)CampfireBlock.LIT)) {
            this.level.levelEvent(null, 1009, blockPos, 0);
            this.level.setBlockAndUpdate(blockPos, ((AbstractStateHolder<O, BlockState>)var3).setValue((Property<Comparable>)CampfireBlock.LIT, false));
        }
    }
    
    @Override
    public void readAdditionalSaveData(final CompoundTag compoundTag) {
        super.readAdditionalSaveData(compoundTag);
        final ItemStack var2 = ItemStack.of(compoundTag.getCompound("Potion"));
        if (var2.isEmpty()) {
            this.remove();
        }
        else {
            this.setItem(var2);
        }
    }
    
    @Override
    public void addAdditionalSaveData(final CompoundTag compoundTag) {
        super.addAdditionalSaveData(compoundTag);
        final ItemStack var2 = this.getItem();
        if (!var2.isEmpty()) {
            compoundTag.put("Potion", var2.save(new CompoundTag()));
        }
    }
    
    private static boolean isWaterSensitiveEntity(final LivingEntity livingEntity) {
        return livingEntity instanceof EnderMan || livingEntity instanceof Blaze;
    }
    
    static {
        DATA_ITEM_STACK = SynchedEntityData.defineId(ThrownPotion.class, EntityDataSerializers.ITEM_STACK);
        LOGGER = LogManager.getLogger();
        WATER_SENSITIVE = ThrownPotion::isWaterSensitiveEntity;
    }
}
