package net.minecraft.world.entity.projectile;

import net.minecraft.world.entity.*;
import net.minecraft.util.*;
import net.minecraft.core.*;
import net.minecraft.world.level.*;
import net.minecraft.world.phys.*;
import net.minecraft.core.particles.*;
import net.minecraft.nbt.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.network.protocol.*;
import net.minecraft.network.protocol.game.*;

public abstract class AbstractHurtingProjectile extends Entity
{
    public LivingEntity owner;
    private int life;
    private int flightTime;
    public double xPower;
    public double yPower;
    public double zPower;
    
    protected AbstractHurtingProjectile(final EntityType<? extends AbstractHurtingProjectile> entityType, final Level level) {
        super(entityType, level);
    }
    
    public AbstractHurtingProjectile(final EntityType<? extends AbstractHurtingProjectile> entityType, final double var2, final double var4, final double var6, final double var8, final double var10, final double var12, final Level level) {
        this(entityType, level);
        this.moveTo(var2, var4, var6, this.yRot, this.xRot);
        this.setPos(var2, var4, var6);
        final double var13 = Mth.sqrt(var8 * var8 + var10 * var10 + var12 * var12);
        this.xPower = var8 / var13 * 0.1;
        this.yPower = var10 / var13 * 0.1;
        this.zPower = var12 / var13 * 0.1;
    }
    
    public AbstractHurtingProjectile(final EntityType<? extends AbstractHurtingProjectile> entityType, final LivingEntity owner, double var3, double var5, double var7, final Level level) {
        this(entityType, level);
        this.owner = owner;
        this.moveTo(owner.x, owner.y, owner.z, owner.yRot, owner.xRot);
        this.setPos(this.x, this.y, this.z);
        this.setDeltaMovement(Vec3.ZERO);
        var3 += this.random.nextGaussian() * 0.4;
        var5 += this.random.nextGaussian() * 0.4;
        var7 += this.random.nextGaussian() * 0.4;
        final double var8 = Mth.sqrt(var3 * var3 + var5 * var5 + var7 * var7);
        this.xPower = var3 / var8 * 0.1;
        this.yPower = var5 / var8 * 0.1;
        this.zPower = var7 / var8 * 0.1;
    }
    
    @Override
    protected void defineSynchedData() {
    }
    
    @Override
    public boolean shouldRenderAtSqrDistance(final double d) {
        double var3 = this.getBoundingBox().getSize() * 4.0;
        if (Double.isNaN(var3)) {
            var3 = 4.0;
        }
        var3 *= 64.0;
        return d < var3 * var3;
    }
    
    @Override
    public void tick() {
        if (!this.level.isClientSide && ((this.owner != null && this.owner.removed) || !this.level.hasChunkAt(new BlockPos(this)))) {
            this.remove();
            return;
        }
        super.tick();
        if (this.shouldBurn()) {
            this.setSecondsOnFire(1);
        }
        ++this.flightTime;
        final HitResult var1 = ProjectileUtil.forwardsRaycast(this, true, this.flightTime >= 25, this.owner, ClipContext.Block.COLLIDER);
        if (var1.getType() != HitResult.Type.MISS) {
            this.onHit(var1);
        }
        final Vec3 var2 = this.getDeltaMovement();
        this.x += var2.x;
        this.y += var2.y;
        this.z += var2.z;
        ProjectileUtil.rotateTowardsMovement(this, 0.2f);
        float var3 = this.getInertia();
        if (this.isInWater()) {
            for (int var4 = 0; var4 < 4; ++var4) {
                final float var5 = 0.25f;
                this.level.addParticle(ParticleTypes.BUBBLE, this.x - var2.x * 0.25, this.y - var2.y * 0.25, this.z - var2.z * 0.25, var2.x, var2.y, var2.z);
            }
            var3 = 0.8f;
        }
        this.setDeltaMovement(var2.add(this.xPower, this.yPower, this.zPower).scale(var3));
        this.level.addParticle(this.getTrailParticle(), this.x, this.y + 0.5, this.z, 0.0, 0.0, 0.0);
        this.setPos(this.x, this.y, this.z);
    }
    
    protected boolean shouldBurn() {
        return true;
    }
    
    protected ParticleOptions getTrailParticle() {
        return ParticleTypes.SMOKE;
    }
    
    protected float getInertia() {
        return 0.95f;
    }
    
    protected abstract void onHit(final HitResult p0);
    
    public void addAdditionalSaveData(final CompoundTag compoundTag) {
        final Vec3 var2 = this.getDeltaMovement();
        compoundTag.put("direction", this.newDoubleList(var2.x, var2.y, var2.z));
        compoundTag.put("power", this.newDoubleList(this.xPower, this.yPower, this.zPower));
        compoundTag.putInt("life", this.life);
    }
    
    public void readAdditionalSaveData(final CompoundTag compoundTag) {
        if (compoundTag.contains("power", 9)) {
            final ListTag var2 = compoundTag.getList("power", 6);
            if (var2.size() == 3) {
                this.xPower = var2.getDouble(0);
                this.yPower = var2.getDouble(1);
                this.zPower = var2.getDouble(2);
            }
        }
        this.life = compoundTag.getInt("life");
        if (compoundTag.contains("direction", 9) && compoundTag.getList("direction", 6).size() == 3) {
            final ListTag var2 = compoundTag.getList("direction", 6);
            this.setDeltaMovement(var2.getDouble(0), var2.getDouble(1), var2.getDouble(2));
        }
        else {
            this.remove();
        }
    }
    
    @Override
    public boolean isPickable() {
        return true;
    }
    
    @Override
    public float getPickRadius() {
        return 1.0f;
    }
    
    @Override
    public boolean hurt(final DamageSource damageSource, final float var2) {
        if (this.isInvulnerableTo(damageSource)) {
            return false;
        }
        this.markHurt();
        if (damageSource.getEntity() != null) {
            final Vec3 var3 = damageSource.getEntity().getLookAngle();
            this.setDeltaMovement(var3);
            this.xPower = var3.x * 0.1;
            this.yPower = var3.y * 0.1;
            this.zPower = var3.z * 0.1;
            if (damageSource.getEntity() instanceof LivingEntity) {
                this.owner = (LivingEntity)damageSource.getEntity();
            }
            return true;
        }
        return false;
    }
    
    @Override
    public float getBrightness() {
        return 1.0f;
    }
    
    @Override
    public int getLightColor() {
        return 15728880;
    }
    
    @Override
    public Packet<?> getAddEntityPacket() {
        final int var1 = (this.owner == null) ? 0 : this.owner.getId();
        return new ClientboundAddEntityPacket(this.getId(), this.getUUID(), this.x, this.y, this.z, this.xRot, this.yRot, this.getType(), var1, new Vec3(this.xPower, this.yPower, this.zPower));
    }
}
