package net.minecraft.world.entity.animal;

import net.minecraft.world.item.*;
import net.minecraft.world.entity.player.*;
import java.util.function.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.level.*;
import net.minecraft.core.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.biome.*;
import net.minecraft.sounds.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import javax.annotation.*;
import net.minecraft.nbt.*;
import net.minecraft.network.syncher.*;
import net.minecraft.world.entity.ai.goal.target.*;
import java.util.*;
import net.minecraft.world.entity.ai.goal.*;

public class PolarBear extends Animal
{
    private static final EntityDataAccessor<Boolean> DATA_STANDING_ID;
    private float clientSideStandAnimationO;
    private float clientSideStandAnimation;
    private int warningSoundTicks;
    
    public PolarBear(final EntityType<? extends PolarBear> entityType, final Level level) {
        super(entityType, level);
    }
    
    @Override
    public AgableMob getBreedOffspring(final AgableMob agableMob) {
        return EntityType.POLAR_BEAR.create(this.level);
    }
    
    @Override
    public boolean isFood(final ItemStack itemStack) {
        return false;
    }
    
    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PolarBearMeleeAttackGoal());
        this.goalSelector.addGoal(1, new PolarBearPanicGoal());
        this.goalSelector.addGoal(4, new FollowParentGoal(this, 1.25));
        this.goalSelector.addGoal(5, new RandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new PolarBearHurtByTargetGoal());
        this.targetSelector.addGoal(2, new PolarBearAttackPlayersGoal());
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<Object>(this, Fox.class, 10, true, true, null));
    }
    
    @Override
    protected void registerAttributes() {
        super.registerAttributes();
        this.getAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(30.0);
        this.getAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(20.0);
        this.getAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.25);
        this.getAttributes().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE);
        this.getAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(6.0);
    }
    
    public static boolean checkPolarBearSpawnRules(final EntityType<PolarBear> entityType, final LevelAccessor levelAccessor, final MobSpawnType mobSpawnType, final BlockPos blockPos, final Random random) {
        final Biome var5 = levelAccessor.getBiome(blockPos);
        if (var5 == Biomes.FROZEN_OCEAN || var5 == Biomes.DEEP_FROZEN_OCEAN) {
            return levelAccessor.getRawBrightness(blockPos, 0) > 8 && levelAccessor.getBlockState(blockPos.below()).getBlock() == Blocks.ICE;
        }
        return Animal.checkAnimalSpawnRules(entityType, levelAccessor, mobSpawnType, blockPos, random);
    }
    
    @Override
    protected SoundEvent getAmbientSound() {
        if (this.isBaby()) {
            return SoundEvents.POLAR_BEAR_AMBIENT_BABY;
        }
        return SoundEvents.POLAR_BEAR_AMBIENT;
    }
    
    @Override
    protected SoundEvent getHurtSound(final DamageSource damageSource) {
        return SoundEvents.POLAR_BEAR_HURT;
    }
    
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.POLAR_BEAR_DEATH;
    }
    
    @Override
    protected void playStepSound(final BlockPos blockPos, final BlockState blockState) {
        this.playSound(SoundEvents.POLAR_BEAR_STEP, 0.15f, 1.0f);
    }
    
    protected void playWarningSound() {
        if (this.warningSoundTicks <= 0) {
            this.playSound(SoundEvents.POLAR_BEAR_WARNING, 1.0f, this.getVoicePitch());
            this.warningSoundTicks = 40;
        }
    }
    
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(PolarBear.DATA_STANDING_ID, false);
    }
    
    @Override
    public void tick() {
        super.tick();
        if (this.level.isClientSide) {
            if (this.clientSideStandAnimation != this.clientSideStandAnimationO) {
                this.refreshDimensions();
            }
            this.clientSideStandAnimationO = this.clientSideStandAnimation;
            if (this.isStanding()) {
                this.clientSideStandAnimation = Mth.clamp(this.clientSideStandAnimation + 1.0f, 0.0f, 6.0f);
            }
            else {
                this.clientSideStandAnimation = Mth.clamp(this.clientSideStandAnimation - 1.0f, 0.0f, 6.0f);
            }
        }
        if (this.warningSoundTicks > 0) {
            --this.warningSoundTicks;
        }
    }
    
    @Override
    public EntityDimensions getDimensions(final Pose pose) {
        if (this.clientSideStandAnimation > 0.0f) {
            final float var2 = this.clientSideStandAnimation / 6.0f;
            final float var3 = 1.0f + var2;
            return super.getDimensions(pose).scale(1.0f, var3);
        }
        return super.getDimensions(pose);
    }
    
    @Override
    public boolean doHurtTarget(final Entity entity) {
        final boolean var2 = entity.hurt(DamageSource.mobAttack(this), (float)(int)this.getAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getValue());
        if (var2) {
            this.doEnchantDamageEffects(this, entity);
        }
        return var2;
    }
    
    public boolean isStanding() {
        return this.entityData.get(PolarBear.DATA_STANDING_ID);
    }
    
    public void setStanding(final boolean standing) {
        this.entityData.set(PolarBear.DATA_STANDING_ID, standing);
    }
    
    public float getStandingAnimationScale(final float f) {
        return Mth.lerp(f, this.clientSideStandAnimationO, this.clientSideStandAnimation) / 6.0f;
    }
    
    @Override
    protected float getWaterSlowDown() {
        return 0.98f;
    }
    
    @Override
    public SpawnGroupData finalizeSpawn(final LevelAccessor levelAccessor, final DifficultyInstance difficultyInstance, final MobSpawnType mobSpawnType, @Nullable SpawnGroupData var4, @Nullable final CompoundTag compoundTag) {
        if (var4 instanceof PolarBearGroupData) {
            this.setAge(-24000);
        }
        else {
            var4 = new PolarBearGroupData();
        }
        return var4;
    }
    
    static {
        DATA_STANDING_ID = SynchedEntityData.defineId(PolarBear.class, EntityDataSerializers.BOOLEAN);
    }
    
    static class PolarBearGroupData implements SpawnGroupData
    {
        private PolarBearGroupData() {
        }
    }
    
    class PolarBearHurtByTargetGoal extends HurtByTargetGoal
    {
        public PolarBearHurtByTargetGoal() {
            super(PolarBear.this, (Class<?>[])new Class[0]);
        }
        
        @Override
        public void start() {
            super.start();
            if (PolarBear.this.isBaby()) {
                this.alertOthers();
                this.stop();
            }
        }
        
        @Override
        protected void alertOther(final Mob mob, final LivingEntity livingEntity) {
            if (mob instanceof PolarBear && !mob.isBaby()) {
                super.alertOther(mob, livingEntity);
            }
        }
    }
    
    class PolarBearAttackPlayersGoal extends NearestAttackableTargetGoal<Player>
    {
        public PolarBearAttackPlayersGoal() {
            super(PolarBear.this, Player.class, 20, true, true, null);
        }
        
        @Override
        public boolean canUse() {
            if (PolarBear.this.isBaby()) {
                return false;
            }
            if (super.canUse()) {
                final List<PolarBear> var1 = PolarBear.this.level.getEntitiesOfClass((Class<? extends PolarBear>)PolarBear.class, PolarBear.this.getBoundingBox().inflate(8.0, 4.0, 8.0));
                for (final PolarBear var2 : var1) {
                    if (var2.isBaby()) {
                        return true;
                    }
                }
            }
            return false;
        }
        
        @Override
        protected double getFollowDistance() {
            return super.getFollowDistance() * 0.5;
        }
    }
    
    class PolarBearMeleeAttackGoal extends MeleeAttackGoal
    {
        public PolarBearMeleeAttackGoal() {
            super(PolarBear.this, 1.25, true);
        }
        
        @Override
        protected void checkAndPerformAttack(final LivingEntity livingEntity, final double var2) {
            final double var3 = this.getAttackReachSqr(livingEntity);
            if (var2 <= var3 && this.attackTime <= 0) {
                this.attackTime = 20;
                this.mob.doHurtTarget(livingEntity);
                PolarBear.this.setStanding(false);
            }
            else if (var2 <= var3 * 2.0) {
                if (this.attackTime <= 0) {
                    PolarBear.this.setStanding(false);
                    this.attackTime = 20;
                }
                if (this.attackTime <= 10) {
                    PolarBear.this.setStanding(true);
                    PolarBear.this.playWarningSound();
                }
            }
            else {
                this.attackTime = 20;
                PolarBear.this.setStanding(false);
            }
        }
        
        @Override
        public void stop() {
            PolarBear.this.setStanding(false);
            super.stop();
        }
        
        @Override
        protected double getAttackReachSqr(final LivingEntity livingEntity) {
            return 4.0f + livingEntity.getBbWidth();
        }
    }
    
    class PolarBearPanicGoal extends PanicGoal
    {
        public PolarBearPanicGoal() {
            super(PolarBear.this, 2.0);
        }
        
        @Override
        public boolean canUse() {
            return (PolarBear.this.isBaby() || PolarBear.this.isOnFire()) && super.canUse();
        }
    }
}
