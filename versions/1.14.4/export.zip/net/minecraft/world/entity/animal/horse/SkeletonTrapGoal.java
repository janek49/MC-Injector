package net.minecraft.world.entity.animal.horse;

import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.core.*;
import net.minecraft.server.level.*;
import net.minecraft.world.entity.global.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.nbt.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.item.enchantment.*;

public class SkeletonTrapGoal extends Goal
{
    private final SkeletonHorse horse;
    
    public SkeletonTrapGoal(final SkeletonHorse horse) {
        this.horse = horse;
    }
    
    @Override
    public boolean canUse() {
        return this.horse.level.hasNearbyAlivePlayer(this.horse.x, this.horse.y, this.horse.z, 10.0);
    }
    
    @Override
    public void tick() {
        final DifficultyInstance var1 = this.horse.level.getCurrentDifficultyAt(new BlockPos(this.horse));
        this.horse.setTrap(false);
        this.horse.setTamed(true);
        this.horse.setAge(0);
        ((ServerLevel)this.horse.level).addGlobalEntity(new LightningBolt(this.horse.level, this.horse.x, this.horse.y, this.horse.z, true));
        final Skeleton var2 = this.createSkeleton(var1, this.horse);
        var2.startRiding(this.horse);
        for (int var3 = 0; var3 < 3; ++var3) {
            final AbstractHorse var4 = this.createHorse(var1);
            final Skeleton var5 = this.createSkeleton(var1, var4);
            var5.startRiding(var4);
            var4.push(this.horse.getRandom().nextGaussian() * 0.5, 0.0, this.horse.getRandom().nextGaussian() * 0.5);
        }
    }
    
    private AbstractHorse createHorse(final DifficultyInstance difficultyInstance) {
        final SkeletonHorse var2 = EntityType.SKELETON_HORSE.create(this.horse.level);
        var2.finalizeSpawn(this.horse.level, difficultyInstance, MobSpawnType.TRIGGERED, null, null);
        var2.setPos(this.horse.x, this.horse.y, this.horse.z);
        var2.invulnerableTime = 60;
        var2.setPersistenceRequired();
        var2.setTamed(true);
        var2.setAge(0);
        var2.level.addFreshEntity(var2);
        return var2;
    }
    
    private Skeleton createSkeleton(final DifficultyInstance difficultyInstance, final AbstractHorse abstractHorse) {
        final Skeleton skeleton = EntityType.SKELETON.create(abstractHorse.level);
        skeleton.finalizeSpawn(abstractHorse.level, difficultyInstance, MobSpawnType.TRIGGERED, null, null);
        skeleton.setPos(abstractHorse.x, abstractHorse.y, abstractHorse.z);
        skeleton.invulnerableTime = 60;
        skeleton.setPersistenceRequired();
        if (skeleton.getItemBySlot(EquipmentSlot.HEAD).isEmpty()) {
            skeleton.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
        }
        skeleton.setItemSlot(EquipmentSlot.MAINHAND, EnchantmentHelper.enchantItem(skeleton.getRandom(), skeleton.getMainHandItem(), (int)(5.0f + difficultyInstance.getSpecialMultiplier() * skeleton.getRandom().nextInt(18)), false));
        skeleton.setItemSlot(EquipmentSlot.HEAD, EnchantmentHelper.enchantItem(skeleton.getRandom(), skeleton.getItemBySlot(EquipmentSlot.HEAD), (int)(5.0f + difficultyInstance.getSpecialMultiplier() * skeleton.getRandom().nextInt(18)), false));
        skeleton.level.addFreshEntity(skeleton);
        return skeleton;
    }
}
