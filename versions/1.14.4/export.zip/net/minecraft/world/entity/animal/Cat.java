package net.minecraft.world.entity.animal;

import net.minecraft.world.item.crafting.*;
import net.minecraft.resources.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.entity.ai.goal.target.*;
import java.util.function.*;
import net.minecraft.nbt.*;
import net.minecraft.sounds.*;
import javax.annotation.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.util.*;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.*;
import net.minecraft.world.level.*;
import net.minecraft.world.item.*;
import net.minecraft.network.syncher.*;
import com.google.common.collect.*;
import net.minecraft.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.*;
import net.minecraft.tags.*;
import net.minecraft.core.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.phys.*;
import net.minecraft.server.level.*;
import net.minecraft.world.level.storage.loot.parameters.*;
import net.minecraft.world.entity.item.*;
import java.util.*;
import net.minecraft.world.level.storage.loot.*;

public class Cat extends TamableAnimal
{
    private static final Ingredient TEMPT_INGREDIENT;
    private static final EntityDataAccessor<Integer> DATA_TYPE_ID;
    private static final EntityDataAccessor<Boolean> IS_LYING;
    private static final EntityDataAccessor<Boolean> RELAX_STATE_ONE;
    private static final EntityDataAccessor<Integer> DATA_COLLAR_COLOR;
    public static final Map<Integer, ResourceLocation> TEXTURE_BY_TYPE;
    private CatAvoidEntityGoal<Player> avoidPlayersGoal;
    private TemptGoal temptGoal;
    private float lieDownAmount;
    private float lieDownAmountO;
    private float lieDownAmountTail;
    private float lieDownAmountOTail;
    private float relaxStateOneAmount;
    private float relaxStateOneAmountO;
    
    public Cat(final EntityType<? extends Cat> entityType, final Level level) {
        super(entityType, level);
    }
    
    public ResourceLocation getResourceLocation() {
        return Cat.TEXTURE_BY_TYPE.get(this.getCatType());
    }
    
    @Override
    protected void registerGoals() {
        this.sitGoal = new SitGoal(this);
        this.temptGoal = new CatTemptGoal(this, 0.6, Cat.TEMPT_INGREDIENT, true);
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(1, new CatRelaxOnOwnerGoal(this));
        this.goalSelector.addGoal(2, this.sitGoal);
        this.goalSelector.addGoal(3, this.temptGoal);
        this.goalSelector.addGoal(5, new CatLieOnBedGoal(this, 1.1, 8));
        this.goalSelector.addGoal(6, new FollowOwnerGoal(this, 1.0, 10.0f, 5.0f));
        this.goalSelector.addGoal(7, new CatSitOnBlockGoal(this, 0.8));
        this.goalSelector.addGoal(8, new LeapAtTargetGoal(this, 0.3f));
        this.goalSelector.addGoal(9, new OcelotAttackGoal(this));
        this.goalSelector.addGoal(10, new BreedGoal(this, 0.8));
        this.goalSelector.addGoal(11, new WaterAvoidingRandomStrollGoal(this, 0.8, 1.0000001E-5f));
        this.goalSelector.addGoal(12, new LookAtPlayerGoal(this, Player.class, 10.0f));
        this.targetSelector.addGoal(1, new NonTameRandomTargetGoal<Object>(this, Rabbit.class, false, null));
        this.targetSelector.addGoal(1, new NonTameRandomTargetGoal<Object>(this, Turtle.class, false, Turtle.BABY_ON_LAND_SELECTOR));
    }
    
    public int getCatType() {
        return this.entityData.get(Cat.DATA_TYPE_ID);
    }
    
    public void setCatType(int catType) {
        if (catType < 0 || catType >= 11) {
            catType = this.random.nextInt(10);
        }
        this.entityData.set(Cat.DATA_TYPE_ID, catType);
    }
    
    public void setLying(final boolean lying) {
        this.entityData.set(Cat.IS_LYING, lying);
    }
    
    public boolean isLying() {
        return this.entityData.get(Cat.IS_LYING);
    }
    
    public void setRelaxStateOne(final boolean relaxStateOne) {
        this.entityData.set(Cat.RELAX_STATE_ONE, relaxStateOne);
    }
    
    public boolean isRelaxStateOne() {
        return this.entityData.get(Cat.RELAX_STATE_ONE);
    }
    
    public DyeColor getCollarColor() {
        return DyeColor.byId(this.entityData.get(Cat.DATA_COLLAR_COLOR));
    }
    
    public void setCollarColor(final DyeColor collarColor) {
        this.entityData.set(Cat.DATA_COLLAR_COLOR, collarColor.getId());
    }
    
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(Cat.DATA_TYPE_ID, 1);
        this.entityData.define(Cat.IS_LYING, false);
        this.entityData.define(Cat.RELAX_STATE_ONE, false);
        this.entityData.define(Cat.DATA_COLLAR_COLOR, DyeColor.RED.getId());
    }
    
    @Override
    public void addAdditionalSaveData(final CompoundTag compoundTag) {
        super.addAdditionalSaveData(compoundTag);
        compoundTag.putInt("CatType", this.getCatType());
        compoundTag.putByte("CollarColor", (byte)this.getCollarColor().getId());
    }
    
    @Override
    public void readAdditionalSaveData(final CompoundTag compoundTag) {
        super.readAdditionalSaveData(compoundTag);
        this.setCatType(compoundTag.getInt("CatType"));
        if (compoundTag.contains("CollarColor", 99)) {
            this.setCollarColor(DyeColor.byId(compoundTag.getInt("CollarColor")));
        }
    }
    
    public void customServerAiStep() {
        if (this.getMoveControl().hasWanted()) {
            final double var1 = this.getMoveControl().getSpeedModifier();
            if (var1 == 0.6) {
                this.setSneaking(true);
                this.setSprinting(false);
            }
            else if (var1 == 1.33) {
                this.setSneaking(false);
                this.setSprinting(true);
            }
            else {
                this.setSneaking(false);
                this.setSprinting(false);
            }
        }
        else {
            this.setSneaking(false);
            this.setSprinting(false);
        }
    }
    
    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        if (!this.isTame()) {
            return SoundEvents.CAT_STRAY_AMBIENT;
        }
        if (this.isInLove()) {
            return SoundEvents.CAT_PURR;
        }
        if (this.random.nextInt(4) == 0) {
            return SoundEvents.CAT_PURREOW;
        }
        return SoundEvents.CAT_AMBIENT;
    }
    
    @Override
    public int getAmbientSoundInterval() {
        return 120;
    }
    
    public void hiss() {
        this.playSound(SoundEvents.CAT_HISS, this.getSoundVolume(), this.getVoicePitch());
    }
    
    @Override
    protected SoundEvent getHurtSound(final DamageSource damageSource) {
        return SoundEvents.CAT_HURT;
    }
    
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.CAT_DEATH;
    }
    
    @Override
    protected void registerAttributes() {
        super.registerAttributes();
        this.getAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(10.0);
        this.getAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.30000001192092896);
    }
    
    @Override
    public void causeFallDamage(final float var1, final float var2) {
    }
    
    @Override
    protected void usePlayerItem(final Player player, final ItemStack itemStack) {
        if (this.isFood(itemStack)) {
            this.playSound(SoundEvents.CAT_EAT, 1.0f, 1.0f);
        }
        super.usePlayerItem(player, itemStack);
    }
    
    @Override
    public boolean doHurtTarget(final Entity entity) {
        return entity.hurt(DamageSource.mobAttack(this), 3.0f);
    }
    
    @Override
    public void tick() {
        super.tick();
        if (this.temptGoal != null && this.temptGoal.isRunning() && !this.isTame() && this.tickCount % 100 == 0) {
            this.playSound(SoundEvents.CAT_BEG_FOR_FOOD, 1.0f, 1.0f);
        }
        this.handleLieDown();
    }
    
    private void handleLieDown() {
        if ((this.isLying() || this.isRelaxStateOne()) && this.tickCount % 5 == 0) {
            this.playSound(SoundEvents.CAT_PURR, 0.6f + 0.4f * (this.random.nextFloat() - this.random.nextFloat()), 1.0f);
        }
        this.updateLieDownAmount();
        this.updateRelaxStateOneAmount();
    }
    
    private void updateLieDownAmount() {
        this.lieDownAmountO = this.lieDownAmount;
        this.lieDownAmountOTail = this.lieDownAmountTail;
        if (this.isLying()) {
            this.lieDownAmount = Math.min(1.0f, this.lieDownAmount + 0.15f);
            this.lieDownAmountTail = Math.min(1.0f, this.lieDownAmountTail + 0.08f);
        }
        else {
            this.lieDownAmount = Math.max(0.0f, this.lieDownAmount - 0.22f);
            this.lieDownAmountTail = Math.max(0.0f, this.lieDownAmountTail - 0.13f);
        }
    }
    
    private void updateRelaxStateOneAmount() {
        this.relaxStateOneAmountO = this.relaxStateOneAmount;
        if (this.isRelaxStateOne()) {
            this.relaxStateOneAmount = Math.min(1.0f, this.relaxStateOneAmount + 0.1f);
        }
        else {
            this.relaxStateOneAmount = Math.max(0.0f, this.relaxStateOneAmount - 0.13f);
        }
    }
    
    public float getLieDownAmount(final float f) {
        return Mth.lerp(f, this.lieDownAmountO, this.lieDownAmount);
    }
    
    public float getLieDownAmountTail(final float f) {
        return Mth.lerp(f, this.lieDownAmountOTail, this.lieDownAmountTail);
    }
    
    public float getRelaxStateOneAmount(final float f) {
        return Mth.lerp(f, this.relaxStateOneAmountO, this.relaxStateOneAmount);
    }
    
    @Override
    public Cat getBreedOffspring(final AgableMob agableMob) {
        final Cat cat = EntityType.CAT.create(this.level);
        if (agableMob instanceof Cat) {
            if (this.random.nextBoolean()) {
                cat.setCatType(this.getCatType());
            }
            else {
                cat.setCatType(((Cat)agableMob).getCatType());
            }
            if (this.isTame()) {
                cat.setOwnerUUID(this.getOwnerUUID());
                cat.setTame(true);
                if (this.random.nextBoolean()) {
                    cat.setCollarColor(this.getCollarColor());
                }
                else {
                    cat.setCollarColor(((Cat)agableMob).getCollarColor());
                }
            }
        }
        return cat;
    }
    
    @Override
    public boolean canMate(final Animal animal) {
        if (!this.isTame()) {
            return false;
        }
        if (!(animal instanceof Cat)) {
            return false;
        }
        final Cat var2 = (Cat)animal;
        return var2.isTame() && super.canMate(animal);
    }
    
    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(final LevelAccessor levelAccessor, final DifficultyInstance difficultyInstance, final MobSpawnType mobSpawnType, @Nullable SpawnGroupData var4, @Nullable final CompoundTag compoundTag) {
        var4 = super.finalizeSpawn(levelAccessor, difficultyInstance, mobSpawnType, var4, compoundTag);
        if (levelAccessor.getMoonBrightness() > 0.9f) {
            this.setCatType(this.random.nextInt(11));
        }
        else {
            this.setCatType(this.random.nextInt(10));
        }
        if (Feature.SWAMP_HUT.isInsideFeature(levelAccessor, new BlockPos(this))) {
            this.setCatType(10);
            this.setPersistenceRequired();
        }
        return var4;
    }
    
    @Override
    public boolean mobInteract(final Player player, final InteractionHand interactionHand) {
        final ItemStack var3 = player.getItemInHand(interactionHand);
        final Item var4 = var3.getItem();
        if (this.isTame()) {
            if (this.isOwnedBy(player)) {
                if (var4 instanceof DyeItem) {
                    final DyeColor var5 = ((DyeItem)var4).getDyeColor();
                    if (var5 != this.getCollarColor()) {
                        this.setCollarColor(var5);
                        if (!player.abilities.instabuild) {
                            var3.shrink(1);
                        }
                        this.setPersistenceRequired();
                        return true;
                    }
                }
                else if (this.isFood(var3)) {
                    if (this.getHealth() < this.getMaxHealth() && var4.isEdible()) {
                        this.usePlayerItem(player, var3);
                        this.heal((float)var4.getFoodProperties().getNutrition());
                        return true;
                    }
                }
                else if (!this.level.isClientSide) {
                    this.sitGoal.wantToSit(!this.isSitting());
                }
            }
        }
        else if (this.isFood(var3)) {
            this.usePlayerItem(player, var3);
            if (!this.level.isClientSide) {
                if (this.random.nextInt(3) == 0) {
                    this.tame(player);
                    this.spawnTamingParticles(true);
                    this.sitGoal.wantToSit(true);
                    this.level.broadcastEntityEvent(this, (byte)7);
                }
                else {
                    this.spawnTamingParticles(false);
                    this.level.broadcastEntityEvent(this, (byte)6);
                }
            }
            this.setPersistenceRequired();
            return true;
        }
        final boolean var6 = super.mobInteract(player, interactionHand);
        if (var6) {
            this.setPersistenceRequired();
        }
        return var6;
    }
    
    @Override
    public boolean isFood(final ItemStack itemStack) {
        return Cat.TEMPT_INGREDIENT.test(itemStack);
    }
    
    @Override
    protected float getStandingEyeHeight(final Pose pose, final EntityDimensions entityDimensions) {
        return entityDimensions.height * 0.5f;
    }
    
    @Override
    public boolean removeWhenFarAway(final double d) {
        return !this.isTame() && this.tickCount > 2400;
    }
    
    @Override
    protected void reassessTameGoals() {
        if (this.avoidPlayersGoal == null) {
            this.avoidPlayersGoal = new CatAvoidEntityGoal<Player>(this, Player.class, 16.0f, 0.8, 1.33);
        }
        this.goalSelector.removeGoal(this.avoidPlayersGoal);
        if (!this.isTame()) {
            this.goalSelector.addGoal(4, this.avoidPlayersGoal);
        }
    }
    
    static {
        TEMPT_INGREDIENT = Ingredient.of(Items.COD, Items.SALMON);
        DATA_TYPE_ID = SynchedEntityData.defineId(Cat.class, EntityDataSerializers.INT);
        IS_LYING = SynchedEntityData.defineId(Cat.class, EntityDataSerializers.BOOLEAN);
        RELAX_STATE_ONE = SynchedEntityData.defineId(Cat.class, EntityDataSerializers.BOOLEAN);
        DATA_COLLAR_COLOR = SynchedEntityData.defineId(Cat.class, EntityDataSerializers.INT);
        TEXTURE_BY_TYPE = Util.make((Map<Integer, ResourceLocation>)Maps.newHashMap(), hashMap -> {
            hashMap.put(0, new ResourceLocation("textures/entity/cat/tabby.png"));
            hashMap.put(1, new ResourceLocation("textures/entity/cat/black.png"));
            hashMap.put(2, new ResourceLocation("textures/entity/cat/red.png"));
            hashMap.put(3, new ResourceLocation("textures/entity/cat/siamese.png"));
            hashMap.put(4, new ResourceLocation("textures/entity/cat/british_shorthair.png"));
            hashMap.put(5, new ResourceLocation("textures/entity/cat/calico.png"));
            hashMap.put(6, new ResourceLocation("textures/entity/cat/persian.png"));
            hashMap.put(7, new ResourceLocation("textures/entity/cat/ragdoll.png"));
            hashMap.put(8, new ResourceLocation("textures/entity/cat/white.png"));
            hashMap.put(9, new ResourceLocation("textures/entity/cat/jellie.png"));
            hashMap.put(10, new ResourceLocation("textures/entity/cat/all_black.png"));
        });
    }
    
    static class CatAvoidEntityGoal<T extends LivingEntity> extends AvoidEntityGoal<T>
    {
        private final Cat cat;
        
        public CatAvoidEntityGoal(final Cat cat, final Class<T> class, final float var3, final double var4, final double var6) {
            super(cat, class, var3, var4, var6, EntitySelector.NO_CREATIVE_OR_SPECTATOR::test);
            this.cat = cat;
        }
        
        @Override
        public boolean canUse() {
            return !this.cat.isTame() && super.canUse();
        }
        
        @Override
        public boolean canContinueToUse() {
            return !this.cat.isTame() && super.canContinueToUse();
        }
    }
    
    static class CatTemptGoal extends TemptGoal
    {
        @Nullable
        private Player selectedPlayer;
        private final Cat cat;
        
        public CatTemptGoal(final Cat cat, final double var2, final Ingredient ingredient, final boolean var5) {
            super(cat, var2, ingredient, var5);
            this.cat = cat;
        }
        
        @Override
        public void tick() {
            super.tick();
            if (this.selectedPlayer == null && this.mob.getRandom().nextInt(600) == 0) {
                this.selectedPlayer = this.player;
            }
            else if (this.mob.getRandom().nextInt(500) == 0) {
                this.selectedPlayer = null;
            }
        }
        
        @Override
        protected boolean canScare() {
            return (this.selectedPlayer == null || !this.selectedPlayer.equals(this.player)) && super.canScare();
        }
        
        @Override
        public boolean canUse() {
            return super.canUse() && !this.cat.isTame();
        }
    }
    
    static class CatRelaxOnOwnerGoal extends Goal
    {
        private final Cat cat;
        private Player ownerPlayer;
        private BlockPos goalPos;
        private int onBedTicks;
        
        public CatRelaxOnOwnerGoal(final Cat cat) {
            this.cat = cat;
        }
        
        @Override
        public boolean canUse() {
            if (!this.cat.isTame()) {
                return false;
            }
            if (this.cat.isSitting()) {
                return false;
            }
            final LivingEntity var1 = this.cat.getOwner();
            if (var1 instanceof Player) {
                this.ownerPlayer = (Player)var1;
                if (!var1.isSleeping()) {
                    return false;
                }
                if (this.cat.distanceToSqr(this.ownerPlayer) > 100.0) {
                    return false;
                }
                final BlockPos var2 = new BlockPos(this.ownerPlayer);
                final BlockState var3 = this.cat.level.getBlockState(var2);
                if (var3.getBlock().is(BlockTags.BEDS)) {
                    final Direction var4 = var3.getValue((Property<Direction>)BedBlock.FACING);
                    this.goalPos = new BlockPos(var2.getX() - var4.getStepX(), var2.getY(), var2.getZ() - var4.getStepZ());
                    return !this.spaceIsOccupied();
                }
            }
            return false;
        }
        
        private boolean spaceIsOccupied() {
            final List<Cat> var1 = this.cat.level.getEntitiesOfClass((Class<? extends Cat>)Cat.class, new AABB(this.goalPos).inflate(2.0));
            for (final Cat var2 : var1) {
                if (var2 != this.cat && (var2.isLying() || var2.isRelaxStateOne())) {
                    return true;
                }
            }
            return false;
        }
        
        @Override
        public boolean canContinueToUse() {
            return this.cat.isTame() && !this.cat.isSitting() && this.ownerPlayer != null && this.ownerPlayer.isSleeping() && this.goalPos != null && !this.spaceIsOccupied();
        }
        
        @Override
        public void start() {
            if (this.goalPos != null) {
                this.cat.getSitGoal().wantToSit(false);
                this.cat.getNavigation().moveTo(this.goalPos.getX(), this.goalPos.getY(), this.goalPos.getZ(), 1.100000023841858);
            }
        }
        
        @Override
        public void stop() {
            this.cat.setLying(false);
            final float var1 = this.cat.level.getTimeOfDay(1.0f);
            if (this.ownerPlayer.getSleepTimer() >= 100 && var1 > 0.77 && var1 < 0.8 && this.cat.level.getRandom().nextFloat() < 0.7) {
                this.giveMorningGift();
            }
            this.onBedTicks = 0;
            this.cat.setRelaxStateOne(false);
            this.cat.getNavigation().stop();
        }
        
        private void giveMorningGift() {
            final Random var1 = this.cat.getRandom();
            final BlockPos.MutableBlockPos var2 = new BlockPos.MutableBlockPos();
            var2.set(this.cat);
            this.cat.randomTeleport(var2.getX() + var1.nextInt(11) - 5, var2.getY() + var1.nextInt(5) - 2, var2.getZ() + var1.nextInt(11) - 5, false);
            var2.set(this.cat);
            final LootTable var3 = this.cat.level.getServer().getLootTables().get(BuiltInLootTables.CAT_MORNING_GIFT);
            final LootContext.Builder var4 = new LootContext.Builder((ServerLevel)this.cat.level).withParameter(LootContextParams.BLOCK_POS, var2).withParameter(LootContextParams.THIS_ENTITY, this.cat).withRandom(var1);
            final List<ItemStack> var5 = var3.getRandomItems(var4.create(LootContextParamSets.GIFT));
            for (final ItemStack var6 : var5) {
                this.cat.level.addFreshEntity(new ItemEntity(this.cat.level, var2.getX() - Mth.sin(this.cat.yBodyRot * 0.017453292f), var2.getY(), var2.getZ() + Mth.cos(this.cat.yBodyRot * 0.017453292f), var6));
            }
        }
        
        @Override
        public void tick() {
            if (this.ownerPlayer != null && this.goalPos != null) {
                this.cat.getSitGoal().wantToSit(false);
                this.cat.getNavigation().moveTo(this.goalPos.getX(), this.goalPos.getY(), this.goalPos.getZ(), 1.100000023841858);
                if (this.cat.distanceToSqr(this.ownerPlayer) < 2.5) {
                    ++this.onBedTicks;
                    if (this.onBedTicks > 16) {
                        this.cat.setLying(true);
                        this.cat.setRelaxStateOne(false);
                    }
                    else {
                        this.cat.lookAt(this.ownerPlayer, 45.0f, 45.0f);
                        this.cat.setRelaxStateOne(true);
                    }
                }
                else {
                    this.cat.setLying(false);
                }
            }
        }
    }
}
