package net.minecraft.world.entity.npc;

import net.minecraft.world.entity.ai.village.poi.*;
import com.google.common.collect.*;
import net.minecraft.core.*;
import net.minecraft.resources.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;

public class VillagerProfession
{
    public static final VillagerProfession NONE;
    public static final VillagerProfession ARMORER;
    public static final VillagerProfession BUTCHER;
    public static final VillagerProfession CARTOGRAPHER;
    public static final VillagerProfession CLERIC;
    public static final VillagerProfession FARMER;
    public static final VillagerProfession FISHERMAN;
    public static final VillagerProfession FLETCHER;
    public static final VillagerProfession LEATHERWORKER;
    public static final VillagerProfession LIBRARIAN;
    public static final VillagerProfession MASON;
    public static final VillagerProfession NITWIT;
    public static final VillagerProfession SHEPHERD;
    public static final VillagerProfession TOOLSMITH;
    public static final VillagerProfession WEAPONSMITH;
    private final String name;
    private final PoiType jobPoiType;
    private final ImmutableSet<Item> requestedItems;
    private final ImmutableSet<Block> secondaryPoi;
    
    private VillagerProfession(final String name, final PoiType jobPoiType, final ImmutableSet<Item> requestedItems, final ImmutableSet<Block> secondaryPoi) {
        this.name = name;
        this.jobPoiType = jobPoiType;
        this.requestedItems = requestedItems;
        this.secondaryPoi = secondaryPoi;
    }
    
    public PoiType getJobPoiType() {
        return this.jobPoiType;
    }
    
    public ImmutableSet<Item> getRequestedItems() {
        return this.requestedItems;
    }
    
    public ImmutableSet<Block> getSecondaryPoi() {
        return this.secondaryPoi;
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    static VillagerProfession register(final String string, final PoiType poiType) {
        return register(string, poiType, (ImmutableSet<Item>)ImmutableSet.of(), (ImmutableSet<Block>)ImmutableSet.of());
    }
    
    static VillagerProfession register(final String string, final PoiType poiType, final ImmutableSet<Item> var2, final ImmutableSet<Block> var3) {
        return Registry.register(Registry.VILLAGER_PROFESSION, new ResourceLocation(string), new VillagerProfession(string, poiType, var2, var3));
    }
    
    static {
        NONE = register("none", PoiType.UNEMPLOYED);
        ARMORER = register("armorer", PoiType.ARMORER);
        BUTCHER = register("butcher", PoiType.BUTCHER);
        CARTOGRAPHER = register("cartographer", PoiType.CARTOGRAPHER);
        CLERIC = register("cleric", PoiType.CLERIC);
        FARMER = register("farmer", PoiType.FARMER, (ImmutableSet<Item>)ImmutableSet.of((Object)Items.WHEAT, (Object)Items.WHEAT_SEEDS, (Object)Items.BEETROOT_SEEDS), (ImmutableSet<Block>)ImmutableSet.of((Object)Blocks.FARMLAND));
        FISHERMAN = register("fisherman", PoiType.FISHERMAN);
        FLETCHER = register("fletcher", PoiType.FLETCHER);
        LEATHERWORKER = register("leatherworker", PoiType.LEATHERWORKER);
        LIBRARIAN = register("librarian", PoiType.LIBRARIAN);
        MASON = register("mason", PoiType.MASON);
        NITWIT = register("nitwit", PoiType.NITWIT);
        SHEPHERD = register("shepherd", PoiType.SHEPHERD);
        TOOLSMITH = register("toolsmith", PoiType.TOOLSMITH);
        WEAPONSMITH = register("weaponsmith", PoiType.WEAPONSMITH);
    }
}
