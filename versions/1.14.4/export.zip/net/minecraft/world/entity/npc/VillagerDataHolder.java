package net.minecraft.world.entity.npc;

public interface VillagerDataHolder
{
    VillagerData getVillagerData();
}
