package net.minecraft.world.item.crafting;

import net.minecraft.resources.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.*;

public class BlastingRecipe extends AbstractCookingRecipe
{
    public BlastingRecipe(final ResourceLocation resourceLocation, final String string, final Ingredient ingredient, final ItemStack itemStack, final float var5, final int var6) {
        super(RecipeType.BLASTING, resourceLocation, string, ingredient, itemStack, var5, var6);
    }
    
    @Override
    public ItemStack getToastSymbol() {
        return new ItemStack(Blocks.BLAST_FURNACE);
    }
    
    @Override
    public RecipeSerializer<?> getSerializer() {
        return RecipeSerializer.BLASTING_RECIPE;
    }
}
