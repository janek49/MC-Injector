package net.minecraft.world.item.crafting;

import net.minecraft.world.*;
import net.minecraft.resources.*;
import net.minecraft.util.*;
import com.google.gson.*;
import net.minecraft.world.item.*;
import net.minecraft.core.*;
import net.minecraft.world.level.*;
import net.minecraft.network.*;

public abstract class SingleItemRecipe implements Recipe<Container>
{
    protected final Ingredient ingredient;
    protected final ItemStack result;
    private final RecipeType<?> type;
    private final RecipeSerializer<?> serializer;
    protected final ResourceLocation id;
    protected final String group;
    
    public SingleItemRecipe(final RecipeType<?> type, final RecipeSerializer<?> serializer, final ResourceLocation id, final String group, final Ingredient ingredient, final ItemStack result) {
        this.type = type;
        this.serializer = serializer;
        this.id = id;
        this.group = group;
        this.ingredient = ingredient;
        this.result = result;
    }
    
    @Override
    public RecipeType<?> getType() {
        return this.type;
    }
    
    @Override
    public RecipeSerializer<?> getSerializer() {
        return this.serializer;
    }
    
    @Override
    public ResourceLocation getId() {
        return this.id;
    }
    
    @Override
    public String getGroup() {
        return this.group;
    }
    
    @Override
    public ItemStack getResultItem() {
        return this.result;
    }
    
    @Override
    public NonNullList<Ingredient> getIngredients() {
        final NonNullList<Ingredient> nonNullList = NonNullList.create();
        nonNullList.add(this.ingredient);
        return nonNullList;
    }
    
    @Override
    public boolean canCraftInDimensions(final int var1, final int var2) {
        return true;
    }
    
    @Override
    public ItemStack assemble(final Container container) {
        return this.result.copy();
    }
    
    public static class Serializer<T extends SingleItemRecipe> implements RecipeSerializer<T>
    {
        final SingleItemMaker<T> factory;
        
        protected Serializer(final SingleItemMaker<T> factory) {
            this.factory = factory;
        }
        
        @Override
        public T fromJson(final ResourceLocation resourceLocation, final JsonObject jsonObject) {
            final String var3 = GsonHelper.getAsString(jsonObject, "group", "");
            Ingredient var4;
            if (GsonHelper.isArrayNode(jsonObject, "ingredient")) {
                var4 = Ingredient.fromJson((JsonElement)GsonHelper.getAsJsonArray(jsonObject, "ingredient"));
            }
            else {
                var4 = Ingredient.fromJson((JsonElement)GsonHelper.getAsJsonObject(jsonObject, "ingredient"));
            }
            final String var5 = GsonHelper.getAsString(jsonObject, "result");
            final int var6 = GsonHelper.getAsInt(jsonObject, "count");
            final ItemStack var7 = new ItemStack(Registry.ITEM.get(new ResourceLocation(var5)), var6);
            return this.factory.create(resourceLocation, var3, var4, var7);
        }
        
        @Override
        public T fromNetwork(final ResourceLocation resourceLocation, final FriendlyByteBuf friendlyByteBuf) {
            final String var3 = friendlyByteBuf.readUtf(32767);
            final Ingredient var4 = Ingredient.fromNetwork(friendlyByteBuf);
            final ItemStack var5 = friendlyByteBuf.readItem();
            return this.factory.create(resourceLocation, var3, var4, var5);
        }
        
        @Override
        public void toNetwork(final FriendlyByteBuf friendlyByteBuf, final T singleItemRecipe) {
            friendlyByteBuf.writeUtf(singleItemRecipe.group);
            singleItemRecipe.ingredient.toNetwork(friendlyByteBuf);
            friendlyByteBuf.writeItem(singleItemRecipe.result);
        }
        
        interface SingleItemMaker<T extends SingleItemRecipe>
        {
            T create(final ResourceLocation p0, final String p1, final Ingredient p2, final ItemStack p3);
        }
    }
}
