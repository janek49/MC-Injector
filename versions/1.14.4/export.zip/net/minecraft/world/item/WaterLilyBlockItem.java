package net.minecraft.world.item;

import net.minecraft.world.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.world.level.*;
import net.minecraft.world.phys.*;
import net.minecraft.world.level.block.*;
import net.minecraft.server.level.*;
import net.minecraft.advancements.*;
import net.minecraft.stats.*;
import net.minecraft.sounds.*;
import net.minecraft.core.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.material.*;

public class WaterLilyBlockItem extends BlockItem
{
    public WaterLilyBlockItem(final Block block, final Properties item$Properties) {
        super(block, item$Properties);
    }
    
    @Override
    public InteractionResult useOn(final UseOnContext useOnContext) {
        return InteractionResult.PASS;
    }
    
    @Override
    public InteractionResultHolder<ItemStack> use(final Level level, final Player player, final InteractionHand interactionHand) {
        final ItemStack var4 = player.getItemInHand(interactionHand);
        final HitResult var5 = Item.getPlayerPOVHitResult(level, player, ClipContext.Fluid.SOURCE_ONLY);
        if (var5.getType() == HitResult.Type.MISS) {
            return new InteractionResultHolder<ItemStack>(InteractionResult.PASS, var4);
        }
        if (var5.getType() == HitResult.Type.BLOCK) {
            final BlockHitResult var6 = (BlockHitResult)var5;
            final BlockPos var7 = var6.getBlockPos();
            final Direction var8 = var6.getDirection();
            if (!level.mayInteract(player, var7) || !player.mayUseItemAt(var7.relative(var8), var8, var4)) {
                return new InteractionResultHolder<ItemStack>(InteractionResult.FAIL, var4);
            }
            final BlockPos var9 = var7.above();
            final BlockState var10 = level.getBlockState(var7);
            final Material var11 = var10.getMaterial();
            final FluidState var12 = level.getFluidState(var7);
            if ((var12.getType() == Fluids.WATER || var11 == Material.ICE) && level.isEmptyBlock(var9)) {
                level.setBlock(var9, Blocks.LILY_PAD.defaultBlockState(), 11);
                if (player instanceof ServerPlayer) {
                    CriteriaTriggers.PLACED_BLOCK.trigger((ServerPlayer)player, var9, var4);
                }
                if (!player.abilities.instabuild) {
                    var4.shrink(1);
                }
                player.awardStat(Stats.ITEM_USED.get(this));
                level.playSound(player, var7, SoundEvents.LILY_PAD_PLACE, SoundSource.BLOCKS, 1.0f, 1.0f);
                return new InteractionResultHolder<ItemStack>(InteractionResult.SUCCESS, var4);
            }
        }
        return new InteractionResultHolder<ItemStack>(InteractionResult.FAIL, var4);
    }
}
