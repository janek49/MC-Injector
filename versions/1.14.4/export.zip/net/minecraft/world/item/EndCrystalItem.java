package net.minecraft.world.item;

import net.minecraft.world.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.boss.enderdragon.*;
import net.minecraft.world.level.*;
import net.minecraft.core.*;
import net.minecraft.world.level.block.state.*;
import java.util.*;
import net.minecraft.world.level.dimension.end.*;

public class EndCrystalItem extends Item
{
    public EndCrystalItem(final Properties item$Properties) {
        super(item$Properties);
    }
    
    @Override
    public InteractionResult useOn(final UseOnContext useOnContext) {
        final Level var2 = useOnContext.getLevel();
        final BlockPos var3 = useOnContext.getClickedPos();
        final BlockState var4 = var2.getBlockState(var3);
        if (var4.getBlock() != Blocks.OBSIDIAN && var4.getBlock() != Blocks.BEDROCK) {
            return InteractionResult.FAIL;
        }
        final BlockPos var5 = var3.above();
        if (!var2.isEmptyBlock(var5)) {
            return InteractionResult.FAIL;
        }
        final double var6 = var5.getX();
        final double var7 = var5.getY();
        final double var8 = var5.getZ();
        final List<Entity> var9 = var2.getEntities(null, new AABB(var6, var7, var8, var6 + 1.0, var7 + 2.0, var8 + 1.0));
        if (!var9.isEmpty()) {
            return InteractionResult.FAIL;
        }
        if (!var2.isClientSide) {
            final EndCrystal var10 = new EndCrystal(var2, var6 + 0.5, var7, var8 + 0.5);
            var10.setShowBottom(false);
            var2.addFreshEntity(var10);
            if (var2.dimension instanceof TheEndDimension) {
                final EndDragonFight var11 = ((TheEndDimension)var2.dimension).getDragonFight();
                var11.tryRespawn();
            }
        }
        useOnContext.getItemInHand().shrink(1);
        return InteractionResult.SUCCESS;
    }
    
    @Override
    public boolean isFoil(final ItemStack itemStack) {
        return true;
    }
}
