package net.minecraft.world.item.enchantment;

import net.minecraft.world.entity.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.item.*;

public enum EnchantmentCategory
{
    ALL {
        @Override
        public boolean canEnchant(final Item item) {
            for (final EnchantmentCategory var5 : EnchantmentCategory.values()) {
                if (var5 != EnchantmentCategory.ALL) {
                    if (var5.canEnchant(item)) {
                        return true;
                    }
                }
            }
            return false;
        }
    }, 
    ARMOR {
        @Override
        public boolean canEnchant(final Item item) {
            return item instanceof ArmorItem;
        }
    }, 
    ARMOR_FEET {
        @Override
        public boolean canEnchant(final Item item) {
            return item instanceof ArmorItem && ((ArmorItem)item).getSlot() == EquipmentSlot.FEET;
        }
    }, 
    ARMOR_LEGS {
        @Override
        public boolean canEnchant(final Item item) {
            return item instanceof ArmorItem && ((ArmorItem)item).getSlot() == EquipmentSlot.LEGS;
        }
    }, 
    ARMOR_CHEST {
        @Override
        public boolean canEnchant(final Item item) {
            return item instanceof ArmorItem && ((ArmorItem)item).getSlot() == EquipmentSlot.CHEST;
        }
    }, 
    ARMOR_HEAD {
        @Override
        public boolean canEnchant(final Item item) {
            return item instanceof ArmorItem && ((ArmorItem)item).getSlot() == EquipmentSlot.HEAD;
        }
    }, 
    WEAPON {
        @Override
        public boolean canEnchant(final Item item) {
            return item instanceof SwordItem;
        }
    }, 
    DIGGER {
        @Override
        public boolean canEnchant(final Item item) {
            return item instanceof DiggerItem;
        }
    }, 
    FISHING_ROD {
        @Override
        public boolean canEnchant(final Item item) {
            return item instanceof FishingRodItem;
        }
    }, 
    TRIDENT {
        @Override
        public boolean canEnchant(final Item item) {
            return item instanceof TridentItem;
        }
    }, 
    BREAKABLE {
        @Override
        public boolean canEnchant(final Item item) {
            return item.canBeDepleted();
        }
    }, 
    BOW {
        @Override
        public boolean canEnchant(final Item item) {
            return item instanceof BowItem;
        }
    }, 
    WEARABLE {
        @Override
        public boolean canEnchant(final Item item) {
            final Block var2 = Block.byItem(item);
            return item instanceof ArmorItem || item instanceof ElytraItem || var2 instanceof AbstractSkullBlock || var2 instanceof PumpkinBlock;
        }
    }, 
    CROSSBOW {
        @Override
        public boolean canEnchant(final Item item) {
            return item instanceof CrossbowItem;
        }
    };
    
    private EnchantmentCategory(final String s, final int n) {
    }
    
    public abstract boolean canEnchant(final Item p0);
}
