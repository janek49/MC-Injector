package net.minecraft.world.item.enchantment;

import net.minecraft.world.entity.*;

public class TridentChannelingEnchantment extends Enchantment
{
    public TridentChannelingEnchantment(final Rarity enchantment$Rarity, final EquipmentSlot... equipmentSlots) {
        super(enchantment$Rarity, EnchantmentCategory.TRIDENT, equipmentSlots);
    }
    
    @Override
    public int getMinCost(final int i) {
        return 25;
    }
    
    @Override
    public int getMaxCost(final int i) {
        return 50;
    }
    
    @Override
    public int getMaxLevel() {
        return 1;
    }
    
    public boolean checkCompatibility(final Enchantment enchantment) {
        return super.checkCompatibility(enchantment);
    }
}
