package net.minecraft.world.item.enchantment;

import net.minecraft.world.entity.*;

public class TridentRiptideEnchantment extends Enchantment
{
    public TridentRiptideEnchantment(final Rarity enchantment$Rarity, final EquipmentSlot... equipmentSlots) {
        super(enchantment$Rarity, EnchantmentCategory.TRIDENT, equipmentSlots);
    }
    
    @Override
    public int getMinCost(final int i) {
        return 10 + i * 7;
    }
    
    @Override
    public int getMaxCost(final int i) {
        return 50;
    }
    
    @Override
    public int getMaxLevel() {
        return 3;
    }
    
    public boolean checkCompatibility(final Enchantment enchantment) {
        return super.checkCompatibility(enchantment) && enchantment != Enchantments.LOYALTY && enchantment != Enchantments.CHANNELING;
    }
}
