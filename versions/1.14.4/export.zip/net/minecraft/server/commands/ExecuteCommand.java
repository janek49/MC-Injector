package net.minecraft.server.commands;

import net.minecraft.commands.*;
import com.mojang.brigadier.tree.*;
import com.mojang.brigadier.suggestion.*;
import com.mojang.brigadier.builder.*;
import com.mojang.brigadier.arguments.*;
import net.minecraft.server.bossevents.*;
import net.minecraft.server.commands.data.*;
import net.minecraft.commands.arguments.coordinates.*;
import net.minecraft.commands.arguments.blocks.*;
import net.minecraft.world.level.block.state.pattern.*;
import net.minecraft.world.level.*;
import net.minecraft.commands.arguments.*;
import com.mojang.brigadier.exceptions.*;
import com.mojang.brigadier.context.*;
import java.util.function.*;
import net.minecraft.world.scores.*;
import net.minecraft.advancements.critereon.*;
import net.minecraft.network.chat.*;
import net.minecraft.server.level.*;
import net.minecraft.world.level.levelgen.structure.*;
import net.minecraft.core.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.nbt.*;
import com.google.common.collect.*;
import net.minecraft.world.entity.*;
import java.util.*;
import com.mojang.brigadier.*;

public class ExecuteCommand
{
    private static final Dynamic2CommandExceptionType ERROR_AREA_TOO_LARGE;
    private static final SimpleCommandExceptionType ERROR_CONDITIONAL_FAILED;
    private static final DynamicCommandExceptionType ERROR_CONDITIONAL_FAILED_COUNT;
    private static final BinaryOperator<ResultConsumer<CommandSourceStack>> CALLBACK_CHAINER;
    
    public static void register(final CommandDispatcher<CommandSourceStack> commandDispatcher) {
        final LiteralCommandNode<CommandSourceStack> var1 = (LiteralCommandNode<CommandSourceStack>)commandDispatcher.register((LiteralArgumentBuilder)Commands.literal("execute").requires(commandSourceStack -> commandSourceStack.hasPermission(2)));
        commandDispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("execute").requires(commandSourceStack -> commandSourceStack.hasPermission(2))).then(Commands.literal("run").redirect((CommandNode)commandDispatcher.getRoot()))).then((ArgumentBuilder)addConditionals((CommandNode<CommandSourceStack>)var1, Commands.literal("if"), true))).then((ArgumentBuilder)addConditionals((CommandNode<CommandSourceStack>)var1, Commands.literal("unless"), false))).then(Commands.literal("as").then(Commands.argument("targets", (com.mojang.brigadier.arguments.ArgumentType<Object>)EntityArgument.entities()).fork((CommandNode)var1, commandContext -> {
            final List<CommandSourceStack> var1 = (List<CommandSourceStack>)Lists.newArrayList();
            for (final Entity var2 : EntityArgument.getOptionalEntities((CommandContext<CommandSourceStack>)commandContext, "targets")) {
                var1.add(((CommandSourceStack)commandContext.getSource()).withEntity(var2));
            }
            return var1;
        })))).then(Commands.literal("at").then(Commands.argument("targets", (com.mojang.brigadier.arguments.ArgumentType<Object>)EntityArgument.entities()).fork((CommandNode)var1, commandContext -> {
            final List<CommandSourceStack> var1 = (List<CommandSourceStack>)Lists.newArrayList();
            for (final Entity var2 : EntityArgument.getOptionalEntities((CommandContext<CommandSourceStack>)commandContext, "targets")) {
                var1.add(((CommandSourceStack)commandContext.getSource()).withLevel((ServerLevel)var2.level).withPosition(var2.getCommandSenderWorldPosition()).withRotation(var2.getRotationVector()));
            }
            return var1;
        })))).then(((LiteralArgumentBuilder)Commands.literal("store").then((ArgumentBuilder)wrapStores(var1, Commands.literal("result"), true))).then((ArgumentBuilder)wrapStores(var1, Commands.literal("success"), false)))).then(((LiteralArgumentBuilder)Commands.literal("positioned").then(Commands.argument("pos", (com.mojang.brigadier.arguments.ArgumentType<Object>)Vec3Argument.vec3()).redirect((CommandNode)var1, commandContext -> ((CommandSourceStack)commandContext.getSource()).withPosition(Vec3Argument.getVec3((CommandContext<CommandSourceStack>)commandContext, "pos"))))).then(Commands.literal("as").then(Commands.argument("targets", (com.mojang.brigadier.arguments.ArgumentType<Object>)EntityArgument.entities()).fork((CommandNode)var1, commandContext -> {
            final List<CommandSourceStack> var1 = (List<CommandSourceStack>)Lists.newArrayList();
            for (final Entity var2 : EntityArgument.getOptionalEntities((CommandContext<CommandSourceStack>)commandContext, "targets")) {
                var1.add(((CommandSourceStack)commandContext.getSource()).withPosition(var2.getCommandSenderWorldPosition()));
            }
            return var1;
        }))))).then(((LiteralArgumentBuilder)Commands.literal("rotated").then(Commands.argument("rot", (com.mojang.brigadier.arguments.ArgumentType<Object>)RotationArgument.rotation()).redirect((CommandNode)var1, commandContext -> ((CommandSourceStack)commandContext.getSource()).withRotation(RotationArgument.getRotation((CommandContext<CommandSourceStack>)commandContext, "rot").getRotation((CommandSourceStack)commandContext.getSource()))))).then(Commands.literal("as").then(Commands.argument("targets", (com.mojang.brigadier.arguments.ArgumentType<Object>)EntityArgument.entities()).fork((CommandNode)var1, commandContext -> {
            final List<CommandSourceStack> var1 = (List<CommandSourceStack>)Lists.newArrayList();
            for (final Entity var2 : EntityArgument.getOptionalEntities((CommandContext<CommandSourceStack>)commandContext, "targets")) {
                var1.add(((CommandSourceStack)commandContext.getSource()).withRotation(var2.getRotationVector()));
            }
            return var1;
        }))))).then(((LiteralArgumentBuilder)Commands.literal("facing").then(Commands.literal("entity").then(Commands.argument("targets", (com.mojang.brigadier.arguments.ArgumentType<Object>)EntityArgument.entities()).then(Commands.argument("anchor", (com.mojang.brigadier.arguments.ArgumentType<Object>)EntityAnchorArgument.anchor()).fork((CommandNode)var1, commandContext -> {
            final List<CommandSourceStack> var1 = (List<CommandSourceStack>)Lists.newArrayList();
            final EntityAnchorArgument.Anchor var2 = EntityAnchorArgument.getAnchor((CommandContext<CommandSourceStack>)commandContext, "anchor");
            for (final Entity var3 : EntityArgument.getOptionalEntities((CommandContext<CommandSourceStack>)commandContext, "targets")) {
                var1.add(((CommandSourceStack)commandContext.getSource()).facing(var3, var2));
            }
            return var1;
        }))))).then(Commands.argument("pos", (com.mojang.brigadier.arguments.ArgumentType<Object>)Vec3Argument.vec3()).redirect((CommandNode)var1, commandContext -> ((CommandSourceStack)commandContext.getSource()).facing(Vec3Argument.getVec3((CommandContext<CommandSourceStack>)commandContext, "pos")))))).then(Commands.literal("align").then(Commands.argument("axes", (com.mojang.brigadier.arguments.ArgumentType<Object>)SwizzleArgument.swizzle()).redirect((CommandNode)var1, commandContext -> ((CommandSourceStack)commandContext.getSource()).withPosition(((CommandSourceStack)commandContext.getSource()).getPosition().align(SwizzleArgument.getSwizzle((CommandContext<CommandSourceStack>)commandContext, "axes"))))))).then(Commands.literal("anchored").then(Commands.argument("anchor", (com.mojang.brigadier.arguments.ArgumentType<Object>)EntityAnchorArgument.anchor()).redirect((CommandNode)var1, commandContext -> ((CommandSourceStack)commandContext.getSource()).withAnchor(EntityAnchorArgument.getAnchor((CommandContext<CommandSourceStack>)commandContext, "anchor")))))).then(Commands.literal("in").then(Commands.argument("dimension", (com.mojang.brigadier.arguments.ArgumentType<Object>)DimensionTypeArgument.dimension()).redirect((CommandNode)var1, commandContext -> ((CommandSourceStack)commandContext.getSource()).withLevel(((CommandSourceStack)commandContext.getSource()).getServer().getLevel(DimensionTypeArgument.getDimension((CommandContext<CommandSourceStack>)commandContext, "dimension")))))));
    }
    
    private static ArgumentBuilder<CommandSourceStack, ?> wrapStores(final LiteralCommandNode<CommandSourceStack> literalCommandNode, final LiteralArgumentBuilder<CommandSourceStack> literalArgumentBuilder, final boolean var2) {
        literalArgumentBuilder.then(Commands.literal("score").then(Commands.argument("targets", (com.mojang.brigadier.arguments.ArgumentType<Object>)ScoreHolderArgument.scoreHolders()).suggests((SuggestionProvider)ScoreHolderArgument.SUGGEST_SCORE_HOLDERS).then(Commands.argument("objective", (com.mojang.brigadier.arguments.ArgumentType<Object>)ObjectiveArgument.objective()).redirect((CommandNode)literalCommandNode, commandContext -> storeValue((CommandSourceStack)commandContext.getSource(), ScoreHolderArgument.getNamesWithDefaultWildcard((CommandContext<CommandSourceStack>)commandContext, "targets"), ObjectiveArgument.getObjective((CommandContext<CommandSourceStack>)commandContext, "objective"), var2)))));
        literalArgumentBuilder.then(Commands.literal("bossbar").then(((RequiredArgumentBuilder)Commands.argument("id", (com.mojang.brigadier.arguments.ArgumentType<Object>)ResourceLocationArgument.id()).suggests((SuggestionProvider)BossBarCommands.SUGGEST_BOSS_BAR).then(Commands.literal("value").redirect((CommandNode)literalCommandNode, commandContext -> storeValue((CommandSourceStack)commandContext.getSource(), BossBarCommands.getBossBar((CommandContext<CommandSourceStack>)commandContext), true, var2)))).then(Commands.literal("max").redirect((CommandNode)literalCommandNode, commandContext -> storeValue((CommandSourceStack)commandContext.getSource(), BossBarCommands.getBossBar((CommandContext<CommandSourceStack>)commandContext), false, var2)))));
        for (final DataCommands.DataProvider var4 : DataCommands.TARGET_PROVIDERS) {
            final Object o;
            var4.wrap((ArgumentBuilder<CommandSourceStack, ?>)literalArgumentBuilder, var3 -> var3.then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("path", (com.mojang.brigadier.arguments.ArgumentType<Object>)NbtPathArgument.nbtPath()).then(Commands.literal("int").then(Commands.argument("scale", (com.mojang.brigadier.arguments.ArgumentType<Object>)DoubleArgumentType.doubleArg()).redirect((CommandNode)literalCommandNode, commandContext -> storeData((CommandSourceStack)commandContext.getSource(), ((DataCommands.DataProvider)o).access((CommandContext<CommandSourceStack>)commandContext), NbtPathArgument.getPath((CommandContext<CommandSourceStack>)commandContext, "path"), var2 -> new IntTag((int)((var2 ? 1 : 0) * DoubleArgumentType.getDouble(commandContext, "scale"))), var2))))).then(Commands.literal("float").then(Commands.argument("scale", (com.mojang.brigadier.arguments.ArgumentType<Object>)DoubleArgumentType.doubleArg()).redirect((CommandNode)literalCommandNode, commandContext -> storeData((CommandSourceStack)commandContext.getSource(), ((DataCommands.DataProvider)o).access((CommandContext<CommandSourceStack>)commandContext), NbtPathArgument.getPath((CommandContext<CommandSourceStack>)commandContext, "path"), var2 -> new FloatTag((float)((var2 ? 1 : 0) * DoubleArgumentType.getDouble(commandContext, "scale"))), var2))))).then(Commands.literal("short").then(Commands.argument("scale", (com.mojang.brigadier.arguments.ArgumentType<Object>)DoubleArgumentType.doubleArg()).redirect((CommandNode)literalCommandNode, commandContext -> storeData((CommandSourceStack)commandContext.getSource(), ((DataCommands.DataProvider)o).access((CommandContext<CommandSourceStack>)commandContext), NbtPathArgument.getPath((CommandContext<CommandSourceStack>)commandContext, "path"), var2 -> new ShortTag((short)((var2 ? 1 : 0) * DoubleArgumentType.getDouble(commandContext, "scale"))), var2))))).then(Commands.literal("long").then(Commands.argument("scale", (com.mojang.brigadier.arguments.ArgumentType<Object>)DoubleArgumentType.doubleArg()).redirect((CommandNode)literalCommandNode, commandContext -> storeData((CommandSourceStack)commandContext.getSource(), ((DataCommands.DataProvider)o).access((CommandContext<CommandSourceStack>)commandContext), NbtPathArgument.getPath((CommandContext<CommandSourceStack>)commandContext, "path"), var2 -> new LongTag((long)((var2 ? 1 : 0) * DoubleArgumentType.getDouble(commandContext, "scale"))), var2))))).then(Commands.literal("double").then(Commands.argument("scale", (com.mojang.brigadier.arguments.ArgumentType<Object>)DoubleArgumentType.doubleArg()).redirect((CommandNode)literalCommandNode, commandContext -> storeData((CommandSourceStack)commandContext.getSource(), ((DataCommands.DataProvider)o).access((CommandContext<CommandSourceStack>)commandContext), NbtPathArgument.getPath((CommandContext<CommandSourceStack>)commandContext, "path"), var2 -> new DoubleTag((var2 ? 1 : 0) * DoubleArgumentType.getDouble(commandContext, "scale")), var2))))).then(Commands.literal("byte").then(Commands.argument("scale", (com.mojang.brigadier.arguments.ArgumentType<Object>)DoubleArgumentType.doubleArg()).redirect((CommandNode)literalCommandNode, commandContext -> storeData((CommandSourceStack)commandContext.getSource(), ((DataCommands.DataProvider)o).access((CommandContext<CommandSourceStack>)commandContext), NbtPathArgument.getPath((CommandContext<CommandSourceStack>)commandContext, "path"), var2 -> new ByteTag((byte)((var2 ? 1 : 0) * DoubleArgumentType.getDouble(commandContext, "scale"))), var2))))));
        }
        return (ArgumentBuilder<CommandSourceStack, ?>)literalArgumentBuilder;
    }
    
    private static CommandSourceStack storeValue(final CommandSourceStack var0, final Collection<String> collection, final Objective objective, final boolean var3) {
        final Scoreboard var4 = var0.getServer().getScoreboard();
        return var0.withCallback((ResultConsumer<CommandSourceStack>)((commandContext, var5, var6) -> {
            for (final String var7 : collection) {
                final Score var8 = var4.getOrCreatePlayerScore(var7, objective);
                final int var9 = var3 ? var6 : (var5 ? 1 : 0);
                var8.setScore(var9);
            }
        }), ExecuteCommand.CALLBACK_CHAINER);
    }
    
    private static CommandSourceStack storeValue(final CommandSourceStack var0, final CustomBossEvent customBossEvent, final boolean var2, final boolean var3) {
        return var0.withCallback((ResultConsumer<CommandSourceStack>)((commandContext, var4, var5) -> {
            final int var6 = var3 ? var5 : (var4 ? 1 : 0);
            if (var2) {
                customBossEvent.setValue(var6);
            }
            else {
                customBossEvent.setMax(var6);
            }
        }), ExecuteCommand.CALLBACK_CHAINER);
    }
    
    private static CommandSourceStack storeData(final CommandSourceStack var0, final DataAccessor dataAccessor, final NbtPathArgument.NbtPath nbtPathArgument$NbtPath, final IntFunction<Tag> intFunction, final boolean var4) {
        return var0.withCallback((ResultConsumer<CommandSourceStack>)((commandContext, var5, var6) -> {
            try {
                final CompoundTag var7 = dataAccessor.getData();
                final int var8 = var4 ? var6 : (var5 ? 1 : 0);
                nbtPathArgument$NbtPath.set(var7, () -> intFunction.apply(var8));
                dataAccessor.setData(var7);
            }
            catch (CommandSyntaxException ex) {}
        }), ExecuteCommand.CALLBACK_CHAINER);
    }
    
    private static ArgumentBuilder<CommandSourceStack, ?> addConditionals(final CommandNode<CommandSourceStack> commandNode, final LiteralArgumentBuilder<CommandSourceStack> literalArgumentBuilder, final boolean var2) {
        ((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)literalArgumentBuilder.then(Commands.literal("block").then(Commands.argument("pos", (com.mojang.brigadier.arguments.ArgumentType<Object>)BlockPosArgument.blockPos()).then((ArgumentBuilder)addConditional(commandNode, (ArgumentBuilder<CommandSourceStack, ?>)Commands.argument("block", (com.mojang.brigadier.arguments.ArgumentType<Object>)BlockPredicateArgument.blockPredicate()), var2, commandContext -> BlockPredicateArgument.getBlockPredicate(commandContext, "block").test(new BlockInWorld(((CommandSourceStack)commandContext.getSource()).getLevel(), BlockPosArgument.getLoadedBlockPos(commandContext, "pos"), true))))))).then(Commands.literal("score").then(Commands.argument("target", (com.mojang.brigadier.arguments.ArgumentType<Object>)ScoreHolderArgument.scoreHolder()).suggests((SuggestionProvider)ScoreHolderArgument.SUGGEST_SCORE_HOLDERS).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("targetObjective", (com.mojang.brigadier.arguments.ArgumentType<Object>)ObjectiveArgument.objective()).then(Commands.literal("=").then(Commands.argument("source", (com.mojang.brigadier.arguments.ArgumentType<Object>)ScoreHolderArgument.scoreHolder()).suggests((SuggestionProvider)ScoreHolderArgument.SUGGEST_SCORE_HOLDERS).then((ArgumentBuilder)addConditional(commandNode, (ArgumentBuilder<CommandSourceStack, ?>)Commands.argument("sourceObjective", (com.mojang.brigadier.arguments.ArgumentType<Object>)ObjectiveArgument.objective()), var2, commandContext -> checkScore(commandContext, Integer::equals)))))).then(Commands.literal("<").then(Commands.argument("source", (com.mojang.brigadier.arguments.ArgumentType<Object>)ScoreHolderArgument.scoreHolder()).suggests((SuggestionProvider)ScoreHolderArgument.SUGGEST_SCORE_HOLDERS).then((ArgumentBuilder)addConditional(commandNode, (ArgumentBuilder<CommandSourceStack, ?>)Commands.argument("sourceObjective", (com.mojang.brigadier.arguments.ArgumentType<Object>)ObjectiveArgument.objective()), var2, commandContext -> checkScore(commandContext, (var0, var1) -> var0 < var1)))))).then(Commands.literal("<=").then(Commands.argument("source", (com.mojang.brigadier.arguments.ArgumentType<Object>)ScoreHolderArgument.scoreHolder()).suggests((SuggestionProvider)ScoreHolderArgument.SUGGEST_SCORE_HOLDERS).then((ArgumentBuilder)addConditional(commandNode, (ArgumentBuilder<CommandSourceStack, ?>)Commands.argument("sourceObjective", (com.mojang.brigadier.arguments.ArgumentType<Object>)ObjectiveArgument.objective()), var2, commandContext -> checkScore(commandContext, (var0, var1) -> var0 <= var1)))))).then(Commands.literal(">").then(Commands.argument("source", (com.mojang.brigadier.arguments.ArgumentType<Object>)ScoreHolderArgument.scoreHolder()).suggests((SuggestionProvider)ScoreHolderArgument.SUGGEST_SCORE_HOLDERS).then((ArgumentBuilder)addConditional(commandNode, (ArgumentBuilder<CommandSourceStack, ?>)Commands.argument("sourceObjective", (com.mojang.brigadier.arguments.ArgumentType<Object>)ObjectiveArgument.objective()), var2, commandContext -> checkScore(commandContext, (var0, var1) -> var0 > var1)))))).then(Commands.literal(">=").then(Commands.argument("source", (com.mojang.brigadier.arguments.ArgumentType<Object>)ScoreHolderArgument.scoreHolder()).suggests((SuggestionProvider)ScoreHolderArgument.SUGGEST_SCORE_HOLDERS).then((ArgumentBuilder)addConditional(commandNode, (ArgumentBuilder<CommandSourceStack, ?>)Commands.argument("sourceObjective", (com.mojang.brigadier.arguments.ArgumentType<Object>)ObjectiveArgument.objective()), var2, commandContext -> checkScore(commandContext, (var0, var1) -> var0 >= var1)))))).then(Commands.literal("matches").then((ArgumentBuilder)addConditional(commandNode, (ArgumentBuilder<CommandSourceStack, ?>)Commands.argument("range", (com.mojang.brigadier.arguments.ArgumentType<Object>)RangeArgument.intRange()), var2, commandContext -> checkScore(commandContext, RangeArgument.Ints.getRange(commandContext, "range"))))))))).then(Commands.literal("blocks").then(Commands.argument("start", (com.mojang.brigadier.arguments.ArgumentType<Object>)BlockPosArgument.blockPos()).then(Commands.argument("end", (com.mojang.brigadier.arguments.ArgumentType<Object>)BlockPosArgument.blockPos()).then(((RequiredArgumentBuilder)Commands.argument("destination", (com.mojang.brigadier.arguments.ArgumentType<Object>)BlockPosArgument.blockPos()).then((ArgumentBuilder)addIfBlocksConditional(commandNode, (ArgumentBuilder<CommandSourceStack, ?>)Commands.literal("all"), var2, false))).then((ArgumentBuilder)addIfBlocksConditional(commandNode, (ArgumentBuilder<CommandSourceStack, ?>)Commands.literal("masked"), var2, true))))))).then(Commands.literal("entity").then(((RequiredArgumentBuilder)Commands.argument("entities", (com.mojang.brigadier.arguments.ArgumentType<Object>)EntityArgument.entities()).fork((CommandNode)commandNode, commandContext -> expect((CommandContext<CommandSourceStack>)commandContext, var2, !EntityArgument.getOptionalEntities((CommandContext<CommandSourceStack>)commandContext, "entities").isEmpty()))).executes((Command)createNumericConditionalHandler(var2, commandContext -> EntityArgument.getOptionalEntities(commandContext, "entities").size()))));
        for (final DataCommands.DataProvider var4 : DataCommands.SOURCE_PROVIDERS) {
            final DataCommands.DataProvider dataProvider;
            literalArgumentBuilder.then((ArgumentBuilder)var4.wrap((ArgumentBuilder<CommandSourceStack, ?>)Commands.literal("data"), var3 -> var3.then(((RequiredArgumentBuilder)Commands.argument("path", (com.mojang.brigadier.arguments.ArgumentType<Object>)NbtPathArgument.nbtPath()).fork((CommandNode)commandNode, commandContext -> expect((CommandContext<CommandSourceStack>)commandContext, var2, checkMatchingData(dataProvider.access((CommandContext<CommandSourceStack>)commandContext), NbtPathArgument.getPath((CommandContext<CommandSourceStack>)commandContext, "path")) > 0))).executes((Command)createNumericConditionalHandler(var2, commandContext -> checkMatchingData(dataProvider.access(commandContext), NbtPathArgument.getPath(commandContext, "path")))))));
        }
        return (ArgumentBuilder<CommandSourceStack, ?>)literalArgumentBuilder;
    }
    
    private static Command<CommandSourceStack> createNumericConditionalHandler(final boolean var0, final CommandNumericPredicate executeCommand$CommandNumericPredicate) {
        if (var0) {
            return (Command<CommandSourceStack>)(commandContext -> {
                final int var2 = executeCommand$CommandNumericPredicate.test((CommandContext<CommandSourceStack>)commandContext);
                if (var2 > 0) {
                    ((CommandSourceStack)commandContext.getSource()).sendSuccess(new TranslatableComponent("commands.execute.conditional.pass_count", new Object[] { var2 }), false);
                    return var2;
                }
                throw ExecuteCommand.ERROR_CONDITIONAL_FAILED.create();
            });
        }
        return (Command<CommandSourceStack>)(commandContext -> {
            final int var2 = executeCommand$CommandNumericPredicate.test((CommandContext<CommandSourceStack>)commandContext);
            if (var2 == 0) {
                ((CommandSourceStack)commandContext.getSource()).sendSuccess(new TranslatableComponent("commands.execute.conditional.pass", new Object[0]), false);
                return 1;
            }
            throw ExecuteCommand.ERROR_CONDITIONAL_FAILED_COUNT.create((Object)var2);
        });
    }
    
    private static int checkMatchingData(final DataAccessor dataAccessor, final NbtPathArgument.NbtPath nbtPathArgument$NbtPath) throws CommandSyntaxException {
        return nbtPathArgument$NbtPath.countMatching(dataAccessor.getData());
    }
    
    private static boolean checkScore(final CommandContext<CommandSourceStack> commandContext, final BiPredicate<Integer, Integer> biPredicate) throws CommandSyntaxException {
        final String var2 = ScoreHolderArgument.getName(commandContext, "target");
        final Objective var3 = ObjectiveArgument.getObjective(commandContext, "targetObjective");
        final String var4 = ScoreHolderArgument.getName(commandContext, "source");
        final Objective var5 = ObjectiveArgument.getObjective(commandContext, "sourceObjective");
        final Scoreboard var6 = ((CommandSourceStack)commandContext.getSource()).getServer().getScoreboard();
        if (!var6.hasPlayerScore(var2, var3) || !var6.hasPlayerScore(var4, var5)) {
            return false;
        }
        final Score var7 = var6.getOrCreatePlayerScore(var2, var3);
        final Score var8 = var6.getOrCreatePlayerScore(var4, var5);
        return biPredicate.test(var7.getScore(), var8.getScore());
    }
    
    private static boolean checkScore(final CommandContext<CommandSourceStack> commandContext, final MinMaxBounds.Ints minMaxBounds$Ints) throws CommandSyntaxException {
        final String var2 = ScoreHolderArgument.getName(commandContext, "target");
        final Objective var3 = ObjectiveArgument.getObjective(commandContext, "targetObjective");
        final Scoreboard var4 = ((CommandSourceStack)commandContext.getSource()).getServer().getScoreboard();
        return var4.hasPlayerScore(var2, var3) && minMaxBounds$Ints.matches(var4.getOrCreatePlayerScore(var2, var3).getScore());
    }
    
    private static Collection<CommandSourceStack> expect(final CommandContext<CommandSourceStack> commandContext, final boolean var1, final boolean var2) {
        if (var2 == var1) {
            return (Collection<CommandSourceStack>)Collections.singleton(commandContext.getSource());
        }
        return (Collection<CommandSourceStack>)Collections.emptyList();
    }
    
    private static ArgumentBuilder<CommandSourceStack, ?> addConditional(final CommandNode<CommandSourceStack> commandNode, final ArgumentBuilder<CommandSourceStack, ?> var1, final boolean var2, final CommandPredicate executeCommand$CommandPredicate) {
        return (ArgumentBuilder<CommandSourceStack, ?>)var1.fork((CommandNode)commandNode, commandContext -> expect((CommandContext<CommandSourceStack>)commandContext, var2, executeCommand$CommandPredicate.test((CommandContext<CommandSourceStack>)commandContext))).executes(commandContext -> {
            if (var2 == executeCommand$CommandPredicate.test((CommandContext<CommandSourceStack>)commandContext)) {
                ((CommandSourceStack)commandContext.getSource()).sendSuccess(new TranslatableComponent("commands.execute.conditional.pass", new Object[0]), false);
                return 1;
            }
            throw ExecuteCommand.ERROR_CONDITIONAL_FAILED.create();
        });
    }
    
    private static ArgumentBuilder<CommandSourceStack, ?> addIfBlocksConditional(final CommandNode<CommandSourceStack> commandNode, final ArgumentBuilder<CommandSourceStack, ?> var1, final boolean var2, final boolean var3) {
        return (ArgumentBuilder<CommandSourceStack, ?>)var1.fork((CommandNode)commandNode, commandContext -> expect((CommandContext<CommandSourceStack>)commandContext, var2, checkRegions((CommandContext<CommandSourceStack>)commandContext, var3).isPresent())).executes(var2 ? (commandContext -> checkIfRegions((CommandContext<CommandSourceStack>)commandContext, var3)) : (commandContext -> checkUnlessRegions((CommandContext<CommandSourceStack>)commandContext, var3)));
    }
    
    private static int checkIfRegions(final CommandContext<CommandSourceStack> commandContext, final boolean var1) throws CommandSyntaxException {
        final OptionalInt var2 = checkRegions(commandContext, var1);
        if (var2.isPresent()) {
            ((CommandSourceStack)commandContext.getSource()).sendSuccess(new TranslatableComponent("commands.execute.conditional.pass_count", new Object[] { var2.getAsInt() }), false);
            return var2.getAsInt();
        }
        throw ExecuteCommand.ERROR_CONDITIONAL_FAILED.create();
    }
    
    private static int checkUnlessRegions(final CommandContext<CommandSourceStack> commandContext, final boolean var1) throws CommandSyntaxException {
        final OptionalInt var2 = checkRegions(commandContext, var1);
        if (var2.isPresent()) {
            throw ExecuteCommand.ERROR_CONDITIONAL_FAILED_COUNT.create((Object)var2.getAsInt());
        }
        ((CommandSourceStack)commandContext.getSource()).sendSuccess(new TranslatableComponent("commands.execute.conditional.pass", new Object[0]), false);
        return 1;
    }
    
    private static OptionalInt checkRegions(final CommandContext<CommandSourceStack> commandContext, final boolean var1) throws CommandSyntaxException {
        return checkRegions(((CommandSourceStack)commandContext.getSource()).getLevel(), BlockPosArgument.getLoadedBlockPos(commandContext, "start"), BlockPosArgument.getLoadedBlockPos(commandContext, "end"), BlockPosArgument.getLoadedBlockPos(commandContext, "destination"), var1);
    }
    
    private static OptionalInt checkRegions(final ServerLevel serverLevel, final BlockPos var1, final BlockPos var2, final BlockPos var3, final boolean var4) throws CommandSyntaxException {
        final BoundingBox var5 = new BoundingBox(var1, var2);
        final BoundingBox var6 = new BoundingBox(var3, var3.offset(var5.getLength()));
        final BlockPos var7 = new BlockPos(var6.x0 - var5.x0, var6.y0 - var5.y0, var6.z0 - var5.z0);
        final int var8 = var5.getXSpan() * var5.getYSpan() * var5.getZSpan();
        if (var8 > 32768) {
            throw ExecuteCommand.ERROR_AREA_TOO_LARGE.create((Object)32768, (Object)var8);
        }
        int var9 = 0;
        for (int var10 = var5.z0; var10 <= var5.z1; ++var10) {
            for (int var11 = var5.y0; var11 <= var5.y1; ++var11) {
                for (int var12 = var5.x0; var12 <= var5.x1; ++var12) {
                    final BlockPos var13 = new BlockPos(var12, var11, var10);
                    final BlockPos var14 = var13.offset(var7);
                    final BlockState var15 = serverLevel.getBlockState(var13);
                    if (!var4 || var15.getBlock() != Blocks.AIR) {
                        if (var15 != serverLevel.getBlockState(var14)) {
                            return OptionalInt.empty();
                        }
                        final BlockEntity var16 = serverLevel.getBlockEntity(var13);
                        final BlockEntity var17 = serverLevel.getBlockEntity(var14);
                        if (var16 != null) {
                            if (var17 == null) {
                                return OptionalInt.empty();
                            }
                            final CompoundTag var18 = var16.save(new CompoundTag());
                            var18.remove("x");
                            var18.remove("y");
                            var18.remove("z");
                            final CompoundTag var19 = var17.save(new CompoundTag());
                            var19.remove("x");
                            var19.remove("y");
                            var19.remove("z");
                            if (!var18.equals(var19)) {
                                return OptionalInt.empty();
                            }
                        }
                        ++var9;
                    }
                }
            }
        }
        return OptionalInt.of(var9);
    }
    
    static {
        ERROR_AREA_TOO_LARGE = new Dynamic2CommandExceptionType((var0, var1) -> new TranslatableComponent("commands.execute.blocks.toobig", new Object[] { var0, var1 }));
        ERROR_CONDITIONAL_FAILED = new SimpleCommandExceptionType((Message)new TranslatableComponent("commands.execute.conditional.fail", new Object[0]));
        final TranslatableComponent translatableComponent;
        ERROR_CONDITIONAL_FAILED_COUNT = new DynamicCommandExceptionType(object -> {
            new TranslatableComponent("commands.execute.conditional.fail_count", new Object[] { object });
            return translatableComponent;
        });
        CALLBACK_CHAINER = (BinaryOperator)((var0, var1) -> (commandContext, var3, var4) -> {
            var0.onCommandComplete(commandContext, var3, var4);
            var1.onCommandComplete(commandContext, var3, var4);
        });
    }
    
    @FunctionalInterface
    interface CommandNumericPredicate
    {
        int test(final CommandContext<CommandSourceStack> p0) throws CommandSyntaxException;
    }
    
    @FunctionalInterface
    interface CommandPredicate
    {
        boolean test(final CommandContext<CommandSourceStack> p0) throws CommandSyntaxException;
    }
}
