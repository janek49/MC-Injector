package net.minecraft.server.commands;

import com.mojang.brigadier.*;
import net.minecraft.commands.*;
import com.mojang.brigadier.builder.*;
import net.minecraft.commands.arguments.*;
import com.mojang.brigadier.arguments.*;
import net.minecraft.server.level.*;
import net.minecraft.network.protocol.game.*;
import net.minecraft.network.protocol.*;
import net.minecraft.network.chat.*;
import net.minecraft.world.entity.*;
import java.util.*;
import com.mojang.brigadier.exceptions.*;
import com.mojang.brigadier.context.*;

public class TitleCommand
{
    public static void register(final CommandDispatcher<CommandSourceStack> commandDispatcher) {
        commandDispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("title").requires(commandSourceStack -> commandSourceStack.hasPermission(2))).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("targets", (com.mojang.brigadier.arguments.ArgumentType<Object>)EntityArgument.players()).then(Commands.literal("clear").executes(commandContext -> clearTitle((CommandSourceStack)commandContext.getSource(), EntityArgument.getPlayers((CommandContext<CommandSourceStack>)commandContext, "targets"))))).then(Commands.literal("reset").executes(commandContext -> resetTitle((CommandSourceStack)commandContext.getSource(), EntityArgument.getPlayers((CommandContext<CommandSourceStack>)commandContext, "targets"))))).then(Commands.literal("title").then(Commands.argument("title", (com.mojang.brigadier.arguments.ArgumentType<Object>)ComponentArgument.textComponent()).executes(commandContext -> showTitle((CommandSourceStack)commandContext.getSource(), EntityArgument.getPlayers((CommandContext<CommandSourceStack>)commandContext, "targets"), ComponentArgument.getComponent((CommandContext<CommandSourceStack>)commandContext, "title"), ClientboundSetTitlesPacket.Type.TITLE))))).then(Commands.literal("subtitle").then(Commands.argument("title", (com.mojang.brigadier.arguments.ArgumentType<Object>)ComponentArgument.textComponent()).executes(commandContext -> showTitle((CommandSourceStack)commandContext.getSource(), EntityArgument.getPlayers((CommandContext<CommandSourceStack>)commandContext, "targets"), ComponentArgument.getComponent((CommandContext<CommandSourceStack>)commandContext, "title"), ClientboundSetTitlesPacket.Type.SUBTITLE))))).then(Commands.literal("actionbar").then(Commands.argument("title", (com.mojang.brigadier.arguments.ArgumentType<Object>)ComponentArgument.textComponent()).executes(commandContext -> showTitle((CommandSourceStack)commandContext.getSource(), EntityArgument.getPlayers((CommandContext<CommandSourceStack>)commandContext, "targets"), ComponentArgument.getComponent((CommandContext<CommandSourceStack>)commandContext, "title"), ClientboundSetTitlesPacket.Type.ACTIONBAR))))).then(Commands.literal("times").then(Commands.argument("fadeIn", (com.mojang.brigadier.arguments.ArgumentType<Object>)IntegerArgumentType.integer(0)).then(Commands.argument("stay", (com.mojang.brigadier.arguments.ArgumentType<Object>)IntegerArgumentType.integer(0)).then(Commands.argument("fadeOut", (com.mojang.brigadier.arguments.ArgumentType<Object>)IntegerArgumentType.integer(0)).executes(commandContext -> setTimes((CommandSourceStack)commandContext.getSource(), EntityArgument.getPlayers((CommandContext<CommandSourceStack>)commandContext, "targets"), IntegerArgumentType.getInteger(commandContext, "fadeIn"), IntegerArgumentType.getInteger(commandContext, "stay"), IntegerArgumentType.getInteger(commandContext, "fadeOut")))))))));
    }
    
    private static int clearTitle(final CommandSourceStack commandSourceStack, final Collection<ServerPlayer> collection) {
        final ClientboundSetTitlesPacket var2 = new ClientboundSetTitlesPacket(ClientboundSetTitlesPacket.Type.CLEAR, null);
        for (final ServerPlayer var3 : collection) {
            var3.connection.send(var2);
        }
        if (collection.size() == 1) {
            commandSourceStack.sendSuccess(new TranslatableComponent("commands.title.cleared.single", new Object[] { collection.iterator().next().getDisplayName() }), true);
        }
        else {
            commandSourceStack.sendSuccess(new TranslatableComponent("commands.title.cleared.multiple", new Object[] { collection.size() }), true);
        }
        return collection.size();
    }
    
    private static int resetTitle(final CommandSourceStack commandSourceStack, final Collection<ServerPlayer> collection) {
        final ClientboundSetTitlesPacket var2 = new ClientboundSetTitlesPacket(ClientboundSetTitlesPacket.Type.RESET, null);
        for (final ServerPlayer var3 : collection) {
            var3.connection.send(var2);
        }
        if (collection.size() == 1) {
            commandSourceStack.sendSuccess(new TranslatableComponent("commands.title.reset.single", new Object[] { collection.iterator().next().getDisplayName() }), true);
        }
        else {
            commandSourceStack.sendSuccess(new TranslatableComponent("commands.title.reset.multiple", new Object[] { collection.size() }), true);
        }
        return collection.size();
    }
    
    private static int showTitle(final CommandSourceStack commandSourceStack, final Collection<ServerPlayer> collection, final Component component, final ClientboundSetTitlesPacket.Type clientboundSetTitlesPacket$Type) throws CommandSyntaxException {
        for (final ServerPlayer var5 : collection) {
            var5.connection.send(new ClientboundSetTitlesPacket(clientboundSetTitlesPacket$Type, ComponentUtils.updateForEntity(commandSourceStack, component, var5, 0)));
        }
        if (collection.size() == 1) {
            commandSourceStack.sendSuccess(new TranslatableComponent("commands.title.show." + clientboundSetTitlesPacket$Type.name().toLowerCase(Locale.ROOT) + ".single", new Object[] { collection.iterator().next().getDisplayName() }), true);
        }
        else {
            commandSourceStack.sendSuccess(new TranslatableComponent("commands.title.show." + clientboundSetTitlesPacket$Type.name().toLowerCase(Locale.ROOT) + ".multiple", new Object[] { collection.size() }), true);
        }
        return collection.size();
    }
    
    private static int setTimes(final CommandSourceStack commandSourceStack, final Collection<ServerPlayer> collection, final int var2, final int var3, final int var4) {
        final ClientboundSetTitlesPacket var5 = new ClientboundSetTitlesPacket(var2, var3, var4);
        for (final ServerPlayer var6 : collection) {
            var6.connection.send(var5);
        }
        if (collection.size() == 1) {
            commandSourceStack.sendSuccess(new TranslatableComponent("commands.title.times.single", new Object[] { collection.iterator().next().getDisplayName() }), true);
        }
        else {
            commandSourceStack.sendSuccess(new TranslatableComponent("commands.title.times.multiple", new Object[] { collection.size() }), true);
        }
        return collection.size();
    }
}
