package net.minecraft.server.commands;

import com.mojang.brigadier.*;
import com.mojang.brigadier.builder.*;
import net.minecraft.commands.*;
import net.minecraft.world.entity.player.*;
import java.util.function.*;
import net.minecraft.server.level.*;
import net.minecraft.network.chat.*;
import net.minecraft.server.players.*;
import java.util.*;
import com.mojang.brigadier.context.*;
import com.mojang.brigadier.exceptions.*;

public class ListPlayersCommand
{
    public static void register(final CommandDispatcher<CommandSourceStack> commandDispatcher) {
        commandDispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("list").executes(commandContext -> listPlayers((CommandSourceStack)commandContext.getSource()))).then(Commands.literal("uuids").executes(commandContext -> listPlayersWithUuids((CommandSourceStack)commandContext.getSource()))));
    }
    
    private static int listPlayers(final CommandSourceStack commandSourceStack) {
        return format(commandSourceStack, Player::getDisplayName);
    }
    
    private static int listPlayersWithUuids(final CommandSourceStack commandSourceStack) {
        return format(commandSourceStack, Player::getDisplayNameWithUuid);
    }
    
    private static int format(final CommandSourceStack commandSourceStack, final Function<ServerPlayer, Component> function) {
        final PlayerList var2 = commandSourceStack.getServer().getPlayerList();
        final List<ServerPlayer> var3 = var2.getPlayers();
        final Component var4 = ComponentUtils.formatList(var3, function);
        commandSourceStack.sendSuccess(new TranslatableComponent("commands.list.players", new Object[] { var3.size(), var2.getMaxPlayers(), var4 }), false);
        return var3.size();
    }
}
