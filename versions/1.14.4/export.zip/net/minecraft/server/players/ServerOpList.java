package net.minecraft.server.players;

import com.mojang.authlib.*;
import java.io.*;
import com.google.gson.*;
import java.util.*;

public class ServerOpList extends StoredUserList<GameProfile, ServerOpListEntry>
{
    public ServerOpList(final File file) {
        super(file);
    }
    
    @Override
    protected StoredUserEntry<GameProfile> createEntry(final JsonObject jsonObject) {
        return new ServerOpListEntry(jsonObject);
    }
    
    @Override
    public String[] getUserList() {
        final String[] strings = new String[((StoredUserList<K, ServerOpListEntry>)this).getEntries().size()];
        int var2 = 0;
        for (final StoredUserEntry<GameProfile> var3 : ((StoredUserList<K, ServerOpListEntry>)this).getEntries()) {
            strings[var2++] = var3.getUser().getName();
        }
        return strings;
    }
    
    public boolean canBypassPlayerLimit(final GameProfile gameProfile) {
        final ServerOpListEntry var2 = this.get(gameProfile);
        return var2 != null && var2.getBypassesPlayerLimit();
    }
    
    @Override
    protected String getKeyForUser(final GameProfile gameProfile) {
        return gameProfile.getId().toString();
    }
}
