package net.minecraft.server.network;

import net.minecraft.server.*;
import net.minecraft.network.protocol.handshake.*;
import net.minecraft.network.*;
import net.minecraft.network.chat.*;

public class MemoryServerHandshakePacketListenerImpl implements ServerHandshakePacketListener
{
    private final MinecraftServer server;
    private final Connection connection;
    
    public MemoryServerHandshakePacketListenerImpl(final MinecraftServer server, final Connection connection) {
        this.server = server;
        this.connection = connection;
    }
    
    @Override
    public void handleIntention(final ClientIntentionPacket clientIntentionPacket) {
        this.connection.setProtocol(clientIntentionPacket.getIntention());
        this.connection.setListener(new ServerLoginPacketListenerImpl(this.server, this.connection));
    }
    
    @Override
    public void onDisconnect(final Component component) {
    }
    
    @Override
    public Connection getConnection() {
        return this.connection;
    }
}
