package net.minecraft.server.rcon;

import java.nio.charset.*;

public class PktUtils
{
    public static final char[] HEX_CHAR;
    
    public static String stringFromByteArray(final byte[] bytes, final int var1, final int var2) {
        int var3;
        int var4;
        for (var3 = var2 - 1, var4 = ((var1 > var3) ? var3 : var1); 0 != bytes[var4] && var4 < var3; ++var4) {}
        return new String(bytes, var1, var4 - var1, StandardCharsets.UTF_8);
    }
    
    public static int intFromByteArray(final byte[] bytes, final int var1) {
        return intFromByteArray(bytes, var1, bytes.length);
    }
    
    public static int intFromByteArray(final byte[] bytes, final int var1, final int var2) {
        if (0 > var2 - var1 - 4) {
            return 0;
        }
        return bytes[var1 + 3] << 24 | (bytes[var1 + 2] & 0xFF) << 16 | (bytes[var1 + 1] & 0xFF) << 8 | (bytes[var1] & 0xFF);
    }
    
    public static int intFromNetworkByteArray(final byte[] bytes, final int var1, final int var2) {
        if (0 > var2 - var1 - 4) {
            return 0;
        }
        return bytes[var1] << 24 | (bytes[var1 + 1] & 0xFF) << 16 | (bytes[var1 + 2] & 0xFF) << 8 | (bytes[var1 + 3] & 0xFF);
    }
    
    public static String toHexString(final byte b) {
        return "" + PktUtils.HEX_CHAR[(b & 0xF0) >>> 4] + PktUtils.HEX_CHAR[b & 0xF];
    }
    
    static {
        HEX_CHAR = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
    }
}
