package net.minecraft.server.packs.repository;

import java.util.*;

public interface RepositorySource
{
     <T extends UnopenedPack> void loadPacks(final Map<String, T> p0, final UnopenedPack.UnopenedPackConstructor<T> p1);
}
