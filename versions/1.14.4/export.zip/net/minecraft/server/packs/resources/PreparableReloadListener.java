package net.minecraft.server.packs.resources;

import net.minecraft.util.profiling.*;
import java.util.concurrent.*;

public interface PreparableReloadListener
{
    CompletableFuture<Void> reload(final PreparationBarrier p0, final ResourceManager p1, final ProfilerFiller p2, final ProfilerFiller p3, final Executor p4, final Executor p5);
    
    public interface PreparationBarrier
    {
         <T> CompletableFuture<T> wait(final T p0);
    }
}
