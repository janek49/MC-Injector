package net.minecraft.data.info;

import net.minecraft.data.*;
import java.net.*;
import java.util.*;
import com.mojang.authlib.yggdrasil.*;
import net.minecraft.server.*;
import net.minecraft.server.players.*;
import net.minecraft.util.datafix.*;
import net.minecraft.server.level.progress.*;
import net.minecraft.server.dedicated.*;
import net.minecraft.commands.synchronization.*;
import com.mojang.brigadier.tree.*;
import net.minecraft.commands.*;
import com.mojang.authlib.minecraft.*;
import com.mojang.authlib.*;
import java.nio.file.*;
import com.mojang.brigadier.*;
import java.io.*;
import com.google.gson.*;

public class CommandsReport implements DataProvider
{
    private static final Gson GSON;
    private final DataGenerator generator;
    
    public CommandsReport(final DataGenerator generator) {
        this.generator = generator;
    }
    
    @Override
    public void run(final HashCache hashCache) throws IOException {
        final YggdrasilAuthenticationService var2 = new YggdrasilAuthenticationService(Proxy.NO_PROXY, UUID.randomUUID().toString());
        final MinecraftSessionService var3 = var2.createMinecraftSessionService();
        final GameProfileRepository var4 = var2.createProfileRepository();
        final File var5 = new File(this.generator.getOutputFolder().toFile(), "tmp");
        final GameProfileCache var6 = new GameProfileCache(var4, new File(var5, MinecraftServer.USERID_CACHE_FILE.getName()));
        final DedicatedServerSettings var7 = new DedicatedServerSettings(Paths.get("server.properties", new String[0]));
        final MinecraftServer var8 = new DedicatedServer(var5, var7, DataFixers.getDataFixer(), var2, var3, var4, var6, LoggerChunkProgressListener::new, var7.getProperties().levelName);
        final Path var9 = this.generator.getOutputFolder().resolve("reports/commands.json");
        final CommandDispatcher<CommandSourceStack> var10 = var8.getCommands().getDispatcher();
        DataProvider.save(CommandsReport.GSON, hashCache, (JsonElement)ArgumentTypes.serializeNodeToJson(var10, (com.mojang.brigadier.tree.CommandNode<CommandSourceStack>)var10.getRoot()), var9);
    }
    
    @Override
    public String getName() {
        return "Command Syntax";
    }
    
    static {
        GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    }
}
