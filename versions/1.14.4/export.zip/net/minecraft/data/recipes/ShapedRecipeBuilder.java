package net.minecraft.data.recipes;

import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.tags.*;
import java.util.function.*;
import net.minecraft.core.*;
import net.minecraft.resources.*;
import net.minecraft.advancements.critereon.*;
import net.minecraft.advancements.*;
import com.google.common.collect.*;
import java.util.*;
import org.apache.logging.log4j.*;
import com.google.gson.*;
import net.minecraft.world.item.crafting.*;
import javax.annotation.*;

public class ShapedRecipeBuilder
{
    private static final Logger LOGGER;
    private final Item result;
    private final int count;
    private final List<String> rows;
    private final Map<Character, Ingredient> key;
    private final Advancement.Builder advancement;
    private String group;
    
    public ShapedRecipeBuilder(final ItemLike itemLike, final int count) {
        this.rows = (List<String>)Lists.newArrayList();
        this.key = (Map<Character, Ingredient>)Maps.newLinkedHashMap();
        this.advancement = Advancement.Builder.advancement();
        this.result = itemLike.asItem();
        this.count = count;
    }
    
    public static ShapedRecipeBuilder shaped(final ItemLike itemLike) {
        return shaped(itemLike, 1);
    }
    
    public static ShapedRecipeBuilder shaped(final ItemLike itemLike, final int var1) {
        return new ShapedRecipeBuilder(itemLike, var1);
    }
    
    public ShapedRecipeBuilder define(final Character character, final Tag<Item> tag) {
        return this.define(character, Ingredient.of(tag));
    }
    
    public ShapedRecipeBuilder define(final Character character, final ItemLike itemLike) {
        return this.define(character, Ingredient.of(itemLike));
    }
    
    public ShapedRecipeBuilder define(final Character character, final Ingredient ingredient) {
        if (this.key.containsKey(character)) {
            throw new IllegalArgumentException("Symbol '" + character + "' is already defined!");
        }
        if (character == ' ') {
            throw new IllegalArgumentException("Symbol ' ' (whitespace) is reserved and cannot be defined");
        }
        this.key.put(character, ingredient);
        return this;
    }
    
    public ShapedRecipeBuilder pattern(final String string) {
        if (!this.rows.isEmpty() && string.length() != this.rows.get(0).length()) {
            throw new IllegalArgumentException("Pattern must be the same width on every line!");
        }
        this.rows.add(string);
        return this;
    }
    
    public ShapedRecipeBuilder unlocks(final String string, final CriterionTriggerInstance criterionTriggerInstance) {
        this.advancement.addCriterion(string, criterionTriggerInstance);
        return this;
    }
    
    public ShapedRecipeBuilder group(final String group) {
        this.group = group;
        return this;
    }
    
    public void save(final Consumer<FinishedRecipe> consumer) {
        this.save(consumer, Registry.ITEM.getKey(this.result));
    }
    
    public void save(final Consumer<FinishedRecipe> consumer, final String string) {
        final ResourceLocation var3 = Registry.ITEM.getKey(this.result);
        if (new ResourceLocation(string).equals(var3)) {
            throw new IllegalStateException("Shaped Recipe " + string + " should remove its 'save' argument");
        }
        this.save(consumer, new ResourceLocation(string));
    }
    
    public void save(final Consumer<FinishedRecipe> consumer, final ResourceLocation resourceLocation) {
        this.ensureValid(resourceLocation);
        this.advancement.parent(new ResourceLocation("recipes/root")).addCriterion("has_the_recipe", new RecipeUnlockedTrigger.TriggerInstance(resourceLocation)).rewards(AdvancementRewards.Builder.recipe(resourceLocation)).requirements(RequirementsStrategy.OR);
        consumer.accept(new Result(resourceLocation, this.result, this.count, (this.group == null) ? "" : this.group, this.rows, this.key, this.advancement, new ResourceLocation(resourceLocation.getNamespace(), "recipes/" + this.result.getItemCategory().getRecipeFolderName() + "/" + resourceLocation.getPath())));
    }
    
    private void ensureValid(final ResourceLocation resourceLocation) {
        if (this.rows.isEmpty()) {
            throw new IllegalStateException("No pattern is defined for shaped recipe " + resourceLocation + "!");
        }
        final Set<Character> var2 = (Set<Character>)Sets.newHashSet((Iterable)this.key.keySet());
        var2.remove(' ');
        for (final String var3 : this.rows) {
            for (int var4 = 0; var4 < var3.length(); ++var4) {
                final char var5 = var3.charAt(var4);
                if (!this.key.containsKey(var5) && var5 != ' ') {
                    throw new IllegalStateException("Pattern in recipe " + resourceLocation + " uses undefined symbol '" + var5 + "'");
                }
                var2.remove(var5);
            }
        }
        if (!var2.isEmpty()) {
            throw new IllegalStateException("Ingredients are defined but not used in pattern for recipe " + resourceLocation);
        }
        if (this.rows.size() == 1 && this.rows.get(0).length() == 1) {
            throw new IllegalStateException("Shaped recipe " + resourceLocation + " only takes in a single item - should it be a shapeless recipe instead?");
        }
        if (this.advancement.getCriteria().isEmpty()) {
            throw new IllegalStateException("No way of obtaining recipe " + resourceLocation);
        }
    }
    
    static {
        LOGGER = LogManager.getLogger();
    }
    
    class Result implements FinishedRecipe
    {
        private final ResourceLocation id;
        private final Item result;
        private final int count;
        private final String group;
        private final List<String> pattern;
        private final Map<Character, Ingredient> key;
        private final Advancement.Builder advancement;
        private final ResourceLocation advancementId;
        
        public Result(final ResourceLocation id, final Item result, final int count, final String group, final List pattern, final Map key, final Advancement.Builder advancement, final ResourceLocation advancementId) {
            this.id = id;
            this.result = result;
            this.count = count;
            this.group = group;
            this.pattern = (List<String>)pattern;
            this.key = (Map<Character, Ingredient>)key;
            this.advancement = advancement;
            this.advancementId = advancementId;
        }
        
        @Override
        public void serializeRecipeData(final JsonObject jsonObject) {
            if (!this.group.isEmpty()) {
                jsonObject.addProperty("group", this.group);
            }
            final JsonArray var2 = new JsonArray();
            for (final String var3 : this.pattern) {
                var2.add(var3);
            }
            jsonObject.add("pattern", (JsonElement)var2);
            final JsonObject var4 = new JsonObject();
            for (final Map.Entry<Character, Ingredient> var5 : this.key.entrySet()) {
                var4.add(String.valueOf(var5.getKey()), var5.getValue().toJson());
            }
            jsonObject.add("key", (JsonElement)var4);
            final JsonObject var6 = new JsonObject();
            var6.addProperty("item", Registry.ITEM.getKey(this.result).toString());
            if (this.count > 1) {
                var6.addProperty("count", (Number)this.count);
            }
            jsonObject.add("result", (JsonElement)var6);
        }
        
        @Override
        public RecipeSerializer<?> getType() {
            return RecipeSerializer.SHAPED_RECIPE;
        }
        
        @Override
        public ResourceLocation getId() {
            return this.id;
        }
        
        @Nullable
        @Override
        public JsonObject serializeAdvancement() {
            return this.advancement.serializeToJson();
        }
        
        @Nullable
        @Override
        public ResourceLocation getAdvancementId() {
            return this.advancementId;
        }
    }
}
