package net.minecraft.advancements.critereon;

import javax.annotation.*;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.*;
import net.minecraft.util.*;
import net.minecraft.nbt.*;
import com.google.gson.*;
import com.mojang.brigadier.exceptions.*;
import net.minecraft.world.entity.player.*;

public class NbtPredicate
{
    public static final NbtPredicate ANY;
    @Nullable
    private final CompoundTag tag;
    
    public NbtPredicate(@Nullable final CompoundTag tag) {
        this.tag = tag;
    }
    
    public boolean matches(final ItemStack itemStack) {
        return this == NbtPredicate.ANY || this.matches(itemStack.getTag());
    }
    
    public boolean matches(final Entity entity) {
        return this == NbtPredicate.ANY || this.matches(getEntityTagToCompare(entity));
    }
    
    public boolean matches(@Nullable final Tag tag) {
        if (tag == null) {
            return this == NbtPredicate.ANY;
        }
        return this.tag == null || NbtUtils.compareNbt(this.tag, tag, true);
    }
    
    public JsonElement serializeToJson() {
        if (this == NbtPredicate.ANY || this.tag == null) {
            return (JsonElement)JsonNull.INSTANCE;
        }
        return (JsonElement)new JsonPrimitive(this.tag.toString());
    }
    
    public static NbtPredicate fromJson(@Nullable final JsonElement json) {
        if (json == null || json.isJsonNull()) {
            return NbtPredicate.ANY;
        }
        CompoundTag var1;
        try {
            var1 = TagParser.parseTag(GsonHelper.convertToString(json, "nbt"));
        }
        catch (CommandSyntaxException var2) {
            throw new JsonSyntaxException("Invalid nbt tag: " + var2.getMessage());
        }
        return new NbtPredicate(var1);
    }
    
    public static CompoundTag getEntityTagToCompare(final Entity entity) {
        final CompoundTag compoundTag = entity.saveWithoutId(new CompoundTag());
        if (entity instanceof Player) {
            final ItemStack var2 = ((Player)entity).inventory.getSelected();
            if (!var2.isEmpty()) {
                compoundTag.put("SelectedItem", var2.save(new CompoundTag()));
            }
        }
        return compoundTag;
    }
    
    static {
        ANY = new NbtPredicate(null);
    }
}
