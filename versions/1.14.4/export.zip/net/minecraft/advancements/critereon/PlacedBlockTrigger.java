package net.minecraft.advancements.critereon;

import net.minecraft.resources.*;
import net.minecraft.server.*;
import net.minecraft.util.*;
import net.minecraft.world.level.block.*;
import com.google.gson.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.core.*;
import net.minecraft.world.item.*;
import net.minecraft.advancements.*;
import javax.annotation.*;
import net.minecraft.server.level.*;
import net.minecraft.*;
import com.google.common.collect.*;
import java.util.*;

public class PlacedBlockTrigger implements CriterionTrigger<TriggerInstance>
{
    private static final ResourceLocation ID;
    private final Map<PlayerAdvancements, PlayerListeners> players;
    
    public PlacedBlockTrigger() {
        this.players = (Map<PlayerAdvancements, PlayerListeners>)Maps.newHashMap();
    }
    
    @Override
    public ResourceLocation getId() {
        return PlacedBlockTrigger.ID;
    }
    
    @Override
    public void addPlayerListener(final PlayerAdvancements playerAdvancements, final Listener<TriggerInstance> criterionTrigger$Listener) {
        PlayerListeners var3 = this.players.get(playerAdvancements);
        if (var3 == null) {
            var3 = new PlayerListeners(playerAdvancements);
            this.players.put(playerAdvancements, var3);
        }
        var3.addListener(criterionTrigger$Listener);
    }
    
    @Override
    public void removePlayerListener(final PlayerAdvancements playerAdvancements, final Listener<TriggerInstance> criterionTrigger$Listener) {
        final PlayerListeners var3 = this.players.get(playerAdvancements);
        if (var3 != null) {
            var3.removeListener(criterionTrigger$Listener);
            if (var3.isEmpty()) {
                this.players.remove(playerAdvancements);
            }
        }
    }
    
    @Override
    public void removePlayerListeners(final PlayerAdvancements playerAdvancements) {
        this.players.remove(playerAdvancements);
    }
    
    @Override
    public TriggerInstance createInstance(final JsonObject jsonObject, final JsonDeserializationContext jsonDeserializationContext) {
        Block var3 = null;
        if (jsonObject.has("block")) {
            final ResourceLocation var4 = new ResourceLocation(GsonHelper.getAsString(jsonObject, "block"));
            final Object o;
            final Object o2;
            var3 = Registry.BLOCK.getOptional(var4).orElseThrow(() -> {
                new JsonSyntaxException("Unknown block type '" + o2 + "'");
                return o;
            });
        }
        Map<Property<?>, Object> var5 = null;
        if (jsonObject.has("state")) {
            if (var3 == null) {
                throw new JsonSyntaxException("Can't define block state without a specific block type");
            }
            final StateDefinition<Block, BlockState> var6 = var3.getStateDefinition();
            for (final Map.Entry<String, JsonElement> var7 : GsonHelper.getAsJsonObject(jsonObject, "state").entrySet()) {
                final Property<?> var8 = var6.getProperty(var7.getKey());
                if (var8 == null) {
                    throw new JsonSyntaxException("Unknown block state property '" + var7.getKey() + "' for block '" + Registry.BLOCK.getKey(var3) + "'");
                }
                final String var9 = GsonHelper.convertToString(var7.getValue(), var7.getKey());
                final Optional<?> var10 = var8.getValue(var9);
                if (!var10.isPresent()) {
                    throw new JsonSyntaxException("Invalid block state value '" + var9 + "' for property '" + var7.getKey() + "' on block '" + Registry.BLOCK.getKey(var3) + "'");
                }
                if (var5 == null) {
                    var5 = (Map<Property<?>, Object>)Maps.newHashMap();
                }
                var5.put(var8, var10.get());
            }
        }
        final LocationPredicate var11 = LocationPredicate.fromJson(jsonObject.get("location"));
        final ItemPredicate var12 = ItemPredicate.fromJson(jsonObject.get("item"));
        return new TriggerInstance(var3, var5, var11, var12);
    }
    
    public void trigger(final ServerPlayer serverPlayer, final BlockPos blockPos, final ItemStack itemStack) {
        final BlockState var4 = serverPlayer.level.getBlockState(blockPos);
        final PlayerListeners var5 = this.players.get(serverPlayer.getAdvancements());
        if (var5 != null) {
            var5.trigger(var4, blockPos, serverPlayer.getLevel(), itemStack);
        }
    }
    
    static {
        ID = new ResourceLocation("placed_block");
    }
    
    public static class TriggerInstance extends AbstractCriterionTriggerInstance
    {
        private final Block block;
        private final Map<Property<?>, Object> state;
        private final LocationPredicate location;
        private final ItemPredicate item;
        
        public TriggerInstance(@Nullable final Block block, @Nullable final Map<Property<?>, Object> state, final LocationPredicate location, final ItemPredicate item) {
            super(PlacedBlockTrigger.ID);
            this.block = block;
            this.state = state;
            this.location = location;
            this.item = item;
        }
        
        public static TriggerInstance placedBlock(final Block block) {
            return new TriggerInstance(block, null, LocationPredicate.ANY, ItemPredicate.ANY);
        }
        
        public boolean matches(final BlockState blockState, final BlockPos blockPos, final ServerLevel serverLevel, final ItemStack itemStack) {
            if (this.block != null && blockState.getBlock() != this.block) {
                return false;
            }
            if (this.state != null) {
                for (final Map.Entry<Property<?>, Object> var6 : this.state.entrySet()) {
                    if (blockState.getValue(var6.getKey()) != var6.getValue()) {
                        return false;
                    }
                }
            }
            return this.location.matches(serverLevel, (float)blockPos.getX(), (float)blockPos.getY(), (float)blockPos.getZ()) && this.item.matches(itemStack);
        }
        
        @Override
        public JsonElement serializeToJson() {
            final JsonObject var1 = new JsonObject();
            if (this.block != null) {
                var1.addProperty("block", Registry.BLOCK.getKey(this.block).toString());
            }
            if (this.state != null) {
                final JsonObject var2 = new JsonObject();
                for (final Map.Entry<Property<?>, Object> var3 : this.state.entrySet()) {
                    var2.addProperty(var3.getKey().getName(), Util.getPropertyName(var3.getKey(), var3.getValue()));
                }
                var1.add("state", (JsonElement)var2);
            }
            var1.add("location", this.location.serializeToJson());
            var1.add("item", this.item.serializeToJson());
            return (JsonElement)var1;
        }
    }
    
    static class PlayerListeners
    {
        private final PlayerAdvancements player;
        private final Set<Listener<TriggerInstance>> listeners;
        
        public PlayerListeners(final PlayerAdvancements player) {
            this.listeners = (Set<Listener<TriggerInstance>>)Sets.newHashSet();
            this.player = player;
        }
        
        public boolean isEmpty() {
            return this.listeners.isEmpty();
        }
        
        public void addListener(final Listener<TriggerInstance> criterionTrigger$Listener) {
            this.listeners.add(criterionTrigger$Listener);
        }
        
        public void removeListener(final Listener<TriggerInstance> criterionTrigger$Listener) {
            this.listeners.remove(criterionTrigger$Listener);
        }
        
        public void trigger(final BlockState blockState, final BlockPos blockPos, final ServerLevel serverLevel, final ItemStack itemStack) {
            List<Listener<TriggerInstance>> var5 = null;
            for (final Listener<TriggerInstance> var6 : this.listeners) {
                if (var6.getTriggerInstance().matches(blockState, blockPos, serverLevel, itemStack)) {
                    if (var5 == null) {
                        var5 = (List<Listener<TriggerInstance>>)Lists.newArrayList();
                    }
                    var5.add(var6);
                }
            }
            if (var5 != null) {
                for (final Listener<TriggerInstance> var6 : var5) {
                    var6.run(this.player);
                }
            }
        }
    }
}
