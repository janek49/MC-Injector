package net.minecraft.nbt;

import java.io.*;
import net.minecraft.network.chat.*;

public class LongTag extends NumericTag
{
    private long data;
    
    LongTag() {
    }
    
    public LongTag(final long data) {
        this.data = data;
    }
    
    @Override
    public void write(final DataOutput dataOutput) throws IOException {
        dataOutput.writeLong(this.data);
    }
    
    @Override
    public void load(final DataInput dataInput, final int var2, final NbtAccounter nbtAccounter) throws IOException {
        nbtAccounter.accountBits(128L);
        this.data = dataInput.readLong();
    }
    
    @Override
    public byte getId() {
        return 4;
    }
    
    @Override
    public String toString() {
        return this.data + "L";
    }
    
    @Override
    public LongTag copy() {
        return new LongTag(this.data);
    }
    
    @Override
    public boolean equals(final Object object) {
        return this == object || (object instanceof LongTag && this.data == ((LongTag)object).data);
    }
    
    @Override
    public int hashCode() {
        return (int)(this.data ^ this.data >>> 32);
    }
    
    @Override
    public Component getPrettyDisplay(final String string, final int var2) {
        final Component component = new TextComponent("L").withStyle(LongTag.SYNTAX_HIGHLIGHTING_NUMBER_TYPE);
        return new TextComponent(String.valueOf(this.data)).append(component).withStyle(LongTag.SYNTAX_HIGHLIGHTING_NUMBER);
    }
    
    @Override
    public long getAsLong() {
        return this.data;
    }
    
    @Override
    public int getAsInt() {
        return (int)(this.data & -1L);
    }
    
    @Override
    public short getAsShort() {
        return (short)(this.data & 0xFFFFL);
    }
    
    @Override
    public byte getAsByte() {
        return (byte)(this.data & 0xFFL);
    }
    
    @Override
    public double getAsDouble() {
        return (double)this.data;
    }
    
    @Override
    public float getAsFloat() {
        return (float)this.data;
    }
    
    @Override
    public Number getAsNumber() {
        return this.data;
    }
}
