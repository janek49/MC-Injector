package net.minecraft.util;

public enum Unit
{
    INSTANCE("INSTANCE", 0);
    
    private Unit(final String s, final int n) {
    }
}
