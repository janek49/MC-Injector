package net.minecraft.util.datafix.fixes;

import com.mojang.datafixers.schemas.*;
import com.mojang.datafixers.types.templates.*;
import java.util.function.*;
import com.google.common.collect.*;
import com.mojang.datafixers.*;
import java.util.stream.*;
import java.util.*;
import com.mojang.datafixers.types.*;
import com.mojang.datafixers.util.*;

public class BedBlockEntityInjecter extends DataFix
{
    public BedBlockEntityInjecter(final Schema schema, final boolean var2) {
        super(schema, var2);
    }
    
    public TypeRewriteRule makeRule() {
        final Type<?> var1 = (Type<?>)this.getOutputSchema().getType(References.CHUNK);
        final Type<?> var2 = (Type<?>)var1.findFieldType("Level");
        final Type<?> var3 = (Type<?>)var2.findFieldType("TileEntities");
        if (!(var3 instanceof List.ListType)) {
            throw new IllegalStateException("Tile entity type is not a list type.");
        }
        final List.ListType<?> var4 = (List.ListType<?>)var3;
        return this.cap(var2, var4);
    }
    
    private <TE> TypeRewriteRule cap(final Type<?> type, final List.ListType<TE> list$ListType) {
        final Type<TE> type2 = (Type<TE>)list$ListType.getElement();
        final OpticFinder<?> var4 = (OpticFinder<?>)DSL.fieldFinder("Level", (Type)type);
        final OpticFinder<java.util.List<TE>> var5 = (OpticFinder<java.util.List<TE>>)DSL.fieldFinder("TileEntities", (Type)list$ListType);
        final int var6 = 416;
        final OpticFinder opticFinder;
        final Typed<?> var7;
        final Dynamic<?> var8;
        final int var9;
        final int var10;
        final OpticFinder opticFinder2;
        final java.util.List<Object> var11;
        java.util.List<? extends Dynamic<?>> var12;
        int var13;
        Dynamic<?> var14;
        int var15;
        Stream<Integer> var16;
        int var17;
        final Iterator<Integer> iterator;
        int var18;
        int var19;
        int var20;
        int var21;
        Map<Dynamic<?>, Dynamic<?>> var22;
        final Type type3;
        return TypeRewriteRule.seq(this.fixTypeEverywhere("InjectBedBlockEntityType", (Type)this.getInputSchema().findChoiceType(References.BLOCK_ENTITY), (Type)this.getOutputSchema().findChoiceType(References.BLOCK_ENTITY), dynamicOps -> pair -> pair), this.fixTypeEverywhereTyped("BedBlockEntityInjecter", this.getOutputSchema().getType(References.CHUNK), var3 -> {
            var7 = (Typed<?>)var3.getTyped(opticFinder);
            var8 = (Dynamic<?>)var7.get(DSL.remainderFinder());
            var9 = var8.get("xPos").asInt(0);
            var10 = var8.get("zPos").asInt(0);
            var11 = (java.util.List<Object>)Lists.newArrayList((Iterable)var7.getOrCreate(opticFinder2));
            for (var12 = (java.util.List<? extends Dynamic<?>>)var8.get("Sections").asList((Function)Function.identity()), var13 = 0; var13 < var12.size(); ++var13) {
                var14 = (Dynamic<?>)var12.get(var13);
                var15 = var14.get("Y").asInt(0);
                var16 = var14.get("Blocks").asStream().map(dynamic -> dynamic.asInt(0));
                var17 = 0;
                ((Iterable<Integer>)var16::iterator).iterator();
                while (iterator.hasNext()) {
                    var18 = iterator.next();
                    if (416 == (var18 & 0xFF) << 4) {
                        var19 = (var17 & 0xF);
                        var20 = (var17 >> 8 & 0xF);
                        var21 = (var17 >> 4 & 0xF);
                        var22 = (Map<Dynamic<?>, Dynamic<?>>)Maps.newHashMap();
                        var22.put((Dynamic<?>)var14.createString("id"), (Dynamic<?>)var14.createString("minecraft:bed"));
                        var22.put((Dynamic<?>)var14.createString("x"), (Dynamic<?>)var14.createInt(var19 + (var9 << 4)));
                        var22.put((Dynamic<?>)var14.createString("y"), (Dynamic<?>)var14.createInt(var20 + (var15 << 4)));
                        var22.put((Dynamic<?>)var14.createString("z"), (Dynamic<?>)var14.createInt(var21 + (var10 << 4)));
                        var22.put((Dynamic<?>)var14.createString("color"), (Dynamic<?>)var14.createShort((short)14));
                        var11.add(((Optional)type3.read(var14.createMap((Map)var22)).getSecond()).orElseThrow(() -> new IllegalStateException("Could not parse newly created bed block entity.")));
                    }
                    ++var17;
                }
            }
            if (!var11.isEmpty()) {
                return var3.set(opticFinder, var7.set(opticFinder2, (Object)var11));
            }
            else {
                return var3;
            }
        }));
    }
}
