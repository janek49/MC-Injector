package net.minecraft.util.datafix.fixes;

import com.mojang.datafixers.schemas.*;
import com.mojang.datafixers.*;
import java.util.function.*;

public class EntityWolfColorFix extends NamedEntityFix
{
    public EntityWolfColorFix(final Schema schema, final boolean var2) {
        super(schema, var2, "EntityWolfColorFix", References.ENTITY, "minecraft:wolf");
    }
    
    public Dynamic<?> fixTag(final Dynamic<?> dynamic) {
        return (Dynamic<?>)dynamic.update("CollarColor", dynamic -> dynamic.createByte((byte)(15 - dynamic.asInt(0))));
    }
    
    @Override
    protected Typed<?> fix(final Typed<?> typed) {
        return (Typed<?>)typed.update(DSL.remainderFinder(), (Function)this::fixTag);
    }
}
