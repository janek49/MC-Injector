package net.minecraft.util.datafix.fixes;

import com.mojang.datafixers.schemas.*;
import org.apache.commons.lang3.*;
import com.mojang.datafixers.*;
import com.mojang.datafixers.types.*;
import java.util.*;
import javax.annotation.*;
import com.google.common.collect.*;

public class StatsCounterFix extends DataFix
{
    private static final Set<String> SKIP;
    private static final Map<String, String> CUSTOM_MAP;
    private static final Map<String, String> ITEM_KEYS;
    private static final Map<String, String> ENTITY_KEYS;
    private static final Map<String, String> ENTITIES;
    
    public StatsCounterFix(final Schema schema, final boolean var2) {
        super(schema, var2);
    }
    
    public TypeRewriteRule makeRule() {
        final Type<?> var3 = (Type<?>)this.getOutputSchema().getType(References.STATS);
        final Dynamic<?> var4;
        final Map<Dynamic<?>, Dynamic<?>> var5;
        final Optional<? extends Map<? extends Dynamic<?>, ? extends Dynamic<?>>> var6;
        final Iterator<Map.Entry<? extends Dynamic<?>, ? extends Dynamic<?>>> iterator;
        Map.Entry<? extends Dynamic<?>, ? extends Dynamic<?>> var7;
        String var8;
        String var9;
        String var10;
        int var11;
        String var12;
        String var13;
        String var14;
        String var15;
        Dynamic<?> var16;
        Dynamic<?> var17;
        final Type type2;
        return this.fixTypeEverywhereTyped("StatsCounterFix", this.getInputSchema().getType(References.STATS), (Type)var3, var2 -> {
            var4 = (Dynamic<?>)var2.get(DSL.remainderFinder());
            var5 = (Map<Dynamic<?>, Dynamic<?>>)Maps.newHashMap();
            var6 = (Optional<? extends Map<? extends Dynamic<?>, ? extends Dynamic<?>>>)var4.getMapValues();
            if (var6.isPresent()) {
                ((Map)var6.get()).entrySet().iterator();
                while (iterator.hasNext()) {
                    var7 = iterator.next();
                    if (((Dynamic)var7.getValue()).asNumber().isPresent()) {
                        var8 = ((Dynamic)var7.getKey()).asString("");
                        if (StatsCounterFix.SKIP.contains(var8)) {
                            continue;
                        }
                        else {
                            if (StatsCounterFix.CUSTOM_MAP.containsKey(var8)) {
                                var9 = "minecraft:custom";
                                var10 = StatsCounterFix.CUSTOM_MAP.get(var8);
                            }
                            else {
                                var11 = StringUtils.ordinalIndexOf((CharSequence)var8, (CharSequence)".", 2);
                                if (var11 < 0) {
                                    continue;
                                }
                                else {
                                    var12 = var8.substring(0, var11);
                                    if ("stat.mineBlock".equals(var12)) {
                                        var9 = "minecraft:mined";
                                        var10 = this.upgradeBlock(var8.substring(var11 + 1).replace('.', ':'));
                                    }
                                    else if (StatsCounterFix.ITEM_KEYS.containsKey(var12)) {
                                        var9 = StatsCounterFix.ITEM_KEYS.get(var12);
                                        var13 = var8.substring(var11 + 1).replace('.', ':');
                                        var14 = this.upgradeItem(var13);
                                        var10 = ((var14 == null) ? var13 : var14);
                                    }
                                    else if (StatsCounterFix.ENTITY_KEYS.containsKey(var12)) {
                                        var9 = StatsCounterFix.ENTITY_KEYS.get(var12);
                                        var15 = var8.substring(var11 + 1).replace('.', ':');
                                        var10 = StatsCounterFix.ENTITIES.getOrDefault(var15, var15);
                                    }
                                    else {
                                        continue;
                                    }
                                }
                            }
                            var16 = (Dynamic<?>)var4.createString(var9);
                            var17 = var5.computeIfAbsent(var16, var1 -> var4.emptyMap());
                            var5.put(var16, (Dynamic<?>)var17.set(var10, (Dynamic)var7.getValue()));
                        }
                    }
                }
            }
            return (Typed)((Optional)type2.readTyped(var4.emptyMap().set("stats", var4.createMap((Map)var5))).getSecond()).orElseThrow(() -> new IllegalStateException("Could not parse new stats object."));
        });
    }
    
    @Nullable
    protected String upgradeItem(final String string) {
        return ItemStackTheFlatteningFix.updateItem(string, 0);
    }
    
    protected String upgradeBlock(final String string) {
        return BlockStateData.upgradeBlock(string);
    }
    
    static {
        SKIP = (Set)ImmutableSet.builder().add((Object)"stat.craftItem.minecraft.spawn_egg").add((Object)"stat.useItem.minecraft.spawn_egg").add((Object)"stat.breakItem.minecraft.spawn_egg").add((Object)"stat.pickup.minecraft.spawn_egg").add((Object)"stat.drop.minecraft.spawn_egg").build();
        CUSTOM_MAP = (Map)ImmutableMap.builder().put((Object)"stat.leaveGame", (Object)"minecraft:leave_game").put((Object)"stat.playOneMinute", (Object)"minecraft:play_one_minute").put((Object)"stat.timeSinceDeath", (Object)"minecraft:time_since_death").put((Object)"stat.sneakTime", (Object)"minecraft:sneak_time").put((Object)"stat.walkOneCm", (Object)"minecraft:walk_one_cm").put((Object)"stat.crouchOneCm", (Object)"minecraft:crouch_one_cm").put((Object)"stat.sprintOneCm", (Object)"minecraft:sprint_one_cm").put((Object)"stat.swimOneCm", (Object)"minecraft:swim_one_cm").put((Object)"stat.fallOneCm", (Object)"minecraft:fall_one_cm").put((Object)"stat.climbOneCm", (Object)"minecraft:climb_one_cm").put((Object)"stat.flyOneCm", (Object)"minecraft:fly_one_cm").put((Object)"stat.diveOneCm", (Object)"minecraft:dive_one_cm").put((Object)"stat.minecartOneCm", (Object)"minecraft:minecart_one_cm").put((Object)"stat.boatOneCm", (Object)"minecraft:boat_one_cm").put((Object)"stat.pigOneCm", (Object)"minecraft:pig_one_cm").put((Object)"stat.horseOneCm", (Object)"minecraft:horse_one_cm").put((Object)"stat.aviateOneCm", (Object)"minecraft:aviate_one_cm").put((Object)"stat.jump", (Object)"minecraft:jump").put((Object)"stat.drop", (Object)"minecraft:drop").put((Object)"stat.damageDealt", (Object)"minecraft:damage_dealt").put((Object)"stat.damageTaken", (Object)"minecraft:damage_taken").put((Object)"stat.deaths", (Object)"minecraft:deaths").put((Object)"stat.mobKills", (Object)"minecraft:mob_kills").put((Object)"stat.animalsBred", (Object)"minecraft:animals_bred").put((Object)"stat.playerKills", (Object)"minecraft:player_kills").put((Object)"stat.fishCaught", (Object)"minecraft:fish_caught").put((Object)"stat.talkedToVillager", (Object)"minecraft:talked_to_villager").put((Object)"stat.tradedWithVillager", (Object)"minecraft:traded_with_villager").put((Object)"stat.cakeSlicesEaten", (Object)"minecraft:eat_cake_slice").put((Object)"stat.cauldronFilled", (Object)"minecraft:fill_cauldron").put((Object)"stat.cauldronUsed", (Object)"minecraft:use_cauldron").put((Object)"stat.armorCleaned", (Object)"minecraft:clean_armor").put((Object)"stat.bannerCleaned", (Object)"minecraft:clean_banner").put((Object)"stat.brewingstandInteraction", (Object)"minecraft:interact_with_brewingstand").put((Object)"stat.beaconInteraction", (Object)"minecraft:interact_with_beacon").put((Object)"stat.dropperInspected", (Object)"minecraft:inspect_dropper").put((Object)"stat.hopperInspected", (Object)"minecraft:inspect_hopper").put((Object)"stat.dispenserInspected", (Object)"minecraft:inspect_dispenser").put((Object)"stat.noteblockPlayed", (Object)"minecraft:play_noteblock").put((Object)"stat.noteblockTuned", (Object)"minecraft:tune_noteblock").put((Object)"stat.flowerPotted", (Object)"minecraft:pot_flower").put((Object)"stat.trappedChestTriggered", (Object)"minecraft:trigger_trapped_chest").put((Object)"stat.enderchestOpened", (Object)"minecraft:open_enderchest").put((Object)"stat.itemEnchanted", (Object)"minecraft:enchant_item").put((Object)"stat.recordPlayed", (Object)"minecraft:play_record").put((Object)"stat.furnaceInteraction", (Object)"minecraft:interact_with_furnace").put((Object)"stat.craftingTableInteraction", (Object)"minecraft:interact_with_crafting_table").put((Object)"stat.chestOpened", (Object)"minecraft:open_chest").put((Object)"stat.sleepInBed", (Object)"minecraft:sleep_in_bed").put((Object)"stat.shulkerBoxOpened", (Object)"minecraft:open_shulker_box").build();
        ITEM_KEYS = (Map)ImmutableMap.builder().put((Object)"stat.craftItem", (Object)"minecraft:crafted").put((Object)"stat.useItem", (Object)"minecraft:used").put((Object)"stat.breakItem", (Object)"minecraft:broken").put((Object)"stat.pickup", (Object)"minecraft:picked_up").put((Object)"stat.drop", (Object)"minecraft:dropped").build();
        ENTITY_KEYS = (Map)ImmutableMap.builder().put((Object)"stat.entityKilledBy", (Object)"minecraft:killed_by").put((Object)"stat.killEntity", (Object)"minecraft:killed").build();
        ENTITIES = (Map)ImmutableMap.builder().put((Object)"Bat", (Object)"minecraft:bat").put((Object)"Blaze", (Object)"minecraft:blaze").put((Object)"CaveSpider", (Object)"minecraft:cave_spider").put((Object)"Chicken", (Object)"minecraft:chicken").put((Object)"Cow", (Object)"minecraft:cow").put((Object)"Creeper", (Object)"minecraft:creeper").put((Object)"Donkey", (Object)"minecraft:donkey").put((Object)"ElderGuardian", (Object)"minecraft:elder_guardian").put((Object)"Enderman", (Object)"minecraft:enderman").put((Object)"Endermite", (Object)"minecraft:endermite").put((Object)"EvocationIllager", (Object)"minecraft:evocation_illager").put((Object)"Ghast", (Object)"minecraft:ghast").put((Object)"Guardian", (Object)"minecraft:guardian").put((Object)"Horse", (Object)"minecraft:horse").put((Object)"Husk", (Object)"minecraft:husk").put((Object)"Llama", (Object)"minecraft:llama").put((Object)"LavaSlime", (Object)"minecraft:magma_cube").put((Object)"MushroomCow", (Object)"minecraft:mooshroom").put((Object)"Mule", (Object)"minecraft:mule").put((Object)"Ozelot", (Object)"minecraft:ocelot").put((Object)"Parrot", (Object)"minecraft:parrot").put((Object)"Pig", (Object)"minecraft:pig").put((Object)"PolarBear", (Object)"minecraft:polar_bear").put((Object)"Rabbit", (Object)"minecraft:rabbit").put((Object)"Sheep", (Object)"minecraft:sheep").put((Object)"Shulker", (Object)"minecraft:shulker").put((Object)"Silverfish", (Object)"minecraft:silverfish").put((Object)"SkeletonHorse", (Object)"minecraft:skeleton_horse").put((Object)"Skeleton", (Object)"minecraft:skeleton").put((Object)"Slime", (Object)"minecraft:slime").put((Object)"Spider", (Object)"minecraft:spider").put((Object)"Squid", (Object)"minecraft:squid").put((Object)"Stray", (Object)"minecraft:stray").put((Object)"Vex", (Object)"minecraft:vex").put((Object)"Villager", (Object)"minecraft:villager").put((Object)"VindicationIllager", (Object)"minecraft:vindication_illager").put((Object)"Witch", (Object)"minecraft:witch").put((Object)"WitherSkeleton", (Object)"minecraft:wither_skeleton").put((Object)"Wolf", (Object)"minecraft:wolf").put((Object)"ZombieHorse", (Object)"minecraft:zombie_horse").put((Object)"PigZombie", (Object)"minecraft:zombie_pigman").put((Object)"ZombieVillager", (Object)"minecraft:zombie_villager").put((Object)"Zombie", (Object)"minecraft:zombie").build();
    }
}
