package net.minecraft.util.datafix.fixes;

import com.mojang.datafixers.schemas.*;
import com.mojang.datafixers.types.*;
import it.unimi.dsi.fastutil.objects.*;
import org.apache.logging.log4j.*;
import com.mojang.datafixers.*;
import com.google.common.collect.*;
import java.nio.*;
import java.util.function.*;
import net.minecraft.util.*;
import java.util.*;
import it.unimi.dsi.fastutil.ints.*;
import javax.annotation.*;
import java.util.stream.*;

public class ChunkPalettedStorageFix extends DataFix
{
    private static final Logger LOGGER;
    private static final BitSet VIRTUAL;
    private static final BitSet FIX;
    private static final Dynamic<?> PUMPKIN;
    private static final Dynamic<?> SNOWY_PODZOL;
    private static final Dynamic<?> SNOWY_GRASS;
    private static final Dynamic<?> SNOWY_MYCELIUM;
    private static final Dynamic<?> UPPER_SUNFLOWER;
    private static final Dynamic<?> UPPER_LILAC;
    private static final Dynamic<?> UPPER_TALL_GRASS;
    private static final Dynamic<?> UPPER_LARGE_FERN;
    private static final Dynamic<?> UPPER_ROSE_BUSH;
    private static final Dynamic<?> UPPER_PEONY;
    private static final Map<String, Dynamic<?>> FLOWER_POT_MAP;
    private static final Map<String, Dynamic<?>> SKULL_MAP;
    private static final Map<String, Dynamic<?>> DOOR_MAP;
    private static final Map<String, Dynamic<?>> NOTE_BLOCK_MAP;
    private static final Int2ObjectMap<String> DYE_COLOR_MAP;
    private static final Map<String, Dynamic<?>> BED_BLOCK_MAP;
    private static final Map<String, Dynamic<?>> BANNER_BLOCK_MAP;
    private static final Dynamic<?> AIR;
    
    public ChunkPalettedStorageFix(final Schema schema, final boolean var2) {
        super(schema, var2);
    }
    
    private static void mapSkull(final Map<String, Dynamic<?>> map, final int var1, final String var2, final String var3) {
        map.put(var1 + "north", BlockStateData.parse("{Name:'minecraft:" + var2 + "_wall_" + var3 + "',Properties:{facing:'north'}}"));
        map.put(var1 + "east", BlockStateData.parse("{Name:'minecraft:" + var2 + "_wall_" + var3 + "',Properties:{facing:'east'}}"));
        map.put(var1 + "south", BlockStateData.parse("{Name:'minecraft:" + var2 + "_wall_" + var3 + "',Properties:{facing:'south'}}"));
        map.put(var1 + "west", BlockStateData.parse("{Name:'minecraft:" + var2 + "_wall_" + var3 + "',Properties:{facing:'west'}}"));
        for (int var4 = 0; var4 < 16; ++var4) {
            map.put(var1 + "" + var4, BlockStateData.parse("{Name:'minecraft:" + var2 + "_" + var3 + "',Properties:{rotation:'" + var4 + "'}}"));
        }
    }
    
    private static void mapDoor(final Map<String, Dynamic<?>> map, final String string, final int var2) {
        map.put("minecraft:" + string + "eastlowerleftfalsefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "eastlowerleftfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "eastlowerlefttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "eastlowerlefttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "eastlowerrightfalsefalse", BlockStateData.getTag(var2));
        map.put("minecraft:" + string + "eastlowerrightfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "eastlowerrighttruefalse", BlockStateData.getTag(var2 + 4));
        map.put("minecraft:" + string + "eastlowerrighttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "eastupperleftfalsefalse", BlockStateData.getTag(var2 + 8));
        map.put("minecraft:" + string + "eastupperleftfalsetrue", BlockStateData.getTag(var2 + 10));
        map.put("minecraft:" + string + "eastupperlefttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'upper',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "eastupperlefttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'upper',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "eastupperrightfalsefalse", BlockStateData.getTag(var2 + 9));
        map.put("minecraft:" + string + "eastupperrightfalsetrue", BlockStateData.getTag(var2 + 11));
        map.put("minecraft:" + string + "eastupperrighttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'upper',hinge:'right',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "eastupperrighttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'upper',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "northlowerleftfalsefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "northlowerleftfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "northlowerlefttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "northlowerlefttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "northlowerrightfalsefalse", BlockStateData.getTag(var2 + 3));
        map.put("minecraft:" + string + "northlowerrightfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "northlowerrighttruefalse", BlockStateData.getTag(var2 + 7));
        map.put("minecraft:" + string + "northlowerrighttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "northupperleftfalsefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "northupperleftfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "northupperlefttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "northupperlefttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "northupperrightfalsefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'right',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "northupperrightfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "northupperrighttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'right',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "northupperrighttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "southlowerleftfalsefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "southlowerleftfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "southlowerlefttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "southlowerlefttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "southlowerrightfalsefalse", BlockStateData.getTag(var2 + 1));
        map.put("minecraft:" + string + "southlowerrightfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "southlowerrighttruefalse", BlockStateData.getTag(var2 + 5));
        map.put("minecraft:" + string + "southlowerrighttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "southupperleftfalsefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "southupperleftfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "southupperlefttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "southupperlefttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "southupperrightfalsefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'right',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "southupperrightfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "southupperrighttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'right',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "southupperrighttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "westlowerleftfalsefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "westlowerleftfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "westlowerlefttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "westlowerlefttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "westlowerrightfalsefalse", BlockStateData.getTag(var2 + 2));
        map.put("minecraft:" + string + "westlowerrightfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "westlowerrighttruefalse", BlockStateData.getTag(var2 + 6));
        map.put("minecraft:" + string + "westlowerrighttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "westupperleftfalsefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "westupperleftfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "westupperlefttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "westupperlefttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "westupperrightfalsefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'right',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "westupperrightfalsetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "westupperrighttruefalse", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'right',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "westupperrighttruetrue", BlockStateData.parse("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'right',open:'true',powered:'true'}}"));
    }
    
    private static void addBeds(final Map<String, Dynamic<?>> map, final int var1, final String string) {
        map.put("southfalsefoot" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'south',occupied:'false',part:'foot'}}"));
        map.put("westfalsefoot" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'west',occupied:'false',part:'foot'}}"));
        map.put("northfalsefoot" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'north',occupied:'false',part:'foot'}}"));
        map.put("eastfalsefoot" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'east',occupied:'false',part:'foot'}}"));
        map.put("southfalsehead" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'south',occupied:'false',part:'head'}}"));
        map.put("westfalsehead" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'west',occupied:'false',part:'head'}}"));
        map.put("northfalsehead" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'north',occupied:'false',part:'head'}}"));
        map.put("eastfalsehead" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'east',occupied:'false',part:'head'}}"));
        map.put("southtruehead" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'south',occupied:'true',part:'head'}}"));
        map.put("westtruehead" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'west',occupied:'true',part:'head'}}"));
        map.put("northtruehead" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'north',occupied:'true',part:'head'}}"));
        map.put("easttruehead" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_bed',Properties:{facing:'east',occupied:'true',part:'head'}}"));
    }
    
    private static void addBanners(final Map<String, Dynamic<?>> map, final int var1, final String string) {
        for (int var2 = 0; var2 < 16; ++var2) {
            map.put("" + var2 + "_" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_banner',Properties:{rotation:'" + var2 + "'}}"));
        }
        map.put("north_" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_wall_banner',Properties:{facing:'north'}}"));
        map.put("south_" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_wall_banner',Properties:{facing:'south'}}"));
        map.put("west_" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_wall_banner',Properties:{facing:'west'}}"));
        map.put("east_" + var1, BlockStateData.parse("{Name:'minecraft:" + string + "_wall_banner',Properties:{facing:'east'}}"));
    }
    
    public static String getName(final Dynamic<?> dynamic) {
        return dynamic.get("Name").asString("");
    }
    
    public static String getProperty(final Dynamic<?> dynamic, final String var1) {
        return dynamic.get("Properties").get(var1).asString("");
    }
    
    public static int idFor(final CrudeIncrementalIntIdentityHashBiMap<Dynamic<?>> crudeIncrementalIntIdentityHashBiMap, final Dynamic<?> dynamic) {
        int var2 = crudeIncrementalIntIdentityHashBiMap.getId(dynamic);
        if (var2 == -1) {
            var2 = crudeIncrementalIntIdentityHashBiMap.add(dynamic);
        }
        return var2;
    }
    
    private Dynamic<?> fix(final Dynamic<?> dynamic) {
        final Optional<? extends Dynamic<?>> var2 = (Optional<? extends Dynamic<?>>)dynamic.get("Level").get();
        if (var2.isPresent() && ((Dynamic)var2.get()).get("Sections").asStreamOpt().isPresent()) {
            return (Dynamic<?>)dynamic.set("Level", (Dynamic)new UpgradeChunk((Dynamic<?>)var2.get()).write());
        }
        return dynamic;
    }
    
    public TypeRewriteRule makeRule() {
        final Type<?> var1 = (Type<?>)this.getInputSchema().getType(References.CHUNK);
        final Type<?> var2 = (Type<?>)this.getOutputSchema().getType(References.CHUNK);
        return this.writeFixAndRead("ChunkPalettedStorageFix", (Type)var1, (Type)var2, (Function)this::fix);
    }
    
    public static int getSideMask(final boolean var0, final boolean var1, final boolean var2, final boolean var3) {
        int var4 = 0;
        if (var2) {
            if (var1) {
                var4 |= 0x2;
            }
            else if (var0) {
                var4 |= 0x80;
            }
            else {
                var4 |= 0x1;
            }
        }
        else if (var3) {
            if (var0) {
                var4 |= 0x20;
            }
            else if (var1) {
                var4 |= 0x8;
            }
            else {
                var4 |= 0x10;
            }
        }
        else if (var1) {
            var4 |= 0x4;
        }
        else if (var0) {
            var4 |= 0x40;
        }
        return var4;
    }
    
    static {
        LOGGER = LogManager.getLogger();
        VIRTUAL = new BitSet(256);
        FIX = new BitSet(256);
        PUMPKIN = BlockStateData.parse("{Name:'minecraft:pumpkin'}");
        SNOWY_PODZOL = BlockStateData.parse("{Name:'minecraft:podzol',Properties:{snowy:'true'}}");
        SNOWY_GRASS = BlockStateData.parse("{Name:'minecraft:grass_block',Properties:{snowy:'true'}}");
        SNOWY_MYCELIUM = BlockStateData.parse("{Name:'minecraft:mycelium',Properties:{snowy:'true'}}");
        UPPER_SUNFLOWER = BlockStateData.parse("{Name:'minecraft:sunflower',Properties:{half:'upper'}}");
        UPPER_LILAC = BlockStateData.parse("{Name:'minecraft:lilac',Properties:{half:'upper'}}");
        UPPER_TALL_GRASS = BlockStateData.parse("{Name:'minecraft:tall_grass',Properties:{half:'upper'}}");
        UPPER_LARGE_FERN = BlockStateData.parse("{Name:'minecraft:large_fern',Properties:{half:'upper'}}");
        UPPER_ROSE_BUSH = BlockStateData.parse("{Name:'minecraft:rose_bush',Properties:{half:'upper'}}");
        UPPER_PEONY = BlockStateData.parse("{Name:'minecraft:peony',Properties:{half:'upper'}}");
        FLOWER_POT_MAP = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
            hashMap.put("minecraft:air0", BlockStateData.parse("{Name:'minecraft:flower_pot'}"));
            hashMap.put("minecraft:red_flower0", BlockStateData.parse("{Name:'minecraft:potted_poppy'}"));
            hashMap.put("minecraft:red_flower1", BlockStateData.parse("{Name:'minecraft:potted_blue_orchid'}"));
            hashMap.put("minecraft:red_flower2", BlockStateData.parse("{Name:'minecraft:potted_allium'}"));
            hashMap.put("minecraft:red_flower3", BlockStateData.parse("{Name:'minecraft:potted_azure_bluet'}"));
            hashMap.put("minecraft:red_flower4", BlockStateData.parse("{Name:'minecraft:potted_red_tulip'}"));
            hashMap.put("minecraft:red_flower5", BlockStateData.parse("{Name:'minecraft:potted_orange_tulip'}"));
            hashMap.put("minecraft:red_flower6", BlockStateData.parse("{Name:'minecraft:potted_white_tulip'}"));
            hashMap.put("minecraft:red_flower7", BlockStateData.parse("{Name:'minecraft:potted_pink_tulip'}"));
            hashMap.put("minecraft:red_flower8", BlockStateData.parse("{Name:'minecraft:potted_oxeye_daisy'}"));
            hashMap.put("minecraft:yellow_flower0", BlockStateData.parse("{Name:'minecraft:potted_dandelion'}"));
            hashMap.put("minecraft:sapling0", BlockStateData.parse("{Name:'minecraft:potted_oak_sapling'}"));
            hashMap.put("minecraft:sapling1", BlockStateData.parse("{Name:'minecraft:potted_spruce_sapling'}"));
            hashMap.put("minecraft:sapling2", BlockStateData.parse("{Name:'minecraft:potted_birch_sapling'}"));
            hashMap.put("minecraft:sapling3", BlockStateData.parse("{Name:'minecraft:potted_jungle_sapling'}"));
            hashMap.put("minecraft:sapling4", BlockStateData.parse("{Name:'minecraft:potted_acacia_sapling'}"));
            hashMap.put("minecraft:sapling5", BlockStateData.parse("{Name:'minecraft:potted_dark_oak_sapling'}"));
            hashMap.put("minecraft:red_mushroom0", BlockStateData.parse("{Name:'minecraft:potted_red_mushroom'}"));
            hashMap.put("minecraft:brown_mushroom0", BlockStateData.parse("{Name:'minecraft:potted_brown_mushroom'}"));
            hashMap.put("minecraft:deadbush0", BlockStateData.parse("{Name:'minecraft:potted_dead_bush'}"));
            hashMap.put("minecraft:tallgrass2", BlockStateData.parse("{Name:'minecraft:potted_fern'}"));
            hashMap.put("minecraft:cactus0", BlockStateData.getTag(2240));
            return;
        });
        SKULL_MAP = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
            mapSkull(hashMap, 0, "skeleton", "skull");
            mapSkull(hashMap, 1, "wither_skeleton", "skull");
            mapSkull(hashMap, 2, "zombie", "head");
            mapSkull(hashMap, 3, "player", "head");
            mapSkull(hashMap, 4, "creeper", "head");
            mapSkull(hashMap, 5, "dragon", "head");
            return;
        });
        DOOR_MAP = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
            mapDoor(hashMap, "oak_door", 1024);
            mapDoor(hashMap, "iron_door", 1136);
            mapDoor(hashMap, "spruce_door", 3088);
            mapDoor(hashMap, "birch_door", 3104);
            mapDoor(hashMap, "jungle_door", 3120);
            mapDoor(hashMap, "acacia_door", 3136);
            mapDoor(hashMap, "dark_oak_door", 3152);
            return;
        });
        int var1;
        NOTE_BLOCK_MAP = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
            for (var1 = 0; var1 < 26; ++var1) {
                hashMap.put("true" + var1, BlockStateData.parse("{Name:'minecraft:note_block',Properties:{powered:'true',note:'" + var1 + "'}}"));
                hashMap.put("false" + var1, BlockStateData.parse("{Name:'minecraft:note_block',Properties:{powered:'false',note:'" + var1 + "'}}"));
            }
            return;
        });
        DYE_COLOR_MAP = (Int2ObjectMap)DataFixUtils.make((Object)new Int2ObjectOpenHashMap(), int2ObjectOpenHashMap -> {
            int2ObjectOpenHashMap.put(0, (Object)"white");
            int2ObjectOpenHashMap.put(1, (Object)"orange");
            int2ObjectOpenHashMap.put(2, (Object)"magenta");
            int2ObjectOpenHashMap.put(3, (Object)"light_blue");
            int2ObjectOpenHashMap.put(4, (Object)"yellow");
            int2ObjectOpenHashMap.put(5, (Object)"lime");
            int2ObjectOpenHashMap.put(6, (Object)"pink");
            int2ObjectOpenHashMap.put(7, (Object)"gray");
            int2ObjectOpenHashMap.put(8, (Object)"light_gray");
            int2ObjectOpenHashMap.put(9, (Object)"cyan");
            int2ObjectOpenHashMap.put(10, (Object)"purple");
            int2ObjectOpenHashMap.put(11, (Object)"blue");
            int2ObjectOpenHashMap.put(12, (Object)"brown");
            int2ObjectOpenHashMap.put(13, (Object)"green");
            int2ObjectOpenHashMap.put(14, (Object)"red");
            int2ObjectOpenHashMap.put(15, (Object)"black");
            return;
        });
        final Iterator<Int2ObjectMap.Entry> iterator;
        Int2ObjectMap.Entry var2;
        BED_BLOCK_MAP = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
            ChunkPalettedStorageFix.DYE_COLOR_MAP.int2ObjectEntrySet().iterator();
            while (iterator.hasNext()) {
                var2 = iterator.next();
                if (!Objects.equals(var2.getValue(), "red")) {
                    addBeds(hashMap, var2.getIntKey(), (String)var2.getValue());
                }
            }
            return;
        });
        final Iterator<Int2ObjectMap.Entry> iterator2;
        Int2ObjectMap.Entry var3;
        BANNER_BLOCK_MAP = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
            ChunkPalettedStorageFix.DYE_COLOR_MAP.int2ObjectEntrySet().iterator();
            while (iterator2.hasNext()) {
                var3 = iterator2.next();
                if (!Objects.equals(var3.getValue(), "white")) {
                    addBanners(hashMap, 15 - var3.getIntKey(), (String)var3.getValue());
                }
            }
            return;
        });
        ChunkPalettedStorageFix.FIX.set(2);
        ChunkPalettedStorageFix.FIX.set(3);
        ChunkPalettedStorageFix.FIX.set(110);
        ChunkPalettedStorageFix.FIX.set(140);
        ChunkPalettedStorageFix.FIX.set(144);
        ChunkPalettedStorageFix.FIX.set(25);
        ChunkPalettedStorageFix.FIX.set(86);
        ChunkPalettedStorageFix.FIX.set(26);
        ChunkPalettedStorageFix.FIX.set(176);
        ChunkPalettedStorageFix.FIX.set(177);
        ChunkPalettedStorageFix.FIX.set(175);
        ChunkPalettedStorageFix.FIX.set(64);
        ChunkPalettedStorageFix.FIX.set(71);
        ChunkPalettedStorageFix.FIX.set(193);
        ChunkPalettedStorageFix.FIX.set(194);
        ChunkPalettedStorageFix.FIX.set(195);
        ChunkPalettedStorageFix.FIX.set(196);
        ChunkPalettedStorageFix.FIX.set(197);
        ChunkPalettedStorageFix.VIRTUAL.set(54);
        ChunkPalettedStorageFix.VIRTUAL.set(146);
        ChunkPalettedStorageFix.VIRTUAL.set(25);
        ChunkPalettedStorageFix.VIRTUAL.set(26);
        ChunkPalettedStorageFix.VIRTUAL.set(51);
        ChunkPalettedStorageFix.VIRTUAL.set(53);
        ChunkPalettedStorageFix.VIRTUAL.set(67);
        ChunkPalettedStorageFix.VIRTUAL.set(108);
        ChunkPalettedStorageFix.VIRTUAL.set(109);
        ChunkPalettedStorageFix.VIRTUAL.set(114);
        ChunkPalettedStorageFix.VIRTUAL.set(128);
        ChunkPalettedStorageFix.VIRTUAL.set(134);
        ChunkPalettedStorageFix.VIRTUAL.set(135);
        ChunkPalettedStorageFix.VIRTUAL.set(136);
        ChunkPalettedStorageFix.VIRTUAL.set(156);
        ChunkPalettedStorageFix.VIRTUAL.set(163);
        ChunkPalettedStorageFix.VIRTUAL.set(164);
        ChunkPalettedStorageFix.VIRTUAL.set(180);
        ChunkPalettedStorageFix.VIRTUAL.set(203);
        ChunkPalettedStorageFix.VIRTUAL.set(55);
        ChunkPalettedStorageFix.VIRTUAL.set(85);
        ChunkPalettedStorageFix.VIRTUAL.set(113);
        ChunkPalettedStorageFix.VIRTUAL.set(188);
        ChunkPalettedStorageFix.VIRTUAL.set(189);
        ChunkPalettedStorageFix.VIRTUAL.set(190);
        ChunkPalettedStorageFix.VIRTUAL.set(191);
        ChunkPalettedStorageFix.VIRTUAL.set(192);
        ChunkPalettedStorageFix.VIRTUAL.set(93);
        ChunkPalettedStorageFix.VIRTUAL.set(94);
        ChunkPalettedStorageFix.VIRTUAL.set(101);
        ChunkPalettedStorageFix.VIRTUAL.set(102);
        ChunkPalettedStorageFix.VIRTUAL.set(160);
        ChunkPalettedStorageFix.VIRTUAL.set(106);
        ChunkPalettedStorageFix.VIRTUAL.set(107);
        ChunkPalettedStorageFix.VIRTUAL.set(183);
        ChunkPalettedStorageFix.VIRTUAL.set(184);
        ChunkPalettedStorageFix.VIRTUAL.set(185);
        ChunkPalettedStorageFix.VIRTUAL.set(186);
        ChunkPalettedStorageFix.VIRTUAL.set(187);
        ChunkPalettedStorageFix.VIRTUAL.set(132);
        ChunkPalettedStorageFix.VIRTUAL.set(139);
        ChunkPalettedStorageFix.VIRTUAL.set(199);
        AIR = BlockStateData.getTag(0);
    }
    
    static class Section
    {
        private final CrudeIncrementalIntIdentityHashBiMap<Dynamic<?>> palette;
        private Dynamic<?> listTag;
        private final Dynamic<?> section;
        private final boolean hasData;
        private final Int2ObjectMap<IntList> toFix;
        private final IntList update;
        public final int y;
        private final Set<Dynamic<?>> seen;
        private final int[] buffer;
        
        public Section(final Dynamic<?> section) {
            this.palette = new CrudeIncrementalIntIdentityHashBiMap<Dynamic<?>>(32);
            this.toFix = (Int2ObjectMap<IntList>)new Int2ObjectLinkedOpenHashMap();
            this.update = (IntList)new IntArrayList();
            this.seen = (Set<Dynamic<?>>)Sets.newIdentityHashSet();
            this.buffer = new int[4096];
            this.listTag = (Dynamic<?>)section.emptyList();
            this.section = section;
            this.y = section.get("Y").asInt(0);
            this.hasData = section.get("Blocks").get().isPresent();
        }
        
        public Dynamic<?> getBlock(final int i) {
            if (i < 0 || i > 4095) {
                return ChunkPalettedStorageFix.AIR;
            }
            final Dynamic<?> dynamic = this.palette.byId(this.buffer[i]);
            return (dynamic == null) ? ChunkPalettedStorageFix.AIR : dynamic;
        }
        
        public void setBlock(final int var1, final Dynamic<?> dynamic) {
            if (this.seen.add(dynamic)) {
                this.listTag = (Dynamic<?>)this.listTag.merge("%%FILTER_ME%%".equals(ChunkPalettedStorageFix.getName(dynamic)) ? ChunkPalettedStorageFix.AIR : dynamic);
            }
            this.buffer[var1] = ChunkPalettedStorageFix.idFor(this.palette, dynamic);
        }
        
        public int upgrade(int i) {
            if (!this.hasData) {
                return i;
            }
            final ByteBuffer var2 = this.section.get("Blocks").asByteBufferOpt().get();
            final DataLayer var3 = this.section.get("Data").asByteBufferOpt().map(byteBuffer -> new DataLayer(DataFixUtils.toArray(byteBuffer))).orElseGet(DataLayer::new);
            final DataLayer var4 = this.section.get("Add").asByteBufferOpt().map(byteBuffer -> new DataLayer(DataFixUtils.toArray(byteBuffer))).orElseGet(DataLayer::new);
            this.seen.add(ChunkPalettedStorageFix.AIR);
            ChunkPalettedStorageFix.idFor(this.palette, ChunkPalettedStorageFix.AIR);
            this.listTag = (Dynamic<?>)this.listTag.merge(ChunkPalettedStorageFix.AIR);
            for (int var5 = 0; var5 < 4096; ++var5) {
                final int var6 = var5 & 0xF;
                final int var7 = var5 >> 8 & 0xF;
                final int var8 = var5 >> 4 & 0xF;
                final int var9 = var4.get(var6, var7, var8) << 12 | (var2.get(var5) & 0xFF) << 4 | var3.get(var6, var7, var8);
                if (ChunkPalettedStorageFix.FIX.get(var9 >> 4)) {
                    this.addFix(var9 >> 4, var5);
                }
                if (ChunkPalettedStorageFix.VIRTUAL.get(var9 >> 4)) {
                    final int var10 = ChunkPalettedStorageFix.getSideMask(var6 == 0, var6 == 15, var8 == 0, var8 == 15);
                    if (var10 == 0) {
                        this.update.add(var5);
                    }
                    else {
                        i |= var10;
                    }
                }
                this.setBlock(var5, BlockStateData.getTag(var9));
            }
            return i;
        }
        
        private void addFix(final int var1, final int var2) {
            IntList var3 = (IntList)this.toFix.get(var1);
            if (var3 == null) {
                var3 = (IntList)new IntArrayList();
                this.toFix.put(var1, (Object)var3);
            }
            var3.add(var2);
        }
        
        public Dynamic<?> write() {
            Dynamic<?> dynamic = this.section;
            if (!this.hasData) {
                return dynamic;
            }
            dynamic = (Dynamic<?>)dynamic.set("Palette", (Dynamic)this.listTag);
            final int var2 = Math.max(4, DataFixUtils.ceillog2(this.seen.size()));
            final BitStorage var3 = new BitStorage(var2, 4096);
            for (int var4 = 0; var4 < this.buffer.length; ++var4) {
                var3.set(var4, this.buffer[var4]);
            }
            dynamic = (Dynamic<?>)dynamic.set("BlockStates", dynamic.createLongList(Arrays.stream(var3.getRaw())));
            dynamic = (Dynamic<?>)dynamic.remove("Blocks");
            dynamic = (Dynamic<?>)dynamic.remove("Data");
            dynamic = (Dynamic<?>)dynamic.remove("Add");
            return dynamic;
        }
    }
    
    static final class UpgradeChunk
    {
        private int sides;
        private final Section[] sections;
        private final Dynamic<?> level;
        private final int x;
        private final int z;
        private final Int2ObjectMap<Dynamic<?>> blockEntities;
        
        public UpgradeChunk(final Dynamic<?> level) {
            this.sections = new Section[16];
            this.blockEntities = (Int2ObjectMap<Dynamic<?>>)new Int2ObjectLinkedOpenHashMap(16);
            this.level = level;
            this.x = level.get("xPos").asInt(0) << 4;
            this.z = level.get("zPos").asInt(0) << 4;
            final int var2;
            final int var3;
            final int var4;
            final int var5;
            level.get("TileEntities").asStreamOpt().ifPresent(stream -> stream.forEach(dynamic -> {
                var2 = (dynamic.get("x").asInt(0) - this.x & 0xF);
                var3 = dynamic.get("y").asInt(0);
                var4 = (dynamic.get("z").asInt(0) - this.z & 0xF);
                var5 = (var3 << 8 | var4 << 4 | var2);
                if (this.blockEntities.put(var5, (Object)dynamic) != null) {
                    ChunkPalettedStorageFix.LOGGER.warn("In chunk: {}x{} found a duplicate block entity at position: [{}, {}, {}]", (Object)this.x, (Object)this.z, (Object)var2, (Object)var3, (Object)var4);
                }
            }));
            final boolean var6 = level.get("convertedFromAlphaFormat").asBoolean(false);
            final Section var7;
            level.get("Sections").asStreamOpt().ifPresent(stream -> stream.forEach(dynamic -> {
                var7 = new Section(dynamic);
                this.sides = var7.upgrade(this.sides);
                this.sections[var7.y] = var7;
            }));
            for (final Section var8 : this.sections) {
                if (var8 != null) {
                    for (final Map.Entry<Integer, IntList> var9 : var8.toFix.entrySet()) {
                        final int var10 = var8.y << 12;
                        switch (var9.getKey()) {
                            case 2: {
                                for (int var11 : var9.getValue()) {
                                    var11 |= var10;
                                    final Dynamic<?> var12 = this.getBlock(var11);
                                    if ("minecraft:grass_block".equals(ChunkPalettedStorageFix.getName(var12))) {
                                        final String var13 = ChunkPalettedStorageFix.getName(this.getBlock(relative(var11, Direction.UP)));
                                        if (!"minecraft:snow".equals(var13) && !"minecraft:snow_layer".equals(var13)) {
                                            continue;
                                        }
                                        this.setBlock(var11, ChunkPalettedStorageFix.SNOWY_GRASS);
                                    }
                                }
                                continue;
                            }
                            case 3: {
                                for (int var11 : var9.getValue()) {
                                    var11 |= var10;
                                    final Dynamic<?> var12 = this.getBlock(var11);
                                    if ("minecraft:podzol".equals(ChunkPalettedStorageFix.getName(var12))) {
                                        final String var13 = ChunkPalettedStorageFix.getName(this.getBlock(relative(var11, Direction.UP)));
                                        if (!"minecraft:snow".equals(var13) && !"minecraft:snow_layer".equals(var13)) {
                                            continue;
                                        }
                                        this.setBlock(var11, ChunkPalettedStorageFix.SNOWY_PODZOL);
                                    }
                                }
                                continue;
                            }
                            case 110: {
                                for (int var11 : var9.getValue()) {
                                    var11 |= var10;
                                    final Dynamic<?> var12 = this.getBlock(var11);
                                    if ("minecraft:mycelium".equals(ChunkPalettedStorageFix.getName(var12))) {
                                        final String var13 = ChunkPalettedStorageFix.getName(this.getBlock(relative(var11, Direction.UP)));
                                        if (!"minecraft:snow".equals(var13) && !"minecraft:snow_layer".equals(var13)) {
                                            continue;
                                        }
                                        this.setBlock(var11, ChunkPalettedStorageFix.SNOWY_MYCELIUM);
                                    }
                                }
                                continue;
                            }
                            case 25: {
                                for (int var11 : var9.getValue()) {
                                    var11 |= var10;
                                    final Dynamic<?> var12 = this.removeBlockEntity(var11);
                                    if (var12 != null) {
                                        final String var13 = Boolean.toString(var12.get("powered").asBoolean(false)) + (byte)Math.min(Math.max(var12.get("note").asInt(0), 0), 24);
                                        this.setBlock(var11, (Dynamic<?>)ChunkPalettedStorageFix.NOTE_BLOCK_MAP.getOrDefault(var13, ChunkPalettedStorageFix.NOTE_BLOCK_MAP.get("false0")));
                                    }
                                }
                                continue;
                            }
                            case 26: {
                                for (int var11 : var9.getValue()) {
                                    var11 |= var10;
                                    final Dynamic<?> var12 = this.getBlockEntity(var11);
                                    final Dynamic<?> var14 = this.getBlock(var11);
                                    if (var12 != null) {
                                        final int var15 = var12.get("color").asInt(0);
                                        if (var15 == 14 || var15 < 0 || var15 >= 16) {
                                            continue;
                                        }
                                        final String var16 = ChunkPalettedStorageFix.getProperty(var14, "facing") + ChunkPalettedStorageFix.getProperty(var14, "occupied") + ChunkPalettedStorageFix.getProperty(var14, "part") + var15;
                                        if (!ChunkPalettedStorageFix.BED_BLOCK_MAP.containsKey(var16)) {
                                            continue;
                                        }
                                        this.setBlock(var11, (Dynamic<?>)ChunkPalettedStorageFix.BED_BLOCK_MAP.get(var16));
                                    }
                                }
                                continue;
                            }
                            case 176:
                            case 177: {
                                for (int var11 : var9.getValue()) {
                                    var11 |= var10;
                                    final Dynamic<?> var12 = this.getBlockEntity(var11);
                                    final Dynamic<?> var14 = this.getBlock(var11);
                                    if (var12 != null) {
                                        final int var15 = var12.get("Base").asInt(0);
                                        if (var15 == 15 || var15 < 0 || var15 >= 16) {
                                            continue;
                                        }
                                        final String var16 = ChunkPalettedStorageFix.getProperty(var14, (var9.getKey() == 176) ? "rotation" : "facing") + "_" + var15;
                                        if (!ChunkPalettedStorageFix.BANNER_BLOCK_MAP.containsKey(var16)) {
                                            continue;
                                        }
                                        this.setBlock(var11, (Dynamic<?>)ChunkPalettedStorageFix.BANNER_BLOCK_MAP.get(var16));
                                    }
                                }
                                continue;
                            }
                            case 86: {
                                for (int var11 : var9.getValue()) {
                                    var11 |= var10;
                                    final Dynamic<?> var12 = this.getBlock(var11);
                                    if ("minecraft:carved_pumpkin".equals(ChunkPalettedStorageFix.getName(var12))) {
                                        final String var13 = ChunkPalettedStorageFix.getName(this.getBlock(relative(var11, Direction.DOWN)));
                                        if (!"minecraft:grass_block".equals(var13) && !"minecraft:dirt".equals(var13)) {
                                            continue;
                                        }
                                        this.setBlock(var11, ChunkPalettedStorageFix.PUMPKIN);
                                    }
                                }
                                continue;
                            }
                            case 140: {
                                for (int var11 : var9.getValue()) {
                                    var11 |= var10;
                                    final Dynamic<?> var12 = this.removeBlockEntity(var11);
                                    if (var12 != null) {
                                        final String var13 = var12.get("Item").asString("") + var12.get("Data").asInt(0);
                                        this.setBlock(var11, (Dynamic<?>)ChunkPalettedStorageFix.FLOWER_POT_MAP.getOrDefault(var13, ChunkPalettedStorageFix.FLOWER_POT_MAP.get("minecraft:air0")));
                                    }
                                }
                                continue;
                            }
                            case 144: {
                                for (int var11 : var9.getValue()) {
                                    var11 |= var10;
                                    final Dynamic<?> var12 = this.getBlockEntity(var11);
                                    if (var12 != null) {
                                        final String var13 = String.valueOf(var12.get("SkullType").asInt(0));
                                        final String var17 = ChunkPalettedStorageFix.getProperty(this.getBlock(var11), "facing");
                                        String var16;
                                        if ("up".equals(var17) || "down".equals(var17)) {
                                            var16 = var13 + String.valueOf(var12.get("Rot").asInt(0));
                                        }
                                        else {
                                            var16 = var13 + var17;
                                        }
                                        var12.remove("SkullType");
                                        var12.remove("facing");
                                        var12.remove("Rot");
                                        this.setBlock(var11, (Dynamic<?>)ChunkPalettedStorageFix.SKULL_MAP.getOrDefault(var16, ChunkPalettedStorageFix.SKULL_MAP.get("0north")));
                                    }
                                }
                                continue;
                            }
                            case 64:
                            case 71:
                            case 193:
                            case 194:
                            case 195:
                            case 196:
                            case 197: {
                                for (int var11 : var9.getValue()) {
                                    var11 |= var10;
                                    final Dynamic<?> var12 = this.getBlock(var11);
                                    if (ChunkPalettedStorageFix.getName(var12).endsWith("_door")) {
                                        final Dynamic<?> var14 = this.getBlock(var11);
                                        if (!"lower".equals(ChunkPalettedStorageFix.getProperty(var14, "half"))) {
                                            continue;
                                        }
                                        final int var15 = relative(var11, Direction.UP);
                                        final Dynamic<?> var18 = this.getBlock(var15);
                                        final String var19 = ChunkPalettedStorageFix.getName(var14);
                                        if (!var19.equals(ChunkPalettedStorageFix.getName(var18))) {
                                            continue;
                                        }
                                        final String var20 = ChunkPalettedStorageFix.getProperty(var14, "facing");
                                        final String var21 = ChunkPalettedStorageFix.getProperty(var14, "open");
                                        final String var22 = var6 ? "left" : ChunkPalettedStorageFix.getProperty(var18, "hinge");
                                        final String var23 = var6 ? "false" : ChunkPalettedStorageFix.getProperty(var18, "powered");
                                        this.setBlock(var11, (Dynamic<?>)ChunkPalettedStorageFix.DOOR_MAP.get(var19 + var20 + "lower" + var22 + var21 + var23));
                                        this.setBlock(var15, (Dynamic<?>)ChunkPalettedStorageFix.DOOR_MAP.get(var19 + var20 + "upper" + var22 + var21 + var23));
                                    }
                                }
                                continue;
                            }
                            case 175: {
                                for (int var11 : var9.getValue()) {
                                    var11 |= var10;
                                    final Dynamic<?> var12 = this.getBlock(var11);
                                    if ("upper".equals(ChunkPalettedStorageFix.getProperty(var12, "half"))) {
                                        final Dynamic<?> var14 = this.getBlock(relative(var11, Direction.DOWN));
                                        final String var17 = ChunkPalettedStorageFix.getName(var14);
                                        if ("minecraft:sunflower".equals(var17)) {
                                            this.setBlock(var11, ChunkPalettedStorageFix.UPPER_SUNFLOWER);
                                        }
                                        else if ("minecraft:lilac".equals(var17)) {
                                            this.setBlock(var11, ChunkPalettedStorageFix.UPPER_LILAC);
                                        }
                                        else if ("minecraft:tall_grass".equals(var17)) {
                                            this.setBlock(var11, ChunkPalettedStorageFix.UPPER_TALL_GRASS);
                                        }
                                        else if ("minecraft:large_fern".equals(var17)) {
                                            this.setBlock(var11, ChunkPalettedStorageFix.UPPER_LARGE_FERN);
                                        }
                                        else if ("minecraft:rose_bush".equals(var17)) {
                                            this.setBlock(var11, ChunkPalettedStorageFix.UPPER_ROSE_BUSH);
                                        }
                                        else {
                                            if (!"minecraft:peony".equals(var17)) {
                                                continue;
                                            }
                                            this.setBlock(var11, ChunkPalettedStorageFix.UPPER_PEONY);
                                        }
                                    }
                                }
                                continue;
                            }
                        }
                    }
                }
            }
        }
        
        @Nullable
        private Dynamic<?> getBlockEntity(final int i) {
            return (Dynamic<?>)this.blockEntities.get(i);
        }
        
        @Nullable
        private Dynamic<?> removeBlockEntity(final int i) {
            return (Dynamic<?>)this.blockEntities.remove(i);
        }
        
        public static int relative(final int var0, final Direction chunkPalettedStorageFix$Direction) {
            switch (chunkPalettedStorageFix$Direction.getAxis()) {
                case X: {
                    final int var = (var0 & 0xF) + chunkPalettedStorageFix$Direction.getAxisDirection().getStep();
                    return (var < 0 || var > 15) ? -1 : ((var0 & 0xFFFFFFF0) | var);
                }
                case Y: {
                    final int var2 = (var0 >> 8) + chunkPalettedStorageFix$Direction.getAxisDirection().getStep();
                    return (var2 < 0 || var2 > 255) ? -1 : ((var0 & 0xFF) | var2 << 8);
                }
                case Z: {
                    final int var3 = (var0 >> 4 & 0xF) + chunkPalettedStorageFix$Direction.getAxisDirection().getStep();
                    return (var3 < 0 || var3 > 15) ? -1 : ((var0 & 0xFFFFFF0F) | var3 << 4);
                }
                default: {
                    return -1;
                }
            }
        }
        
        private void setBlock(final int var1, final Dynamic<?> dynamic) {
            if (var1 < 0 || var1 > 65535) {
                return;
            }
            final Section var2 = this.getSection(var1);
            if (var2 == null) {
                return;
            }
            var2.setBlock(var1 & 0xFFF, dynamic);
        }
        
        @Nullable
        private Section getSection(final int i) {
            final int var2 = i >> 12;
            return (var2 < this.sections.length) ? this.sections[var2] : null;
        }
        
        public Dynamic<?> getBlock(final int i) {
            if (i < 0 || i > 65535) {
                return ChunkPalettedStorageFix.AIR;
            }
            final Section var2 = this.getSection(i);
            if (var2 == null) {
                return ChunkPalettedStorageFix.AIR;
            }
            return var2.getBlock(i & 0xFFF);
        }
        
        public Dynamic<?> write() {
            Dynamic<?> dynamic = this.level;
            if (this.blockEntities.isEmpty()) {
                dynamic = (Dynamic<?>)dynamic.remove("TileEntities");
            }
            else {
                dynamic = (Dynamic<?>)dynamic.set("TileEntities", dynamic.createList(this.blockEntities.values().stream()));
            }
            Dynamic<?> var2 = (Dynamic<?>)dynamic.emptyMap();
            Dynamic<?> var3 = (Dynamic<?>)dynamic.emptyList();
            for (final Section var4 : this.sections) {
                if (var4 != null) {
                    var3 = (Dynamic<?>)var3.merge((Dynamic)var4.write());
                    var2 = (Dynamic<?>)var2.set(String.valueOf(var4.y), var2.createIntList(Arrays.stream(var4.update.toIntArray())));
                }
            }
            Dynamic<?> var5 = (Dynamic<?>)dynamic.emptyMap();
            var5 = (Dynamic<?>)var5.set("Sides", var5.createByte((byte)this.sides));
            var5 = (Dynamic<?>)var5.set("Indices", (Dynamic)var2);
            return (Dynamic<?>)dynamic.set("UpgradeData", (Dynamic)var5).set("Sections", (Dynamic)var3);
        }
    }
    
    static class DataLayer
    {
        private final byte[] data;
        
        public DataLayer() {
            this.data = new byte[2048];
        }
        
        public DataLayer(final byte[] data) {
            this.data = data;
            if (data.length != 2048) {
                throw new IllegalArgumentException("ChunkNibbleArrays should be 2048 bytes not: " + data.length);
            }
        }
        
        public int get(final int var1, final int var2, final int var3) {
            final int var4 = this.getPosition(var2 << 8 | var3 << 4 | var1);
            if (this.isFirst(var2 << 8 | var3 << 4 | var1)) {
                return this.data[var4] & 0xF;
            }
            return this.data[var4] >> 4 & 0xF;
        }
        
        private boolean isFirst(final int i) {
            return (i & 0x1) == 0x0;
        }
        
        private int getPosition(final int i) {
            return i >> 1;
        }
    }
    
    public enum Direction
    {
        DOWN("DOWN", 0, AxisDirection.NEGATIVE, Axis.Y), 
        UP("UP", 1, AxisDirection.POSITIVE, Axis.Y), 
        NORTH("NORTH", 2, AxisDirection.NEGATIVE, Axis.Z), 
        SOUTH("SOUTH", 3, AxisDirection.POSITIVE, Axis.Z), 
        WEST("WEST", 4, AxisDirection.NEGATIVE, Axis.X), 
        EAST("EAST", 5, AxisDirection.POSITIVE, Axis.X);
        
        private final Axis axis;
        private final AxisDirection axisDirection;
        
        private Direction(final String s, final int n, final AxisDirection axisDirection, final Axis axis) {
            this.axis = axis;
            this.axisDirection = axisDirection;
        }
        
        public AxisDirection getAxisDirection() {
            return this.axisDirection;
        }
        
        public Axis getAxis() {
            return this.axis;
        }
        
        public enum Axis
        {
            X("X", 0), 
            Y("Y", 1), 
            Z("Z", 2);
            
            private Axis(final String s, final int n) {
            }
        }
        
        public enum AxisDirection
        {
            POSITIVE("POSITIVE", 0, 1), 
            NEGATIVE("NEGATIVE", 1, -1);
            
            private final int step;
            
            private AxisDirection(final String s, final int n, final int step) {
                this.step = step;
            }
            
            public int getStep() {
                return this.step;
            }
        }
    }
}
