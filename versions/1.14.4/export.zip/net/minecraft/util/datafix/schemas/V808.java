package net.minecraft.util.datafix.schemas;

import com.mojang.datafixers.schemas.*;
import java.util.*;
import java.util.function.*;
import com.mojang.datafixers.types.templates.*;
import net.minecraft.util.datafix.fixes.*;
import com.mojang.datafixers.*;

public class V808 extends NamespacedSchema
{
    public V808(final int var1, final Schema schema) {
        super(var1, schema);
    }
    
    protected static void registerInventory(final Schema schema, final Map<String, Supplier<TypeTemplate>> map, final String string) {
        schema.register((Map)map, string, () -> DSL.optionalFields("Items", DSL.list(References.ITEM_STACK.in(schema))));
    }
    
    public Map<String, Supplier<TypeTemplate>> registerBlockEntities(final Schema schema) {
        final Map<String, Supplier<TypeTemplate>> map = (Map<String, Supplier<TypeTemplate>>)super.registerBlockEntities(schema);
        registerInventory(schema, map, "minecraft:shulker_box");
        return map;
    }
}
