package net.minecraft.util.datafix.schemas;

import com.mojang.datafixers.schemas.*;
import java.util.*;
import java.util.function.*;
import com.mojang.datafixers.types.templates.*;

public class V702 extends Schema
{
    public V702(final int var1, final Schema schema) {
        super(var1, schema);
    }
    
    protected static void registerMob(final Schema schema, final Map<String, Supplier<TypeTemplate>> map, final String string) {
        schema.register((Map)map, string, () -> V100.equipment(schema));
    }
    
    public Map<String, Supplier<TypeTemplate>> registerEntities(final Schema schema) {
        final Map<String, Supplier<TypeTemplate>> map = (Map<String, Supplier<TypeTemplate>>)super.registerEntities(schema);
        registerMob(schema, map, "ZombieVillager");
        registerMob(schema, map, "Husk");
        return map;
    }
}
