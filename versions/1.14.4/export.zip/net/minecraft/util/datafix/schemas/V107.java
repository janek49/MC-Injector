package net.minecraft.util.datafix.schemas;

import com.mojang.datafixers.schemas.*;
import java.util.*;
import java.util.function.*;
import com.mojang.datafixers.types.templates.*;

public class V107 extends Schema
{
    public V107(final int var1, final Schema schema) {
        super(var1, schema);
    }
    
    public Map<String, Supplier<TypeTemplate>> registerEntities(final Schema schema) {
        final Map<String, Supplier<TypeTemplate>> map = (Map<String, Supplier<TypeTemplate>>)super.registerEntities(schema);
        map.remove("Minecart");
        return map;
    }
}
