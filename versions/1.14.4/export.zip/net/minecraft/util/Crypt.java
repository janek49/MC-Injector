package net.minecraft.util;

import java.io.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.spec.*;
import java.security.*;
import org.apache.logging.log4j.*;

public class Crypt
{
    private static final Logger LOGGER;
    
    public static SecretKey generateSecretKey() {
        try {
            final KeyGenerator var0 = KeyGenerator.getInstance("AES");
            var0.init(128);
            return var0.generateKey();
        }
        catch (NoSuchAlgorithmException var2) {
            throw new Error(var2);
        }
    }
    
    public static KeyPair generateKeyPair() {
        try {
            final KeyPairGenerator var0 = KeyPairGenerator.getInstance("RSA");
            var0.initialize(1024);
            return var0.generateKeyPair();
        }
        catch (NoSuchAlgorithmException var2) {
            var2.printStackTrace();
            Crypt.LOGGER.error("Key pair generation failed!");
            return null;
        }
    }
    
    public static byte[] digestData(final String string, final PublicKey publicKey, final SecretKey secretKey) {
        try {
            return digestData("SHA-1", new byte[][] { string.getBytes("ISO_8859_1"), secretKey.getEncoded(), publicKey.getEncoded() });
        }
        catch (UnsupportedEncodingException var3) {
            var3.printStackTrace();
            return null;
        }
    }
    
    private static byte[] digestData(final String string, final byte[]... bytes) {
        try {
            final MessageDigest var2 = MessageDigest.getInstance(string);
            for (final byte[] vars6 : bytes) {
                var2.update(vars6);
            }
            return var2.digest();
        }
        catch (NoSuchAlgorithmException var3) {
            var3.printStackTrace();
            return null;
        }
    }
    
    public static PublicKey byteToPublicKey(final byte[] bytes) {
        try {
            final EncodedKeySpec var1 = new X509EncodedKeySpec(bytes);
            final KeyFactory var2 = KeyFactory.getInstance("RSA");
            return var2.generatePublic(var1);
        }
        catch (NoSuchAlgorithmException ex) {}
        catch (InvalidKeySpecException ex2) {}
        Crypt.LOGGER.error("Public key reconstitute failed!");
        return null;
    }
    
    public static SecretKey decryptByteToSecretKey(final PrivateKey privateKey, final byte[] bytes) {
        return new SecretKeySpec(decryptUsingKey(privateKey, bytes), "AES");
    }
    
    public static byte[] encryptUsingKey(final Key key, final byte[] vars1) {
        return cipherData(1, key, vars1);
    }
    
    public static byte[] decryptUsingKey(final Key key, final byte[] vars1) {
        return cipherData(2, key, vars1);
    }
    
    private static byte[] cipherData(final int var0, final Key key, final byte[] vars2) {
        try {
            return setupCipher(var0, key.getAlgorithm(), key).doFinal(vars2);
        }
        catch (IllegalBlockSizeException var) {
            var.printStackTrace();
        }
        catch (BadPaddingException var2) {
            var2.printStackTrace();
        }
        Crypt.LOGGER.error("Cipher data failed!");
        return null;
    }
    
    private static Cipher setupCipher(final int var0, final String string, final Key key) {
        try {
            final Cipher cipher = Cipher.getInstance(string);
            cipher.init(var0, key);
            return cipher;
        }
        catch (InvalidKeyException var) {
            var.printStackTrace();
        }
        catch (NoSuchAlgorithmException var2) {
            var2.printStackTrace();
        }
        catch (NoSuchPaddingException var3) {
            var3.printStackTrace();
        }
        Crypt.LOGGER.error("Cipher creation failed!");
        return null;
    }
    
    public static Cipher getCipher(final int var0, final Key key) {
        try {
            final Cipher cipher = Cipher.getInstance("AES/CFB8/NoPadding");
            cipher.init(var0, key, new IvParameterSpec(key.getEncoded()));
            return cipher;
        }
        catch (GeneralSecurityException var) {
            throw new RuntimeException(var);
        }
    }
    
    static {
        LOGGER = LogManager.getLogger();
    }
}
