package net.minecraft.network.protocol.game;

import net.minecraft.network.protocol.*;
import net.minecraft.world.level.block.*;
import net.minecraft.core.*;
import java.io.*;
import net.minecraft.network.*;

public class ClientboundBlockEventPacket implements Packet<ClientGamePacketListener>
{
    private BlockPos pos;
    private int b0;
    private int b1;
    private Block block;
    
    public ClientboundBlockEventPacket() {
    }
    
    public ClientboundBlockEventPacket(final BlockPos pos, final Block block, final int b0, final int b1) {
        this.pos = pos;
        this.block = block;
        this.b0 = b0;
        this.b1 = b1;
    }
    
    @Override
    public void read(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        this.pos = friendlyByteBuf.readBlockPos();
        this.b0 = friendlyByteBuf.readUnsignedByte();
        this.b1 = friendlyByteBuf.readUnsignedByte();
        this.block = Registry.BLOCK.byId(friendlyByteBuf.readVarInt());
    }
    
    @Override
    public void write(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        friendlyByteBuf.writeBlockPos(this.pos);
        friendlyByteBuf.writeByte(this.b0);
        friendlyByteBuf.writeByte(this.b1);
        friendlyByteBuf.writeVarInt(Registry.BLOCK.getId(this.block));
    }
    
    @Override
    public void handle(final ClientGamePacketListener clientGamePacketListener) {
        clientGamePacketListener.handleBlockEvent(this);
    }
    
    public BlockPos getPos() {
        return this.pos;
    }
    
    public int getB0() {
        return this.b0;
    }
    
    public int getB1() {
        return this.b1;
    }
    
    public Block getBlock() {
        return this.block;
    }
}
