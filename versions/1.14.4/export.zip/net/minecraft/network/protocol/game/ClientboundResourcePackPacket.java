package net.minecraft.network.protocol.game;

import net.minecraft.network.protocol.*;
import java.io.*;
import net.minecraft.network.*;

public class ClientboundResourcePackPacket implements Packet<ClientGamePacketListener>
{
    private String url;
    private String hash;
    
    public ClientboundResourcePackPacket() {
    }
    
    public ClientboundResourcePackPacket(final String url, final String hash) {
        this.url = url;
        this.hash = hash;
        if (hash.length() > 40) {
            throw new IllegalArgumentException("Hash is too long (max 40, was " + hash.length() + ")");
        }
    }
    
    @Override
    public void read(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        this.url = friendlyByteBuf.readUtf(32767);
        this.hash = friendlyByteBuf.readUtf(40);
    }
    
    @Override
    public void write(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        friendlyByteBuf.writeUtf(this.url);
        friendlyByteBuf.writeUtf(this.hash);
    }
    
    @Override
    public void handle(final ClientGamePacketListener clientGamePacketListener) {
        clientGamePacketListener.handleResourcePack(this);
    }
    
    public String getUrl() {
        return this.url;
    }
    
    public String getHash() {
        return this.hash;
    }
}
