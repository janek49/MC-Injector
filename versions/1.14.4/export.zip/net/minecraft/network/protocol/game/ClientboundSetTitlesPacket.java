package net.minecraft.network.protocol.game;

import net.minecraft.network.protocol.*;
import net.minecraft.network.chat.*;
import javax.annotation.*;
import java.io.*;
import net.minecraft.network.*;

public class ClientboundSetTitlesPacket implements Packet<ClientGamePacketListener>
{
    private Type type;
    private Component text;
    private int fadeInTime;
    private int stayTime;
    private int fadeOutTime;
    
    public ClientboundSetTitlesPacket() {
    }
    
    public ClientboundSetTitlesPacket(final Type clientboundSetTitlesPacket$Type, final Component component) {
        this(clientboundSetTitlesPacket$Type, component, -1, -1, -1);
    }
    
    public ClientboundSetTitlesPacket(final int var1, final int var2, final int var3) {
        this(Type.TIMES, null, var1, var2, var3);
    }
    
    public ClientboundSetTitlesPacket(final Type type, @Nullable final Component text, final int fadeInTime, final int stayTime, final int fadeOutTime) {
        this.type = type;
        this.text = text;
        this.fadeInTime = fadeInTime;
        this.stayTime = stayTime;
        this.fadeOutTime = fadeOutTime;
    }
    
    @Override
    public void read(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        this.type = friendlyByteBuf.readEnum(Type.class);
        if (this.type == Type.TITLE || this.type == Type.SUBTITLE || this.type == Type.ACTIONBAR) {
            this.text = friendlyByteBuf.readComponent();
        }
        if (this.type == Type.TIMES) {
            this.fadeInTime = friendlyByteBuf.readInt();
            this.stayTime = friendlyByteBuf.readInt();
            this.fadeOutTime = friendlyByteBuf.readInt();
        }
    }
    
    @Override
    public void write(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        friendlyByteBuf.writeEnum(this.type);
        if (this.type == Type.TITLE || this.type == Type.SUBTITLE || this.type == Type.ACTIONBAR) {
            friendlyByteBuf.writeComponent(this.text);
        }
        if (this.type == Type.TIMES) {
            friendlyByteBuf.writeInt(this.fadeInTime);
            friendlyByteBuf.writeInt(this.stayTime);
            friendlyByteBuf.writeInt(this.fadeOutTime);
        }
    }
    
    @Override
    public void handle(final ClientGamePacketListener clientGamePacketListener) {
        clientGamePacketListener.handleSetTitles(this);
    }
    
    public Type getType() {
        return this.type;
    }
    
    public Component getText() {
        return this.text;
    }
    
    public int getFadeInTime() {
        return this.fadeInTime;
    }
    
    public int getStayTime() {
        return this.stayTime;
    }
    
    public int getFadeOutTime() {
        return this.fadeOutTime;
    }
    
    public enum Type
    {
        TITLE("TITLE", 0), 
        SUBTITLE("SUBTITLE", 1), 
        ACTIONBAR("ACTIONBAR", 2), 
        TIMES("TIMES", 3), 
        CLEAR("CLEAR", 4), 
        RESET("RESET", 5);
        
        private Type(final String s, final int n) {
        }
    }
}
