package net.minecraft.network.protocol.game;

import net.minecraft.network.protocol.*;
import java.io.*;
import net.minecraft.network.*;

public class ClientboundSetTimePacket implements Packet<ClientGamePacketListener>
{
    private long gameTime;
    private long dayTime;
    
    public ClientboundSetTimePacket() {
    }
    
    public ClientboundSetTimePacket(final long gameTime, final long dayTime, final boolean var5) {
        this.gameTime = gameTime;
        this.dayTime = dayTime;
        if (!var5) {
            this.dayTime = -this.dayTime;
            if (this.dayTime == 0L) {
                this.dayTime = -1L;
            }
        }
    }
    
    @Override
    public void read(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        this.gameTime = friendlyByteBuf.readLong();
        this.dayTime = friendlyByteBuf.readLong();
    }
    
    @Override
    public void write(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        friendlyByteBuf.writeLong(this.gameTime);
        friendlyByteBuf.writeLong(this.dayTime);
    }
    
    @Override
    public void handle(final ClientGamePacketListener clientGamePacketListener) {
        clientGamePacketListener.handleSetTime(this);
    }
    
    public long getGameTime() {
        return this.gameTime;
    }
    
    public long getDayTime() {
        return this.dayTime;
    }
}
