package net.minecraft.network.protocol.game;

import net.minecraft.network.protocol.*;
import net.minecraft.world.level.lighting.*;
import com.google.common.collect.*;
import net.minecraft.world.level.*;
import net.minecraft.core.*;
import net.minecraft.world.level.chunk.*;
import java.io.*;
import java.util.*;
import net.minecraft.network.*;

public class ClientboundLightUpdatePacket implements Packet<ClientGamePacketListener>
{
    private int x;
    private int z;
    private int skyYMask;
    private int blockYMask;
    private int emptySkyYMask;
    private int emptyBlockYMask;
    private List<byte[]> skyUpdates;
    private List<byte[]> blockUpdates;
    
    public ClientboundLightUpdatePacket() {
    }
    
    public ClientboundLightUpdatePacket(final ChunkPos chunkPos, final LevelLightEngine levelLightEngine) {
        this.x = chunkPos.x;
        this.z = chunkPos.z;
        this.skyUpdates = (List<byte[]>)Lists.newArrayList();
        this.blockUpdates = (List<byte[]>)Lists.newArrayList();
        for (int var3 = 0; var3 < 18; ++var3) {
            final DataLayer var4 = levelLightEngine.getLayerListener(LightLayer.SKY).getDataLayerData(SectionPos.of(chunkPos, -1 + var3));
            final DataLayer var5 = levelLightEngine.getLayerListener(LightLayer.BLOCK).getDataLayerData(SectionPos.of(chunkPos, -1 + var3));
            if (var4 != null) {
                if (var4.isEmpty()) {
                    this.emptySkyYMask |= 1 << var3;
                }
                else {
                    this.skyYMask |= 1 << var3;
                    this.skyUpdates.add(var4.getData().clone());
                }
            }
            if (var5 != null) {
                if (var5.isEmpty()) {
                    this.emptyBlockYMask |= 1 << var3;
                }
                else {
                    this.blockYMask |= 1 << var3;
                    this.blockUpdates.add(var5.getData().clone());
                }
            }
        }
    }
    
    public ClientboundLightUpdatePacket(final ChunkPos chunkPos, final LevelLightEngine levelLightEngine, final int skyYMask, final int blockYMask) {
        this.x = chunkPos.x;
        this.z = chunkPos.z;
        this.skyYMask = skyYMask;
        this.blockYMask = blockYMask;
        this.skyUpdates = (List<byte[]>)Lists.newArrayList();
        this.blockUpdates = (List<byte[]>)Lists.newArrayList();
        for (int var5 = 0; var5 < 18; ++var5) {
            if ((this.skyYMask & 1 << var5) != 0x0) {
                final DataLayer var6 = levelLightEngine.getLayerListener(LightLayer.SKY).getDataLayerData(SectionPos.of(chunkPos, -1 + var5));
                if (var6 == null || var6.isEmpty()) {
                    this.skyYMask &= ~(1 << var5);
                    if (var6 != null) {
                        this.emptySkyYMask |= 1 << var5;
                    }
                }
                else {
                    this.skyUpdates.add(var6.getData().clone());
                }
            }
            if ((this.blockYMask & 1 << var5) != 0x0) {
                final DataLayer var6 = levelLightEngine.getLayerListener(LightLayer.BLOCK).getDataLayerData(SectionPos.of(chunkPos, -1 + var5));
                if (var6 == null || var6.isEmpty()) {
                    this.blockYMask &= ~(1 << var5);
                    if (var6 != null) {
                        this.emptyBlockYMask |= 1 << var5;
                    }
                }
                else {
                    this.blockUpdates.add(var6.getData().clone());
                }
            }
        }
    }
    
    @Override
    public void read(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        this.x = friendlyByteBuf.readVarInt();
        this.z = friendlyByteBuf.readVarInt();
        this.skyYMask = friendlyByteBuf.readVarInt();
        this.blockYMask = friendlyByteBuf.readVarInt();
        this.emptySkyYMask = friendlyByteBuf.readVarInt();
        this.emptyBlockYMask = friendlyByteBuf.readVarInt();
        this.skyUpdates = (List<byte[]>)Lists.newArrayList();
        for (int var2 = 0; var2 < 18; ++var2) {
            if ((this.skyYMask & 1 << var2) != 0x0) {
                this.skyUpdates.add(friendlyByteBuf.readByteArray(2048));
            }
        }
        this.blockUpdates = (List<byte[]>)Lists.newArrayList();
        for (int var2 = 0; var2 < 18; ++var2) {
            if ((this.blockYMask & 1 << var2) != 0x0) {
                this.blockUpdates.add(friendlyByteBuf.readByteArray(2048));
            }
        }
    }
    
    @Override
    public void write(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        friendlyByteBuf.writeVarInt(this.x);
        friendlyByteBuf.writeVarInt(this.z);
        friendlyByteBuf.writeVarInt(this.skyYMask);
        friendlyByteBuf.writeVarInt(this.blockYMask);
        friendlyByteBuf.writeVarInt(this.emptySkyYMask);
        friendlyByteBuf.writeVarInt(this.emptyBlockYMask);
        for (final byte[] vars3 : this.skyUpdates) {
            friendlyByteBuf.writeByteArray(vars3);
        }
        for (final byte[] vars3 : this.blockUpdates) {
            friendlyByteBuf.writeByteArray(vars3);
        }
    }
    
    @Override
    public void handle(final ClientGamePacketListener clientGamePacketListener) {
        clientGamePacketListener.handleLightUpdatePacked(this);
    }
    
    public int getX() {
        return this.x;
    }
    
    public int getZ() {
        return this.z;
    }
    
    public int getSkyYMask() {
        return this.skyYMask;
    }
    
    public int getEmptySkyYMask() {
        return this.emptySkyYMask;
    }
    
    public List<byte[]> getSkyUpdates() {
        return this.skyUpdates;
    }
    
    public int getBlockYMask() {
        return this.blockYMask;
    }
    
    public int getEmptyBlockYMask() {
        return this.emptyBlockYMask;
    }
    
    public List<byte[]> getBlockUpdates() {
        return this.blockUpdates;
    }
}
