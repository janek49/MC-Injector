package net.minecraft.network.protocol.game;

import net.minecraft.network.protocol.*;
import net.minecraft.core.*;
import net.minecraft.resources.*;
import java.io.*;
import net.minecraft.network.*;

public class ServerboundSetJigsawBlockPacket implements Packet<ServerGamePacketListener>
{
    private BlockPos pos;
    private ResourceLocation attachementType;
    private ResourceLocation targetPool;
    private String finalState;
    
    public ServerboundSetJigsawBlockPacket() {
    }
    
    public ServerboundSetJigsawBlockPacket(final BlockPos pos, final ResourceLocation attachementType, final ResourceLocation targetPool, final String finalState) {
        this.pos = pos;
        this.attachementType = attachementType;
        this.targetPool = targetPool;
        this.finalState = finalState;
    }
    
    @Override
    public void read(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        this.pos = friendlyByteBuf.readBlockPos();
        this.attachementType = friendlyByteBuf.readResourceLocation();
        this.targetPool = friendlyByteBuf.readResourceLocation();
        this.finalState = friendlyByteBuf.readUtf(32767);
    }
    
    @Override
    public void write(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        friendlyByteBuf.writeBlockPos(this.pos);
        friendlyByteBuf.writeResourceLocation(this.attachementType);
        friendlyByteBuf.writeResourceLocation(this.targetPool);
        friendlyByteBuf.writeUtf(this.finalState);
    }
    
    @Override
    public void handle(final ServerGamePacketListener serverGamePacketListener) {
        serverGamePacketListener.handleSetJigsawBlock(this);
    }
    
    public BlockPos getPos() {
        return this.pos;
    }
    
    public ResourceLocation getTargetPool() {
        return this.targetPool;
    }
    
    public ResourceLocation getAttachementType() {
        return this.attachementType;
    }
    
    public String getFinalState() {
        return this.finalState;
    }
}
