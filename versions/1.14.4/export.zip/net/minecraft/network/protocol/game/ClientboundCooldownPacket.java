package net.minecraft.network.protocol.game;

import net.minecraft.network.protocol.*;
import net.minecraft.world.item.*;
import java.io.*;
import net.minecraft.network.*;

public class ClientboundCooldownPacket implements Packet<ClientGamePacketListener>
{
    private Item item;
    private int duration;
    
    public ClientboundCooldownPacket() {
    }
    
    public ClientboundCooldownPacket(final Item item, final int duration) {
        this.item = item;
        this.duration = duration;
    }
    
    @Override
    public void read(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        this.item = Item.byId(friendlyByteBuf.readVarInt());
        this.duration = friendlyByteBuf.readVarInt();
    }
    
    @Override
    public void write(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        friendlyByteBuf.writeVarInt(Item.getId(this.item));
        friendlyByteBuf.writeVarInt(this.duration);
    }
    
    @Override
    public void handle(final ClientGamePacketListener clientGamePacketListener) {
        clientGamePacketListener.handleItemCooldown(this);
    }
    
    public Item getItem() {
        return this.item;
    }
    
    public int getDuration() {
        return this.duration;
    }
}
