package net.minecraft.network.protocol.game;

import net.minecraft.network.protocol.*;
import net.minecraft.world.entity.player.*;
import java.io.*;
import net.minecraft.network.*;

public class ClientboundPlayerAbilitiesPacket implements Packet<ClientGamePacketListener>
{
    private boolean invulnerable;
    private boolean isFlying;
    private boolean canFly;
    private boolean instabuild;
    private float flyingSpeed;
    private float walkingSpeed;
    
    public ClientboundPlayerAbilitiesPacket() {
    }
    
    public ClientboundPlayerAbilitiesPacket(final Abilities abilities) {
        this.setInvulnerable(abilities.invulnerable);
        this.setFlying(abilities.flying);
        this.setCanFly(abilities.mayfly);
        this.setInstabuild(abilities.instabuild);
        this.setFlyingSpeed(abilities.getFlyingSpeed());
        this.setWalkingSpeed(abilities.getWalkingSpeed());
    }
    
    @Override
    public void read(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        final byte var2 = friendlyByteBuf.readByte();
        this.setInvulnerable((var2 & 0x1) > 0);
        this.setFlying((var2 & 0x2) > 0);
        this.setCanFly((var2 & 0x4) > 0);
        this.setInstabuild((var2 & 0x8) > 0);
        this.setFlyingSpeed(friendlyByteBuf.readFloat());
        this.setWalkingSpeed(friendlyByteBuf.readFloat());
    }
    
    @Override
    public void write(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        byte var2 = 0;
        if (this.isInvulnerable()) {
            var2 |= 0x1;
        }
        if (this.isFlying()) {
            var2 |= 0x2;
        }
        if (this.canFly()) {
            var2 |= 0x4;
        }
        if (this.canInstabuild()) {
            var2 |= 0x8;
        }
        friendlyByteBuf.writeByte(var2);
        friendlyByteBuf.writeFloat(this.flyingSpeed);
        friendlyByteBuf.writeFloat(this.walkingSpeed);
    }
    
    @Override
    public void handle(final ClientGamePacketListener clientGamePacketListener) {
        clientGamePacketListener.handlePlayerAbilities(this);
    }
    
    public boolean isInvulnerable() {
        return this.invulnerable;
    }
    
    public void setInvulnerable(final boolean invulnerable) {
        this.invulnerable = invulnerable;
    }
    
    public boolean isFlying() {
        return this.isFlying;
    }
    
    public void setFlying(final boolean flying) {
        this.isFlying = flying;
    }
    
    public boolean canFly() {
        return this.canFly;
    }
    
    public void setCanFly(final boolean canFly) {
        this.canFly = canFly;
    }
    
    public boolean canInstabuild() {
        return this.instabuild;
    }
    
    public void setInstabuild(final boolean instabuild) {
        this.instabuild = instabuild;
    }
    
    public float getFlyingSpeed() {
        return this.flyingSpeed;
    }
    
    public void setFlyingSpeed(final float flyingSpeed) {
        this.flyingSpeed = flyingSpeed;
    }
    
    public float getWalkingSpeed() {
        return this.walkingSpeed;
    }
    
    public void setWalkingSpeed(final float walkingSpeed) {
        this.walkingSpeed = walkingSpeed;
    }
}
