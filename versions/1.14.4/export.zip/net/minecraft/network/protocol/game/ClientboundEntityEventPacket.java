package net.minecraft.network.protocol.game;

import net.minecraft.network.protocol.*;
import net.minecraft.world.entity.*;
import java.io.*;
import net.minecraft.world.level.*;
import net.minecraft.network.*;

public class ClientboundEntityEventPacket implements Packet<ClientGamePacketListener>
{
    private int entityId;
    private byte eventId;
    
    public ClientboundEntityEventPacket() {
    }
    
    public ClientboundEntityEventPacket(final Entity entity, final byte eventId) {
        this.entityId = entity.getId();
        this.eventId = eventId;
    }
    
    @Override
    public void read(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        this.entityId = friendlyByteBuf.readInt();
        this.eventId = friendlyByteBuf.readByte();
    }
    
    @Override
    public void write(final FriendlyByteBuf friendlyByteBuf) throws IOException {
        friendlyByteBuf.writeInt(this.entityId);
        friendlyByteBuf.writeByte(this.eventId);
    }
    
    @Override
    public void handle(final ClientGamePacketListener clientGamePacketListener) {
        clientGamePacketListener.handleEntityEvent(this);
    }
    
    public Entity getEntity(final Level level) {
        return level.getEntity(this.entityId);
    }
    
    public byte getEventId() {
        return this.eventId;
    }
}
