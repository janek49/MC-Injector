package net.minecraft.network.protocol.status;

import net.minecraft.network.protocol.*;
import java.io.*;
import net.minecraft.network.*;

public class ServerboundStatusRequestPacket implements Packet<ServerStatusPacketListener>
{
    @Override
    public void read(final FriendlyByteBuf friendlyByteBuf) throws IOException {
    }
    
    @Override
    public void write(final FriendlyByteBuf friendlyByteBuf) throws IOException {
    }
    
    @Override
    public void handle(final ServerStatusPacketListener serverStatusPacketListener) {
        serverStatusPacketListener.handleStatusRequest(this);
    }
}
