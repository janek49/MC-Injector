package net.minecraft.network.protocol.status;

import net.minecraft.network.chat.*;
import com.mojang.authlib.*;
import java.lang.reflect.*;
import net.minecraft.util.*;
import java.util.*;
import com.google.gson.*;

public class ServerStatus
{
    private Component description;
    private Players players;
    private Version version;
    private String favicon;
    
    public Component getDescription() {
        return this.description;
    }
    
    public void setDescription(final Component description) {
        this.description = description;
    }
    
    public Players getPlayers() {
        return this.players;
    }
    
    public void setPlayers(final Players players) {
        this.players = players;
    }
    
    public Version getVersion() {
        return this.version;
    }
    
    public void setVersion(final Version version) {
        this.version = version;
    }
    
    public void setFavicon(final String favicon) {
        this.favicon = favicon;
    }
    
    public String getFavicon() {
        return this.favicon;
    }
    
    public static class Players
    {
        private final int maxPlayers;
        private final int numPlayers;
        private GameProfile[] sample;
        
        public Players(final int maxPlayers, final int numPlayers) {
            this.maxPlayers = maxPlayers;
            this.numPlayers = numPlayers;
        }
        
        public int getMaxPlayers() {
            return this.maxPlayers;
        }
        
        public int getNumPlayers() {
            return this.numPlayers;
        }
        
        public GameProfile[] getSample() {
            return this.sample;
        }
        
        public void setSample(final GameProfile[] sample) {
            this.sample = sample;
        }
        
        public static class Serializer implements JsonDeserializer<Players>, JsonSerializer<Players>
        {
            public Players deserialize(final JsonElement jsonElement, final Type type, final JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
                final JsonObject var4 = GsonHelper.convertToJsonObject(jsonElement, "players");
                final Players var5 = new Players(GsonHelper.getAsInt(var4, "max"), GsonHelper.getAsInt(var4, "online"));
                if (GsonHelper.isArrayNode(var4, "sample")) {
                    final JsonArray var6 = GsonHelper.getAsJsonArray(var4, "sample");
                    if (var6.size() > 0) {
                        final GameProfile[] vars7 = new GameProfile[var6.size()];
                        for (int var7 = 0; var7 < vars7.length; ++var7) {
                            final JsonObject var8 = GsonHelper.convertToJsonObject(var6.get(var7), "player[" + var7 + "]");
                            final String var9 = GsonHelper.getAsString(var8, "id");
                            vars7[var7] = new GameProfile(UUID.fromString(var9), GsonHelper.getAsString(var8, "name"));
                        }
                        var5.setSample(vars7);
                    }
                }
                return var5;
            }
            
            public JsonElement serialize(final Players serverStatus$Players, final Type type, final JsonSerializationContext jsonSerializationContext) {
                final JsonObject var4 = new JsonObject();
                var4.addProperty("max", (Number)serverStatus$Players.getMaxPlayers());
                var4.addProperty("online", (Number)serverStatus$Players.getNumPlayers());
                if (serverStatus$Players.getSample() != null && serverStatus$Players.getSample().length > 0) {
                    final JsonArray var5 = new JsonArray();
                    for (int var6 = 0; var6 < serverStatus$Players.getSample().length; ++var6) {
                        final JsonObject var7 = new JsonObject();
                        final UUID var8 = serverStatus$Players.getSample()[var6].getId();
                        var7.addProperty("id", (var8 == null) ? "" : var8.toString());
                        var7.addProperty("name", serverStatus$Players.getSample()[var6].getName());
                        var5.add((JsonElement)var7);
                    }
                    var4.add("sample", (JsonElement)var5);
                }
                return (JsonElement)var4;
            }
        }
    }
    
    public static class Version
    {
        private final String name;
        private final int protocol;
        
        public Version(final String name, final int protocol) {
            this.name = name;
            this.protocol = protocol;
        }
        
        public String getName() {
            return this.name;
        }
        
        public int getProtocol() {
            return this.protocol;
        }
        
        public static class Serializer implements JsonDeserializer<Version>, JsonSerializer<Version>
        {
            public Version deserialize(final JsonElement jsonElement, final Type type, final JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
                final JsonObject var4 = GsonHelper.convertToJsonObject(jsonElement, "version");
                return new Version(GsonHelper.getAsString(var4, "name"), GsonHelper.getAsInt(var4, "protocol"));
            }
            
            public JsonElement serialize(final Version serverStatus$Version, final Type type, final JsonSerializationContext jsonSerializationContext) {
                final JsonObject var4 = new JsonObject();
                var4.addProperty("name", serverStatus$Version.getName());
                var4.addProperty("protocol", (Number)serverStatus$Version.getProtocol());
                return (JsonElement)var4;
            }
        }
    }
    
    public static class Serializer implements JsonDeserializer<ServerStatus>, JsonSerializer<ServerStatus>
    {
        public ServerStatus deserialize(final JsonElement jsonElement, final Type type, final JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            final JsonObject var4 = GsonHelper.convertToJsonObject(jsonElement, "status");
            final ServerStatus var5 = new ServerStatus();
            if (var4.has("description")) {
                var5.setDescription((Component)jsonDeserializationContext.deserialize(var4.get("description"), (Type)Component.class));
            }
            if (var4.has("players")) {
                var5.setPlayers((Players)jsonDeserializationContext.deserialize(var4.get("players"), (Type)Players.class));
            }
            if (var4.has("version")) {
                var5.setVersion((Version)jsonDeserializationContext.deserialize(var4.get("version"), (Type)Version.class));
            }
            if (var4.has("favicon")) {
                var5.setFavicon(GsonHelper.getAsString(var4, "favicon"));
            }
            return var5;
        }
        
        public JsonElement serialize(final ServerStatus serverStatus, final Type type, final JsonSerializationContext jsonSerializationContext) {
            final JsonObject var4 = new JsonObject();
            if (serverStatus.getDescription() != null) {
                var4.add("description", jsonSerializationContext.serialize((Object)serverStatus.getDescription()));
            }
            if (serverStatus.getPlayers() != null) {
                var4.add("players", jsonSerializationContext.serialize((Object)serverStatus.getPlayers()));
            }
            if (serverStatus.getVersion() != null) {
                var4.add("version", jsonSerializationContext.serialize((Object)serverStatus.getVersion()));
            }
            if (serverStatus.getFavicon() != null) {
                var4.addProperty("favicon", serverStatus.getFavicon());
            }
            return (JsonElement)var4;
        }
    }
}
