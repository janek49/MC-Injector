package net.minecraft.network.chat;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;

public class ClickEvent
{
    private final Action action;
    private final String value;
    
    public ClickEvent(final Action action, final String value) {
        this.action = action;
        this.value = value;
    }
    
    public Action getAction() {
        return this.action;
    }
    
    public String getValue() {
        return this.value;
    }
    
    @Override
    public boolean equals(final Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        final ClickEvent var2 = (ClickEvent)object;
        if (this.action != var2.action) {
            return false;
        }
        if (this.value != null) {
            if (this.value.equals(var2.value)) {
                return true;
            }
        }
        else if (var2.value == null) {
            return true;
        }
        return false;
    }
    
    @Override
    public String toString() {
        return "ClickEvent{action=" + this.action + ", value='" + this.value + '\'' + '}';
    }
    
    @Override
    public int hashCode() {
        int var1 = this.action.hashCode();
        var1 = 31 * var1 + ((this.value != null) ? this.value.hashCode() : 0);
        return var1;
    }
    
    public enum Action
    {
        OPEN_URL("OPEN_URL", 0, "open_url", true), 
        OPEN_FILE("OPEN_FILE", 1, "open_file", false), 
        RUN_COMMAND("RUN_COMMAND", 2, "run_command", true), 
        SUGGEST_COMMAND("SUGGEST_COMMAND", 3, "suggest_command", true), 
        CHANGE_PAGE("CHANGE_PAGE", 4, "change_page", true);
        
        private static final Map<String, Action> LOOKUP;
        private final boolean allowFromServer;
        private final String name;
        
        private Action(final String s, final int n, final String name, final boolean allowFromServer) {
            this.name = name;
            this.allowFromServer = allowFromServer;
        }
        
        public boolean isAllowedFromServer() {
            return this.allowFromServer;
        }
        
        public String getName() {
            return this.name;
        }
        
        public static Action getByName(final String name) {
            return Action.LOOKUP.get(name);
        }
        
        static {
            LOOKUP = Arrays.stream(values()).collect(Collectors.toMap((Function<? super Action, ? extends String>)Action::getName, clickEvent$Action -> clickEvent$Action));
        }
    }
}
