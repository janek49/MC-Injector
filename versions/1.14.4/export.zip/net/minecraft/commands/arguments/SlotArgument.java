package net.minecraft.commands.arguments;

import com.mojang.brigadier.arguments.*;
import com.mojang.brigadier.context.*;
import com.mojang.brigadier.exceptions.*;
import java.util.concurrent.*;
import com.mojang.brigadier.suggestion.*;
import net.minecraft.commands.*;
import net.minecraft.world.entity.*;
import com.mojang.brigadier.*;
import net.minecraft.network.chat.*;
import java.util.*;
import com.google.common.collect.*;
import net.minecraft.*;

public class SlotArgument implements ArgumentType<Integer>
{
    private static final Collection<String> EXAMPLES;
    private static final DynamicCommandExceptionType ERROR_UNKNOWN_SLOT;
    private static final Map<String, Integer> SLOTS;
    
    public static SlotArgument slot() {
        return new SlotArgument();
    }
    
    public static int getSlot(final CommandContext<CommandSourceStack> commandContext, final String string) {
        return (int)commandContext.getArgument(string, (Class)Integer.class);
    }
    
    public Integer parse(final StringReader stringReader) throws CommandSyntaxException {
        final String var2 = stringReader.readUnquotedString();
        if (!SlotArgument.SLOTS.containsKey(var2)) {
            throw SlotArgument.ERROR_UNKNOWN_SLOT.create((Object)var2);
        }
        return SlotArgument.SLOTS.get(var2);
    }
    
    public <S> CompletableFuture<Suggestions> listSuggestions(final CommandContext<S> commandContext, final SuggestionsBuilder suggestionsBuilder) {
        return SharedSuggestionProvider.suggest(SlotArgument.SLOTS.keySet(), suggestionsBuilder);
    }
    
    public Collection<String> getExamples() {
        return SlotArgument.EXAMPLES;
    }
    
    static {
        EXAMPLES = Arrays.asList("container.5", "12", "weapon");
        final TranslatableComponent translatableComponent;
        ERROR_UNKNOWN_SLOT = new DynamicCommandExceptionType(object -> {
            new TranslatableComponent("slot.unknown", new Object[] { object });
            return translatableComponent;
        });
        int var1;
        int var2;
        int var3;
        int var4;
        int var5;
        int var6;
        SLOTS = Util.make((Map<String, Integer>)Maps.newHashMap(), hashMap -> {
            for (var1 = 0; var1 < 54; ++var1) {
                hashMap.put("container." + var1, var1);
            }
            for (var2 = 0; var2 < 9; ++var2) {
                hashMap.put("hotbar." + var2, var2);
            }
            for (var3 = 0; var3 < 27; ++var3) {
                hashMap.put("inventory." + var3, 9 + var3);
            }
            for (var4 = 0; var4 < 27; ++var4) {
                hashMap.put("enderchest." + var4, 200 + var4);
            }
            for (var5 = 0; var5 < 8; ++var5) {
                hashMap.put("villager." + var5, 300 + var5);
            }
            for (var6 = 0; var6 < 15; ++var6) {
                hashMap.put("horse." + var6, 500 + var6);
            }
            hashMap.put("weapon", 98);
            hashMap.put("weapon.mainhand", 98);
            hashMap.put("weapon.offhand", 99);
            hashMap.put("armor.head", 100 + EquipmentSlot.HEAD.getIndex());
            hashMap.put("armor.chest", 100 + EquipmentSlot.CHEST.getIndex());
            hashMap.put("armor.legs", 100 + EquipmentSlot.LEGS.getIndex());
            hashMap.put("armor.feet", 100 + EquipmentSlot.FEET.getIndex());
            hashMap.put("horse.saddle", 400);
            hashMap.put("horse.armor", 401);
            hashMap.put("horse.chest", 499);
        });
    }
}
