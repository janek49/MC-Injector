package net.minecraft.commands.arguments;

import com.mojang.brigadier.arguments.*;
import com.mojang.brigadier.exceptions.*;
import com.mojang.brigadier.context.*;
import java.util.concurrent.*;
import com.mojang.brigadier.suggestion.*;
import net.minecraft.commands.*;
import com.mojang.brigadier.*;
import net.minecraft.network.chat.*;
import java.util.*;
import it.unimi.dsi.fastutil.objects.*;

public class TimeArgument implements ArgumentType<Integer>
{
    private static final Collection<String> EXAMPLES;
    private static final SimpleCommandExceptionType ERROR_INVALID_UNIT;
    private static final DynamicCommandExceptionType ERROR_INVALID_TICK_COUNT;
    private static final Object2IntMap<String> UNITS;
    
    public static TimeArgument time() {
        return new TimeArgument();
    }
    
    public Integer parse(final StringReader stringReader) throws CommandSyntaxException {
        final float var2 = stringReader.readFloat();
        final String var3 = stringReader.readUnquotedString();
        final int var4 = TimeArgument.UNITS.getOrDefault((Object)var3, 0);
        if (var4 == 0) {
            throw TimeArgument.ERROR_INVALID_UNIT.create();
        }
        final int var5 = Math.round(var2 * var4);
        if (var5 < 0) {
            throw TimeArgument.ERROR_INVALID_TICK_COUNT.create((Object)var5);
        }
        return var5;
    }
    
    public <S> CompletableFuture<Suggestions> listSuggestions(final CommandContext<S> commandContext, final SuggestionsBuilder suggestionsBuilder) {
        final StringReader var3 = new StringReader(suggestionsBuilder.getRemaining());
        try {
            var3.readFloat();
        }
        catch (CommandSyntaxException var4) {
            return (CompletableFuture<Suggestions>)suggestionsBuilder.buildFuture();
        }
        return SharedSuggestionProvider.suggest((Iterable<String>)TimeArgument.UNITS.keySet(), suggestionsBuilder.createOffset(suggestionsBuilder.getStart() + var3.getCursor()));
    }
    
    public Collection<String> getExamples() {
        return TimeArgument.EXAMPLES;
    }
    
    static {
        EXAMPLES = Arrays.asList("0d", "0s", "0t", "0");
        ERROR_INVALID_UNIT = new SimpleCommandExceptionType((Message)new TranslatableComponent("argument.time.invalid_unit", new Object[0]));
        final TranslatableComponent translatableComponent;
        ERROR_INVALID_TICK_COUNT = new DynamicCommandExceptionType(object -> {
            new TranslatableComponent("argument.time.invalid_tick_count", new Object[] { object });
            return translatableComponent;
        });
        (UNITS = (Object2IntMap)new Object2IntOpenHashMap()).put((Object)"d", 24000);
        TimeArgument.UNITS.put((Object)"s", 20);
        TimeArgument.UNITS.put((Object)"t", 1);
        TimeArgument.UNITS.put((Object)"", 1);
    }
}
