package net.minecraft.commands.arguments;

import com.mojang.brigadier.arguments.*;
import com.mojang.brigadier.context.*;
import net.minecraft.world.scores.*;
import com.mojang.brigadier.exceptions.*;
import java.util.concurrent.*;
import com.mojang.brigadier.suggestion.*;
import net.minecraft.commands.*;
import com.mojang.brigadier.*;
import net.minecraft.network.chat.*;
import java.util.*;

public class ObjectiveArgument implements ArgumentType<String>
{
    private static final Collection<String> EXAMPLES;
    private static final DynamicCommandExceptionType ERROR_OBJECTIVE_NOT_FOUND;
    private static final DynamicCommandExceptionType ERROR_OBJECTIVE_READ_ONLY;
    public static final DynamicCommandExceptionType ERROR_OBJECTIVE_NAME_TOO_LONG;
    
    public static ObjectiveArgument objective() {
        return new ObjectiveArgument();
    }
    
    public static Objective getObjective(final CommandContext<CommandSourceStack> commandContext, final String string) throws CommandSyntaxException {
        final String string2 = (String)commandContext.getArgument(string, (Class)String.class);
        final Scoreboard var3 = ((CommandSourceStack)commandContext.getSource()).getServer().getScoreboard();
        final Objective var4 = var3.getObjective(string2);
        if (var4 == null) {
            throw ObjectiveArgument.ERROR_OBJECTIVE_NOT_FOUND.create((Object)string2);
        }
        return var4;
    }
    
    public static Objective getWritableObjective(final CommandContext<CommandSourceStack> commandContext, final String string) throws CommandSyntaxException {
        final Objective objective = getObjective(commandContext, string);
        if (objective.getCriteria().isReadOnly()) {
            throw ObjectiveArgument.ERROR_OBJECTIVE_READ_ONLY.create((Object)objective.getName());
        }
        return objective;
    }
    
    public String parse(final StringReader stringReader) throws CommandSyntaxException {
        final String string = stringReader.readUnquotedString();
        if (string.length() > 16) {
            throw ObjectiveArgument.ERROR_OBJECTIVE_NAME_TOO_LONG.create((Object)16);
        }
        return string;
    }
    
    public <S> CompletableFuture<Suggestions> listSuggestions(final CommandContext<S> commandContext, final SuggestionsBuilder suggestionsBuilder) {
        if (commandContext.getSource() instanceof CommandSourceStack) {
            return SharedSuggestionProvider.suggest(((CommandSourceStack)commandContext.getSource()).getServer().getScoreboard().getObjectiveNames(), suggestionsBuilder);
        }
        if (commandContext.getSource() instanceof SharedSuggestionProvider) {
            final SharedSuggestionProvider var3 = (SharedSuggestionProvider)commandContext.getSource();
            return var3.customSuggestion((CommandContext<SharedSuggestionProvider>)commandContext, suggestionsBuilder);
        }
        return (CompletableFuture<Suggestions>)Suggestions.empty();
    }
    
    public Collection<String> getExamples() {
        return ObjectiveArgument.EXAMPLES;
    }
    
    static {
        EXAMPLES = Arrays.asList("foo", "*", "012");
        final TranslatableComponent translatableComponent;
        ERROR_OBJECTIVE_NOT_FOUND = new DynamicCommandExceptionType(object -> {
            new TranslatableComponent("arguments.objective.notFound", new Object[] { object });
            return translatableComponent;
        });
        final TranslatableComponent translatableComponent2;
        ERROR_OBJECTIVE_READ_ONLY = new DynamicCommandExceptionType(object -> {
            new TranslatableComponent("arguments.objective.readonly", new Object[] { object });
            return translatableComponent2;
        });
        final TranslatableComponent translatableComponent3;
        ERROR_OBJECTIVE_NAME_TOO_LONG = new DynamicCommandExceptionType(object -> {
            new TranslatableComponent("commands.scoreboard.objectives.add.longName", new Object[] { object });
            return translatableComponent3;
        });
    }
}
