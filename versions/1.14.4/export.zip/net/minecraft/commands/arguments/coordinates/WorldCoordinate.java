package net.minecraft.commands.arguments.coordinates;

import com.mojang.brigadier.exceptions.*;
import net.minecraft.network.chat.*;
import com.mojang.brigadier.*;

public class WorldCoordinate
{
    public static final SimpleCommandExceptionType ERROR_EXPECTED_DOUBLE;
    public static final SimpleCommandExceptionType ERROR_EXPECTED_INT;
    private final boolean relative;
    private final double value;
    
    public WorldCoordinate(final boolean relative, final double value) {
        this.relative = relative;
        this.value = value;
    }
    
    public double get(final double d) {
        if (this.relative) {
            return this.value + d;
        }
        return this.value;
    }
    
    public static WorldCoordinate parseDouble(final StringReader stringReader, final boolean var1) throws CommandSyntaxException {
        if (stringReader.canRead() && stringReader.peek() == '^') {
            throw Vec3Argument.ERROR_MIXED_TYPE.createWithContext((ImmutableStringReader)stringReader);
        }
        if (!stringReader.canRead()) {
            throw WorldCoordinate.ERROR_EXPECTED_DOUBLE.createWithContext((ImmutableStringReader)stringReader);
        }
        final boolean var2 = isRelative(stringReader);
        final int var3 = stringReader.getCursor();
        double var4 = (stringReader.canRead() && stringReader.peek() != ' ') ? stringReader.readDouble() : 0.0;
        final String var5 = stringReader.getString().substring(var3, stringReader.getCursor());
        if (var2 && var5.isEmpty()) {
            return new WorldCoordinate(true, 0.0);
        }
        if (!var5.contains(".") && !var2 && var1) {
            var4 += 0.5;
        }
        return new WorldCoordinate(var2, var4);
    }
    
    public static WorldCoordinate parseInt(final StringReader stringReader) throws CommandSyntaxException {
        if (stringReader.canRead() && stringReader.peek() == '^') {
            throw Vec3Argument.ERROR_MIXED_TYPE.createWithContext((ImmutableStringReader)stringReader);
        }
        if (!stringReader.canRead()) {
            throw WorldCoordinate.ERROR_EXPECTED_INT.createWithContext((ImmutableStringReader)stringReader);
        }
        final boolean var1 = isRelative(stringReader);
        double var2;
        if (stringReader.canRead() && stringReader.peek() != ' ') {
            var2 = (var1 ? stringReader.readDouble() : stringReader.readInt());
        }
        else {
            var2 = 0.0;
        }
        return new WorldCoordinate(var1, var2);
    }
    
    private static boolean isRelative(final StringReader stringReader) {
        boolean var1;
        if (stringReader.peek() == '~') {
            var1 = true;
            stringReader.skip();
        }
        else {
            var1 = false;
        }
        return var1;
    }
    
    @Override
    public boolean equals(final Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof WorldCoordinate)) {
            return false;
        }
        final WorldCoordinate var2 = (WorldCoordinate)object;
        return this.relative == var2.relative && Double.compare(var2.value, this.value) == 0;
    }
    
    @Override
    public int hashCode() {
        int var1 = this.relative ? 1 : 0;
        final long var2 = Double.doubleToLongBits(this.value);
        var1 = 31 * var1 + (int)(var2 ^ var2 >>> 32);
        return var1;
    }
    
    public boolean isRelative() {
        return this.relative;
    }
    
    static {
        ERROR_EXPECTED_DOUBLE = new SimpleCommandExceptionType((Message)new TranslatableComponent("argument.pos.missing.double", new Object[0]));
        ERROR_EXPECTED_INT = new SimpleCommandExceptionType((Message)new TranslatableComponent("argument.pos.missing.int", new Object[0]));
    }
}
