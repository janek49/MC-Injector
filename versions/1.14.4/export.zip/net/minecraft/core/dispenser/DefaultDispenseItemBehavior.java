package net.minecraft.core.dispenser;

import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.core.*;
import net.minecraft.world.level.*;
import net.minecraft.world.entity.item.*;
import net.minecraft.world.entity.*;

public class DefaultDispenseItemBehavior implements DispenseItemBehavior
{
    @Override
    public final ItemStack dispense(final BlockSource blockSource, final ItemStack var2) {
        final ItemStack var3 = this.execute(blockSource, var2);
        this.playSound(blockSource);
        this.playAnimation(blockSource, blockSource.getBlockState().getValue((Property<Direction>)DispenserBlock.FACING));
        return var3;
    }
    
    protected ItemStack execute(final BlockSource blockSource, final ItemStack var2) {
        final Direction var3 = blockSource.getBlockState().getValue((Property<Direction>)DispenserBlock.FACING);
        final Position var4 = DispenserBlock.getDispensePosition(blockSource);
        final ItemStack var5 = var2.split(1);
        spawnItem(blockSource.getLevel(), var5, 6, var3, var4);
        return var2;
    }
    
    public static void spawnItem(final Level level, final ItemStack itemStack, final int var2, final Direction direction, final Position position) {
        final double var3 = position.x();
        double var4 = position.y();
        final double var5 = position.z();
        if (direction.getAxis() == Direction.Axis.Y) {
            var4 -= 0.125;
        }
        else {
            var4 -= 0.15625;
        }
        final ItemEntity var6 = new ItemEntity(level, var3, var4, var5, itemStack);
        final double var7 = level.random.nextDouble() * 0.1 + 0.2;
        var6.setDeltaMovement(level.random.nextGaussian() * 0.007499999832361937 * var2 + direction.getStepX() * var7, level.random.nextGaussian() * 0.007499999832361937 * var2 + 0.20000000298023224, level.random.nextGaussian() * 0.007499999832361937 * var2 + direction.getStepZ() * var7);
        level.addFreshEntity(var6);
    }
    
    protected void playSound(final BlockSource blockSource) {
        blockSource.getLevel().levelEvent(1000, blockSource.getPos(), 0);
    }
    
    protected void playAnimation(final BlockSource blockSource, final Direction direction) {
        blockSource.getLevel().levelEvent(2000, blockSource.getPos(), direction.get3DDataValue());
    }
}
