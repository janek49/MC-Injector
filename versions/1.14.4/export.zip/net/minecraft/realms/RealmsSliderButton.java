package net.minecraft.realms;

import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import net.minecraft.util.*;
import net.minecraft.client.gui.components.*;

@ClientJarOnly
public abstract class RealmsSliderButton extends AbstractRealmsButton<RealmsSliderButtonProxy>
{
    protected static final ResourceLocation WIDGETS_LOCATION;
    private final int id;
    private final RealmsSliderButtonProxy proxy;
    private final double minValue;
    private final double maxValue;
    
    public RealmsSliderButton(final int id, final int var2, final int var3, final int var4, final int var5, final double minValue, final double maxValue) {
        this.id = id;
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.proxy = new RealmsSliderButtonProxy(this, var2, var3, var4, 20, this.toPct(var5));
        this.getProxy().setMessage(this.getMessage());
    }
    
    public String getMessage() {
        return "";
    }
    
    public double toPct(final double d) {
        return Mth.clamp((this.clamp(d) - this.minValue) / (this.maxValue - this.minValue), 0.0, 1.0);
    }
    
    public double toValue(final double d) {
        return this.clamp(Mth.lerp(Mth.clamp(d, 0.0, 1.0), this.minValue, this.maxValue));
    }
    
    public double clamp(final double d) {
        return Mth.clamp(d, this.minValue, this.maxValue);
    }
    
    public int getYImage(final boolean b) {
        return 0;
    }
    
    public void onClick(final double var1, final double var3) {
    }
    
    public void onRelease(final double var1, final double var3) {
    }
    
    @Override
    public RealmsSliderButtonProxy getProxy() {
        return this.proxy;
    }
    
    public double getValue() {
        return this.proxy.getValue();
    }
    
    public void setValue(final double value) {
        this.proxy.setValue(value);
    }
    
    public int id() {
        return this.id;
    }
    
    public void setMessage(final String message) {
        this.proxy.setMessage(message);
    }
    
    public int getWidth() {
        return this.proxy.getWidth();
    }
    
    public int getHeight() {
        return this.proxy.getHeight();
    }
    
    public int y() {
        return this.proxy.y();
    }
    
    public abstract void applyValue();
    
    public void updateMessage() {
        this.proxy.setMessage(this.getMessage());
    }
    
    static {
        WIDGETS_LOCATION = new ResourceLocation("textures/gui/widgets.png");
    }
}
