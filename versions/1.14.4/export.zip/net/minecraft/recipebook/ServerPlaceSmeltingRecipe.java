package net.minecraft.recipebook;

import net.minecraft.world.*;
import net.minecraft.world.item.crafting.*;
import it.unimi.dsi.fastutil.ints.*;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.player.*;
import java.util.*;
import net.minecraft.world.inventory.*;

public class ServerPlaceSmeltingRecipe<C extends Container> extends ServerPlaceRecipe<C>
{
    private boolean recipeMatchesPlaced;
    
    public ServerPlaceSmeltingRecipe(final RecipeBookMenu<C> recipeBookMenu) {
        super(recipeBookMenu);
    }
    
    @Override
    protected void handleRecipeClicked(final Recipe<C> recipe, final boolean var2) {
        this.recipeMatchesPlaced = this.menu.recipeMatches(recipe);
        final int var3 = this.stackedContents.getBiggestCraftableStack(recipe, null);
        if (this.recipeMatchesPlaced) {
            final ItemStack var4 = this.menu.getSlot(0).getItem();
            if (var4.isEmpty() || var3 <= var4.getCount()) {
                return;
            }
        }
        final int var5 = this.getStackSize(var2, var3, this.recipeMatchesPlaced);
        final IntList var6 = (IntList)new IntArrayList();
        if (!this.stackedContents.canCraft(recipe, var6, var5)) {
            return;
        }
        if (!this.recipeMatchesPlaced) {
            this.moveItemToInventory(this.menu.getResultSlotIndex());
            this.moveItemToInventory(0);
        }
        this.placeRecipe(var5, var6);
    }
    
    @Override
    protected void clearGrid() {
        this.moveItemToInventory(this.menu.getResultSlotIndex());
        super.clearGrid();
    }
    
    protected void placeRecipe(final int var1, final IntList intList) {
        final Iterator<Integer> var2 = (Iterator<Integer>)intList.iterator();
        final Slot var3 = this.menu.getSlot(0);
        final ItemStack var4 = StackedContents.fromStackingIndex(var2.next());
        if (var4.isEmpty()) {
            return;
        }
        int var5 = Math.min(var4.getMaxStackSize(), var1);
        if (this.recipeMatchesPlaced) {
            var5 -= var3.getItem().getCount();
        }
        for (int var6 = 0; var6 < var5; ++var6) {
            this.moveItemToGrid(var3, var4);
        }
    }
}
