package net.minecraft.client.resources;

import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import com.google.common.collect.*;
import net.minecraft.util.profiling.*;
import net.minecraft.client.*;
import java.nio.charset.*;
import java.util.function.*;
import java.util.stream.*;
import java.io.*;
import net.minecraft.server.packs.resources.*;
import java.util.*;
import javax.annotation.*;

@ClientJarOnly
public class SplashManager extends SimplePreparableReloadListener<List<String>>
{
    private static final ResourceLocation SPLASHES_LOCATION;
    private static final Random RANDOM;
    private final List<String> splashes;
    private final User user;
    
    public SplashManager(final User user) {
        this.splashes = (List<String>)Lists.newArrayList();
        this.user = user;
    }
    
    @Override
    protected List<String> prepare(final ResourceManager resourceManager, final ProfilerFiller profilerFiller) {
        try (final Resource var3 = Minecraft.getInstance().getResourceManager().getResource(SplashManager.SPLASHES_LOCATION);
             final BufferedReader var4 = new BufferedReader(new InputStreamReader(var3.getInputStream(), StandardCharsets.UTF_8))) {
            return (List<String>)var4.lines().map((Function<? super String, ?>)String::trim).filter(string -> string.hashCode() != 125780783).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList());
        }
        catch (IOException var5) {
            return Collections.emptyList();
        }
    }
    
    @Override
    protected void apply(final List<String> list, final ResourceManager resourceManager, final ProfilerFiller profilerFiller) {
        this.splashes.clear();
        this.splashes.addAll(list);
    }
    
    @Nullable
    public String getSplash() {
        final Calendar var1 = Calendar.getInstance();
        var1.setTime(new Date());
        if (var1.get(2) + 1 == 12 && var1.get(5) == 24) {
            return "Merry X-mas!";
        }
        if (var1.get(2) + 1 == 1 && var1.get(5) == 1) {
            return "Happy new year!";
        }
        if (var1.get(2) + 1 == 10 && var1.get(5) == 31) {
            return "OOoooOOOoooo! Spooky!";
        }
        if (this.splashes.isEmpty()) {
            return null;
        }
        if (this.user != null && SplashManager.RANDOM.nextInt(this.splashes.size()) == 42) {
            return this.user.getName().toUpperCase(Locale.ROOT) + " IS YOU";
        }
        return this.splashes.get(SplashManager.RANDOM.nextInt(this.splashes.size()));
    }
    
    static {
        SPLASHES_LOCATION = new ResourceLocation("texts/splashes.txt");
        RANDOM = new Random();
    }
}
