package net.minecraft.client.resources.sounds;

import com.fox2code.repacker.*;
import net.minecraft.world.entity.vehicle.*;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;
import net.minecraft.util.*;

@ClientJarOnly
public class MinecartSoundInstance extends AbstractTickableSoundInstance
{
    private final AbstractMinecart minecart;
    private float pitch;
    
    public MinecartSoundInstance(final AbstractMinecart minecart) {
        super(SoundEvents.MINECART_RIDING, SoundSource.NEUTRAL);
        this.pitch = 0.0f;
        this.minecart = minecart;
        this.looping = true;
        this.delay = 0;
        this.volume = 0.0f;
        this.x = (float)minecart.x;
        this.y = (float)minecart.y;
        this.z = (float)minecart.z;
    }
    
    @Override
    public boolean canStartSilent() {
        return true;
    }
    
    @Override
    public void tick() {
        if (this.minecart.removed) {
            this.stopped = true;
            return;
        }
        this.x = (float)this.minecart.x;
        this.y = (float)this.minecart.y;
        this.z = (float)this.minecart.z;
        final float var1 = Mth.sqrt(Entity.getHorizontalDistanceSqr(this.minecart.getDeltaMovement()));
        if (var1 >= 0.01) {
            this.pitch = Mth.clamp(this.pitch + 0.0025f, 0.0f, 1.0f);
            this.volume = Mth.lerp(Mth.clamp(var1, 0.0f, 0.5f), 0.0f, 0.7f);
        }
        else {
            this.pitch = 0.0f;
            this.volume = 0.0f;
        }
    }
}
