package net.minecraft.client.renderer;

import com.fox2code.repacker.*;
import net.minecraft.core.*;
import net.minecraft.*;

@ClientJarOnly
public enum FaceInfo
{
    DOWN("DOWN", 0, new VertexInfo[] { new VertexInfo(Constants.MIN_X, Constants.MIN_Y, Constants.MAX_Z), new VertexInfo(Constants.MIN_X, Constants.MIN_Y, Constants.MIN_Z), new VertexInfo(Constants.MAX_X, Constants.MIN_Y, Constants.MIN_Z), new VertexInfo(Constants.MAX_X, Constants.MIN_Y, Constants.MAX_Z) }), 
    UP("UP", 1, new VertexInfo[] { new VertexInfo(Constants.MIN_X, Constants.MAX_Y, Constants.MIN_Z), new VertexInfo(Constants.MIN_X, Constants.MAX_Y, Constants.MAX_Z), new VertexInfo(Constants.MAX_X, Constants.MAX_Y, Constants.MAX_Z), new VertexInfo(Constants.MAX_X, Constants.MAX_Y, Constants.MIN_Z) }), 
    NORTH("NORTH", 2, new VertexInfo[] { new VertexInfo(Constants.MAX_X, Constants.MAX_Y, Constants.MIN_Z), new VertexInfo(Constants.MAX_X, Constants.MIN_Y, Constants.MIN_Z), new VertexInfo(Constants.MIN_X, Constants.MIN_Y, Constants.MIN_Z), new VertexInfo(Constants.MIN_X, Constants.MAX_Y, Constants.MIN_Z) }), 
    SOUTH("SOUTH", 3, new VertexInfo[] { new VertexInfo(Constants.MIN_X, Constants.MAX_Y, Constants.MAX_Z), new VertexInfo(Constants.MIN_X, Constants.MIN_Y, Constants.MAX_Z), new VertexInfo(Constants.MAX_X, Constants.MIN_Y, Constants.MAX_Z), new VertexInfo(Constants.MAX_X, Constants.MAX_Y, Constants.MAX_Z) }), 
    WEST("WEST", 4, new VertexInfo[] { new VertexInfo(Constants.MIN_X, Constants.MAX_Y, Constants.MIN_Z), new VertexInfo(Constants.MIN_X, Constants.MIN_Y, Constants.MIN_Z), new VertexInfo(Constants.MIN_X, Constants.MIN_Y, Constants.MAX_Z), new VertexInfo(Constants.MIN_X, Constants.MAX_Y, Constants.MAX_Z) }), 
    EAST("EAST", 5, new VertexInfo[] { new VertexInfo(Constants.MAX_X, Constants.MAX_Y, Constants.MAX_Z), new VertexInfo(Constants.MAX_X, Constants.MIN_Y, Constants.MAX_Z), new VertexInfo(Constants.MAX_X, Constants.MIN_Y, Constants.MIN_Z), new VertexInfo(Constants.MAX_X, Constants.MAX_Y, Constants.MIN_Z) });
    
    private static final FaceInfo[] BY_FACING;
    private final VertexInfo[] infos;
    
    public static FaceInfo fromFacing(final Direction facing) {
        return FaceInfo.BY_FACING[facing.get3DDataValue()];
    }
    
    private FaceInfo(final String s, final int n, final VertexInfo... infos) {
        this.infos = infos;
    }
    
    public VertexInfo getVertexInfo(final int i) {
        return this.infos[i];
    }
    
    static {
        BY_FACING = Util.make(new FaceInfo[6], faceInfos -> {
            faceInfos[Constants.MIN_Y] = FaceInfo.DOWN;
            faceInfos[Constants.MAX_Y] = FaceInfo.UP;
            faceInfos[Constants.MIN_Z] = FaceInfo.NORTH;
            faceInfos[Constants.MAX_Z] = FaceInfo.SOUTH;
            faceInfos[Constants.MIN_X] = FaceInfo.WEST;
            faceInfos[Constants.MAX_X] = FaceInfo.EAST;
        });
    }
    
    @ClientJarOnly
    public static final class Constants
    {
        public static final int MAX_Z;
        public static final int MAX_Y;
        public static final int MAX_X;
        public static final int MIN_Z;
        public static final int MIN_Y;
        public static final int MIN_X;
        
        static {
            MAX_Z = Direction.SOUTH.get3DDataValue();
            MAX_Y = Direction.UP.get3DDataValue();
            MAX_X = Direction.EAST.get3DDataValue();
            MIN_Z = Direction.NORTH.get3DDataValue();
            MIN_Y = Direction.DOWN.get3DDataValue();
            MIN_X = Direction.WEST.get3DDataValue();
        }
    }
    
    @ClientJarOnly
    public static class VertexInfo
    {
        public final int xFace;
        public final int yFace;
        public final int zFace;
        
        private VertexInfo(final int xFace, final int yFace, final int zFace) {
            this.xFace = xFace;
            this.yFace = yFace;
            this.zFace = zFace;
        }
    }
}
