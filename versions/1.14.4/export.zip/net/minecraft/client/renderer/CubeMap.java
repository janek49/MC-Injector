package net.minecraft.client.renderer;

import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import net.minecraft.client.*;
import com.mojang.blaze3d.platform.*;
import com.mojang.math.*;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.renderer.texture.*;
import java.util.concurrent.*;

@ClientJarOnly
public class CubeMap
{
    private final ResourceLocation[] images;
    
    public CubeMap(final ResourceLocation resourceLocation) {
        this.images = new ResourceLocation[6];
        for (int var2 = 0; var2 < 6; ++var2) {
            this.images[var2] = new ResourceLocation(resourceLocation.getNamespace(), resourceLocation.getPath() + '_' + var2 + ".png");
        }
    }
    
    public void render(final Minecraft minecraft, final float var2, final float var3, final float var4) {
        final Tesselator var5 = Tesselator.getInstance();
        final BufferBuilder var6 = var5.getBuilder();
        GlStateManager.matrixMode(5889);
        GlStateManager.pushMatrix();
        GlStateManager.loadIdentity();
        GlStateManager.multMatrix(Matrix4f.perspective(85.0, minecraft.window.getWidth() / (float)minecraft.window.getHeight(), 0.05f, 10.0f));
        GlStateManager.matrixMode(5888);
        GlStateManager.pushMatrix();
        GlStateManager.loadIdentity();
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.rotatef(180.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.enableBlend();
        GlStateManager.disableAlphaTest();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);
        GlStateManager.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        final int var7 = 2;
        for (int var8 = 0; var8 < 4; ++var8) {
            GlStateManager.pushMatrix();
            final float var9 = (var8 % 2 / 2.0f - 0.5f) / 256.0f;
            final float var10 = (var8 / 2 / 2.0f - 0.5f) / 256.0f;
            final float var11 = 0.0f;
            GlStateManager.translatef(var9, var10, 0.0f);
            GlStateManager.rotatef(var2, 1.0f, 0.0f, 0.0f);
            GlStateManager.rotatef(var3, 0.0f, 1.0f, 0.0f);
            for (int var12 = 0; var12 < 6; ++var12) {
                minecraft.getTextureManager().bind(this.images[var12]);
                var6.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
                final int var13 = Math.round(255.0f * var4) / (var8 + 1);
                if (var12 == 0) {
                    var6.vertex(-1.0, -1.0, 1.0).uv(0.0, 0.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(-1.0, 1.0, 1.0).uv(0.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(1.0, 1.0, 1.0).uv(1.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(1.0, -1.0, 1.0).uv(1.0, 0.0).color(255, 255, 255, var13).endVertex();
                }
                if (var12 == 1) {
                    var6.vertex(1.0, -1.0, 1.0).uv(0.0, 0.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(1.0, 1.0, 1.0).uv(0.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(1.0, 1.0, -1.0).uv(1.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(1.0, -1.0, -1.0).uv(1.0, 0.0).color(255, 255, 255, var13).endVertex();
                }
                if (var12 == 2) {
                    var6.vertex(1.0, -1.0, -1.0).uv(0.0, 0.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(1.0, 1.0, -1.0).uv(0.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(-1.0, 1.0, -1.0).uv(1.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(-1.0, -1.0, -1.0).uv(1.0, 0.0).color(255, 255, 255, var13).endVertex();
                }
                if (var12 == 3) {
                    var6.vertex(-1.0, -1.0, -1.0).uv(0.0, 0.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(-1.0, 1.0, -1.0).uv(0.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(-1.0, 1.0, 1.0).uv(1.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(-1.0, -1.0, 1.0).uv(1.0, 0.0).color(255, 255, 255, var13).endVertex();
                }
                if (var12 == 4) {
                    var6.vertex(-1.0, -1.0, -1.0).uv(0.0, 0.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(-1.0, -1.0, 1.0).uv(0.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(1.0, -1.0, 1.0).uv(1.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(1.0, -1.0, -1.0).uv(1.0, 0.0).color(255, 255, 255, var13).endVertex();
                }
                if (var12 == 5) {
                    var6.vertex(-1.0, 1.0, 1.0).uv(0.0, 0.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(-1.0, 1.0, -1.0).uv(0.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(1.0, 1.0, -1.0).uv(1.0, 1.0).color(255, 255, 255, var13).endVertex();
                    var6.vertex(1.0, 1.0, 1.0).uv(1.0, 0.0).color(255, 255, 255, var13).endVertex();
                }
                var5.end();
            }
            GlStateManager.popMatrix();
            GlStateManager.colorMask(true, true, true, false);
        }
        var6.offset(0.0, 0.0, 0.0);
        GlStateManager.colorMask(true, true, true, true);
        GlStateManager.matrixMode(5889);
        GlStateManager.popMatrix();
        GlStateManager.matrixMode(5888);
        GlStateManager.popMatrix();
        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.enableDepthTest();
    }
    
    public CompletableFuture<Void> preload(final TextureManager textureManager, final Executor executor) {
        final CompletableFuture<?>[] vars3 = (CompletableFuture<?>[])new CompletableFuture[6];
        for (int var4 = 0; var4 < vars3.length; ++var4) {
            vars3[var4] = textureManager.preload(this.images[var4], executor);
        }
        return CompletableFuture.allOf(vars3);
    }
}
