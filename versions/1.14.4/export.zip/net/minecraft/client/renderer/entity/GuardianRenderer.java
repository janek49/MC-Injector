package net.minecraft.client.renderer.entity;

import net.minecraft.world.entity.monster.*;
import net.minecraft.client.model.*;
import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import net.minecraft.client.renderer.culling.*;
import net.minecraft.world.phys.*;
import net.minecraft.util.*;
import com.mojang.blaze3d.platform.*;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.world.entity.*;

@ClientJarOnly
public class GuardianRenderer extends MobRenderer<Guardian, GuardianModel>
{
    private static final ResourceLocation GUARDIAN_LOCATION;
    private static final ResourceLocation GUARDIAN_BEAM_LOCATION;
    
    public GuardianRenderer(final EntityRenderDispatcher entityRenderDispatcher) {
        this(entityRenderDispatcher, 0.5f);
    }
    
    protected GuardianRenderer(final EntityRenderDispatcher entityRenderDispatcher, final float var2) {
        super(entityRenderDispatcher, new GuardianModel(), var2);
    }
    
    @Override
    public boolean shouldRender(final Guardian guardian, final Culler culler, final double var3, final double var5, final double var7) {
        if (super.shouldRender(guardian, culler, var3, var5, var7)) {
            return true;
        }
        if (guardian.hasActiveAttackTarget()) {
            final LivingEntity var8 = guardian.getActiveAttackTarget();
            if (var8 != null) {
                final Vec3 var9 = this.getPosition(var8, var8.getBbHeight() * 0.5, 1.0f);
                final Vec3 var10 = this.getPosition(guardian, guardian.getEyeHeight(), 1.0f);
                if (culler.isVisible(new AABB(var10.x, var10.y, var10.z, var9.x, var9.y, var9.z))) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private Vec3 getPosition(final LivingEntity livingEntity, final double var2, final float var4) {
        final double var5 = Mth.lerp(var4, livingEntity.xOld, livingEntity.x);
        final double var6 = Mth.lerp(var4, livingEntity.yOld, livingEntity.y) + var2;
        final double var7 = Mth.lerp(var4, livingEntity.zOld, livingEntity.z);
        return new Vec3(var5, var6, var7);
    }
    
    @Override
    public void render(final Guardian guardian, final double var2, final double var4, final double var6, final float var8, final float var9) {
        super.render(guardian, var2, var4, var6, var8, var9);
        final LivingEntity var10 = guardian.getActiveAttackTarget();
        if (var10 != null) {
            final float var11 = guardian.getAttackAnimationScale(var9);
            final Tesselator var12 = Tesselator.getInstance();
            final BufferBuilder var13 = var12.getBuilder();
            this.bindTexture(GuardianRenderer.GUARDIAN_BEAM_LOCATION);
            GlStateManager.texParameter(3553, 10242, 10497);
            GlStateManager.texParameter(3553, 10243, 10497);
            GlStateManager.disableLighting();
            GlStateManager.disableCull();
            GlStateManager.disableBlend();
            GlStateManager.depthMask(true);
            final float var14 = 240.0f;
            GLX.glMultiTexCoord2f(GLX.GL_TEXTURE1, 240.0f, 240.0f);
            GlStateManager.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            final float var15 = guardian.level.getGameTime() + var9;
            final float var16 = var15 * 0.5f % 1.0f;
            final float var17 = guardian.getEyeHeight();
            GlStateManager.pushMatrix();
            GlStateManager.translatef((float)var2, (float)var4 + var17, (float)var6);
            final Vec3 var18 = this.getPosition(var10, var10.getBbHeight() * 0.5, var9);
            final Vec3 var19 = this.getPosition(guardian, var17, var9);
            Vec3 var20 = var18.subtract(var19);
            final double var21 = var20.length() + 1.0;
            var20 = var20.normalize();
            final float var22 = (float)Math.acos(var20.y);
            final float var23 = (float)Math.atan2(var20.z, var20.x);
            GlStateManager.rotatef((1.5707964f - var23) * 57.295776f, 0.0f, 1.0f, 0.0f);
            GlStateManager.rotatef(var22 * 57.295776f, 1.0f, 0.0f, 0.0f);
            final int var24 = 1;
            final double var25 = var15 * 0.05 * -1.5;
            var13.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
            final float var26 = var11 * var11;
            final int var27 = 64 + (int)(var26 * 191.0f);
            final int var28 = 32 + (int)(var26 * 191.0f);
            final int var29 = 128 - (int)(var26 * 64.0f);
            final double var30 = 0.2;
            final double var31 = 0.282;
            final double var32 = 0.0 + Math.cos(var25 + 2.356194490192345) * 0.282;
            final double var33 = 0.0 + Math.sin(var25 + 2.356194490192345) * 0.282;
            final double var34 = 0.0 + Math.cos(var25 + 0.7853981633974483) * 0.282;
            final double var35 = 0.0 + Math.sin(var25 + 0.7853981633974483) * 0.282;
            final double var36 = 0.0 + Math.cos(var25 + 3.9269908169872414) * 0.282;
            final double var37 = 0.0 + Math.sin(var25 + 3.9269908169872414) * 0.282;
            final double var38 = 0.0 + Math.cos(var25 + 5.497787143782138) * 0.282;
            final double var39 = 0.0 + Math.sin(var25 + 5.497787143782138) * 0.282;
            final double var40 = 0.0 + Math.cos(var25 + 3.141592653589793) * 0.2;
            final double var41 = 0.0 + Math.sin(var25 + 3.141592653589793) * 0.2;
            final double var42 = 0.0 + Math.cos(var25 + 0.0) * 0.2;
            final double var43 = 0.0 + Math.sin(var25 + 0.0) * 0.2;
            final double var44 = 0.0 + Math.cos(var25 + 1.5707963267948966) * 0.2;
            final double var45 = 0.0 + Math.sin(var25 + 1.5707963267948966) * 0.2;
            final double var46 = 0.0 + Math.cos(var25 + 4.71238898038469) * 0.2;
            final double var47 = 0.0 + Math.sin(var25 + 4.71238898038469) * 0.2;
            final double var48 = var21;
            final double var49 = 0.0;
            final double var50 = 0.4999;
            final double var51 = -1.0f + var16;
            final double var52 = var21 * 2.5 + var51;
            var13.vertex(var40, var48, var41).uv(0.4999, var52).color(var27, var28, var29, 255).endVertex();
            var13.vertex(var40, 0.0, var41).uv(0.4999, var51).color(var27, var28, var29, 255).endVertex();
            var13.vertex(var42, 0.0, var43).uv(0.0, var51).color(var27, var28, var29, 255).endVertex();
            var13.vertex(var42, var48, var43).uv(0.0, var52).color(var27, var28, var29, 255).endVertex();
            var13.vertex(var44, var48, var45).uv(0.4999, var52).color(var27, var28, var29, 255).endVertex();
            var13.vertex(var44, 0.0, var45).uv(0.4999, var51).color(var27, var28, var29, 255).endVertex();
            var13.vertex(var46, 0.0, var47).uv(0.0, var51).color(var27, var28, var29, 255).endVertex();
            var13.vertex(var46, var48, var47).uv(0.0, var52).color(var27, var28, var29, 255).endVertex();
            double var53 = 0.0;
            if (guardian.tickCount % 2 == 0) {
                var53 = 0.5;
            }
            var13.vertex(var32, var48, var33).uv(0.5, var53 + 0.5).color(var27, var28, var29, 255).endVertex();
            var13.vertex(var34, var48, var35).uv(1.0, var53 + 0.5).color(var27, var28, var29, 255).endVertex();
            var13.vertex(var38, var48, var39).uv(1.0, var53).color(var27, var28, var29, 255).endVertex();
            var13.vertex(var36, var48, var37).uv(0.5, var53).color(var27, var28, var29, 255).endVertex();
            var12.end();
            GlStateManager.popMatrix();
        }
    }
    
    protected ResourceLocation getTextureLocation(final Guardian guardian) {
        return GuardianRenderer.GUARDIAN_LOCATION;
    }
    
    static {
        GUARDIAN_LOCATION = new ResourceLocation("textures/entity/guardian.png");
        GUARDIAN_BEAM_LOCATION = new ResourceLocation("textures/entity/guardian_beam.png");
    }
}
