package net.minecraft.client.renderer.entity;

import com.fox2code.repacker.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.util.*;
import com.mojang.blaze3d.platform.*;
import net.minecraft.client.*;
import net.minecraft.world.level.block.*;
import net.minecraft.client.renderer.block.*;
import net.minecraft.world.entity.vehicle.*;

@ClientJarOnly
public class TntMinecartRenderer extends MinecartRenderer<MinecartTNT>
{
    public TntMinecartRenderer(final EntityRenderDispatcher entityRenderDispatcher) {
        super(entityRenderDispatcher);
    }
    
    @Override
    protected void renderMinecartContents(final MinecartTNT minecartTNT, final float var2, final BlockState blockState) {
        final int var3 = minecartTNT.getFuse();
        if (var3 > -1 && var3 - var2 + 1.0f < 10.0f) {
            float var4 = 1.0f - (var3 - var2 + 1.0f) / 10.0f;
            var4 = Mth.clamp(var4, 0.0f, 1.0f);
            var4 *= var4;
            var4 *= var4;
            final float var5 = 1.0f + var4 * 0.3f;
            GlStateManager.scalef(var5, var5, var5);
        }
        super.renderMinecartContents(minecartTNT, var2, blockState);
        if (var3 > -1 && var3 / 5 % 2 == 0) {
            final BlockRenderDispatcher var6 = Minecraft.getInstance().getBlockRenderer();
            GlStateManager.disableTexture();
            GlStateManager.disableLighting();
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.DST_ALPHA);
            GlStateManager.color4f(1.0f, 1.0f, 1.0f, (1.0f - (var3 - var2 + 1.0f) / 100.0f) * 0.8f);
            GlStateManager.pushMatrix();
            var6.renderSingleBlock(Blocks.TNT.defaultBlockState(), 1.0f);
            GlStateManager.popMatrix();
            GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.disableBlend();
            GlStateManager.enableLighting();
            GlStateManager.enableTexture();
        }
    }
}
