package net.minecraft.client.renderer.entity.layers;

import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import java.util.*;
import net.minecraft.client.renderer.entity.*;
import com.mojang.blaze3d.platform.*;
import net.minecraft.client.model.*;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.*;
import javax.annotation.*;
import java.util.function.*;
import com.google.common.collect.*;

@ClientJarOnly
public abstract class AbstractArmorLayer<T extends LivingEntity, M extends HumanoidModel<T>, A extends HumanoidModel<T>> extends RenderLayer<T, M>
{
    protected static final ResourceLocation ENCHANT_GLINT_LOCATION;
    protected final A innerModel;
    protected final A outerModel;
    private float alpha;
    private float red;
    private float green;
    private float blue;
    private boolean colorized;
    private static final Map<String, ResourceLocation> ARMOR_LOCATION_CACHE;
    
    protected AbstractArmorLayer(final RenderLayerParent<T, M> renderLayerParent, final A innerModel, final A outerModel) {
        super(renderLayerParent);
        this.alpha = 1.0f;
        this.red = 1.0f;
        this.green = 1.0f;
        this.blue = 1.0f;
        this.innerModel = innerModel;
        this.outerModel = outerModel;
    }
    
    @Override
    public void render(final T livingEntity, final float var2, final float var3, final float var4, final float var5, final float var6, final float var7, final float var8) {
        this.renderArmorPiece(livingEntity, var2, var3, var4, var5, var6, var7, var8, EquipmentSlot.CHEST);
        this.renderArmorPiece(livingEntity, var2, var3, var4, var5, var6, var7, var8, EquipmentSlot.LEGS);
        this.renderArmorPiece(livingEntity, var2, var3, var4, var5, var6, var7, var8, EquipmentSlot.FEET);
        this.renderArmorPiece(livingEntity, var2, var3, var4, var5, var6, var7, var8, EquipmentSlot.HEAD);
    }
    
    @Override
    public boolean colorsOnDamage() {
        return false;
    }
    
    private void renderArmorPiece(final T livingEntity, final float var2, final float var3, final float var4, final float var5, final float var6, final float var7, final float var8, final EquipmentSlot equipmentSlot) {
        final ItemStack var9 = livingEntity.getItemBySlot(equipmentSlot);
        if (!(var9.getItem() instanceof ArmorItem)) {
            return;
        }
        final ArmorItem var10 = (ArmorItem)var9.getItem();
        if (var10.getSlot() != equipmentSlot) {
            return;
        }
        final A var11 = this.getArmorModel(equipmentSlot);
        this.getParentModel().copyPropertiesTo(var11);
        var11.prepareMobModel(livingEntity, var2, var3, var4);
        this.setPartVisibility(var11, equipmentSlot);
        final boolean var12 = this.usesInnerModel(equipmentSlot);
        this.bindTexture(this.getArmorLocation(var10, var12));
        if (var10 instanceof DyeableArmorItem) {
            final int var13 = ((DyeableArmorItem)var10).getColor(var9);
            final float var14 = (var13 >> 16 & 0xFF) / 255.0f;
            final float var15 = (var13 >> 8 & 0xFF) / 255.0f;
            final float var16 = (var13 & 0xFF) / 255.0f;
            GlStateManager.color4f(this.red * var14, this.green * var15, this.blue * var16, this.alpha);
            var11.render(livingEntity, var2, var3, var5, var6, var7, var8);
            this.bindTexture(this.getArmorLocation(var10, var12, "overlay"));
        }
        GlStateManager.color4f(this.red, this.green, this.blue, this.alpha);
        var11.render(livingEntity, var2, var3, var5, var6, var7, var8);
        if (!this.colorized && var9.isEnchanted()) {
            renderFoil(this::bindTexture, livingEntity, var11, var2, var3, var4, var5, var6, var7, var8);
        }
    }
    
    public A getArmorModel(final EquipmentSlot equipmentSlot) {
        return this.usesInnerModel(equipmentSlot) ? this.innerModel : this.outerModel;
    }
    
    private boolean usesInnerModel(final EquipmentSlot equipmentSlot) {
        return equipmentSlot == EquipmentSlot.LEGS;
    }
    
    public static <T extends Entity> void renderFoil(final Consumer<ResourceLocation> consumer, final T entity, final EntityModel<T> entityModel, final float var3, final float var4, final float var5, final float var6, final float var7, final float var8, final float var9) {
        final float var10 = entity.tickCount + var5;
        consumer.accept(AbstractArmorLayer.ENCHANT_GLINT_LOCATION);
        final GameRenderer var11 = Minecraft.getInstance().gameRenderer;
        var11.resetFogColor(true);
        GlStateManager.enableBlend();
        GlStateManager.depthFunc(514);
        GlStateManager.depthMask(false);
        final float var12 = 0.5f;
        GlStateManager.color4f(0.5f, 0.5f, 0.5f, 1.0f);
        for (int var13 = 0; var13 < 2; ++var13) {
            GlStateManager.disableLighting();
            GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_COLOR, GlStateManager.DestFactor.ONE);
            final float var14 = 0.76f;
            GlStateManager.color4f(0.38f, 0.19f, 0.608f, 1.0f);
            GlStateManager.matrixMode(5890);
            GlStateManager.loadIdentity();
            final float var15 = 0.33333334f;
            GlStateManager.scalef(0.33333334f, 0.33333334f, 0.33333334f);
            GlStateManager.rotatef(30.0f - var13 * 60.0f, 0.0f, 0.0f, 1.0f);
            GlStateManager.translatef(0.0f, var10 * (0.001f + var13 * 0.003f) * 20.0f, 0.0f);
            GlStateManager.matrixMode(5888);
            entityModel.render(entity, var3, var4, var6, var7, var8, var9);
            GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        }
        GlStateManager.matrixMode(5890);
        GlStateManager.loadIdentity();
        GlStateManager.matrixMode(5888);
        GlStateManager.enableLighting();
        GlStateManager.depthMask(true);
        GlStateManager.depthFunc(515);
        GlStateManager.disableBlend();
        var11.resetFogColor(false);
    }
    
    private ResourceLocation getArmorLocation(final ArmorItem armorItem, final boolean var2) {
        return this.getArmorLocation(armorItem, var2, null);
    }
    
    private ResourceLocation getArmorLocation(final ArmorItem armorItem, final boolean var2, @Nullable final String string) {
        final String string2 = "textures/models/armor/" + armorItem.getMaterial().getName() + "_layer_" + (var2 ? 2 : 1) + ((string == null) ? "" : ("_" + string)) + ".png";
        return AbstractArmorLayer.ARMOR_LOCATION_CACHE.computeIfAbsent(string2, ResourceLocation::new);
    }
    
    protected abstract void setPartVisibility(final A p0, final EquipmentSlot p1);
    
    protected abstract void hideAllArmor(final A p0);
    
    static {
        ENCHANT_GLINT_LOCATION = new ResourceLocation("textures/misc/enchanted_item_glint.png");
        ARMOR_LOCATION_CACHE = Maps.newHashMap();
    }
}
