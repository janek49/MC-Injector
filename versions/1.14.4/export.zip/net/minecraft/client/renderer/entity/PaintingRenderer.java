package net.minecraft.client.renderer.entity;

import com.fox2code.repacker.*;
import net.minecraft.client.*;
import net.minecraft.world.entity.decoration.*;
import net.minecraft.client.resources.*;
import net.minecraft.resources.*;
import net.minecraft.client.renderer.texture.*;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.util.*;
import net.minecraft.core.*;
import com.mojang.blaze3d.platform.*;
import net.minecraft.world.entity.*;

@ClientJarOnly
public class PaintingRenderer extends EntityRenderer<Painting>
{
    public PaintingRenderer(final EntityRenderDispatcher entityRenderDispatcher) {
        super(entityRenderDispatcher);
    }
    
    @Override
    public void render(final Painting painting, final double var2, final double var4, final double var6, final float var8, final float var9) {
        GlStateManager.pushMatrix();
        GlStateManager.translated(var2, var4, var6);
        GlStateManager.rotatef(180.0f - var8, 0.0f, 1.0f, 0.0f);
        GlStateManager.enableRescaleNormal();
        this.bindTexture(painting);
        final Motive var10 = painting.motive;
        final float var11 = 0.0625f;
        GlStateManager.scalef(0.0625f, 0.0625f, 0.0625f);
        if (this.solidRender) {
            GlStateManager.enableColorMaterial();
            GlStateManager.setupSolidRenderingTextureCombine(this.getTeamColor(painting));
        }
        final PaintingTextureManager var12 = Minecraft.getInstance().getPaintingTextures();
        this.renderPainting(painting, var10.getWidth(), var10.getHeight(), var12.get(var10), var12.getBackSprite());
        if (this.solidRender) {
            GlStateManager.tearDownSolidRenderingTextureCombine();
            GlStateManager.disableColorMaterial();
        }
        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
        super.render(painting, var2, var4, var6, var8, var9);
    }
    
    @Override
    protected ResourceLocation getTextureLocation(final Painting painting) {
        return TextureAtlas.LOCATION_PAINTINGS;
    }
    
    private void renderPainting(final Painting painting, final int var2, final int var3, final TextureAtlasSprite var4, final TextureAtlasSprite var5) {
        final float var6 = -var2 / 2.0f;
        final float var7 = -var3 / 2.0f;
        final float var8 = 0.5f;
        final float var9 = var5.getU0();
        final float var10 = var5.getU1();
        final float var11 = var5.getV0();
        final float var12 = var5.getV1();
        final float var13 = var5.getU0();
        final float var14 = var5.getU1();
        final float var15 = var5.getV0();
        final float var16 = var5.getV(1.0);
        final float var17 = var5.getU0();
        final float var18 = var5.getU(1.0);
        final float var19 = var5.getV0();
        final float var20 = var5.getV1();
        final int var21 = var2 / 16;
        final int var22 = var3 / 16;
        final double var23 = 16.0 / var21;
        final double var24 = 16.0 / var22;
        for (int var25 = 0; var25 < var21; ++var25) {
            for (int var26 = 0; var26 < var22; ++var26) {
                final float var27 = var6 + (var25 + 1) * 16;
                final float var28 = var6 + var25 * 16;
                final float var29 = var7 + (var26 + 1) * 16;
                final float var30 = var7 + var26 * 16;
                this.setBrightness(painting, (var27 + var28) / 2.0f, (var29 + var30) / 2.0f);
                final float var31 = var4.getU(var23 * (var21 - var25));
                final float var32 = var4.getU(var23 * (var21 - (var25 + 1)));
                final float var33 = var4.getV(var24 * (var22 - var26));
                final float var34 = var4.getV(var24 * (var22 - (var26 + 1)));
                final Tesselator var35 = Tesselator.getInstance();
                final BufferBuilder var36 = var35.getBuilder();
                var36.begin(7, DefaultVertexFormat.POSITION_TEX_NORMAL);
                var36.vertex(var27, var30, -0.5).uv(var32, var33).normal(0.0f, 0.0f, -1.0f).endVertex();
                var36.vertex(var28, var30, -0.5).uv(var31, var33).normal(0.0f, 0.0f, -1.0f).endVertex();
                var36.vertex(var28, var29, -0.5).uv(var31, var34).normal(0.0f, 0.0f, -1.0f).endVertex();
                var36.vertex(var27, var29, -0.5).uv(var32, var34).normal(0.0f, 0.0f, -1.0f).endVertex();
                var36.vertex(var27, var29, 0.5).uv(var9, var11).normal(0.0f, 0.0f, 1.0f).endVertex();
                var36.vertex(var28, var29, 0.5).uv(var10, var11).normal(0.0f, 0.0f, 1.0f).endVertex();
                var36.vertex(var28, var30, 0.5).uv(var10, var12).normal(0.0f, 0.0f, 1.0f).endVertex();
                var36.vertex(var27, var30, 0.5).uv(var9, var12).normal(0.0f, 0.0f, 1.0f).endVertex();
                var36.vertex(var27, var29, -0.5).uv(var13, var15).normal(0.0f, 1.0f, 0.0f).endVertex();
                var36.vertex(var28, var29, -0.5).uv(var14, var15).normal(0.0f, 1.0f, 0.0f).endVertex();
                var36.vertex(var28, var29, 0.5).uv(var14, var16).normal(0.0f, 1.0f, 0.0f).endVertex();
                var36.vertex(var27, var29, 0.5).uv(var13, var16).normal(0.0f, 1.0f, 0.0f).endVertex();
                var36.vertex(var27, var30, 0.5).uv(var13, var15).normal(0.0f, -1.0f, 0.0f).endVertex();
                var36.vertex(var28, var30, 0.5).uv(var14, var15).normal(0.0f, -1.0f, 0.0f).endVertex();
                var36.vertex(var28, var30, -0.5).uv(var14, var16).normal(0.0f, -1.0f, 0.0f).endVertex();
                var36.vertex(var27, var30, -0.5).uv(var13, var16).normal(0.0f, -1.0f, 0.0f).endVertex();
                var36.vertex(var27, var29, 0.5).uv(var18, var19).normal(-1.0f, 0.0f, 0.0f).endVertex();
                var36.vertex(var27, var30, 0.5).uv(var18, var20).normal(-1.0f, 0.0f, 0.0f).endVertex();
                var36.vertex(var27, var30, -0.5).uv(var17, var20).normal(-1.0f, 0.0f, 0.0f).endVertex();
                var36.vertex(var27, var29, -0.5).uv(var17, var19).normal(-1.0f, 0.0f, 0.0f).endVertex();
                var36.vertex(var28, var29, -0.5).uv(var18, var19).normal(1.0f, 0.0f, 0.0f).endVertex();
                var36.vertex(var28, var30, -0.5).uv(var18, var20).normal(1.0f, 0.0f, 0.0f).endVertex();
                var36.vertex(var28, var30, 0.5).uv(var17, var20).normal(1.0f, 0.0f, 0.0f).endVertex();
                var36.vertex(var28, var29, 0.5).uv(var17, var19).normal(1.0f, 0.0f, 0.0f).endVertex();
                var35.end();
            }
        }
    }
    
    private void setBrightness(final Painting painting, final float var2, final float var3) {
        int var4 = Mth.floor(painting.x);
        final int var5 = Mth.floor(painting.y + var3 / 16.0f);
        int var6 = Mth.floor(painting.z);
        final Direction var7 = painting.getDirection();
        if (var7 == Direction.NORTH) {
            var4 = Mth.floor(painting.x + var2 / 16.0f);
        }
        if (var7 == Direction.WEST) {
            var6 = Mth.floor(painting.z - var2 / 16.0f);
        }
        if (var7 == Direction.SOUTH) {
            var4 = Mth.floor(painting.x - var2 / 16.0f);
        }
        if (var7 == Direction.EAST) {
            var6 = Mth.floor(painting.z + var2 / 16.0f);
        }
        final int var8 = this.entityRenderDispatcher.level.getLightColor(new BlockPos(var4, var5, var6), 0);
        final int var9 = var8 % 65536;
        final int var10 = var8 / 65536;
        GLX.glMultiTexCoord2f(GLX.GL_TEXTURE1, (float)var9, (float)var10);
        GlStateManager.color3f(1.0f, 1.0f, 1.0f);
    }
}
