package net.minecraft.client.renderer.entity;

import net.minecraft.world.entity.animal.*;
import net.minecraft.client.model.*;
import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import javax.annotation.*;
import net.minecraft.util.*;
import com.mojang.blaze3d.platform.*;
import net.minecraft.world.entity.*;

@ClientJarOnly
public class SalmonRenderer extends MobRenderer<Salmon, SalmonModel<Salmon>>
{
    private static final ResourceLocation SALMON_LOCATION;
    
    public SalmonRenderer(final EntityRenderDispatcher entityRenderDispatcher) {
        super(entityRenderDispatcher, new SalmonModel(), 0.4f);
    }
    
    @Nullable
    protected ResourceLocation getTextureLocation(final Salmon salmon) {
        return SalmonRenderer.SALMON_LOCATION;
    }
    
    @Override
    protected void setupRotations(final Salmon salmon, final float var2, final float var3, final float var4) {
        super.setupRotations(salmon, var2, var3, var4);
        float var5 = 1.0f;
        float var6 = 1.0f;
        if (!salmon.isInWater()) {
            var5 = 1.3f;
            var6 = 1.7f;
        }
        final float var7 = var5 * 4.3f * Mth.sin(var6 * 0.6f * var2);
        GlStateManager.rotatef(var7, 0.0f, 1.0f, 0.0f);
        GlStateManager.translatef(0.0f, 0.0f, -0.4f);
        if (!salmon.isInWater()) {
            GlStateManager.translatef(0.2f, 0.1f, 0.0f);
            GlStateManager.rotatef(90.0f, 0.0f, 0.0f, 1.0f);
        }
    }
    
    static {
        SALMON_LOCATION = new ResourceLocation("textures/entity/fish/salmon.png");
    }
}
