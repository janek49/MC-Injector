package net.minecraft.client.renderer.entity;

import net.minecraft.world.entity.animal.*;
import net.minecraft.client.model.*;
import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import net.minecraft.client.renderer.entity.layers.*;
import javax.annotation.*;
import com.mojang.blaze3d.platform.*;
import net.minecraft.util.*;
import net.minecraft.world.entity.*;
import java.util.*;
import com.google.common.collect.*;
import net.minecraft.*;

@ClientJarOnly
public class PandaRenderer extends MobRenderer<Panda, PandaModel<Panda>>
{
    private static final Map<Panda.Gene, ResourceLocation> TEXTURES;
    
    public PandaRenderer(final EntityRenderDispatcher entityRenderDispatcher) {
        super(entityRenderDispatcher, new PandaModel(9, 0.0f), 0.9f);
        this.addLayer(new PandaHoldsItemLayer(this));
    }
    
    @Nullable
    protected ResourceLocation getTextureLocation(final Panda panda) {
        return PandaRenderer.TEXTURES.getOrDefault(panda.getVariant(), PandaRenderer.TEXTURES.get(Panda.Gene.NORMAL));
    }
    
    @Override
    protected void setupRotations(final Panda panda, final float var2, final float var3, final float var4) {
        super.setupRotations(panda, var2, var3, var4);
        if (panda.rollCounter > 0) {
            final int var5 = panda.rollCounter;
            final int var6 = var5 + 1;
            final float var7 = 7.0f;
            final float var8 = panda.isBaby() ? 0.3f : 0.8f;
            if (var5 < 8) {
                final float var9 = 90 * var5 / 7.0f;
                final float var10 = 90 * var6 / 7.0f;
                final float var11 = this.getAngle(var9, var10, var6, var4, 8.0f);
                GlStateManager.translatef(0.0f, (var8 + 0.2f) * (var11 / 90.0f), 0.0f);
                GlStateManager.rotatef(-var11, 1.0f, 0.0f, 0.0f);
            }
            else if (var5 < 16) {
                final float var9 = (var5 - 8.0f) / 7.0f;
                final float var10 = 90.0f + 90.0f * var9;
                final float var12 = 90.0f + 90.0f * (var6 - 8.0f) / 7.0f;
                final float var11 = this.getAngle(var10, var12, var6, var4, 16.0f);
                GlStateManager.translatef(0.0f, var8 + 0.2f + (var8 - 0.2f) * (var11 - 90.0f) / 90.0f, 0.0f);
                GlStateManager.rotatef(-var11, 1.0f, 0.0f, 0.0f);
            }
            else if (var5 < 24.0f) {
                final float var9 = (var5 - 16.0f) / 7.0f;
                final float var10 = 180.0f + 90.0f * var9;
                final float var12 = 180.0f + 90.0f * (var6 - 16.0f) / 7.0f;
                final float var11 = this.getAngle(var10, var12, var6, var4, 24.0f);
                GlStateManager.translatef(0.0f, var8 + var8 * (270.0f - var11) / 90.0f, 0.0f);
                GlStateManager.rotatef(-var11, 1.0f, 0.0f, 0.0f);
            }
            else if (var5 < 32) {
                final float var9 = (var5 - 24.0f) / 7.0f;
                final float var10 = 270.0f + 90.0f * var9;
                final float var12 = 270.0f + 90.0f * (var6 - 24.0f) / 7.0f;
                final float var11 = this.getAngle(var10, var12, var6, var4, 32.0f);
                GlStateManager.translatef(0.0f, var8 * ((360.0f - var11) / 90.0f), 0.0f);
                GlStateManager.rotatef(-var11, 1.0f, 0.0f, 0.0f);
            }
        }
        else {
            GlStateManager.rotatef(0.0f, 1.0f, 0.0f, 0.0f);
        }
        final float var13 = panda.getSitAmount(var4);
        if (var13 > 0.0f) {
            GlStateManager.translatef(0.0f, 0.8f * var13, 0.0f);
            GlStateManager.rotatef(Mth.lerp(var13, panda.xRot, panda.xRot + 90.0f), 1.0f, 0.0f, 0.0f);
            GlStateManager.translatef(0.0f, -1.0f * var13, 0.0f);
            if (panda.isScared()) {
                final float var14 = (float)(Math.cos(panda.tickCount * 1.25) * 3.141592653589793 * 0.05000000074505806);
                GlStateManager.rotatef(var14, 0.0f, 1.0f, 0.0f);
                if (panda.isBaby()) {
                    GlStateManager.translatef(0.0f, 0.8f, 0.55f);
                }
            }
        }
        final float var14 = panda.getLieOnBackAmount(var4);
        if (var14 > 0.0f) {
            final float var7 = panda.isBaby() ? 0.5f : 1.3f;
            GlStateManager.translatef(0.0f, var7 * var14, 0.0f);
            GlStateManager.rotatef(Mth.lerp(var14, panda.xRot, panda.xRot + 180.0f), 1.0f, 0.0f, 0.0f);
        }
    }
    
    private float getAngle(final float var1, final float var2, final int var3, final float var4, final float var5) {
        if (var3 < var5) {
            return Mth.lerp(var4, var1, var2);
        }
        return var1;
    }
    
    static {
        TEXTURES = Util.make((Map<Panda.Gene, ResourceLocation>)Maps.newEnumMap((Class)Panda.Gene.class), enumMap -> {
            enumMap.put(Panda.Gene.NORMAL, new ResourceLocation("textures/entity/panda/panda.png"));
            enumMap.put(Panda.Gene.LAZY, new ResourceLocation("textures/entity/panda/lazy_panda.png"));
            enumMap.put(Panda.Gene.WORRIED, new ResourceLocation("textures/entity/panda/worried_panda.png"));
            enumMap.put(Panda.Gene.PLAYFUL, new ResourceLocation("textures/entity/panda/playful_panda.png"));
            enumMap.put(Panda.Gene.BROWN, new ResourceLocation("textures/entity/panda/brown_panda.png"));
            enumMap.put(Panda.Gene.WEAK, new ResourceLocation("textures/entity/panda/weak_panda.png"));
            enumMap.put(Panda.Gene.AGGRESSIVE, new ResourceLocation("textures/entity/panda/aggressive_panda.png"));
        });
    }
}
