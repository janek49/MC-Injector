package net.minecraft.client.renderer.entity;

import net.minecraft.world.entity.boss.enderdragon.*;
import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import net.minecraft.client.model.*;
import net.minecraft.client.model.dragon.*;
import com.mojang.blaze3d.platform.*;
import net.minecraft.util.*;
import net.minecraft.core.*;
import net.minecraft.client.renderer.culling.*;
import net.minecraft.world.entity.*;

@ClientJarOnly
public class EndCrystalRenderer extends EntityRenderer<EndCrystal>
{
    private static final ResourceLocation END_CRYSTAL_LOCATION;
    private final EntityModel<EndCrystal> model;
    private final EntityModel<EndCrystal> modelWithoutBottom;
    
    public EndCrystalRenderer(final EntityRenderDispatcher entityRenderDispatcher) {
        super(entityRenderDispatcher);
        this.model = new EndCrystalModel<EndCrystal>(0.0f, true);
        this.modelWithoutBottom = new EndCrystalModel<EndCrystal>(0.0f, false);
        this.shadowRadius = 0.5f;
    }
    
    @Override
    public void render(final EndCrystal endCrystal, final double var2, final double var4, final double var6, final float var8, final float var9) {
        final float var10 = endCrystal.time + var9;
        GlStateManager.pushMatrix();
        GlStateManager.translatef((float)var2, (float)var4, (float)var6);
        this.bindTexture(EndCrystalRenderer.END_CRYSTAL_LOCATION);
        float var11 = Mth.sin(var10 * 0.2f) / 2.0f + 0.5f;
        var11 += var11 * var11;
        if (this.solidRender) {
            GlStateManager.enableColorMaterial();
            GlStateManager.setupSolidRenderingTextureCombine(this.getTeamColor(endCrystal));
        }
        if (endCrystal.showsBottom()) {
            this.model.render(endCrystal, 0.0f, var10 * 3.0f, var11 * 0.2f, 0.0f, 0.0f, 0.0625f);
        }
        else {
            this.modelWithoutBottom.render(endCrystal, 0.0f, var10 * 3.0f, var11 * 0.2f, 0.0f, 0.0f, 0.0625f);
        }
        if (this.solidRender) {
            GlStateManager.tearDownSolidRenderingTextureCombine();
            GlStateManager.disableColorMaterial();
        }
        GlStateManager.popMatrix();
        final BlockPos var12 = endCrystal.getBeamTarget();
        if (var12 != null) {
            this.bindTexture(EnderDragonRenderer.CRYSTAL_BEAM_LOCATION);
            final float var13 = var12.getX() + 0.5f;
            final float var14 = var12.getY() + 0.5f;
            final float var15 = var12.getZ() + 0.5f;
            final double var16 = var13 - endCrystal.x;
            final double var17 = var14 - endCrystal.y;
            final double var18 = var15 - endCrystal.z;
            EnderDragonRenderer.renderCrystalBeams(var2 + var16, var4 - 0.3 + var11 * 0.4f + var17, var6 + var18, var9, var13, var14, var15, endCrystal.time, endCrystal.x, endCrystal.y, endCrystal.z);
        }
        super.render(endCrystal, var2, var4, var6, var8, var9);
    }
    
    @Override
    protected ResourceLocation getTextureLocation(final EndCrystal endCrystal) {
        return EndCrystalRenderer.END_CRYSTAL_LOCATION;
    }
    
    @Override
    public boolean shouldRender(final EndCrystal endCrystal, final Culler culler, final double var3, final double var5, final double var7) {
        return super.shouldRender(endCrystal, culler, var3, var5, var7) || endCrystal.getBeamTarget() != null;
    }
    
    static {
        END_CRYSTAL_LOCATION = new ResourceLocation("textures/entity/end_crystal/end_crystal.png");
    }
}
