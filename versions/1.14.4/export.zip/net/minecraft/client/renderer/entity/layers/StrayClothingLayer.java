package net.minecraft.client.renderer.entity.layers;

import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import net.minecraft.client.model.*;
import net.minecraft.client.renderer.entity.*;
import com.mojang.blaze3d.platform.*;
import net.minecraft.world.entity.*;

@ClientJarOnly
public class StrayClothingLayer<T extends Mob, M extends EntityModel<T>> extends RenderLayer<T, M>
{
    private static final ResourceLocation STRAY_CLOTHES_LOCATION;
    private final SkeletonModel<T> layerModel;
    
    public StrayClothingLayer(final RenderLayerParent<T, M> renderLayerParent) {
        super(renderLayerParent);
        this.layerModel = new SkeletonModel<T>(0.25f, true);
    }
    
    @Override
    public void render(final T mob, final float var2, final float var3, final float var4, final float var5, final float var6, final float var7, final float var8) {
        this.getParentModel().copyPropertiesTo(this.layerModel);
        this.layerModel.prepareMobModel(mob, var2, var3, var4);
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.bindTexture(StrayClothingLayer.STRAY_CLOTHES_LOCATION);
        this.layerModel.render(mob, var2, var3, var5, var6, var7, var8);
    }
    
    @Override
    public boolean colorsOnDamage() {
        return true;
    }
    
    static {
        STRAY_CLOTHES_LOCATION = new ResourceLocation("textures/entity/skeleton/stray_overlay.png");
    }
}
