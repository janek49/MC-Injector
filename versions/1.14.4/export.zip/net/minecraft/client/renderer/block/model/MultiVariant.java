package net.minecraft.client.renderer.block.model;

import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import java.util.function.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.client.resources.model.*;
import java.util.*;
import javax.annotation.*;
import java.util.stream.*;
import java.lang.reflect.*;
import com.google.common.collect.*;
import com.google.gson.*;

@ClientJarOnly
public class MultiVariant implements UnbakedModel
{
    private final List<Variant> variants;
    
    public MultiVariant(final List<Variant> variants) {
        this.variants = variants;
    }
    
    public List<Variant> getVariants() {
        return this.variants;
    }
    
    @Override
    public boolean equals(final Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof MultiVariant) {
            final MultiVariant var2 = (MultiVariant)object;
            return this.variants.equals(var2.variants);
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return this.variants.hashCode();
    }
    
    @Override
    public Collection<ResourceLocation> getDependencies() {
        return this.getVariants().stream().map((Function<? super Object, ?>)Variant::getModelLocation).collect((Collector<? super Object, ?, Collection<ResourceLocation>>)Collectors.toSet());
    }
    
    @Override
    public Collection<ResourceLocation> getTextures(final Function<ResourceLocation, UnbakedModel> function, final Set<String> set) {
        return this.getVariants().stream().map((Function<? super Object, ?>)Variant::getModelLocation).distinct().flatMap(resourceLocation -> function.apply(resourceLocation).getTextures(function, set).stream()).collect((Collector<? super Object, ?, Collection<ResourceLocation>>)Collectors.toSet());
    }
    
    @Nullable
    @Override
    public BakedModel bake(final ModelBakery modelBakery, final Function<ResourceLocation, TextureAtlasSprite> function, final ModelState modelState) {
        if (this.getVariants().isEmpty()) {
            return null;
        }
        final WeightedBakedModel.Builder var4 = new WeightedBakedModel.Builder();
        for (final Variant var5 : this.getVariants()) {
            final BakedModel var6 = modelBakery.bake(var5.getModelLocation(), var5);
            var4.add(var6, var5.getWeight());
        }
        return var4.build();
    }
    
    @ClientJarOnly
    public static class Deserializer implements JsonDeserializer<MultiVariant>
    {
        public MultiVariant deserialize(final JsonElement jsonElement, final Type type, final JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            final List<Variant> var4 = (List<Variant>)Lists.newArrayList();
            if (jsonElement.isJsonArray()) {
                final JsonArray var5 = jsonElement.getAsJsonArray();
                if (var5.size() == 0) {
                    throw new JsonParseException("Empty variant array");
                }
                for (final JsonElement var6 : var5) {
                    var4.add((Variant)jsonDeserializationContext.deserialize(var6, (Type)Variant.class));
                }
            }
            else {
                var4.add((Variant)jsonDeserializationContext.deserialize(jsonElement, (Type)Variant.class));
            }
            return new MultiVariant(var4);
        }
    }
}
