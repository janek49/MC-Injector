package net.minecraft.client.renderer.block.model;

import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import net.minecraft.client.resources.model.*;
import java.lang.reflect.*;
import com.google.gson.*;
import net.minecraft.util.*;

@ClientJarOnly
public class Variant implements ModelState
{
    private final ResourceLocation modelLocation;
    private final BlockModelRotation rotation;
    private final boolean uvLock;
    private final int weight;
    
    public Variant(final ResourceLocation modelLocation, final BlockModelRotation rotation, final boolean uvLock, final int weight) {
        this.modelLocation = modelLocation;
        this.rotation = rotation;
        this.uvLock = uvLock;
        this.weight = weight;
    }
    
    public ResourceLocation getModelLocation() {
        return this.modelLocation;
    }
    
    @Override
    public BlockModelRotation getRotation() {
        return this.rotation;
    }
    
    @Override
    public boolean isUvLocked() {
        return this.uvLock;
    }
    
    public int getWeight() {
        return this.weight;
    }
    
    @Override
    public String toString() {
        return "Variant{modelLocation=" + this.modelLocation + ", rotation=" + this.rotation + ", uvLock=" + this.uvLock + ", weight=" + this.weight + '}';
    }
    
    @Override
    public boolean equals(final Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof Variant) {
            final Variant var2 = (Variant)object;
            return this.modelLocation.equals(var2.modelLocation) && this.rotation == var2.rotation && this.uvLock == var2.uvLock && this.weight == var2.weight;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        int var1 = this.modelLocation.hashCode();
        var1 = 31 * var1 + this.rotation.hashCode();
        var1 = 31 * var1 + Boolean.valueOf(this.uvLock).hashCode();
        var1 = 31 * var1 + this.weight;
        return var1;
    }
    
    @ClientJarOnly
    public static class Deserializer implements JsonDeserializer<Variant>
    {
        public Variant deserialize(final JsonElement jsonElement, final Type type, final JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            final JsonObject var4 = jsonElement.getAsJsonObject();
            final ResourceLocation var5 = this.getModel(var4);
            final BlockModelRotation var6 = this.getBlockRotation(var4);
            final boolean var7 = this.getUvLock(var4);
            final int var8 = this.getWeight(var4);
            return new Variant(var5, var6, var7, var8);
        }
        
        private boolean getUvLock(final JsonObject jsonObject) {
            return GsonHelper.getAsBoolean(jsonObject, "uvlock", false);
        }
        
        protected BlockModelRotation getBlockRotation(final JsonObject jsonObject) {
            final int var2 = GsonHelper.getAsInt(jsonObject, "x", 0);
            final int var3 = GsonHelper.getAsInt(jsonObject, "y", 0);
            final BlockModelRotation var4 = BlockModelRotation.by(var2, var3);
            if (var4 == null) {
                throw new JsonParseException("Invalid BlockModelRotation x: " + var2 + ", y: " + var3);
            }
            return var4;
        }
        
        protected ResourceLocation getModel(final JsonObject jsonObject) {
            return new ResourceLocation(GsonHelper.getAsString(jsonObject, "model"));
        }
        
        protected int getWeight(final JsonObject jsonObject) {
            final int var2 = GsonHelper.getAsInt(jsonObject, "weight", 1);
            if (var2 < 1) {
                throw new JsonParseException("Invalid weight " + var2 + " found, expected integer >= 1");
            }
            return var2;
        }
    }
}
