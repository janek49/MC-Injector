package net.minecraft.client.renderer.debug;

import com.fox2code.repacker.*;
import com.mojang.blaze3d.platform.*;
import net.minecraft.util.*;
import net.minecraft.core.*;
import net.minecraft.client.*;
import net.minecraft.world.level.*;
import it.unimi.dsi.fastutil.longs.*;
import java.util.*;

@ClientJarOnly
public class LightDebugRenderer implements DebugRenderer.SimpleDebugRenderer
{
    private final Minecraft minecraft;
    
    public LightDebugRenderer(final Minecraft minecraft) {
        this.minecraft = minecraft;
    }
    
    @Override
    public void render(final long l) {
        final Camera var3 = this.minecraft.gameRenderer.getMainCamera();
        final Level var4 = this.minecraft.level;
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.disableTexture();
        final BlockPos var5 = new BlockPos(var3.getPosition());
        final LongSet var6 = (LongSet)new LongOpenHashSet();
        for (final BlockPos var7 : BlockPos.betweenClosed(var5.offset(-10, -10, -10), var5.offset(10, 10, 10))) {
            final int var8 = var4.getBrightness(LightLayer.SKY, var7);
            final float var9 = (15 - var8) / 15.0f * 0.5f + 0.16f;
            final int var10 = Mth.hsvToRgb(var9, 0.9f, 0.9f);
            final long var11 = SectionPos.blockToSection(var7.asLong());
            if (var6.add(var11)) {
                DebugRenderer.renderFloatingText(var4.getChunkSource().getLightEngine().getDebugData(LightLayer.SKY, SectionPos.of(var11)), SectionPos.x(var11) * 16 + 8, SectionPos.y(var11) * 16 + 8, SectionPos.z(var11) * 16 + 8, 16711680, 0.3f);
            }
            if (var8 != 15) {
                DebugRenderer.renderFloatingText(String.valueOf(var8), var7.getX() + 0.5, var7.getY() + 0.25, var7.getZ() + 0.5, var10);
            }
        }
        GlStateManager.enableTexture();
        GlStateManager.popMatrix();
    }
}
