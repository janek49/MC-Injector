package net.minecraft.client.renderer;

import com.fox2code.repacker.*;
import net.minecraft.world.level.*;
import net.minecraft.client.renderer.chunk.*;
import com.mojang.blaze3d.vertex.*;
import java.util.*;
import com.mojang.blaze3d.platform.*;

@ClientJarOnly
public class VboRenderList extends ChunkRenderList
{
    @Override
    public void render(final BlockLayer blockLayer) {
        if (!this.ready) {
            return;
        }
        for (final RenderChunk var3 : this.chunks) {
            final VertexBuffer var4 = var3.getBuffer(blockLayer.ordinal());
            GlStateManager.pushMatrix();
            this.translateToRelativeChunkPosition(var3);
            var4.bind();
            this.applyVertexDeclaration();
            var4.draw(7);
            GlStateManager.popMatrix();
        }
        VertexBuffer.unbind();
        GlStateManager.clearCurrentColor();
        this.chunks.clear();
    }
    
    private void applyVertexDeclaration() {
        GlStateManager.vertexPointer(3, 5126, 28, 0);
        GlStateManager.colorPointer(4, 5121, 28, 12);
        GlStateManager.texCoordPointer(2, 5126, 28, 16);
        GLX.glClientActiveTexture(GLX.GL_TEXTURE1);
        GlStateManager.texCoordPointer(2, 5122, 28, 24);
        GLX.glClientActiveTexture(GLX.GL_TEXTURE0);
    }
}
