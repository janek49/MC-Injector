package net.minecraft.client;

import net.minecraft.util.thread.*;
import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import com.mojang.authlib.properties.*;
import com.mojang.datafixers.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.player.*;
import net.minecraft.world.entity.*;
import javax.annotation.*;
import net.minecraft.client.particle.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.debug.*;
import net.minecraft.client.server.*;
import java.util.concurrent.atomic.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.resources.language.*;
import net.minecraft.client.color.block.*;
import net.minecraft.client.color.item.*;
import com.mojang.blaze3d.pipeline.*;
import net.minecraft.client.sounds.*;
import net.minecraft.client.gui.font.*;
import com.mojang.authlib.minecraft.*;
import net.minecraft.client.gui.components.toasts.*;
import net.minecraft.client.tutorial.*;
import net.minecraft.client.main.*;
import com.mojang.authlib.yggdrasil.*;
import net.minecraft.util.datafix.*;
import net.minecraft.server.packs.*;
import net.minecraft.server.packs.repository.*;
import net.minecraft.server.packs.resources.*;
import net.minecraft.client.resources.*;
import com.mojang.blaze3d.platform.*;
import java.util.function.*;
import java.io.*;
import java.util.stream.*;
import net.minecraft.tags.*;
import net.minecraft.client.gui.screens.recipebook.*;
import net.minecraft.client.searchtree.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.*;
import net.minecraft.client.renderer.block.*;
import net.minecraft.client.resources.model.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.network.chat.*;
import net.minecraft.client.gui.screens.multiplayer.*;
import net.minecraft.client.gui.chat.*;
import net.minecraft.client.renderer.chunk.*;
import net.minecraft.util.*;
import java.text.*;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.core.*;
import net.minecraft.world.phys.*;
import net.minecraft.world.*;
import net.minecraft.*;
import net.minecraft.client.gui.screens.inventory.*;
import net.minecraft.client.gui.screens.advancements.*;
import net.minecraft.network.protocol.game.*;
import net.minecraft.network.protocol.*;
import net.minecraft.server.*;
import net.minecraft.server.players.*;
import net.minecraft.server.level.progress.*;
import net.minecraft.network.*;
import net.minecraft.network.protocol.handshake.*;
import net.minecraft.network.protocol.login.*;
import net.minecraft.world.level.storage.*;
import java.net.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.client.renderer.blockentity.*;
import net.minecraft.world.level.*;
import net.minecraft.world.entity.vehicle.*;
import net.minecraft.world.entity.decoration.*;
import net.minecraft.world.entity.boss.enderdragon.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.item.*;
import net.minecraft.nbt.*;
import java.nio.*;
import com.google.common.collect.*;
import com.mojang.authlib.*;
import net.minecraft.client.gui.screens.*;
import net.minecraft.world.level.dimension.*;
import net.minecraft.world.level.dimension.end.*;
import net.minecraft.world.level.biome.*;
import net.minecraft.util.profiling.*;
import java.util.concurrent.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.server.packs.metadata.pack.*;
import org.apache.logging.log4j.*;
import java.util.*;

@ClientJarOnly
public class Minecraft extends ReentrantBlockableEventLoop<Runnable> implements SnooperPopulator, WindowEventHandler, AutoCloseable
{
    private static final Logger LOGGER;
    public static final boolean ON_OSX;
    public static final ResourceLocation DEFAULT_FONT;
    public static final ResourceLocation ALT_FONT;
    private static final CompletableFuture<Unit> RESOURCE_RELOAD_INITIAL_TASK;
    public static byte[] reserve;
    private static int MAX_SUPPORTED_TEXTURE_SIZE;
    private final File resourcePackDirectory;
    private final PropertyMap profileProperties;
    private final DisplayData displayData;
    private ServerData currentServer;
    private TextureManager textureManager;
    private static Minecraft instance;
    private final DataFixer fixerUpper;
    public MultiPlayerGameMode gameMode;
    private VirtualScreen virtualScreen;
    public Window window;
    private boolean hasCrashed;
    private CrashReport delayedCrash;
    private boolean connectedToRealms;
    private final Timer timer;
    private final Snooper snooper;
    public MultiPlayerLevel level;
    public LevelRenderer levelRenderer;
    private EntityRenderDispatcher entityRenderDispatcher;
    private ItemRenderer itemRenderer;
    private ItemInHandRenderer itemInHandRenderer;
    public LocalPlayer player;
    @Nullable
    public Entity cameraEntity;
    @Nullable
    public Entity crosshairPickEntity;
    public ParticleEngine particleEngine;
    private final SearchRegistry searchRegistry;
    private final User user;
    private boolean pause;
    private float pausePartialTick;
    public Font font;
    @Nullable
    public Screen screen;
    @Nullable
    public Overlay overlay;
    public GameRenderer gameRenderer;
    public DebugRenderer debugRenderer;
    protected int missTime;
    @Nullable
    private IntegratedServer singleplayerServer;
    private final AtomicReference<StoringChunkProgressListener> progressListener;
    public Gui gui;
    public boolean noRender;
    public HitResult hitResult;
    public Options options;
    private HotbarManager hotbarManager;
    public MouseHandler mouseHandler;
    public KeyboardHandler keyboardHandler;
    public final File gameDirectory;
    private final File assetsDirectory;
    private final String launchedVersion;
    private final String versionType;
    private final Proxy proxy;
    private LevelStorageSource levelSource;
    private static int fps;
    private int rightClickDelay;
    private String connectToIp;
    private int connectToPort;
    public final FrameTimer frameTimer;
    private long lastNanoTime;
    private final boolean is64bit;
    private final boolean demo;
    @Nullable
    private Connection pendingConnection;
    private boolean isLocalServer;
    private final GameProfiler profiler;
    private ReloadableResourceManager resourceManager;
    private final ClientPackSource clientPackSource;
    private final PackRepository<UnopenedResourcePack> resourcePackRepository;
    private LanguageManager languageManager;
    private BlockColors blockColors;
    private ItemColors itemColors;
    private RenderTarget mainRenderTarget;
    private TextureAtlas textureAtlas;
    private SoundManager soundManager;
    private MusicManager musicManager;
    private FontManager fontManager;
    private SplashManager splashManager;
    private final MinecraftSessionService minecraftSessionService;
    private SkinManager skinManager;
    private final Thread gameThread;
    private ModelManager modelManager;
    private BlockRenderDispatcher blockRenderer;
    private PaintingTextureManager paintingTextures;
    private MobEffectTextureManager mobEffectTextures;
    private final ToastComponent toast;
    private final Game game;
    private volatile boolean running;
    public String fpsString;
    public boolean smartCull;
    private long lastTime;
    private int frames;
    private final Tutorial tutorial;
    private boolean windowActive;
    private final Queue<Runnable> progressTasks;
    private CompletableFuture<Void> pendingReload;
    private String debugPath;
    
    public Minecraft(final GameConfig gameConfig) {
        super("Client");
        this.timer = new Timer(20.0f, 0L);
        this.snooper = new Snooper("client", this, Util.getMillis());
        this.searchRegistry = new SearchRegistry();
        this.progressListener = new AtomicReference<StoringChunkProgressListener>();
        this.frameTimer = new FrameTimer();
        this.lastNanoTime = Util.getNanos();
        this.profiler = new GameProfiler(() -> this.timer.ticks);
        this.gameThread = Thread.currentThread();
        this.game = new Game(this);
        this.running = true;
        this.fpsString = "";
        this.smartCull = true;
        this.progressTasks = (Queue<Runnable>)Queues.newConcurrentLinkedQueue();
        this.debugPath = "root";
        this.displayData = gameConfig.display;
        Minecraft.instance = this;
        this.gameDirectory = gameConfig.location.gameDirectory;
        this.assetsDirectory = gameConfig.location.assetDirectory;
        this.resourcePackDirectory = gameConfig.location.resourcePackDirectory;
        this.launchedVersion = gameConfig.game.launchVersion;
        this.versionType = gameConfig.game.versionType;
        this.profileProperties = gameConfig.user.profileProperties;
        this.clientPackSource = new ClientPackSource(new File(this.gameDirectory, "server-resource-packs"), gameConfig.location.getAssetIndex());
        Object supplier2;
        (this.resourcePackRepository = new PackRepository<UnopenedResourcePack>((string, var1, supplier, pack, packMetadataSection, unopenedPack$Position) -> {
            if (packMetadataSection.getPackFormat() < SharedConstants.getCurrentVersion().getPackVersion()) {
                supplier2 = (() -> new LegacyResourcePackAdapter(supplier.get(), LegacyResourcePackAdapter.V3));
            }
            else {
                supplier2 = supplier;
            }
            return new UnopenedResourcePack(string, var1, (Supplier<Pack>)supplier2, pack, packMetadataSection, unopenedPack$Position);
        })).addSource(this.clientPackSource);
        this.resourcePackRepository.addSource(new FolderRepositorySource(this.resourcePackDirectory));
        this.proxy = ((gameConfig.user.proxy == null) ? Proxy.NO_PROXY : gameConfig.user.proxy);
        this.minecraftSessionService = new YggdrasilAuthenticationService(this.proxy, UUID.randomUUID().toString()).createMinecraftSessionService();
        this.user = gameConfig.user.user;
        Minecraft.LOGGER.info("Setting user: {}", (Object)this.user.getName());
        Minecraft.LOGGER.debug("(Session ID is {})", (Object)this.user.getSessionId());
        this.demo = gameConfig.game.demo;
        this.is64bit = checkIs64Bit();
        this.singleplayerServer = null;
        if (gameConfig.server.hostname != null) {
            this.connectToIp = gameConfig.server.hostname;
            this.connectToPort = gameConfig.server.port;
        }
        Bootstrap.bootStrap();
        Bootstrap.validate();
        KeybindComponent.keyResolver = KeyMapping::createNameSupplier;
        this.fixerUpper = DataFixers.getDataFixer();
        this.toast = new ToastComponent(this);
        this.tutorial = new Tutorial(this);
    }
    
    public void run() {
        this.running = true;
        try {
            this.init();
        }
        catch (Throwable var3) {
            final CrashReport var2 = CrashReport.forThrowable(var3, "Initializing game");
            var2.addCategory("Initialization");
            this.crash(this.fillReport(var2));
            return;
        }
        try {
            boolean var4 = false;
            while (this.running) {
                if (this.hasCrashed && this.delayedCrash != null) {
                    this.crash(this.delayedCrash);
                    return;
                }
                try {
                    this.runTick(!var4);
                }
                catch (OutOfMemoryError var5) {
                    if (var4) {
                        throw var5;
                    }
                    this.emergencySave();
                    this.setScreen(new OutOfMemoryScreen());
                    System.gc();
                    Minecraft.LOGGER.fatal("Out of memory", (Throwable)var5);
                    var4 = true;
                }
            }
        }
        catch (ReportedException var6) {
            this.fillReport(var6.getReport());
            this.emergencySave();
            Minecraft.LOGGER.fatal("Reported exception thrown!", (Throwable)var6);
            this.crash(var6.getReport());
        }
        catch (Throwable var3) {
            final CrashReport var2 = this.fillReport(new CrashReport("Unexpected error", var3));
            Minecraft.LOGGER.fatal("Unreported exception thrown!", var3);
            this.emergencySave();
            this.crash(var2);
        }
        finally {
            this.destroy();
        }
    }
    
    private void init() {
        this.options = new Options(this, this.gameDirectory);
        this.hotbarManager = new HotbarManager(this.gameDirectory, this.fixerUpper);
        this.startTimerHackThread();
        Minecraft.LOGGER.info("LWJGL Version: {}", (Object)GLX.getLWJGLVersion());
        DisplayData var1 = this.displayData;
        if (this.options.overrideHeight > 0 && this.options.overrideWidth > 0) {
            var1 = new DisplayData(this.options.overrideWidth, this.options.overrideHeight, var1.fullscreenWidth, var1.fullscreenHeight, var1.isFullscreen);
        }
        final LongSupplier var2 = GLX.initGlfw();
        if (var2 != null) {
            Util.timeSource = var2;
        }
        this.virtualScreen = new VirtualScreen(this);
        this.window = this.virtualScreen.newWindow(var1, this.options.fullscreenVideoModeString, "Minecraft " + SharedConstants.getCurrentVersion().getName());
        this.setWindowActive(true);
        try {
            final InputStream var3 = this.getClientPackSource().getVanillaPack().getResource(PackType.CLIENT_RESOURCES, new ResourceLocation("icons/icon_16x16.png"));
            final InputStream var4 = this.getClientPackSource().getVanillaPack().getResource(PackType.CLIENT_RESOURCES, new ResourceLocation("icons/icon_32x32.png"));
            this.window.setIcon(var3, var4);
        }
        catch (IOException var5) {
            Minecraft.LOGGER.error("Couldn't set icon", (Throwable)var5);
        }
        this.window.setFramerateLimit(this.options.framerateLimit);
        (this.mouseHandler = new MouseHandler(this)).setup(this.window.getWindow());
        (this.keyboardHandler = new KeyboardHandler(this)).setup(this.window.getWindow());
        GLX.init();
        GlDebug.enableDebugCallback(this.options.glDebugVerbosity, false);
        (this.mainRenderTarget = new RenderTarget(this.window.getWidth(), this.window.getHeight(), true, Minecraft.ON_OSX)).setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        this.resourceManager = new SimpleReloadableResourceManager(PackType.CLIENT_RESOURCES, this.gameThread);
        this.options.loadResourcePacks(this.resourcePackRepository);
        this.resourcePackRepository.reload();
        final List<Pack> var6 = this.resourcePackRepository.getSelected().stream().map((Function<? super UnopenedResourcePack, ?>)UnopenedPack::open).collect((Collector<? super Object, ?, List<Pack>>)Collectors.toList());
        for (final Pack var7 : var6) {
            this.resourceManager.add(var7);
        }
        this.languageManager = new LanguageManager(this.options.languageCode);
        this.resourceManager.registerReloadListener(this.languageManager);
        this.languageManager.reload(var6);
        this.textureManager = new TextureManager(this.resourceManager);
        this.resourceManager.registerReloadListener(this.textureManager);
        this.resizeDisplay();
        this.skinManager = new SkinManager(this.textureManager, new File(this.assetsDirectory, "skins"), this.minecraftSessionService);
        this.levelSource = new LevelStorageSource(this.gameDirectory.toPath().resolve("saves"), this.gameDirectory.toPath().resolve("backups"), this.fixerUpper);
        this.soundManager = new SoundManager(this.resourceManager, this.options);
        this.resourceManager.registerReloadListener(this.soundManager);
        this.splashManager = new SplashManager(this.user);
        this.resourceManager.registerReloadListener(this.splashManager);
        this.musicManager = new MusicManager(this);
        this.fontManager = new FontManager(this.textureManager, this.isEnforceUnicode());
        this.resourceManager.registerReloadListener(this.fontManager.getReloadListener());
        this.font = this.fontManager.get(Minecraft.DEFAULT_FONT);
        if (this.options.languageCode != null) {
            this.font.setBidirectional(this.languageManager.isBidirectional());
        }
        this.resourceManager.registerReloadListener(new GrassColorReloadListener());
        this.resourceManager.registerReloadListener(new FoliageColorReloadListener());
        this.window.setGlErrorSection("Startup");
        GlStateManager.enableTexture();
        GlStateManager.shadeModel(7425);
        GlStateManager.clearDepth(1.0);
        GlStateManager.enableDepthTest();
        GlStateManager.depthFunc(515);
        GlStateManager.enableAlphaTest();
        GlStateManager.alphaFunc(516, 0.1f);
        GlStateManager.cullFace(GlStateManager.CullFace.BACK);
        GlStateManager.matrixMode(5889);
        GlStateManager.loadIdentity();
        GlStateManager.matrixMode(5888);
        this.window.setGlErrorSection("Post startup");
        (this.textureAtlas = new TextureAtlas("textures")).setMaxMipLevel(this.options.mipmapLevels);
        this.textureManager.register(TextureAtlas.LOCATION_BLOCKS, this.textureAtlas);
        this.textureManager.bind(TextureAtlas.LOCATION_BLOCKS);
        this.textureAtlas.setFilter(false, this.options.mipmapLevels > 0);
        this.blockColors = BlockColors.createDefault();
        this.itemColors = ItemColors.createDefault(this.blockColors);
        this.modelManager = new ModelManager(this.textureAtlas, this.blockColors);
        this.resourceManager.registerReloadListener(this.modelManager);
        this.itemRenderer = new ItemRenderer(this.textureManager, this.modelManager, this.itemColors);
        this.entityRenderDispatcher = new EntityRenderDispatcher(this.textureManager, this.itemRenderer, this.resourceManager);
        this.itemInHandRenderer = new ItemInHandRenderer(this);
        this.resourceManager.registerReloadListener(this.itemRenderer);
        this.gameRenderer = new GameRenderer(this, this.resourceManager);
        this.resourceManager.registerReloadListener(this.gameRenderer);
        this.blockRenderer = new BlockRenderDispatcher(this.modelManager.getBlockModelShaper(), this.blockColors);
        this.resourceManager.registerReloadListener(this.blockRenderer);
        this.levelRenderer = new LevelRenderer(this);
        this.resourceManager.registerReloadListener(this.levelRenderer);
        this.createSearchTrees();
        this.resourceManager.registerReloadListener(this.searchRegistry);
        GlStateManager.viewport(0, 0, this.window.getWidth(), this.window.getHeight());
        this.particleEngine = new ParticleEngine(this.level, this.textureManager);
        this.resourceManager.registerReloadListener(this.particleEngine);
        this.paintingTextures = new PaintingTextureManager(this.textureManager);
        this.resourceManager.registerReloadListener(this.paintingTextures);
        this.mobEffectTextures = new MobEffectTextureManager(this.textureManager);
        this.resourceManager.registerReloadListener(this.mobEffectTextures);
        this.gui = new Gui(this);
        this.debugRenderer = new DebugRenderer(this);
        GLX.setGlfwErrorCallback(this::onFullscreenError);
        if (this.options.fullscreen && !this.window.isFullscreen()) {
            this.window.toggleFullScreen();
            this.options.fullscreen = this.window.isFullscreen();
        }
        this.window.updateVsync(this.options.enableVsync);
        this.window.updateRawMouseInput(this.options.rawMouseInput);
        this.window.setDefaultGlErrorCallback();
        if (this.connectToIp != null) {
            this.setScreen(new ConnectScreen(new TitleScreen(), this, this.connectToIp, this.connectToPort));
        }
        else {
            this.setScreen(new TitleScreen(true));
        }
        LoadingOverlay.registerTextures(this);
        this.setOverlay(new LoadingOverlay(this, this.resourceManager.createQueuedReload(Util.backgroundExecutor(), this, Minecraft.RESOURCE_RELOAD_INITIAL_TASK), () -> {
            if (SharedConstants.IS_RUNNING_IN_IDE) {
                this.selfTest();
            }
        }, false));
    }
    
    private void createSearchTrees() {
        final ReloadableSearchTree<ItemStack> var1 = new ReloadableSearchTree<ItemStack>(itemStack -> itemStack.getTooltipLines(null, TooltipFlag.Default.NORMAL).stream().map(component -> ChatFormatting.stripFormatting(component.getString()).trim()).filter(string -> !string.isEmpty()), itemStack -> Stream.of(Registry.ITEM.getKey(itemStack.getItem())));
        final ReloadableIdSearchTree<ItemStack> var2 = new ReloadableIdSearchTree<ItemStack>(itemStack -> ItemTags.getAllTags().getMatchingTags(itemStack.getItem()).stream());
        final NonNullList<ItemStack> var3 = NonNullList.create();
        for (final Item var4 : Registry.ITEM) {
            var4.fillItemCategory(CreativeModeTab.TAB_SEARCH, var3);
        }
        final ReloadableIdSearchTree<ItemStack> reloadableIdSearchTree2;
        final ReloadableIdSearchTree<ItemStack> reloadableIdSearchTree3;
        var3.forEach(itemStack -> {
            reloadableIdSearchTree2.add(itemStack);
            reloadableIdSearchTree3.add(itemStack);
            return;
        });
        final ReloadableSearchTree<RecipeCollection> var5 = new ReloadableSearchTree<RecipeCollection>(recipeCollection -> recipeCollection.getRecipes().stream().flatMap(recipe -> recipe.getResultItem().getTooltipLines(null, TooltipFlag.Default.NORMAL).stream()).map(component -> ChatFormatting.stripFormatting(component.getString()).trim()).filter(string -> !string.isEmpty()), recipeCollection -> recipeCollection.getRecipes().stream().map(recipe -> Registry.ITEM.getKey(recipe.getResultItem().getItem())));
        this.searchRegistry.register(SearchRegistry.CREATIVE_NAMES, var1);
        this.searchRegistry.register(SearchRegistry.CREATIVE_TAGS, var2);
        this.searchRegistry.register(SearchRegistry.RECIPE_COLLECTIONS, var5);
    }
    
    private void onFullscreenError(final int var1, final long var2) {
        this.options.enableVsync = false;
        this.options.save();
    }
    
    private static boolean checkIs64Bit() {
        final String[] array;
        final String[] vars0 = array = new String[] { "sun.arch.data.model", "com.ibm.vm.bitmode", "os.arch" };
        for (final String var4 : array) {
            final String var5 = System.getProperty(var4);
            if (var5 != null && var5.contains("64")) {
                return true;
            }
        }
        return false;
    }
    
    public RenderTarget getMainRenderTarget() {
        return this.mainRenderTarget;
    }
    
    public String getLaunchedVersion() {
        return this.launchedVersion;
    }
    
    public String getVersionType() {
        return this.versionType;
    }
    
    private void startTimerHackThread() {
        final Thread var1 = new Thread("Timer hack thread") {
            @Override
            public void run() {
                while (Minecraft.this.running) {
                    try {
                        Thread.sleep(2147483647L);
                    }
                    catch (InterruptedException ex) {}
                }
            }
        };
        var1.setDaemon(true);
        var1.setUncaughtExceptionHandler(new DefaultUncaughtExceptionHandler(Minecraft.LOGGER));
        var1.start();
    }
    
    public void delayCrash(final CrashReport delayedCrash) {
        this.hasCrashed = true;
        this.delayedCrash = delayedCrash;
    }
    
    public void crash(final CrashReport crashReport) {
        final File var2 = new File(getInstance().gameDirectory, "crash-reports");
        final File var3 = new File(var2, "crash-" + new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss").format(new Date()) + "-client.txt");
        Bootstrap.realStdoutPrintln(crashReport.getFriendlyReport());
        if (crashReport.getSaveFile() != null) {
            Bootstrap.realStdoutPrintln("#@!@# Game crashed! Crash report saved to: #@!@# " + crashReport.getSaveFile());
            System.exit(-1);
        }
        else if (crashReport.saveToFile(var3)) {
            Bootstrap.realStdoutPrintln("#@!@# Game crashed! Crash report saved to: #@!@# " + var3.getAbsolutePath());
            System.exit(-1);
        }
        else {
            Bootstrap.realStdoutPrintln("#@?@# Game crashed! Crash report could not be saved. #@?@#");
            System.exit(-2);
        }
    }
    
    public boolean isEnforceUnicode() {
        return this.options.forceUnicodeFont;
    }
    
    public CompletableFuture<Void> reloadResourcePacks() {
        if (this.pendingReload != null) {
            return this.pendingReload;
        }
        final CompletableFuture<Void> completableFuture = new CompletableFuture<Void>();
        if (this.overlay instanceof LoadingOverlay) {
            return this.pendingReload = completableFuture;
        }
        this.resourcePackRepository.reload();
        final List<Pack> var2 = this.resourcePackRepository.getSelected().stream().map((Function<? super UnopenedResourcePack, ?>)UnopenedPack::open).collect((Collector<? super Object, ?, List<Pack>>)Collectors.toList());
        final List<Pack> list2;
        final CompletableFuture<Object> completableFuture2;
        this.setOverlay(new LoadingOverlay(this, this.resourceManager.createFullReload(Util.backgroundExecutor(), this, Minecraft.RESOURCE_RELOAD_INITIAL_TASK, var2), () -> {
            this.languageManager.reload(list2);
            if (this.levelRenderer != null) {
                this.levelRenderer.allChanged();
            }
            completableFuture2.complete(null);
            return;
        }, true));
        return completableFuture;
    }
    
    private void selfTest() {
        boolean var1 = false;
        final BlockModelShaper var2 = this.getBlockRenderer().getBlockModelShaper();
        final BakedModel var3 = var2.getModelManager().getMissingModel();
        for (final Block var4 : Registry.BLOCK) {
            for (final BlockState var5 : var4.getStateDefinition().getPossibleStates()) {
                if (var5.getRenderShape() == RenderShape.MODEL) {
                    final BakedModel var6 = var2.getBlockModel(var5);
                    if (var6 != var3) {
                        continue;
                    }
                    Minecraft.LOGGER.debug("Missing model for: {}", (Object)var5);
                    var1 = true;
                }
            }
        }
        final TextureAtlasSprite var7 = var3.getParticleIcon();
        for (final Block var8 : Registry.BLOCK) {
            for (final BlockState var9 : var8.getStateDefinition().getPossibleStates()) {
                final TextureAtlasSprite var10 = var2.getParticleIcon(var9);
                if (!var9.isAir() && var10 == var7) {
                    Minecraft.LOGGER.debug("Missing particle icon for: {}", (Object)var9);
                    var1 = true;
                }
            }
        }
        final NonNullList<ItemStack> var11 = NonNullList.create();
        for (final Item var12 : Registry.ITEM) {
            var11.clear();
            var12.fillItemCategory(CreativeModeTab.TAB_SEARCH, var11);
            for (final ItemStack var13 : var11) {
                final String var14 = var13.getDescriptionId();
                final String var15 = new TranslatableComponent(var14, new Object[0]).getString();
                if (var15.toLowerCase(Locale.ROOT).equals(var12.getDescriptionId())) {
                    Minecraft.LOGGER.debug("Missing translation for: {} {} {}", (Object)var13, (Object)var14, (Object)var13.getItem());
                }
            }
        }
        var1 |= MenuScreens.selfTest();
        if (var1) {
            throw new IllegalStateException("Your game data is foobar, fix the errors above!");
        }
    }
    
    public LevelStorageSource getLevelSource() {
        return this.levelSource;
    }
    
    public void setScreen(@Nullable Screen screen) {
        if (this.screen != null) {
            this.screen.removed();
        }
        if (screen == null && this.level == null) {
            screen = new TitleScreen();
        }
        else if (screen == null && this.player.getHealth() <= 0.0f) {
            screen = new DeathScreen(null, this.level.getLevelData().isHardcore());
        }
        if (screen instanceof TitleScreen || screen instanceof JoinMultiplayerScreen) {
            this.options.renderDebug = false;
            this.gui.getChat().clearMessages(true);
        }
        if ((this.screen = screen) != null) {
            this.mouseHandler.releaseMouse();
            KeyMapping.releaseAll();
            screen.init(this, this.window.getGuiScaledWidth(), this.window.getGuiScaledHeight());
            this.noRender = false;
            NarratorChatListener.INSTANCE.sayNow(screen.getNarrationMessage());
        }
        else {
            this.soundManager.resume();
            this.mouseHandler.grabMouse();
        }
    }
    
    public void setOverlay(@Nullable final Overlay overlay) {
        this.overlay = overlay;
    }
    
    public void destroy() {
        try {
            Minecraft.LOGGER.info("Stopping!");
            NarratorChatListener.INSTANCE.destroy();
            try {
                if (this.level != null) {
                    this.level.disconnect();
                }
                this.clearLevel();
            }
            catch (Throwable t) {}
            if (this.screen != null) {
                this.screen.removed();
            }
            this.close();
        }
        finally {
            Util.timeSource = System::nanoTime;
            if (!this.hasCrashed) {
                System.exit(0);
            }
        }
    }
    
    @Override
    public void close() {
        try {
            this.textureAtlas.clearTextureData();
            this.font.close();
            this.fontManager.close();
            this.gameRenderer.close();
            this.levelRenderer.close();
            this.soundManager.destroy();
            this.resourcePackRepository.close();
            this.particleEngine.close();
            this.mobEffectTextures.close();
            this.paintingTextures.close();
            Util.shutdownBackgroundExecutor();
        }
        finally {
            this.virtualScreen.close();
            this.window.close();
        }
    }
    
    private void runTick(final boolean b) {
        this.window.setGlErrorSection("Pre render");
        final long var2 = Util.getNanos();
        this.profiler.startTick();
        if (GLX.shouldClose(this.window)) {
            this.stop();
        }
        if (this.pendingReload != null && !(this.overlay instanceof LoadingOverlay)) {
            final CompletableFuture<Void> var3 = this.pendingReload;
            this.pendingReload = null;
            this.reloadResourcePacks().thenRun(() -> var3.complete(null));
        }
        Runnable var4;
        while ((var4 = this.progressTasks.poll()) != null) {
            var4.run();
        }
        if (b) {
            this.timer.advanceTime(Util.getMillis());
            this.profiler.push("scheduledExecutables");
            this.runAllTasks();
            this.profiler.pop();
        }
        final long var5 = Util.getNanos();
        this.profiler.push("tick");
        if (b) {
            for (int var6 = 0; var6 < Math.min(10, this.timer.ticks); ++var6) {
                this.tick();
            }
        }
        this.mouseHandler.turnPlayer();
        this.window.setGlErrorSection("Render");
        GLX.pollEvents();
        final long var7 = Util.getNanos() - var5;
        this.profiler.popPush("sound");
        this.soundManager.updateSource(this.gameRenderer.getMainCamera());
        this.profiler.pop();
        this.profiler.push("render");
        GlStateManager.pushMatrix();
        GlStateManager.clear(16640, Minecraft.ON_OSX);
        this.mainRenderTarget.bindWrite(true);
        this.profiler.push("display");
        GlStateManager.enableTexture();
        this.profiler.pop();
        if (!this.noRender) {
            this.profiler.popPush("gameRenderer");
            this.gameRenderer.render(this.pause ? this.pausePartialTick : this.timer.partialTick, var2, b);
            this.profiler.popPush("toasts");
            this.toast.render();
            this.profiler.pop();
        }
        this.profiler.endTick();
        if (this.options.renderDebug && this.options.renderDebugCharts && !this.options.hideGui) {
            this.profiler.continuous().enable();
            this.renderFpsMeter();
        }
        else {
            this.profiler.continuous().disable();
        }
        this.mainRenderTarget.unbindWrite();
        GlStateManager.popMatrix();
        GlStateManager.pushMatrix();
        this.mainRenderTarget.blitToScreen(this.window.getWidth(), this.window.getHeight());
        GlStateManager.popMatrix();
        this.profiler.startTick();
        this.updateDisplay(true);
        Thread.yield();
        this.window.setGlErrorSection("Post render");
        ++this.frames;
        final boolean var8 = this.hasSingleplayerServer() && ((this.screen != null && this.screen.isPauseScreen()) || (this.overlay != null && this.overlay.isPauseScreen())) && !this.singleplayerServer.isPublished();
        if (this.pause != var8) {
            if (this.pause) {
                this.pausePartialTick = this.timer.partialTick;
            }
            else {
                this.timer.partialTick = this.pausePartialTick;
            }
            this.pause = var8;
        }
        final long var9 = Util.getNanos();
        this.frameTimer.logFrameDuration(var9 - this.lastNanoTime);
        this.lastNanoTime = var9;
        while (Util.getMillis() >= this.lastTime + 1000L) {
            Minecraft.fps = this.frames;
            this.fpsString = String.format("%d fps (%d chunk update%s) T: %s%s%s%s%s", Minecraft.fps, RenderChunk.updateCounter, (RenderChunk.updateCounter == 1) ? "" : "s", (this.options.framerateLimit == Option.FRAMERATE_LIMIT.getMaxValue()) ? "inf" : Integer.valueOf(this.options.framerateLimit), this.options.enableVsync ? " vsync" : "", this.options.fancyGraphics ? "" : " fast", (this.options.renderClouds == CloudStatus.OFF) ? "" : ((this.options.renderClouds == CloudStatus.FAST) ? " fast-clouds" : " fancy-clouds"), GLX.useVbo() ? " vbo" : "");
            RenderChunk.updateCounter = 0;
            this.lastTime += 1000L;
            this.frames = 0;
            this.snooper.prepare();
            if (!this.snooper.isStarted()) {
                this.snooper.start();
            }
        }
        this.profiler.endTick();
    }
    
    @Override
    public void updateDisplay(final boolean b) {
        this.profiler.push("display_update");
        this.window.updateDisplay(this.options.fullscreen);
        this.profiler.pop();
        if (b && this.isFramerateLimited()) {
            this.profiler.push("fpslimit_wait");
            this.window.limitDisplayFPS();
            this.profiler.pop();
        }
    }
    
    @Override
    public void resizeDisplay() {
        final int var1 = this.window.calculateScale(this.options.guiScale, this.isEnforceUnicode());
        this.window.setGuiScale(var1);
        if (this.screen != null) {
            this.screen.resize(this, this.window.getGuiScaledWidth(), this.window.getGuiScaledHeight());
        }
        final RenderTarget var2 = this.getMainRenderTarget();
        if (var2 != null) {
            var2.resize(this.window.getWidth(), this.window.getHeight(), Minecraft.ON_OSX);
        }
        if (this.gameRenderer != null) {
            this.gameRenderer.resize(this.window.getWidth(), this.window.getHeight());
        }
        if (this.mouseHandler != null) {
            this.mouseHandler.setIgnoreFirstMove();
        }
    }
    
    private int getFramerateLimit() {
        if (this.level == null && (this.screen != null || this.overlay != null)) {
            return 60;
        }
        return this.window.getFramerateLimit();
    }
    
    private boolean isFramerateLimited() {
        return this.getFramerateLimit() < Option.FRAMERATE_LIMIT.getMaxValue();
    }
    
    public void emergencySave() {
        try {
            Minecraft.reserve = new byte[0];
            this.levelRenderer.clear();
        }
        catch (Throwable t) {}
        try {
            System.gc();
            if (this.hasSingleplayerServer()) {
                this.singleplayerServer.halt(true);
            }
            this.clearLevel(new GenericDirtMessageScreen(new TranslatableComponent("menu.savingLevel", new Object[0])));
        }
        catch (Throwable t2) {}
        System.gc();
    }
    
    void debugFpsMeterKeyPress(int i) {
        final ProfileResults var2 = this.profiler.continuous().getResults();
        final List<ResultField> var3 = var2.getTimes(this.debugPath);
        if (var3.isEmpty()) {
            return;
        }
        final ResultField var4 = var3.remove(0);
        if (i == 0) {
            if (!var4.name.isEmpty()) {
                final int var5 = this.debugPath.lastIndexOf(46);
                if (var5 >= 0) {
                    this.debugPath = this.debugPath.substring(0, var5);
                }
            }
        }
        else if (--i < var3.size() && !"unspecified".equals(var3.get(i).name)) {
            if (!this.debugPath.isEmpty()) {
                this.debugPath += ".";
            }
            this.debugPath += var3.get(i).name;
        }
    }
    
    private void renderFpsMeter() {
        if (!this.profiler.continuous().isEnabled()) {
            return;
        }
        final ProfileResults var1 = this.profiler.continuous().getResults();
        final List<ResultField> var2 = var1.getTimes(this.debugPath);
        final ResultField var3 = var2.remove(0);
        GlStateManager.clear(256, Minecraft.ON_OSX);
        GlStateManager.matrixMode(5889);
        GlStateManager.enableColorMaterial();
        GlStateManager.loadIdentity();
        GlStateManager.ortho(0.0, this.window.getWidth(), this.window.getHeight(), 0.0, 1000.0, 3000.0);
        GlStateManager.matrixMode(5888);
        GlStateManager.loadIdentity();
        GlStateManager.translatef(0.0f, 0.0f, -2000.0f);
        GlStateManager.lineWidth(1.0f);
        GlStateManager.disableTexture();
        final Tesselator var4 = Tesselator.getInstance();
        final BufferBuilder var5 = var4.getBuilder();
        final int var6 = 160;
        final int var7 = this.window.getWidth() - 160 - 10;
        final int var8 = this.window.getHeight() - 320;
        GlStateManager.enableBlend();
        var5.begin(7, DefaultVertexFormat.POSITION_COLOR);
        var5.vertex(var7 - 176.0f, var8 - 96.0f - 16.0f, 0.0).color(200, 0, 0, 0).endVertex();
        var5.vertex(var7 - 176.0f, var8 + 320, 0.0).color(200, 0, 0, 0).endVertex();
        var5.vertex(var7 + 176.0f, var8 + 320, 0.0).color(200, 0, 0, 0).endVertex();
        var5.vertex(var7 + 176.0f, var8 - 96.0f - 16.0f, 0.0).color(200, 0, 0, 0).endVertex();
        var4.end();
        GlStateManager.disableBlend();
        double var9 = 0.0;
        for (int var10 = 0; var10 < var2.size(); ++var10) {
            final ResultField var11 = var2.get(var10);
            final int var12 = Mth.floor(var11.percentage / 4.0) + 1;
            var5.begin(6, DefaultVertexFormat.POSITION_COLOR);
            final int var13 = var11.getColor();
            final int var14 = var13 >> 16 & 0xFF;
            final int var15 = var13 >> 8 & 0xFF;
            final int var16 = var13 & 0xFF;
            var5.vertex(var7, var8, 0.0).color(var14, var15, var16, 255).endVertex();
            for (int var17 = var12; var17 >= 0; --var17) {
                final float var18 = (float)((var9 + var11.percentage * var17 / var12) * 6.2831854820251465 / 100.0);
                final float var19 = Mth.sin(var18) * 160.0f;
                final float var20 = Mth.cos(var18) * 160.0f * 0.5f;
                var5.vertex(var7 + var19, var8 - var20, 0.0).color(var14, var15, var16, 255).endVertex();
            }
            var4.end();
            var5.begin(5, DefaultVertexFormat.POSITION_COLOR);
            for (int var17 = var12; var17 >= 0; --var17) {
                final float var18 = (float)((var9 + var11.percentage * var17 / var12) * 6.2831854820251465 / 100.0);
                final float var19 = Mth.sin(var18) * 160.0f;
                final float var20 = Mth.cos(var18) * 160.0f * 0.5f;
                var5.vertex(var7 + var19, var8 - var20, 0.0).color(var14 >> 1, var15 >> 1, var16 >> 1, 255).endVertex();
                var5.vertex(var7 + var19, var8 - var20 + 10.0f, 0.0).color(var14 >> 1, var15 >> 1, var16 >> 1, 255).endVertex();
            }
            var4.end();
            var9 += var11.percentage;
        }
        final DecimalFormat var21 = new DecimalFormat("##0.00");
        var21.setDecimalFormatSymbols(DecimalFormatSymbols.getInstance(Locale.ROOT));
        GlStateManager.enableTexture();
        String var22 = "";
        if (!"unspecified".equals(var3.name)) {
            var22 += "[0] ";
        }
        if (var3.name.isEmpty()) {
            var22 += "ROOT ";
        }
        else {
            var22 = var22 + var3.name + ' ';
        }
        final int var12 = 16777215;
        this.font.drawShadow(var22, (float)(var7 - 160), (float)(var8 - 80 - 16), 16777215);
        var22 = var21.format(var3.globalPercentage) + "%";
        this.font.drawShadow(var22, (float)(var7 + 160 - this.font.width(var22)), (float)(var8 - 80 - 16), 16777215);
        for (int var23 = 0; var23 < var2.size(); ++var23) {
            final ResultField var24 = var2.get(var23);
            final StringBuilder var25 = new StringBuilder();
            if ("unspecified".equals(var24.name)) {
                var25.append("[?] ");
            }
            else {
                var25.append("[").append(var23 + 1).append("] ");
            }
            String var26 = var25.append(var24.name).toString();
            this.font.drawShadow(var26, (float)(var7 - 160), (float)(var8 + 80 + var23 * 8 + 20), var24.getColor());
            var26 = var21.format(var24.percentage) + "%";
            this.font.drawShadow(var26, (float)(var7 + 160 - 50 - this.font.width(var26)), (float)(var8 + 80 + var23 * 8 + 20), var24.getColor());
            var26 = var21.format(var24.globalPercentage) + "%";
            this.font.drawShadow(var26, (float)(var7 + 160 - this.font.width(var26)), (float)(var8 + 80 + var23 * 8 + 20), var24.getColor());
        }
    }
    
    public void stop() {
        this.running = false;
    }
    
    public void pauseGame(final boolean b) {
        if (this.screen != null) {
            return;
        }
        final boolean var2 = this.hasSingleplayerServer() && !this.singleplayerServer.isPublished();
        if (var2) {
            this.setScreen(new PauseScreen(!b));
            this.soundManager.pause();
        }
        else {
            this.setScreen(new PauseScreen(true));
        }
    }
    
    private void continueAttack(final boolean b) {
        if (!b) {
            this.missTime = 0;
        }
        if (this.missTime > 0 || this.player.isUsingItem()) {
            return;
        }
        if (b && this.hitResult != null && this.hitResult.getType() == HitResult.Type.BLOCK) {
            final BlockHitResult var2 = (BlockHitResult)this.hitResult;
            final BlockPos var3 = var2.getBlockPos();
            if (!this.level.getBlockState(var3).isAir()) {
                final Direction var4 = var2.getDirection();
                if (this.gameMode.continueDestroyBlock(var3, var4)) {
                    this.particleEngine.crack(var3, var4);
                    this.player.swing(InteractionHand.MAIN_HAND);
                }
            }
            return;
        }
        this.gameMode.stopDestroyBlock();
    }
    
    private void startAttack() {
        if (this.missTime > 0) {
            return;
        }
        if (this.hitResult == null) {
            Minecraft.LOGGER.error("Null returned as 'hitResult', this shouldn't happen!");
            if (this.gameMode.hasMissTime()) {
                this.missTime = 10;
            }
            return;
        }
        if (this.player.isHandsBusy()) {
            return;
        }
        switch (this.hitResult.getType()) {
            case ENTITY: {
                this.gameMode.attack(this.player, ((EntityHitResult)this.hitResult).getEntity());
                break;
            }
            case BLOCK: {
                final BlockHitResult var1 = (BlockHitResult)this.hitResult;
                final BlockPos var2 = var1.getBlockPos();
                if (!this.level.getBlockState(var2).isAir()) {
                    this.gameMode.startDestroyBlock(var2, var1.getDirection());
                    break;
                }
            }
            case MISS: {
                if (this.gameMode.hasMissTime()) {
                    this.missTime = 10;
                }
                this.player.resetAttackStrengthTicker();
                break;
            }
        }
        this.player.swing(InteractionHand.MAIN_HAND);
    }
    
    private void startUseItem() {
        if (this.gameMode.isDestroying()) {
            return;
        }
        this.rightClickDelay = 4;
        if (this.player.isHandsBusy()) {
            return;
        }
        if (this.hitResult == null) {
            Minecraft.LOGGER.warn("Null returned as 'hitResult', this shouldn't happen!");
        }
        for (final InteractionHand var4 : InteractionHand.values()) {
            final ItemStack var5 = this.player.getItemInHand(var4);
            if (this.hitResult != null) {
                switch (this.hitResult.getType()) {
                    case ENTITY: {
                        final EntityHitResult var6 = (EntityHitResult)this.hitResult;
                        final Entity var7 = var6.getEntity();
                        if (this.gameMode.interactAt(this.player, var7, var6, var4) == InteractionResult.SUCCESS) {
                            return;
                        }
                        if (this.gameMode.interact(this.player, var7, var4) == InteractionResult.SUCCESS) {
                            return;
                        }
                        break;
                    }
                    case BLOCK: {
                        final BlockHitResult var8 = (BlockHitResult)this.hitResult;
                        final int var9 = var5.getCount();
                        final InteractionResult var10 = this.gameMode.useItemOn(this.player, this.level, var4, var8);
                        if (var10 == InteractionResult.SUCCESS) {
                            this.player.swing(var4);
                            if (!var5.isEmpty() && (var5.getCount() != var9 || this.gameMode.hasInfiniteItems())) {
                                this.gameRenderer.itemInHandRenderer.itemUsed(var4);
                            }
                            return;
                        }
                        if (var10 == InteractionResult.FAIL) {
                            return;
                        }
                        break;
                    }
                }
            }
            if (!var5.isEmpty() && this.gameMode.useItem(this.player, this.level, var4) == InteractionResult.SUCCESS) {
                this.gameRenderer.itemInHandRenderer.itemUsed(var4);
                return;
            }
        }
    }
    
    public MusicManager getMusicManager() {
        return this.musicManager;
    }
    
    public void tick() {
        if (this.rightClickDelay > 0) {
            --this.rightClickDelay;
        }
        this.profiler.push("gui");
        if (!this.pause) {
            this.gui.tick();
        }
        this.profiler.pop();
        this.gameRenderer.pick(1.0f);
        this.tutorial.onLookAt(this.level, this.hitResult);
        this.profiler.push("gameMode");
        if (!this.pause && this.level != null) {
            this.gameMode.tick();
        }
        this.profiler.popPush("textures");
        if (this.level != null) {
            this.textureManager.tick();
        }
        if (this.screen == null && this.player != null) {
            if (this.player.getHealth() <= 0.0f && !(this.screen instanceof DeathScreen)) {
                this.setScreen(null);
            }
            else if (this.player.isSleeping() && this.level != null) {
                this.setScreen(new InBedChatScreen());
            }
        }
        else if (this.screen != null && this.screen instanceof InBedChatScreen && !this.player.isSleeping()) {
            this.setScreen(null);
        }
        if (this.screen != null) {
            this.missTime = 10000;
        }
        if (this.screen != null) {
            Screen.wrapScreenError(() -> this.screen.tick(), "Ticking screen", this.screen.getClass().getCanonicalName());
        }
        if (!this.options.renderDebug) {
            this.gui.clearCache();
        }
        if (this.overlay == null && (this.screen == null || this.screen.passEvents)) {
            this.profiler.popPush("GLFW events");
            GLX.pollEvents();
            this.handleKeybinds();
            if (this.missTime > 0) {
                --this.missTime;
            }
        }
        if (this.level != null) {
            this.profiler.popPush("gameRenderer");
            if (!this.pause) {
                this.gameRenderer.tick();
            }
            this.profiler.popPush("levelRenderer");
            if (!this.pause) {
                this.levelRenderer.tick();
            }
            this.profiler.popPush("level");
            if (!this.pause) {
                if (this.level.getSkyFlashTime() > 0) {
                    this.level.setSkyFlashTime(this.level.getSkyFlashTime() - 1);
                }
                this.level.tickEntities();
            }
        }
        else if (this.gameRenderer.postEffectActive()) {
            this.gameRenderer.shutdownEffect();
        }
        if (!this.pause) {
            this.musicManager.tick();
        }
        this.soundManager.tick(this.pause);
        if (this.level != null) {
            if (!this.pause) {
                this.level.setSpawnSettings(this.level.getDifficulty() != Difficulty.PEACEFUL, true);
                this.tutorial.tick();
                try {
                    this.level.tick(() -> true);
                }
                catch (Throwable var3) {
                    final CrashReport var2 = CrashReport.forThrowable(var3, "Exception in world tick");
                    if (this.level == null) {
                        final CrashReportCategory var4 = var2.addCategory("Affected level");
                        var4.setDetail("Problem", "Level is null!");
                    }
                    else {
                        this.level.fillReportDetails(var2);
                    }
                    throw new ReportedException(var2);
                }
            }
            this.profiler.popPush("animateTick");
            if (!this.pause && this.level != null) {
                this.level.animateTick(Mth.floor(this.player.x), Mth.floor(this.player.y), Mth.floor(this.player.z));
            }
            this.profiler.popPush("particles");
            if (!this.pause) {
                this.particleEngine.tick();
            }
        }
        else if (this.pendingConnection != null) {
            this.profiler.popPush("pendingConnection");
            this.pendingConnection.tick();
        }
        this.profiler.popPush("keyboard");
        this.keyboardHandler.tick();
        this.profiler.pop();
    }
    
    private void handleKeybinds() {
        while (this.options.keyTogglePerspective.consumeClick()) {
            final Options options = this.options;
            ++options.thirdPersonView;
            if (this.options.thirdPersonView > 2) {
                this.options.thirdPersonView = 0;
            }
            if (this.options.thirdPersonView == 0) {
                this.gameRenderer.checkEntityPostEffect(this.getCameraEntity());
            }
            else if (this.options.thirdPersonView == 1) {
                this.gameRenderer.checkEntityPostEffect(null);
            }
            this.levelRenderer.needsUpdate();
        }
        while (this.options.keySmoothCamera.consumeClick()) {
            this.options.smoothCamera = !this.options.smoothCamera;
        }
        for (int var1 = 0; var1 < 9; ++var1) {
            final boolean var2 = this.options.keySaveHotbarActivator.isDown();
            final boolean var3 = this.options.keyLoadHotbarActivator.isDown();
            if (this.options.keyHotbarSlots[var1].consumeClick()) {
                if (this.player.isSpectator()) {
                    this.gui.getSpectatorGui().onHotbarSelected(var1);
                }
                else if (this.player.isCreative() && this.screen == null && (var3 || var2)) {
                    CreativeModeInventoryScreen.handleHotbarLoadOrSave(this, var1, var3, var2);
                }
                else {
                    this.player.inventory.selected = var1;
                }
            }
        }
        while (this.options.keyInventory.consumeClick()) {
            if (this.gameMode.isServerControlledInventory()) {
                this.player.sendOpenInventory();
            }
            else {
                this.tutorial.onOpenInventory();
                this.setScreen(new InventoryScreen(this.player));
            }
        }
        while (this.options.keyAdvancements.consumeClick()) {
            this.setScreen(new AdvancementsScreen(this.player.connection.getAdvancements()));
        }
        while (this.options.keySwapHands.consumeClick()) {
            if (!this.player.isSpectator()) {
                this.getConnection().send(new ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action.SWAP_HELD_ITEMS, BlockPos.ZERO, Direction.DOWN));
            }
        }
        while (this.options.keyDrop.consumeClick()) {
            if (!this.player.isSpectator()) {
                this.player.drop(Screen.hasControlDown());
            }
        }
        final boolean var4 = this.options.chatVisibility != ChatVisiblity.HIDDEN;
        if (var4) {
            while (this.options.keyChat.consumeClick()) {
                this.setScreen(new ChatScreen(""));
            }
            if (this.screen == null && this.overlay == null && this.options.keyCommand.consumeClick()) {
                this.setScreen(new ChatScreen("/"));
            }
        }
        if (this.player.isUsingItem()) {
            if (!this.options.keyUse.isDown()) {
                this.gameMode.releaseUsingItem(this.player);
            }
            while (this.options.keyAttack.consumeClick()) {}
            while (this.options.keyUse.consumeClick()) {}
            while (this.options.keyPickItem.consumeClick()) {}
        }
        else {
            while (this.options.keyAttack.consumeClick()) {
                this.startAttack();
            }
            while (this.options.keyUse.consumeClick()) {
                this.startUseItem();
            }
            while (this.options.keyPickItem.consumeClick()) {
                this.pickBlock();
            }
        }
        if (this.options.keyUse.isDown() && this.rightClickDelay == 0 && !this.player.isUsingItem()) {
            this.startUseItem();
        }
        this.continueAttack(this.screen == null && this.options.keyAttack.isDown() && this.mouseHandler.isMouseGrabbed());
    }
    
    public void selectLevel(final String var1, final String var2, @Nullable LevelSettings levelSettings) {
        this.clearLevel();
        final LevelStorage var3 = this.levelSource.selectLevel(var1, null);
        LevelData var4 = var3.prepareLevel();
        if (var4 == null && levelSettings != null) {
            var4 = new LevelData(levelSettings, var1);
            var3.saveLevelData(var4);
        }
        if (levelSettings == null) {
            levelSettings = new LevelSettings(var4);
        }
        this.progressListener.set(null);
        try {
            final YggdrasilAuthenticationService var5 = new YggdrasilAuthenticationService(this.proxy, UUID.randomUUID().toString());
            final MinecraftSessionService var6 = var5.createMinecraftSessionService();
            final GameProfileRepository var7 = var5.createProfileRepository();
            final GameProfileCache var8 = new GameProfileCache(var7, new File(this.gameDirectory, MinecraftServer.USERID_CACHE_FILE.getName()));
            SkullBlockEntity.setProfileCache(var8);
            SkullBlockEntity.setSessionService(var6);
            GameProfileCache.setUsesAuthentication(false);
            final StoringChunkProgressListener var9;
            (this.singleplayerServer = new IntegratedServer(this, var1, var2, levelSettings, var5, var6, var7, var8, i -> {
                var9 = new StoringChunkProgressListener(i + 0);
                var9.start();
                this.progressListener.set(var9);
                return new ProcessorChunkProgressListener(var9, this.progressTasks::add);
            })).forkAndRun();
            this.isLocalServer = true;
        }
        catch (Throwable var11) {
            final CrashReport var10 = CrashReport.forThrowable(var11, "Starting integrated server");
            final CrashReportCategory var12 = var10.addCategory("Starting integrated server");
            var12.setDetail("Level ID", var1);
            var12.setDetail("Level Name", var2);
            throw new ReportedException(var10);
        }
        while (this.progressListener.get() == null) {
            Thread.yield();
        }
        final LevelLoadingScreen var13 = new LevelLoadingScreen(this.progressListener.get());
        this.setScreen(var13);
        while (!this.singleplayerServer.isReady()) {
            var13.tick();
            this.runTick(false);
            try {
                Thread.sleep(16L);
            }
            catch (InterruptedException ex) {}
            if (this.hasCrashed && this.delayedCrash != null) {
                this.crash(this.delayedCrash);
                return;
            }
        }
        final SocketAddress var14 = this.singleplayerServer.getConnection().startMemoryChannel();
        final Connection var15 = Connection.connectToLocalServer(var14);
        var15.setListener(new ClientHandshakePacketListenerImpl(var15, this, null, component -> {}));
        var15.send(new ClientIntentionPacket(var14.toString(), 0, ConnectionProtocol.LOGIN));
        var15.send(new ServerboundHelloPacket(this.getUser().getGameProfile()));
        this.pendingConnection = var15;
    }
    
    public void setLevel(final MultiPlayerLevel level) {
        final ProgressScreen var2 = new ProgressScreen();
        var2.progressStartNoAbort(new TranslatableComponent("connect.joining", new Object[0]));
        this.updateScreenAndTick(var2);
        this.updateLevelInEngines(this.level = level);
        if (!this.isLocalServer) {
            final AuthenticationService var3 = (AuthenticationService)new YggdrasilAuthenticationService(this.proxy, UUID.randomUUID().toString());
            final MinecraftSessionService var4 = var3.createMinecraftSessionService();
            final GameProfileRepository var5 = var3.createProfileRepository();
            final GameProfileCache var6 = new GameProfileCache(var5, new File(this.gameDirectory, MinecraftServer.USERID_CACHE_FILE.getName()));
            SkullBlockEntity.setProfileCache(var6);
            SkullBlockEntity.setSessionService(var4);
            GameProfileCache.setUsesAuthentication(false);
        }
    }
    
    public void clearLevel() {
        this.clearLevel(new ProgressScreen());
    }
    
    public void clearLevel(final Screen screen) {
        final ClientPacketListener var2 = this.getConnection();
        if (var2 != null) {
            this.dropAllTasks();
            var2.cleanup();
        }
        final IntegratedServer var3 = this.singleplayerServer;
        this.singleplayerServer = null;
        this.gameRenderer.resetData();
        this.gameMode = null;
        NarratorChatListener.INSTANCE.clear();
        this.updateScreenAndTick(screen);
        if (this.level != null) {
            if (var3 != null) {
                while (!var3.isShutdown()) {
                    this.runTick(false);
                }
            }
            this.clientPackSource.clearServerPack();
            this.gui.onDisconnected();
            this.setCurrentServer(null);
            this.isLocalServer = false;
            this.game.onLeaveGameSession();
        }
        this.updateLevelInEngines(this.level = null);
        this.player = null;
    }
    
    private void updateScreenAndTick(final Screen screen) {
        this.musicManager.stopPlaying();
        this.soundManager.stop();
        this.cameraEntity = null;
        this.pendingConnection = null;
        this.setScreen(screen);
        this.runTick(false);
    }
    
    private void updateLevelInEngines(@Nullable final MultiPlayerLevel multiPlayerLevel) {
        if (this.levelRenderer != null) {
            this.levelRenderer.setLevel(multiPlayerLevel);
        }
        if (this.particleEngine != null) {
            this.particleEngine.setLevel(multiPlayerLevel);
        }
        BlockEntityRenderDispatcher.instance.setLevel(multiPlayerLevel);
    }
    
    public final boolean isDemo() {
        return this.demo;
    }
    
    @Nullable
    public ClientPacketListener getConnection() {
        return (this.player == null) ? null : this.player.connection;
    }
    
    public static boolean renderNames() {
        return Minecraft.instance == null || !Minecraft.instance.options.hideGui;
    }
    
    public static boolean useFancyGraphics() {
        return Minecraft.instance != null && Minecraft.instance.options.fancyGraphics;
    }
    
    public static boolean useAmbientOcclusion() {
        return Minecraft.instance != null && Minecraft.instance.options.ambientOcclusion != AmbientOcclusionStatus.OFF;
    }
    
    private void pickBlock() {
        if (this.hitResult == null || this.hitResult.getType() == HitResult.Type.MISS) {
            return;
        }
        final boolean var1 = this.player.abilities.instabuild;
        BlockEntity var2 = null;
        final HitResult.Type var3 = this.hitResult.getType();
        ItemStack var7;
        if (var3 == HitResult.Type.BLOCK) {
            final BlockPos var4 = ((BlockHitResult)this.hitResult).getBlockPos();
            final BlockState var5 = this.level.getBlockState(var4);
            final Block var6 = var5.getBlock();
            if (var5.isAir()) {
                return;
            }
            var7 = var6.getCloneItemStack(this.level, var4, var5);
            if (var7.isEmpty()) {
                return;
            }
            if (var1 && Screen.hasControlDown() && var6.isEntityBlock()) {
                var2 = this.level.getBlockEntity(var4);
            }
        }
        else {
            if (var3 != HitResult.Type.ENTITY || !var1) {
                return;
            }
            final Entity var8 = ((EntityHitResult)this.hitResult).getEntity();
            if (var8 instanceof Painting) {
                var7 = new ItemStack(Items.PAINTING);
            }
            else if (var8 instanceof LeashFenceKnotEntity) {
                var7 = new ItemStack(Items.LEAD);
            }
            else if (var8 instanceof ItemFrame) {
                final ItemFrame var9 = (ItemFrame)var8;
                final ItemStack var10 = var9.getItem();
                if (var10.isEmpty()) {
                    var7 = new ItemStack(Items.ITEM_FRAME);
                }
                else {
                    var7 = var10.copy();
                }
            }
            else if (var8 instanceof AbstractMinecart) {
                final AbstractMinecart var11 = (AbstractMinecart)var8;
                Item var12 = null;
                switch (var11.getMinecartType()) {
                    case FURNACE: {
                        var12 = Items.FURNACE_MINECART;
                        break;
                    }
                    case CHEST: {
                        var12 = Items.CHEST_MINECART;
                        break;
                    }
                    case TNT: {
                        var12 = Items.TNT_MINECART;
                        break;
                    }
                    case HOPPER: {
                        var12 = Items.HOPPER_MINECART;
                        break;
                    }
                    case COMMAND_BLOCK: {
                        var12 = Items.COMMAND_BLOCK_MINECART;
                        break;
                    }
                    default: {
                        var12 = Items.MINECART;
                        break;
                    }
                }
                var7 = new ItemStack(var12);
            }
            else if (var8 instanceof Boat) {
                var7 = new ItemStack(((Boat)var8).getDropItem());
            }
            else if (var8 instanceof ArmorStand) {
                var7 = new ItemStack(Items.ARMOR_STAND);
            }
            else if (var8 instanceof EndCrystal) {
                var7 = new ItemStack(Items.END_CRYSTAL);
            }
            else {
                final SpawnEggItem var13 = SpawnEggItem.byId(var8.getType());
                if (var13 == null) {
                    return;
                }
                var7 = new ItemStack(var13);
            }
        }
        if (var7.isEmpty()) {
            String var14 = "";
            if (var3 == HitResult.Type.BLOCK) {
                var14 = Registry.BLOCK.getKey(this.level.getBlockState(((BlockHitResult)this.hitResult).getBlockPos()).getBlock()).toString();
            }
            else if (var3 == HitResult.Type.ENTITY) {
                var14 = Registry.ENTITY_TYPE.getKey(((EntityHitResult)this.hitResult).getEntity().getType()).toString();
            }
            Minecraft.LOGGER.warn("Picking on: [{}] {} gave null item", (Object)var3, (Object)var14);
            return;
        }
        final Inventory var15 = this.player.inventory;
        if (var2 != null) {
            this.addCustomNbtData(var7, var2);
        }
        final int var16 = var15.findSlotMatchingItem(var7);
        if (var1) {
            var15.setPickedItem(var7);
            this.gameMode.handleCreativeModeItemAdd(this.player.getItemInHand(InteractionHand.MAIN_HAND), 36 + var15.selected);
        }
        else if (var16 != -1) {
            if (Inventory.isHotbarSlot(var16)) {
                var15.selected = var16;
            }
            else {
                this.gameMode.handlePickItem(var16);
            }
        }
    }
    
    private ItemStack addCustomNbtData(final ItemStack var1, final BlockEntity blockEntity) {
        final CompoundTag var2 = blockEntity.save(new CompoundTag());
        if (var1.getItem() instanceof PlayerHeadItem && var2.contains("Owner")) {
            final CompoundTag var3 = var2.getCompound("Owner");
            var1.getOrCreateTag().put("SkullOwner", var3);
            return var1;
        }
        var1.addTagElement("BlockEntityTag", var2);
        final CompoundTag var3 = new CompoundTag();
        final ListTag var4 = new ListTag();
        ((AbstractList<StringTag>)var4).add(new StringTag("\"(+NBT)\""));
        var3.put("Lore", var4);
        var1.addTagElement("display", var3);
        return var1;
    }
    
    public CrashReport fillReport(final CrashReport crashReport) {
        final CrashReportCategory var2 = crashReport.getSystemDetails();
        var2.setDetail("Launched Version", () -> this.launchedVersion);
        var2.setDetail("LWJGL", GLX::getLWJGLVersion);
        var2.setDetail("OpenGL", GLX::getOpenGLVersionString);
        var2.setDetail("GL Caps", GLX::getCapsString);
        var2.setDetail("Using VBOs", () -> "Yes");
        final String string;
        var2.setDetail("Is Modded", () -> {
            string = ClientBrandRetriever.getClientModName();
            if (!"vanilla".equals(string)) {
                return "Definitely; Client brand changed to '" + string + "'";
            }
            else if (Minecraft.class.getSigners() == null) {
                return "Very likely; Jar signature invalidated";
            }
            else {
                return "Probably not. Jar signature remains and client brand is untouched.";
            }
        });
        var2.setDetail("Type", "Client (map_client.txt)");
        final StringBuilder var3;
        final Iterator<String> iterator;
        String var4;
        var2.setDetail("Resource Packs", () -> {
            var3 = new StringBuilder();
            this.options.resourcePacks.iterator();
            while (iterator.hasNext()) {
                var4 = iterator.next();
                if (var3.length() > 0) {
                    var3.append(", ");
                }
                var3.append(var4);
                if (this.options.incompatibleResourcePacks.contains(var4)) {
                    var3.append(" (incompatible)");
                }
            }
            return var3.toString();
        });
        var2.setDetail("Current Language", () -> this.languageManager.getSelected().toString());
        var2.setDetail("CPU", GLX::getCpuInfo);
        if (this.level != null) {
            this.level.fillReportDetails(crashReport);
        }
        return crashReport;
    }
    
    public static Minecraft getInstance() {
        return Minecraft.instance;
    }
    
    public CompletableFuture<Void> delayTextureReload() {
        return this.submit(this::reloadResourcePacks).thenCompose(completableFuture -> completableFuture);
    }
    
    @Override
    public void populateSnooper(final Snooper snooper) {
        snooper.setDynamicData("fps", Minecraft.fps);
        snooper.setDynamicData("vsync_enabled", this.options.enableVsync);
        final int var2 = GLX.getRefreshRate(this.window);
        snooper.setDynamicData("display_frequency", var2);
        snooper.setDynamicData("display_type", this.window.isFullscreen() ? "fullscreen" : "windowed");
        snooper.setDynamicData("run_time", (Util.getMillis() - snooper.getStartupTime()) / 60L * 1000L);
        snooper.setDynamicData("current_action", this.getCurrentSnooperAction());
        snooper.setDynamicData("language", (this.options.languageCode == null) ? "en_us" : this.options.languageCode);
        final String var3 = (ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN) ? "little" : "big";
        snooper.setDynamicData("endianness", var3);
        snooper.setDynamicData("subtitles", this.options.showSubtitles);
        snooper.setDynamicData("touch", this.options.touchscreen ? "touch" : "mouse");
        int var4 = 0;
        for (final UnopenedResourcePack var5 : this.resourcePackRepository.getSelected()) {
            if (!var5.isRequired() && !var5.isFixedPosition()) {
                snooper.setDynamicData("resource_pack[" + var4++ + "]", var5.getId());
            }
        }
        snooper.setDynamicData("resource_packs", var4);
        if (this.singleplayerServer != null && this.singleplayerServer.getSnooper() != null) {
            snooper.setDynamicData("snooper_partner", this.singleplayerServer.getSnooper().getToken());
        }
    }
    
    private String getCurrentSnooperAction() {
        if (this.singleplayerServer != null) {
            if (this.singleplayerServer.isPublished()) {
                return "hosting_lan";
            }
            return "singleplayer";
        }
        else {
            if (this.currentServer == null) {
                return "out_of_game";
            }
            if (this.currentServer.isLan()) {
                return "playing_lan";
            }
            return "multiplayer";
        }
    }
    
    public static int maxSupportedTextureSize() {
        if (Minecraft.MAX_SUPPORTED_TEXTURE_SIZE == -1) {
            for (int var0 = 16384; var0 > 0; var0 >>= 1) {
                GlStateManager.texImage2D(32868, 0, 6408, var0, var0, 0, 6408, 5121, null);
                final int var2 = GlStateManager.getTexLevelParameter(32868, 0, 4096);
                if (var2 != 0) {
                    return Minecraft.MAX_SUPPORTED_TEXTURE_SIZE = var0;
                }
            }
            Minecraft.MAX_SUPPORTED_TEXTURE_SIZE = Mth.clamp(GlStateManager.getInteger(3379), 1024, 16384);
            Minecraft.LOGGER.info("Failed to determine maximum texture size by probing, trying GL_MAX_TEXTURE_SIZE = {}", (Object)Minecraft.MAX_SUPPORTED_TEXTURE_SIZE);
        }
        return Minecraft.MAX_SUPPORTED_TEXTURE_SIZE;
    }
    
    public void setCurrentServer(final ServerData currentServer) {
        this.currentServer = currentServer;
    }
    
    @Nullable
    public ServerData getCurrentServer() {
        return this.currentServer;
    }
    
    public boolean isLocalServer() {
        return this.isLocalServer;
    }
    
    public boolean hasSingleplayerServer() {
        return this.isLocalServer && this.singleplayerServer != null;
    }
    
    @Nullable
    public IntegratedServer getSingleplayerServer() {
        return this.singleplayerServer;
    }
    
    public Snooper getSnooper() {
        return this.snooper;
    }
    
    public User getUser() {
        return this.user;
    }
    
    public PropertyMap getProfileProperties() {
        if (this.profileProperties.isEmpty()) {
            final GameProfile var1 = this.getMinecraftSessionService().fillProfileProperties(this.user.getGameProfile(), false);
            this.profileProperties.putAll((Multimap)var1.getProperties());
        }
        return this.profileProperties;
    }
    
    public Proxy getProxy() {
        return this.proxy;
    }
    
    public TextureManager getTextureManager() {
        return this.textureManager;
    }
    
    public ResourceManager getResourceManager() {
        return this.resourceManager;
    }
    
    public PackRepository<UnopenedResourcePack> getResourcePackRepository() {
        return this.resourcePackRepository;
    }
    
    public ClientPackSource getClientPackSource() {
        return this.clientPackSource;
    }
    
    public File getResourcePackDirectory() {
        return this.resourcePackDirectory;
    }
    
    public LanguageManager getLanguageManager() {
        return this.languageManager;
    }
    
    public TextureAtlas getTextureAtlas() {
        return this.textureAtlas;
    }
    
    public boolean is64Bit() {
        return this.is64bit;
    }
    
    public boolean isPaused() {
        return this.pause;
    }
    
    public SoundManager getSoundManager() {
        return this.soundManager;
    }
    
    public MusicManager.Music getSituationalMusic() {
        if (this.screen instanceof WinScreen) {
            return MusicManager.Music.CREDITS;
        }
        if (this.player == null) {
            return MusicManager.Music.MENU;
        }
        if (this.player.level.dimension instanceof NetherDimension) {
            return MusicManager.Music.NETHER;
        }
        if (this.player.level.dimension instanceof TheEndDimension) {
            if (this.gui.getBossOverlay().shouldPlayMusic()) {
                return MusicManager.Music.END_BOSS;
            }
            return MusicManager.Music.END;
        }
        else {
            final Biome.BiomeCategory var1 = this.player.level.getBiome(new BlockPos(this.player)).getBiomeCategory();
            if (this.musicManager.isPlayingMusic(MusicManager.Music.UNDER_WATER) || (this.player.isUnderWater() && !this.musicManager.isPlayingMusic(MusicManager.Music.GAME) && (var1 == Biome.BiomeCategory.OCEAN || var1 == Biome.BiomeCategory.RIVER))) {
                return MusicManager.Music.UNDER_WATER;
            }
            if (this.player.abilities.instabuild && this.player.abilities.mayfly) {
                return MusicManager.Music.CREATIVE;
            }
            return MusicManager.Music.GAME;
        }
    }
    
    public MinecraftSessionService getMinecraftSessionService() {
        return this.minecraftSessionService;
    }
    
    public SkinManager getSkinManager() {
        return this.skinManager;
    }
    
    @Nullable
    public Entity getCameraEntity() {
        return this.cameraEntity;
    }
    
    public void setCameraEntity(final Entity cameraEntity) {
        this.cameraEntity = cameraEntity;
        this.gameRenderer.checkEntityPostEffect(cameraEntity);
    }
    
    @Override
    protected Thread getRunningThread() {
        return this.gameThread;
    }
    
    @Override
    protected Runnable wrapRunnable(final Runnable runnable) {
        return runnable;
    }
    
    @Override
    protected boolean shouldRun(final Runnable runnable) {
        return true;
    }
    
    public BlockRenderDispatcher getBlockRenderer() {
        return this.blockRenderer;
    }
    
    public EntityRenderDispatcher getEntityRenderDispatcher() {
        return this.entityRenderDispatcher;
    }
    
    public ItemRenderer getItemRenderer() {
        return this.itemRenderer;
    }
    
    public ItemInHandRenderer getItemInHandRenderer() {
        return this.itemInHandRenderer;
    }
    
    public <T> MutableSearchTree<T> getSearchTree(final SearchRegistry.Key<T> searchRegistry$Key) {
        return this.searchRegistry.getTree(searchRegistry$Key);
    }
    
    public static int getAverageFps() {
        return Minecraft.fps;
    }
    
    public FrameTimer getFrameTimer() {
        return this.frameTimer;
    }
    
    public boolean isConnectedToRealms() {
        return this.connectedToRealms;
    }
    
    public void setConnectedToRealms(final boolean connectedToRealms) {
        this.connectedToRealms = connectedToRealms;
    }
    
    public DataFixer getFixerUpper() {
        return this.fixerUpper;
    }
    
    public float getFrameTime() {
        return this.timer.partialTick;
    }
    
    public float getDeltaFrameTime() {
        return this.timer.tickDelta;
    }
    
    public BlockColors getBlockColors() {
        return this.blockColors;
    }
    
    public boolean showOnlyReducedInfo() {
        return (this.player != null && this.player.isReducedDebugInfo()) || this.options.reducedDebugInfo;
    }
    
    public ToastComponent getToasts() {
        return this.toast;
    }
    
    public Tutorial getTutorial() {
        return this.tutorial;
    }
    
    public boolean isWindowActive() {
        return this.windowActive;
    }
    
    public HotbarManager getHotbarManager() {
        return this.hotbarManager;
    }
    
    public ModelManager getModelManager() {
        return this.modelManager;
    }
    
    public FontManager getFontManager() {
        return this.fontManager;
    }
    
    public PaintingTextureManager getPaintingTextures() {
        return this.paintingTextures;
    }
    
    public MobEffectTextureManager getMobEffectTextures() {
        return this.mobEffectTextures;
    }
    
    @Override
    public void setWindowActive(final boolean windowActive) {
        this.windowActive = windowActive;
    }
    
    public ProfilerFiller getProfiler() {
        return this.profiler;
    }
    
    public Game getGame() {
        return this.game;
    }
    
    public SplashManager getSplashManager() {
        return this.splashManager;
    }
    
    @Nullable
    public Overlay getOverlay() {
        return this.overlay;
    }
    
    static {
        LOGGER = LogManager.getLogger();
        ON_OSX = (Util.getPlatform() == Util.OS.OSX);
        DEFAULT_FONT = new ResourceLocation("default");
        ALT_FONT = new ResourceLocation("alt");
        RESOURCE_RELOAD_INITIAL_TASK = CompletableFuture.completedFuture(Unit.INSTANCE);
        Minecraft.reserve = new byte[10485760];
        Minecraft.MAX_SUPPORTED_TEXTURE_SIZE = -1;
    }
}
