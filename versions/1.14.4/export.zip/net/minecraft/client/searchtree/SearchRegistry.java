package net.minecraft.client.searchtree;

import com.fox2code.repacker.*;
import net.minecraft.world.item.*;
import net.minecraft.client.gui.screens.recipebook.*;
import com.google.common.collect.*;
import net.minecraft.server.packs.resources.*;
import java.util.*;

@ClientJarOnly
public class SearchRegistry implements ResourceManagerReloadListener
{
    public static final Key<ItemStack> CREATIVE_NAMES;
    public static final Key<ItemStack> CREATIVE_TAGS;
    public static final Key<RecipeCollection> RECIPE_COLLECTIONS;
    private final Map<Key<?>, MutableSearchTree<?>> searchTrees;
    
    public SearchRegistry() {
        this.searchTrees = (Map<Key<?>, MutableSearchTree<?>>)Maps.newHashMap();
    }
    
    @Override
    public void onResourceManagerReload(final ResourceManager resourceManager) {
        for (final MutableSearchTree<?> var3 : this.searchTrees.values()) {
            var3.refresh();
        }
    }
    
    public <T> void register(final Key<T> searchRegistry$Key, final MutableSearchTree<T> mutableSearchTree) {
        this.searchTrees.put(searchRegistry$Key, mutableSearchTree);
    }
    
    public <T> MutableSearchTree<T> getTree(final Key<T> searchRegistry$Key) {
        return (MutableSearchTree<T>)this.searchTrees.get(searchRegistry$Key);
    }
    
    static {
        CREATIVE_NAMES = new Key<ItemStack>();
        CREATIVE_TAGS = new Key<ItemStack>();
        RECIPE_COLLECTIONS = new Key<RecipeCollection>();
    }
    
    @ClientJarOnly
    public static class Key<T>
    {
    }
}
