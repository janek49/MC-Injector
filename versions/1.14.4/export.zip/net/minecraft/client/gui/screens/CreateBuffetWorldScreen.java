package net.minecraft.client.gui.screens;

import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import net.minecraft.client.gui.screens.worldselection.*;
import net.minecraft.network.chat.*;
import net.minecraft.client.resources.language.*;
import net.minecraft.*;
import net.minecraft.core.*;
import net.minecraft.nbt.*;
import net.minecraft.world.level.chunk.*;
import java.util.stream.*;
import net.minecraft.world.level.biome.*;
import javax.annotation.*;
import net.minecraft.client.gui.chat.*;
import net.minecraft.client.gui.components.*;
import java.util.*;

@ClientJarOnly
public class CreateBuffetWorldScreen extends Screen
{
    private static final List<ResourceLocation> GENERATORS;
    private final CreateWorldScreen parent;
    private final CompoundTag optionsTag;
    private BiomeList list;
    private int generatorIndex;
    private Button doneButton;
    
    public CreateBuffetWorldScreen(final CreateWorldScreen parent, final CompoundTag optionsTag) {
        super(new TranslatableComponent("createWorld.customize.buffet.title", new Object[0]));
        this.parent = parent;
        this.optionsTag = optionsTag;
    }
    
    @Override
    protected void init() {
        this.minecraft.keyboardHandler.setSendRepeatsToGui(true);
        this.addButton(new Button((this.width - 200) / 2, 40, 200, 20, I18n.get("createWorld.customize.buffet.generatortype", new Object[0]) + " " + I18n.get(Util.makeDescriptionId("generator", CreateBuffetWorldScreen.GENERATORS.get(this.generatorIndex)), new Object[0]), button -> {
            ++this.generatorIndex;
            if (this.generatorIndex >= CreateBuffetWorldScreen.GENERATORS.size()) {
                this.generatorIndex = 0;
            }
            button.setMessage(I18n.get("createWorld.customize.buffet.generatortype", new Object[0]) + " " + I18n.get(Util.makeDescriptionId("generator", CreateBuffetWorldScreen.GENERATORS.get(this.generatorIndex)), new Object[0]));
            return;
        }));
        this.list = new BiomeList();
        this.children.add(this.list);
        this.doneButton = this.addButton(new Button(this.width / 2 - 155, this.height - 28, 150, 20, I18n.get("gui.done", new Object[0]), button -> {
            this.parent.levelTypeOptions = this.saveOptions();
            this.minecraft.setScreen(this.parent);
            return;
        }));
        this.addButton(new Button(this.width / 2 + 5, this.height - 28, 150, 20, I18n.get("gui.cancel", new Object[0]), button -> this.minecraft.setScreen(this.parent)));
        this.loadOptions();
        this.updateButtonValidity();
    }
    
    private void loadOptions() {
        if (this.optionsTag.contains("chunk_generator", 10) && this.optionsTag.getCompound("chunk_generator").contains("type", 8)) {
            final ResourceLocation var1 = new ResourceLocation(this.optionsTag.getCompound("chunk_generator").getString("type"));
            for (int var2 = 0; var2 < CreateBuffetWorldScreen.GENERATORS.size(); ++var2) {
                if (CreateBuffetWorldScreen.GENERATORS.get(var2).equals(var1)) {
                    this.generatorIndex = var2;
                    break;
                }
            }
        }
        if (this.optionsTag.contains("biome_source", 10) && this.optionsTag.getCompound("biome_source").contains("biomes", 9)) {
            final ListTag var3 = this.optionsTag.getCompound("biome_source").getList("biomes", 8);
            for (int var2 = 0; var2 < var3.size(); ++var2) {
                final ResourceLocation var4 = new ResourceLocation(var3.getString(var2));
                this.list.setSelected(this.list.children().stream().filter(createBuffetWorldScreen$BiomeList$Entry -> Objects.equals(createBuffetWorldScreen$BiomeList$Entry.key, var4)).findFirst().orElse(null));
            }
        }
        this.optionsTag.remove("chunk_generator");
        this.optionsTag.remove("biome_source");
    }
    
    private CompoundTag saveOptions() {
        final CompoundTag compoundTag = new CompoundTag();
        final CompoundTag var2 = new CompoundTag();
        var2.putString("type", Registry.BIOME_SOURCE_TYPE.getKey(BiomeSourceType.FIXED).toString());
        final CompoundTag var3 = new CompoundTag();
        final ListTag var4 = new ListTag();
        ((AbstractList<StringTag>)var4).add(new StringTag(this.list.getSelected().key.toString()));
        var3.put("biomes", var4);
        var2.put("options", var3);
        final CompoundTag var5 = new CompoundTag();
        final CompoundTag var6 = new CompoundTag();
        var5.putString("type", CreateBuffetWorldScreen.GENERATORS.get(this.generatorIndex).toString());
        var6.putString("default_block", "minecraft:stone");
        var6.putString("default_fluid", "minecraft:water");
        var5.put("options", var6);
        compoundTag.put("biome_source", var2);
        compoundTag.put("chunk_generator", var5);
        return compoundTag;
    }
    
    public void updateButtonValidity() {
        this.doneButton.active = (this.list.getSelected() != null);
    }
    
    @Override
    public void render(final int var1, final int var2, final float var3) {
        this.renderDirtBackground(0);
        this.list.render(var1, var2, var3);
        this.drawCenteredString(this.font, this.title.getColoredString(), this.width / 2, 8, 16777215);
        this.drawCenteredString(this.font, I18n.get("createWorld.customize.buffet.generator", new Object[0]), this.width / 2, 30, 10526880);
        this.drawCenteredString(this.font, I18n.get("createWorld.customize.buffet.biome", new Object[0]), this.width / 2, 68, 10526880);
        super.render(var1, var2, var3);
    }
    
    static {
        GENERATORS = Registry.CHUNK_GENERATOR_TYPE.keySet().stream().filter(resourceLocation -> Registry.CHUNK_GENERATOR_TYPE.get(resourceLocation).isPublic()).collect((Collector<? super Object, ?, List<ResourceLocation>>)Collectors.toList());
    }
    
    @ClientJarOnly
    class BiomeList extends ObjectSelectionList<Entry>
    {
        private BiomeList() {
            super(CreateBuffetWorldScreen.this.minecraft, CreateBuffetWorldScreen.this.width, CreateBuffetWorldScreen.this.height, 80, CreateBuffetWorldScreen.this.height - 37, 16);
            Registry.BIOME.keySet().stream().sorted(Comparator.comparing(resourceLocation -> Registry.BIOME.get(resourceLocation).getName().getString())).forEach(resourceLocation -> this.addEntry(new Entry(resourceLocation)));
        }
        
        @Override
        protected boolean isFocused() {
            return CreateBuffetWorldScreen.this.getFocused() == this;
        }
        
        @Override
        public void setSelected(@Nullable final Entry selected) {
            super.setSelected(selected);
            if (selected != null) {
                NarratorChatListener.INSTANCE.sayNow(new TranslatableComponent("narrator.select", new Object[] { Registry.BIOME.get(selected.key).getName().getString() }).getString());
            }
        }
        
        @Override
        protected void moveSelection(final int i) {
            super.moveSelection(i);
            CreateBuffetWorldScreen.this.updateButtonValidity();
        }
        
        @ClientJarOnly
        class Entry extends ObjectSelectionList.Entry<Entry>
        {
            private final ResourceLocation key;
            
            public Entry(final ResourceLocation key) {
                this.key = key;
            }
            
            @Override
            public void render(final int var1, final int var2, final int var3, final int var4, final int var5, final int var6, final int var7, final boolean var8, final float var9) {
                BiomeList.this.drawString(CreateBuffetWorldScreen.this.font, Registry.BIOME.get(this.key).getName().getString(), var3 + 5, var2 + 2, 16777215);
            }
            
            @Override
            public boolean mouseClicked(final double var1, final double var3, final int var5) {
                if (var5 == 0) {
                    BiomeList.this.setSelected(this);
                    CreateBuffetWorldScreen.this.updateButtonValidity();
                    return true;
                }
                return false;
            }
        }
    }
}
