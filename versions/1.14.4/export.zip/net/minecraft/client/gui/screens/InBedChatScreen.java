package net.minecraft.client.gui.screens;

import com.fox2code.repacker.*;
import net.minecraft.client.resources.language.*;
import net.minecraft.client.gui.components.*;
import net.minecraft.network.protocol.game.*;
import net.minecraft.world.entity.*;
import net.minecraft.network.protocol.*;
import net.minecraft.client.multiplayer.*;

@ClientJarOnly
public class InBedChatScreen extends ChatScreen
{
    public InBedChatScreen() {
        super("");
    }
    
    @Override
    protected void init() {
        super.init();
        this.addButton(new Button(this.width / 2 - 100, this.height - 40, 200, 20, I18n.get("multiplayer.stopSleeping", new Object[0]), button -> this.sendWakeUp()));
    }
    
    @Override
    public void onClose() {
        this.sendWakeUp();
    }
    
    @Override
    public boolean keyPressed(final int var1, final int var2, final int var3) {
        if (var1 == 256) {
            this.sendWakeUp();
        }
        else if (var1 == 257 || var1 == 335) {
            final String var4 = this.input.getValue().trim();
            if (!var4.isEmpty()) {
                this.minecraft.player.chat(var4);
            }
            this.input.setValue("");
            this.minecraft.gui.getChat().resetChatScroll();
            return true;
        }
        return super.keyPressed(var1, var2, var3);
    }
    
    private void sendWakeUp() {
        final ClientPacketListener var1 = this.minecraft.player.connection;
        var1.send(new ServerboundPlayerCommandPacket(this.minecraft.player, ServerboundPlayerCommandPacket.Action.STOP_SLEEPING));
    }
}
