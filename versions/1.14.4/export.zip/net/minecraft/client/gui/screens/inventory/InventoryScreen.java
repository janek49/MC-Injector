package net.minecraft.client.gui.screens.inventory;

import com.fox2code.repacker.*;
import net.minecraft.resources.*;
import net.minecraft.client.gui.screens.recipebook.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.network.chat.*;
import net.minecraft.client.gui.screens.*;
import net.minecraft.client.gui.components.events.*;
import net.minecraft.client.*;
import net.minecraft.world.entity.*;
import com.mojang.blaze3d.platform.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.world.inventory.*;
import net.minecraft.client.gui.components.*;

@ClientJarOnly
public class InventoryScreen extends EffectRenderingInventoryScreen<InventoryMenu> implements RecipeUpdateListener
{
    private static final ResourceLocation RECIPE_BUTTON_LOCATION;
    private float xMouse;
    private float yMouse;
    private final RecipeBookComponent recipeBookComponent;
    private boolean recipeBookComponentInitialized;
    private boolean widthTooNarrow;
    private boolean buttonClicked;
    
    public InventoryScreen(final Player player) {
        super(player.inventoryMenu, player.inventory, new TranslatableComponent("container.crafting", new Object[0]));
        this.recipeBookComponent = new RecipeBookComponent();
        this.passEvents = true;
    }
    
    @Override
    public void tick() {
        if (this.minecraft.gameMode.hasInfiniteItems()) {
            this.minecraft.setScreen(new CreativeModeInventoryScreen(this.minecraft.player));
            return;
        }
        this.recipeBookComponent.tick();
    }
    
    @Override
    protected void init() {
        if (this.minecraft.gameMode.hasInfiniteItems()) {
            this.minecraft.setScreen(new CreativeModeInventoryScreen(this.minecraft.player));
            return;
        }
        super.init();
        this.widthTooNarrow = (this.width < 379);
        this.recipeBookComponent.init(this.width, this.height, this.minecraft, this.widthTooNarrow, (RecipeBookMenu<?>)this.menu);
        this.recipeBookComponentInitialized = true;
        this.leftPos = this.recipeBookComponent.updateScreenPosition(this.widthTooNarrow, this.width, this.imageWidth);
        this.children.add(this.recipeBookComponent);
        this.setInitialFocus(this.recipeBookComponent);
        this.addButton(new ImageButton(this.leftPos + 104, this.height / 2 - 22, 20, 18, 0, 0, 19, InventoryScreen.RECIPE_BUTTON_LOCATION, button -> {
            this.recipeBookComponent.initVisuals(this.widthTooNarrow);
            this.recipeBookComponent.toggleVisibility();
            this.leftPos = this.recipeBookComponent.updateScreenPosition(this.widthTooNarrow, this.width, this.imageWidth);
            button.setPosition(this.leftPos + 104, this.height / 2 - 22);
            this.buttonClicked = true;
        }));
    }
    
    @Override
    protected void renderLabels(final int var1, final int var2) {
        this.font.draw(this.title.getColoredString(), 97.0f, 8.0f, 4210752);
    }
    
    @Override
    public void render(final int var1, final int var2, final float var3) {
        this.renderBackground();
        this.doRenderEffects = !this.recipeBookComponent.isVisible();
        if (this.recipeBookComponent.isVisible() && this.widthTooNarrow) {
            this.renderBg(var3, var1, var2);
            this.recipeBookComponent.render(var1, var2, var3);
        }
        else {
            this.recipeBookComponent.render(var1, var2, var3);
            super.render(var1, var2, var3);
            this.recipeBookComponent.renderGhostRecipe(this.leftPos, this.topPos, false, var3);
        }
        this.renderTooltip(var1, var2);
        this.recipeBookComponent.renderTooltip(this.leftPos, this.topPos, var1, var2);
        this.xMouse = (float)var1;
        this.yMouse = (float)var2;
        this.magicalSpecialHackyFocus(this.recipeBookComponent);
    }
    
    @Override
    protected void renderBg(final float var1, final int var2, final int var3) {
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.minecraft.getTextureManager().bind(InventoryScreen.INVENTORY_LOCATION);
        final int var4 = this.leftPos;
        final int var5 = this.topPos;
        this.blit(var4, var5, 0, 0, this.imageWidth, this.imageHeight);
        renderPlayerModel(var4 + 51, var5 + 75, 30, var4 + 51 - this.xMouse, var5 + 75 - 50 - this.yMouse, this.minecraft.player);
    }
    
    public static void renderPlayerModel(final int var0, final int var1, final int var2, final float var3, final float var4, final LivingEntity livingEntity) {
        GlStateManager.enableColorMaterial();
        GlStateManager.pushMatrix();
        GlStateManager.translatef((float)var0, (float)var1, 50.0f);
        GlStateManager.scalef((float)(-var2), (float)var2, (float)var2);
        GlStateManager.rotatef(180.0f, 0.0f, 0.0f, 1.0f);
        final float var5 = livingEntity.yBodyRot;
        final float var6 = livingEntity.yRot;
        final float var7 = livingEntity.xRot;
        final float var8 = livingEntity.yHeadRotO;
        final float var9 = livingEntity.yHeadRot;
        GlStateManager.rotatef(135.0f, 0.0f, 1.0f, 0.0f);
        Lighting.turnOn();
        GlStateManager.rotatef(-135.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotatef(-(float)Math.atan(var4 / 40.0f) * 20.0f, 1.0f, 0.0f, 0.0f);
        livingEntity.yBodyRot = (float)Math.atan(var3 / 40.0f) * 20.0f;
        livingEntity.yRot = (float)Math.atan(var3 / 40.0f) * 40.0f;
        livingEntity.xRot = -(float)Math.atan(var4 / 40.0f) * 20.0f;
        livingEntity.yHeadRot = livingEntity.yRot;
        livingEntity.yHeadRotO = livingEntity.yRot;
        GlStateManager.translatef(0.0f, 0.0f, 0.0f);
        final EntityRenderDispatcher var10 = Minecraft.getInstance().getEntityRenderDispatcher();
        var10.setPlayerRotY(180.0f);
        var10.setRenderShadow(false);
        var10.render(livingEntity, 0.0, 0.0, 0.0, 0.0f, 1.0f, false);
        var10.setRenderShadow(true);
        livingEntity.yBodyRot = var5;
        livingEntity.yRot = var6;
        livingEntity.xRot = var7;
        livingEntity.yHeadRotO = var8;
        livingEntity.yHeadRot = var9;
        GlStateManager.popMatrix();
        Lighting.turnOff();
        GlStateManager.disableRescaleNormal();
        GlStateManager.activeTexture(GLX.GL_TEXTURE1);
        GlStateManager.disableTexture();
        GlStateManager.activeTexture(GLX.GL_TEXTURE0);
    }
    
    @Override
    protected boolean isHovering(final int var1, final int var2, final int var3, final int var4, final double var5, final double var7) {
        return (!this.widthTooNarrow || !this.recipeBookComponent.isVisible()) && super.isHovering(var1, var2, var3, var4, var5, var7);
    }
    
    @Override
    public boolean mouseClicked(final double var1, final double var3, final int var5) {
        return this.recipeBookComponent.mouseClicked(var1, var3, var5) || ((!this.widthTooNarrow || !this.recipeBookComponent.isVisible()) && super.mouseClicked(var1, var3, var5));
    }
    
    @Override
    public boolean mouseReleased(final double var1, final double var3, final int var5) {
        if (this.buttonClicked) {
            this.buttonClicked = false;
            return true;
        }
        return super.mouseReleased(var1, var3, var5);
    }
    
    @Override
    protected boolean hasClickedOutside(final double var1, final double var3, final int var5, final int var6, final int var7) {
        final boolean var8 = var1 < var5 || var3 < var6 || var1 >= var5 + this.imageWidth || var3 >= var6 + this.imageHeight;
        return this.recipeBookComponent.hasClickedOutside(var1, var3, this.leftPos, this.topPos, this.imageWidth, this.imageHeight, var7) && var8;
    }
    
    @Override
    protected void slotClicked(final Slot slot, final int var2, final int var3, final ClickType clickType) {
        super.slotClicked(slot, var2, var3, clickType);
        this.recipeBookComponent.slotClicked(slot);
    }
    
    @Override
    public void recipesUpdated() {
        this.recipeBookComponent.recipesUpdated();
    }
    
    @Override
    public void removed() {
        if (this.recipeBookComponentInitialized) {
            this.recipeBookComponent.removed();
        }
        super.removed();
    }
    
    @Override
    public RecipeBookComponent getRecipeBookComponent() {
        return this.recipeBookComponent;
    }
    
    static {
        RECIPE_BUTTON_LOCATION = new ResourceLocation("textures/gui/recipe_button.png");
    }
}
