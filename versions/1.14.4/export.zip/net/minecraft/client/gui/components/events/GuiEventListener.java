package net.minecraft.client.gui.components.events;

import com.fox2code.repacker.*;

@ClientJarOnly
public interface GuiEventListener
{
    default void mouseMoved(final double var1, final double var3) {
    }
    
    default boolean mouseClicked(final double var1, final double var3, final int var5) {
        return false;
    }
    
    default boolean mouseReleased(final double var1, final double var3, final int var5) {
        return false;
    }
    
    default boolean mouseDragged(final double var1, final double var3, final int var5, final double var6, final double var8) {
        return false;
    }
    
    default boolean mouseScrolled(final double var1, final double var3, final double var5) {
        return false;
    }
    
    default boolean keyPressed(final int var1, final int var2, final int var3) {
        return false;
    }
    
    default boolean keyReleased(final int var1, final int var2, final int var3) {
        return false;
    }
    
    default boolean charTyped(final char var1, final int var2) {
        return false;
    }
    
    default boolean changeFocus(final boolean b) {
        return false;
    }
    
    default boolean isMouseOver(final double var1, final double var3) {
        return false;
    }
}
