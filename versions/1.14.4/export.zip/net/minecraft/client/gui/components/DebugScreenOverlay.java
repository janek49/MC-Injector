package net.minecraft.client.gui.components;

import com.fox2code.repacker.*;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.client.gui.*;
import javax.annotation.*;
import java.util.concurrent.*;
import net.minecraft.world.entity.*;
import net.minecraft.client.server.*;
import com.google.common.base.*;
import net.minecraft.client.*;
import net.minecraft.world.level.dimension.*;
import net.minecraft.world.*;
import net.minecraft.world.phys.*;
import net.minecraft.network.*;
import net.minecraft.core.*;
import net.minecraft.world.level.*;
import it.unimi.dsi.fastutil.longs.*;
import net.minecraft.world.level.lighting.*;
import com.mojang.datafixers.*;
import com.mojang.blaze3d.platform.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.resources.*;
import net.minecraft.world.level.block.state.*;
import com.google.common.collect.*;
import net.minecraft.world.level.material.*;
import net.minecraft.*;
import net.minecraft.util.*;
import com.mojang.datafixers.util.*;
import net.minecraft.server.level.*;
import net.minecraft.world.level.chunk.*;
import java.util.*;

@ClientJarOnly
public class DebugScreenOverlay extends GuiComponent
{
    private static final Map<Heightmap.Types, String> HEIGHTMAP_NAMES;
    private final Minecraft minecraft;
    private final Font font;
    private HitResult block;
    private HitResult liquid;
    @Nullable
    private ChunkPos lastPos;
    @Nullable
    private LevelChunk clientChunk;
    @Nullable
    private CompletableFuture<LevelChunk> serverChunk;
    
    public DebugScreenOverlay(final Minecraft minecraft) {
        this.minecraft = minecraft;
        this.font = minecraft.font;
    }
    
    public void clearChunkCache() {
        this.serverChunk = null;
        this.clientChunk = null;
    }
    
    public void render() {
        this.minecraft.getProfiler().push("debug");
        GlStateManager.pushMatrix();
        final Entity var1 = this.minecraft.getCameraEntity();
        this.block = var1.pick(20.0, 0.0f, false);
        this.liquid = var1.pick(20.0, 0.0f, true);
        this.drawGameInformation();
        this.drawSystemInformation();
        GlStateManager.popMatrix();
        if (this.minecraft.options.renderFpsChart) {
            final int var2 = this.minecraft.window.getGuiScaledWidth();
            this.drawChart(this.minecraft.getFrameTimer(), 0, var2 / 2, true);
            final IntegratedServer var3 = this.minecraft.getSingleplayerServer();
            if (var3 != null) {
                this.drawChart(var3.getFrameTimer(), var2 - Math.min(var2 / 2, 240), var2 / 2, false);
            }
        }
        this.minecraft.getProfiler().pop();
    }
    
    protected void drawGameInformation() {
        final List<String> var1 = this.getGameInformation();
        var1.add("");
        final boolean var2 = this.minecraft.getSingleplayerServer() != null;
        var1.add("Debug: Pie [shift]: " + (this.minecraft.options.renderDebugCharts ? "visible" : "hidden") + (var2 ? " FPS + TPS" : " FPS") + " [alt]: " + (this.minecraft.options.renderFpsChart ? "visible" : "hidden"));
        var1.add("For help: press F3 + Q");
        for (int var3 = 0; var3 < var1.size(); ++var3) {
            final String var4 = var1.get(var3);
            if (!Strings.isNullOrEmpty(var4)) {
                this.font.getClass();
                final int var5 = 9;
                final int var6 = this.font.width(var4);
                final int var7 = 2;
                final int var8 = 2 + var5 * var3;
                GuiComponent.fill(1, var8 - 1, 2 + var6 + 1, var8 + var5 - 1, -1873784752);
                this.font.draw(var4, 2.0f, (float)var8, 14737632);
            }
        }
    }
    
    protected void drawSystemInformation() {
        final List<String> var1 = this.getSystemInformation();
        for (int var2 = 0; var2 < var1.size(); ++var2) {
            final String var3 = var1.get(var2);
            if (!Strings.isNullOrEmpty(var3)) {
                this.font.getClass();
                final int var4 = 9;
                final int var5 = this.font.width(var3);
                final int var6 = this.minecraft.window.getGuiScaledWidth() - 2 - var5;
                final int var7 = 2 + var4 * var2;
                GuiComponent.fill(var6 - 1, var7 - 1, var6 + var5 + 1, var7 + var4 - 1, -1873784752);
                this.font.draw(var3, (float)var6, (float)var7, 14737632);
            }
        }
    }
    
    protected List<String> getGameInformation() {
        final IntegratedServer var2 = this.minecraft.getSingleplayerServer();
        final Connection var3 = this.minecraft.getConnection().getConnection();
        final float var4 = var3.getAverageSentPackets();
        final float var5 = var3.getAverageReceivedPackets();
        String var6;
        if (var2 != null) {
            var6 = String.format("Integrated server @ %.0f ms ticks, %.0f tx, %.0f rx", var2.getAverageTickTime(), var4, var5);
        }
        else {
            var6 = String.format("\"%s\" server, %.0f tx, %.0f rx", this.minecraft.player.getServerBrand(), var4, var5);
        }
        final BlockPos var7 = new BlockPos(this.minecraft.getCameraEntity().x, this.minecraft.getCameraEntity().getBoundingBox().minY, this.minecraft.getCameraEntity().z);
        if (this.minecraft.showOnlyReducedInfo()) {
            return (List<String>)Lists.newArrayList((Object[])new String[] { "Minecraft " + SharedConstants.getCurrentVersion().getName() + " (" + this.minecraft.getLaunchedVersion() + "/" + ClientBrandRetriever.getClientModName() + ")", this.minecraft.fpsString, var6, this.minecraft.levelRenderer.getChunkStatistics(), this.minecraft.levelRenderer.getEntityStatistics(), "P: " + this.minecraft.particleEngine.countParticles() + ". T: " + this.minecraft.level.getEntityCount(), this.minecraft.level.gatherChunkSourceStats(), "", String.format("Chunk-relative: %d %d %d", var7.getX() & 0xF, var7.getY() & 0xF, var7.getZ() & 0xF) });
        }
        final Entity var8 = this.minecraft.getCameraEntity();
        final Direction var9 = var8.getDirection();
        String var10 = null;
        switch (var9) {
            case NORTH: {
                var10 = "Towards negative Z";
                break;
            }
            case SOUTH: {
                var10 = "Towards positive Z";
                break;
            }
            case WEST: {
                var10 = "Towards negative X";
                break;
            }
            case EAST: {
                var10 = "Towards positive X";
                break;
            }
            default: {
                var10 = "Invalid";
                break;
            }
        }
        final ChunkPos var11 = new ChunkPos(var7);
        if (!Objects.equals(this.lastPos, var11)) {
            this.lastPos = var11;
            this.clearChunkCache();
        }
        final Level var12 = this.getLevel();
        final LongSet var13 = (var12 instanceof ServerLevel) ? ((ServerLevel)var12).getForcedChunks() : LongSets.EMPTY_SET;
        final List<String> var14 = (List<String>)Lists.newArrayList((Object[])new String[] { "Minecraft " + SharedConstants.getCurrentVersion().getName() + " (" + this.minecraft.getLaunchedVersion() + "/" + ClientBrandRetriever.getClientModName() + ("release".equalsIgnoreCase(this.minecraft.getVersionType()) ? "" : ("/" + this.minecraft.getVersionType())) + ")", this.minecraft.fpsString, var6, this.minecraft.levelRenderer.getChunkStatistics(), this.minecraft.levelRenderer.getEntityStatistics(), "P: " + this.minecraft.particleEngine.countParticles() + ". T: " + this.minecraft.level.getEntityCount(), this.minecraft.level.gatherChunkSourceStats() });
        final String var15 = this.getServerChunkStats();
        if (var15 != null) {
            var14.add(var15);
        }
        var14.add(DimensionType.getName(this.minecraft.level.dimension.getType()).toString() + " FC: " + Integer.toString(var13.size()));
        var14.add("");
        var14.add(String.format(Locale.ROOT, "XYZ: %.3f / %.5f / %.3f", this.minecraft.getCameraEntity().x, this.minecraft.getCameraEntity().getBoundingBox().minY, this.minecraft.getCameraEntity().z));
        var14.add(String.format("Block: %d %d %d", var7.getX(), var7.getY(), var7.getZ()));
        var14.add(String.format("Chunk: %d %d %d in %d %d %d", var7.getX() & 0xF, var7.getY() & 0xF, var7.getZ() & 0xF, var7.getX() >> 4, var7.getY() >> 4, var7.getZ() >> 4));
        var14.add(String.format(Locale.ROOT, "Facing: %s (%s) (%.1f / %.1f)", var9, var10, Mth.wrapDegrees(var8.yRot), Mth.wrapDegrees(var8.xRot)));
        if (this.minecraft.level != null) {
            if (this.minecraft.level.hasChunkAt(var7)) {
                final LevelChunk var16 = this.getClientChunk();
                if (var16.isEmpty()) {
                    var14.add("Waiting for chunk...");
                }
                else {
                    var14.add("Client Light: " + var16.getRawBrightness(var7, 0) + " (" + this.minecraft.level.getBrightness(LightLayer.SKY, var7) + " sky, " + this.minecraft.level.getBrightness(LightLayer.BLOCK, var7) + " block)");
                    final LevelChunk var17 = this.getServerChunk();
                    if (var17 != null) {
                        final LevelLightEngine var18 = var12.getChunkSource().getLightEngine();
                        var14.add("Server Light: (" + var18.getLayerListener(LightLayer.SKY).getLightValue(var7) + " sky, " + var18.getLayerListener(LightLayer.BLOCK).getLightValue(var7) + " block)");
                    }
                    final StringBuilder var19 = new StringBuilder("CH");
                    for (final Heightmap.Types var20 : Heightmap.Types.values()) {
                        if (var20.sendToClient()) {
                            var19.append(" ").append(DebugScreenOverlay.HEIGHTMAP_NAMES.get(var20)).append(": ").append(var16.getHeight(var20, var7.getX(), var7.getZ()));
                        }
                    }
                    var14.add(var19.toString());
                    if (var17 != null) {
                        var19.setLength(0);
                        var19.append("SH");
                        for (final Heightmap.Types var20 : Heightmap.Types.values()) {
                            if (var20.keepAfterWorldgen()) {
                                var19.append(" ").append(DebugScreenOverlay.HEIGHTMAP_NAMES.get(var20)).append(": ").append(var17.getHeight(var20, var7.getX(), var7.getZ()));
                            }
                        }
                        var14.add(var19.toString());
                    }
                    if (var7.getY() >= 0 && var7.getY() < 256) {
                        var14.add("Biome: " + Registry.BIOME.getKey(var16.getBiome(var7)));
                        long var21 = 0L;
                        float var22 = 0.0f;
                        if (var17 != null) {
                            var22 = var12.getMoonBrightness();
                            var21 = var17.getInhabitedTime();
                        }
                        final DifficultyInstance var23 = new DifficultyInstance(var12.getDifficulty(), var12.getDayTime(), var21, var22);
                        var14.add(String.format(Locale.ROOT, "Local Difficulty: %.2f // %.2f (Day %d)", var23.getEffectiveDifficulty(), var23.getSpecialMultiplier(), this.minecraft.level.getDayTime() / 24000L));
                    }
                }
            }
            else {
                var14.add("Outside of world...");
            }
        }
        else {
            var14.add("Outside of world...");
        }
        if (this.minecraft.gameRenderer != null && this.minecraft.gameRenderer.postEffectActive()) {
            var14.add("Shader: " + this.minecraft.gameRenderer.currentEffect().getName());
        }
        if (this.block.getType() == HitResult.Type.BLOCK) {
            final BlockPos var24 = ((BlockHitResult)this.block).getBlockPos();
            var14.add(String.format("Looking at block: %d %d %d", var24.getX(), var24.getY(), var24.getZ()));
        }
        if (this.liquid.getType() == HitResult.Type.BLOCK) {
            final BlockPos var24 = ((BlockHitResult)this.liquid).getBlockPos();
            var14.add(String.format("Looking at liquid: %d %d %d", var24.getX(), var24.getY(), var24.getZ()));
        }
        var14.add(this.minecraft.getSoundManager().getDebugString());
        return var14;
    }
    
    @Nullable
    private String getServerChunkStats() {
        final IntegratedServer var1 = this.minecraft.getSingleplayerServer();
        if (var1 != null) {
            final ServerLevel var2 = var1.getLevel(this.minecraft.level.getDimension().getType());
            if (var2 != null) {
                return var2.gatherChunkSourceStats();
            }
        }
        return null;
    }
    
    private Level getLevel() {
        return (Level)DataFixUtils.orElse((Optional)Optional.ofNullable(this.minecraft.getSingleplayerServer()).map(integratedServer -> integratedServer.getLevel(this.minecraft.level.dimension.getType())), (Object)this.minecraft.level);
    }
    
    @Nullable
    private LevelChunk getServerChunk() {
        if (this.serverChunk == null) {
            final IntegratedServer var1 = this.minecraft.getSingleplayerServer();
            if (var1 != null) {
                final ServerLevel var2 = var1.getLevel(this.minecraft.level.dimension.getType());
                if (var2 != null) {
                    this.serverChunk = var2.getChunkSource().getChunkFuture(this.lastPos.x, this.lastPos.z, ChunkStatus.FULL, false).thenApply(either -> (LevelChunk)either.map(chunkAccess -> chunkAccess, chunkHolder$ChunkLoadingFailure -> null));
                }
            }
            if (this.serverChunk == null) {
                this.serverChunk = CompletableFuture.completedFuture(this.getClientChunk());
            }
        }
        return this.serverChunk.getNow(null);
    }
    
    private LevelChunk getClientChunk() {
        if (this.clientChunk == null) {
            this.clientChunk = this.minecraft.level.getChunk(this.lastPos.x, this.lastPos.z);
        }
        return this.clientChunk;
    }
    
    protected List<String> getSystemInformation() {
        final long var1 = Runtime.getRuntime().maxMemory();
        final long var2 = Runtime.getRuntime().totalMemory();
        final long var3 = Runtime.getRuntime().freeMemory();
        final long var4 = var2 - var3;
        final List<String> var5 = (List<String>)Lists.newArrayList((Object[])new String[] { String.format("Java: %s %dbit", System.getProperty("java.version"), this.minecraft.is64Bit() ? 64 : 32), String.format("Mem: % 2d%% %03d/%03dMB", var4 * 100L / var1, bytesToMegabytes(var4), bytesToMegabytes(var1)), String.format("Allocated: % 2d%% %03dMB", var2 * 100L / var1, bytesToMegabytes(var2)), "", String.format("CPU: %s", GLX.getCpuInfo()), "", String.format("Display: %dx%d (%s)", Minecraft.getInstance().window.getWidth(), Minecraft.getInstance().window.getHeight(), GLX.getVendor()), GLX.getRenderer(), GLX.getOpenGLVersion() });
        if (this.minecraft.showOnlyReducedInfo()) {
            return var5;
        }
        if (this.block.getType() == HitResult.Type.BLOCK) {
            final BlockPos var6 = ((BlockHitResult)this.block).getBlockPos();
            final BlockState var7 = this.minecraft.level.getBlockState(var6);
            var5.add("");
            var5.add(ChatFormatting.UNDERLINE + "Targeted Block");
            var5.add(String.valueOf(Registry.BLOCK.getKey(var7.getBlock())));
            for (final Map.Entry<Property<?>, Comparable<?>> var8 : var7.getValues().entrySet()) {
                var5.add(this.getPropertyValueString(var8));
            }
            for (final ResourceLocation var9 : this.minecraft.getConnection().getTags().getBlocks().getMatchingTags(var7.getBlock())) {
                var5.add("#" + var9);
            }
        }
        if (this.liquid.getType() == HitResult.Type.BLOCK) {
            final BlockPos var6 = ((BlockHitResult)this.liquid).getBlockPos();
            final FluidState var10 = this.minecraft.level.getFluidState(var6);
            var5.add("");
            var5.add(ChatFormatting.UNDERLINE + "Targeted Fluid");
            var5.add(String.valueOf(Registry.FLUID.getKey(var10.getType())));
            for (final Map.Entry<Property<?>, Comparable<?>> var8 : var10.getValues().entrySet()) {
                var5.add(this.getPropertyValueString(var8));
            }
            for (final ResourceLocation var9 : this.minecraft.getConnection().getTags().getFluids().getMatchingTags(var10.getType())) {
                var5.add("#" + var9);
            }
        }
        final Entity var11 = this.minecraft.crosshairPickEntity;
        if (var11 != null) {
            var5.add("");
            var5.add(ChatFormatting.UNDERLINE + "Targeted Entity");
            var5.add(String.valueOf(Registry.ENTITY_TYPE.getKey(var11.getType())));
        }
        return var5;
    }
    
    private String getPropertyValueString(final Map.Entry<Property<?>, Comparable<?>> map$Entry) {
        final Property<?> var2 = map$Entry.getKey();
        final Comparable<?> var3 = map$Entry.getValue();
        String var4 = Util.getPropertyName(var2, var3);
        if (Boolean.TRUE.equals(var3)) {
            var4 = ChatFormatting.GREEN + var4;
        }
        else if (Boolean.FALSE.equals(var3)) {
            var4 = ChatFormatting.RED + var4;
        }
        return var2.getName() + ": " + var4;
    }
    
    private void drawChart(final FrameTimer frameTimer, final int var2, final int var3, final boolean var4) {
        GlStateManager.disableDepthTest();
        final int var5 = frameTimer.getLogStart();
        final int var6 = frameTimer.getLogEnd();
        final long[] vars7 = frameTimer.getLog();
        int var7 = var5;
        int var8 = var2;
        final int var9 = Math.max(0, vars7.length - var3);
        final int var10 = vars7.length - var9;
        var7 = frameTimer.wrapIndex(var7 + var9);
        long var11 = 0L;
        int var12 = Integer.MAX_VALUE;
        int var13 = Integer.MIN_VALUE;
        for (int var14 = 0; var14 < var10; ++var14) {
            final int var15 = (int)(vars7[frameTimer.wrapIndex(var7 + var14)] / 1000000L);
            var12 = Math.min(var12, var15);
            var13 = Math.max(var13, var15);
            var11 += var15;
        }
        int var14 = this.minecraft.window.getGuiScaledHeight();
        GuiComponent.fill(var2, var14 - 60, var2 + var10, var14, -1873784752);
        while (var7 != var6) {
            final int var15 = frameTimer.scaleSampleTo(vars7[var7], var4 ? 30 : 60, var4 ? 60 : 20);
            final int var16 = var4 ? 100 : 60;
            final int var17 = this.getSampleColor(Mth.clamp(var15, 0, var16), 0, var16 / 2, var16);
            this.vLine(var8, var14, var14 - var15, var17);
            ++var8;
            var7 = frameTimer.wrapIndex(var7 + 1);
        }
        if (var4) {
            GuiComponent.fill(var2 + 1, var14 - 30 + 1, var2 + 14, var14 - 30 + 10, -1873784752);
            this.font.draw("60 FPS", (float)(var2 + 2), (float)(var14 - 30 + 2), 14737632);
            this.hLine(var2, var2 + var10 - 1, var14 - 30, -1);
            GuiComponent.fill(var2 + 1, var14 - 60 + 1, var2 + 14, var14 - 60 + 10, -1873784752);
            this.font.draw("30 FPS", (float)(var2 + 2), (float)(var14 - 60 + 2), 14737632);
            this.hLine(var2, var2 + var10 - 1, var14 - 60, -1);
        }
        else {
            GuiComponent.fill(var2 + 1, var14 - 60 + 1, var2 + 14, var14 - 60 + 10, -1873784752);
            this.font.draw("20 TPS", (float)(var2 + 2), (float)(var14 - 60 + 2), 14737632);
            this.hLine(var2, var2 + var10 - 1, var14 - 60, -1);
        }
        this.hLine(var2, var2 + var10 - 1, var14 - 1, -1);
        this.vLine(var2, var14 - 60, var14, -1);
        this.vLine(var2 + var10 - 1, var14 - 60, var14, -1);
        if (var4 && this.minecraft.options.framerateLimit > 0 && this.minecraft.options.framerateLimit <= 250) {
            this.hLine(var2, var2 + var10 - 1, var14 - 1 - (int)(1800.0 / this.minecraft.options.framerateLimit), -16711681);
        }
        final String var18 = var12 + " ms min";
        final String var19 = var11 / var10 + " ms avg";
        final String var20 = var13 + " ms max";
        final Font font = this.font;
        final String string = var18;
        final float var21 = (float)(var2 + 2);
        final int n = var14 - 60;
        this.font.getClass();
        font.drawShadow(string, var21, (float)(n - 9), 14737632);
        final Font font2 = this.font;
        final String string2 = var19;
        final float var22 = (float)(var2 + var10 / 2 - this.font.width(var19) / 2);
        final int n2 = var14 - 60;
        this.font.getClass();
        font2.drawShadow(string2, var22, (float)(n2 - 9), 14737632);
        final Font font3 = this.font;
        final String string3 = var20;
        final float var23 = (float)(var2 + var10 - this.font.width(var20));
        final int n3 = var14 - 60;
        this.font.getClass();
        font3.drawShadow(string3, var23, (float)(n3 - 9), 14737632);
        GlStateManager.enableDepthTest();
    }
    
    private int getSampleColor(final int var1, final int var2, final int var3, final int var4) {
        if (var1 < var3) {
            return this.colorLerp(-16711936, -256, var1 / (float)var3);
        }
        return this.colorLerp(-256, -65536, (var1 - var3) / (float)(var4 - var3));
    }
    
    private int colorLerp(final int var1, final int var2, final float var3) {
        final int var4 = var1 >> 24 & 0xFF;
        final int var5 = var1 >> 16 & 0xFF;
        final int var6 = var1 >> 8 & 0xFF;
        final int var7 = var1 & 0xFF;
        final int var8 = var2 >> 24 & 0xFF;
        final int var9 = var2 >> 16 & 0xFF;
        final int var10 = var2 >> 8 & 0xFF;
        final int var11 = var2 & 0xFF;
        final int var12 = Mth.clamp((int)Mth.lerp(var3, (float)var4, (float)var8), 0, 255);
        final int var13 = Mth.clamp((int)Mth.lerp(var3, (float)var5, (float)var9), 0, 255);
        final int var14 = Mth.clamp((int)Mth.lerp(var3, (float)var6, (float)var10), 0, 255);
        final int var15 = Mth.clamp((int)Mth.lerp(var3, (float)var7, (float)var11), 0, 255);
        return var12 << 24 | var13 << 16 | var14 << 8 | var15;
    }
    
    private static long bytesToMegabytes(final long l) {
        return l / 1024L / 1024L;
    }
    
    static {
        HEIGHTMAP_NAMES = Util.make(new EnumMap<Heightmap.Types, String>(Heightmap.Types.class), enumMap -> {
            enumMap.put(Heightmap.Types.WORLD_SURFACE_WG, "SW");
            enumMap.put(Heightmap.Types.WORLD_SURFACE, "S");
            enumMap.put(Heightmap.Types.OCEAN_FLOOR_WG, "OW");
            enumMap.put(Heightmap.Types.OCEAN_FLOOR, "O");
            enumMap.put(Heightmap.Types.MOTION_BLOCKING, "M");
            enumMap.put(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, "ML");
        });
    }
}
