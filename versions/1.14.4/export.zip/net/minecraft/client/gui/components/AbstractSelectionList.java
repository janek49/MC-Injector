package net.minecraft.client.gui.components;

import com.fox2code.repacker.*;
import net.minecraft.client.*;
import javax.annotation.*;
import net.minecraft.util.*;
import com.mojang.blaze3d.platform.*;
import net.minecraft.client.gui.*;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.gui.components.events.*;
import java.util.*;
import com.google.common.collect.*;

@ClientJarOnly
public abstract class AbstractSelectionList<E extends Entry<E>> extends AbstractContainerEventHandler implements Widget
{
    protected static final int DRAG_OUTSIDE = -2;
    protected final Minecraft minecraft;
    protected final int itemHeight;
    private final List<E> children;
    protected int width;
    protected int height;
    protected int y0;
    protected int y1;
    protected int x1;
    protected int x0;
    protected boolean centerListVertically;
    protected int yDrag;
    private double scrollAmount;
    protected boolean renderSelection;
    protected boolean renderHeader;
    protected int headerHeight;
    private boolean scrolling;
    private E selected;
    
    public AbstractSelectionList(final Minecraft minecraft, final int width, final int height, final int y0, final int y1, final int itemHeight) {
        this.children = new TrackedList();
        this.centerListVertically = true;
        this.yDrag = -2;
        this.renderSelection = true;
        this.minecraft = minecraft;
        this.width = width;
        this.height = height;
        this.y0 = y0;
        this.y1 = y1;
        this.itemHeight = itemHeight;
        this.x0 = 0;
        this.x1 = width;
    }
    
    public void setRenderSelection(final boolean renderSelection) {
        this.renderSelection = renderSelection;
    }
    
    protected void setRenderHeader(final boolean renderHeader, final int headerHeight) {
        this.renderHeader = renderHeader;
        this.headerHeight = headerHeight;
        if (!renderHeader) {
            this.headerHeight = 0;
        }
    }
    
    public int getRowWidth() {
        return 220;
    }
    
    @Nullable
    public E getSelected() {
        return this.selected;
    }
    
    public void setSelected(@Nullable final E selected) {
        this.selected = selected;
    }
    
    @Nullable
    @Override
    public E getFocused() {
        return (E)super.getFocused();
    }
    
    @Override
    public final List<E> children() {
        return this.children;
    }
    
    protected final void clearEntries() {
        this.children.clear();
    }
    
    protected void replaceEntries(final Collection<E> collection) {
        this.children.clear();
        this.children.addAll((Collection<? extends E>)collection);
    }
    
    protected E getEntry(final int i) {
        return this.children().get(i);
    }
    
    protected int addEntry(final E abstractSelectionList$Entry) {
        this.children.add(abstractSelectionList$Entry);
        return this.children.size() - 1;
    }
    
    protected int getItemCount() {
        return this.children().size();
    }
    
    protected boolean isSelectedItem(final int i) {
        return Objects.equals(this.getSelected(), this.children().get(i));
    }
    
    @Nullable
    protected final E getEntryAtPosition(final double var1, final double var3) {
        final int var4 = this.getRowWidth() / 2;
        final int var5 = this.x0 + this.width / 2;
        final int var6 = var5 - var4;
        final int var7 = var5 + var4;
        final int var8 = Mth.floor(var3 - this.y0) - this.headerHeight + (int)this.getScrollAmount() - 4;
        final int var9 = var8 / this.itemHeight;
        if (var1 < this.getScrollbarPosition() && var1 >= var6 && var1 <= var7 && var9 >= 0 && var8 >= 0 && var9 < this.getItemCount()) {
            return this.children().get(var9);
        }
        return null;
    }
    
    public void updateSize(final int width, final int height, final int y0, final int y1) {
        this.width = width;
        this.height = height;
        this.y0 = y0;
        this.y1 = y1;
        this.x0 = 0;
        this.x1 = width;
    }
    
    public void setLeftPos(final int leftPos) {
        this.x0 = leftPos;
        this.x1 = leftPos + this.width;
    }
    
    protected int getMaxPosition() {
        return this.getItemCount() * this.itemHeight + this.headerHeight;
    }
    
    protected void clickedHeader(final int var1, final int var2) {
    }
    
    protected void renderHeader(final int var1, final int var2, final Tesselator tesselator) {
    }
    
    protected void renderBackground() {
    }
    
    protected void renderDecorations(final int var1, final int var2) {
    }
    
    @Override
    public void render(final int var1, final int var2, final float var3) {
        this.renderBackground();
        final int var4 = this.getScrollbarPosition();
        final int var5 = var4 + 6;
        GlStateManager.disableLighting();
        GlStateManager.disableFog();
        final Tesselator var6 = Tesselator.getInstance();
        final BufferBuilder var7 = var6.getBuilder();
        this.minecraft.getTextureManager().bind(GuiComponent.BACKGROUND_LOCATION);
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        final float var8 = 32.0f;
        var7.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
        var7.vertex(this.x0, this.y1, 0.0).uv(this.x0 / 32.0f, (this.y1 + (int)this.getScrollAmount()) / 32.0f).color(32, 32, 32, 255).endVertex();
        var7.vertex(this.x1, this.y1, 0.0).uv(this.x1 / 32.0f, (this.y1 + (int)this.getScrollAmount()) / 32.0f).color(32, 32, 32, 255).endVertex();
        var7.vertex(this.x1, this.y0, 0.0).uv(this.x1 / 32.0f, (this.y0 + (int)this.getScrollAmount()) / 32.0f).color(32, 32, 32, 255).endVertex();
        var7.vertex(this.x0, this.y0, 0.0).uv(this.x0 / 32.0f, (this.y0 + (int)this.getScrollAmount()) / 32.0f).color(32, 32, 32, 255).endVertex();
        var6.end();
        final int var9 = this.getRowLeft();
        final int var10 = this.y0 + 4 - (int)this.getScrollAmount();
        if (this.renderHeader) {
            this.renderHeader(var9, var10, var6);
        }
        this.renderList(var9, var10, var1, var2, var3);
        GlStateManager.disableDepthTest();
        this.renderHoleBackground(0, this.y0, 255, 255);
        this.renderHoleBackground(this.y1, this.height, 255, 255);
        GlStateManager.enableBlend();
        GlStateManager.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ZERO, GlStateManager.DestFactor.ONE);
        GlStateManager.disableAlphaTest();
        GlStateManager.shadeModel(7425);
        GlStateManager.disableTexture();
        final int var11 = 4;
        var7.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
        var7.vertex(this.x0, this.y0 + 4, 0.0).uv(0.0, 1.0).color(0, 0, 0, 0).endVertex();
        var7.vertex(this.x1, this.y0 + 4, 0.0).uv(1.0, 1.0).color(0, 0, 0, 0).endVertex();
        var7.vertex(this.x1, this.y0, 0.0).uv(1.0, 0.0).color(0, 0, 0, 255).endVertex();
        var7.vertex(this.x0, this.y0, 0.0).uv(0.0, 0.0).color(0, 0, 0, 255).endVertex();
        var6.end();
        var7.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
        var7.vertex(this.x0, this.y1, 0.0).uv(0.0, 1.0).color(0, 0, 0, 255).endVertex();
        var7.vertex(this.x1, this.y1, 0.0).uv(1.0, 1.0).color(0, 0, 0, 255).endVertex();
        var7.vertex(this.x1, this.y1 - 4, 0.0).uv(1.0, 0.0).color(0, 0, 0, 0).endVertex();
        var7.vertex(this.x0, this.y1 - 4, 0.0).uv(0.0, 0.0).color(0, 0, 0, 0).endVertex();
        var6.end();
        final int var12 = this.getMaxScroll();
        if (var12 > 0) {
            int var13 = (int)((this.y1 - this.y0) * (this.y1 - this.y0) / (float)this.getMaxPosition());
            var13 = Mth.clamp(var13, 32, this.y1 - this.y0 - 8);
            int var14 = (int)this.getScrollAmount() * (this.y1 - this.y0 - var13) / var12 + this.y0;
            if (var14 < this.y0) {
                var14 = this.y0;
            }
            var7.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
            var7.vertex(var4, this.y1, 0.0).uv(0.0, 1.0).color(0, 0, 0, 255).endVertex();
            var7.vertex(var5, this.y1, 0.0).uv(1.0, 1.0).color(0, 0, 0, 255).endVertex();
            var7.vertex(var5, this.y0, 0.0).uv(1.0, 0.0).color(0, 0, 0, 255).endVertex();
            var7.vertex(var4, this.y0, 0.0).uv(0.0, 0.0).color(0, 0, 0, 255).endVertex();
            var6.end();
            var7.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
            var7.vertex(var4, var14 + var13, 0.0).uv(0.0, 1.0).color(128, 128, 128, 255).endVertex();
            var7.vertex(var5, var14 + var13, 0.0).uv(1.0, 1.0).color(128, 128, 128, 255).endVertex();
            var7.vertex(var5, var14, 0.0).uv(1.0, 0.0).color(128, 128, 128, 255).endVertex();
            var7.vertex(var4, var14, 0.0).uv(0.0, 0.0).color(128, 128, 128, 255).endVertex();
            var6.end();
            var7.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
            var7.vertex(var4, var14 + var13 - 1, 0.0).uv(0.0, 1.0).color(192, 192, 192, 255).endVertex();
            var7.vertex(var5 - 1, var14 + var13 - 1, 0.0).uv(1.0, 1.0).color(192, 192, 192, 255).endVertex();
            var7.vertex(var5 - 1, var14, 0.0).uv(1.0, 0.0).color(192, 192, 192, 255).endVertex();
            var7.vertex(var4, var14, 0.0).uv(0.0, 0.0).color(192, 192, 192, 255).endVertex();
            var6.end();
        }
        this.renderDecorations(var1, var2);
        GlStateManager.enableTexture();
        GlStateManager.shadeModel(7424);
        GlStateManager.enableAlphaTest();
        GlStateManager.disableBlend();
    }
    
    protected void centerScrollOn(final E abstractSelectionList$Entry) {
        this.setScrollAmount(this.children().indexOf(abstractSelectionList$Entry) * this.itemHeight + this.itemHeight / 2 - (this.y1 - this.y0) / 2);
    }
    
    protected void ensureVisible(final E abstractSelectionList$Entry) {
        final int var2 = this.getRowTop(this.children().indexOf(abstractSelectionList$Entry));
        final int var3 = var2 - this.y0 - 4 - this.itemHeight;
        if (var3 < 0) {
            this.scroll(var3);
        }
        final int var4 = this.y1 - var2 - this.itemHeight - this.itemHeight;
        if (var4 < 0) {
            this.scroll(-var4);
        }
    }
    
    private void scroll(final int i) {
        this.setScrollAmount(this.getScrollAmount() + i);
        this.yDrag = -2;
    }
    
    public double getScrollAmount() {
        return this.scrollAmount;
    }
    
    public void setScrollAmount(final double scrollAmount) {
        this.scrollAmount = Mth.clamp(scrollAmount, 0.0, this.getMaxScroll());
    }
    
    private int getMaxScroll() {
        return Math.max(0, this.getMaxPosition() - (this.y1 - this.y0 - 4));
    }
    
    public int getScrollBottom() {
        return (int)this.getScrollAmount() - this.height - this.headerHeight;
    }
    
    protected void updateScrollingState(final double var1, final double var3, final int var5) {
        this.scrolling = (var5 == 0 && var1 >= this.getScrollbarPosition() && var1 < this.getScrollbarPosition() + 6);
    }
    
    protected int getScrollbarPosition() {
        return this.width / 2 + 124;
    }
    
    @Override
    public boolean mouseClicked(final double var1, final double var3, final int var5) {
        this.updateScrollingState(var1, var3, var5);
        if (!this.isMouseOver(var1, var3)) {
            return false;
        }
        final E var6 = this.getEntryAtPosition(var1, var3);
        if (var6 != null) {
            if (var6.mouseClicked(var1, var3, var5)) {
                this.setFocused(var6);
                this.setDragging(true);
                return true;
            }
        }
        else if (var5 == 0) {
            this.clickedHeader((int)(var1 - (this.x0 + this.width / 2 - this.getRowWidth() / 2)), (int)(var3 - this.y0) + (int)this.getScrollAmount() - 4);
            return true;
        }
        return this.scrolling;
    }
    
    @Override
    public boolean mouseReleased(final double var1, final double var3, final int var5) {
        if (this.getFocused() != null) {
            this.getFocused().mouseReleased(var1, var3, var5);
        }
        return false;
    }
    
    @Override
    public boolean mouseDragged(final double var1, final double var3, final int var5, final double var6, final double var8) {
        if (super.mouseDragged(var1, var3, var5, var6, var8)) {
            return true;
        }
        if (var5 != 0 || !this.scrolling) {
            return false;
        }
        if (var3 < this.y0) {
            this.setScrollAmount(0.0);
        }
        else if (var3 > this.y1) {
            this.setScrollAmount(this.getMaxScroll());
        }
        else {
            final double var9 = Math.max(1, this.getMaxScroll());
            final int var10 = this.y1 - this.y0;
            final int var11 = Mth.clamp((int)(var10 * var10 / (float)this.getMaxPosition()), 32, var10 - 8);
            final double var12 = Math.max(1.0, var9 / (var10 - var11));
            this.setScrollAmount(this.getScrollAmount() + var8 * var12);
        }
        return true;
    }
    
    @Override
    public boolean mouseScrolled(final double var1, final double var3, final double var5) {
        this.setScrollAmount(this.getScrollAmount() - var5 * this.itemHeight / 2.0);
        return true;
    }
    
    @Override
    public boolean keyPressed(final int var1, final int var2, final int var3) {
        if (super.keyPressed(var1, var2, var3)) {
            return true;
        }
        if (var1 == 264) {
            this.moveSelection(1);
            return true;
        }
        if (var1 == 265) {
            this.moveSelection(-1);
            return true;
        }
        return false;
    }
    
    protected void moveSelection(final int i) {
        if (!this.children().isEmpty()) {
            final int var2 = this.children().indexOf(this.getSelected());
            final int var3 = Mth.clamp(var2 + i, 0, this.getItemCount() - 1);
            final E var4 = this.children().get(var3);
            this.setSelected(var4);
            this.ensureVisible(var4);
        }
    }
    
    @Override
    public boolean isMouseOver(final double var1, final double var3) {
        return var3 >= this.y0 && var3 <= this.y1 && var1 >= this.x0 && var1 <= this.x1;
    }
    
    protected void renderList(final int var1, final int var2, final int var3, final int var4, final float var5) {
        final int var6 = this.getItemCount();
        final Tesselator var7 = Tesselator.getInstance();
        final BufferBuilder var8 = var7.getBuilder();
        for (int var9 = 0; var9 < var6; ++var9) {
            final int var10 = this.getRowTop(var9);
            final int var11 = this.getRowBottom(var9);
            if (var11 >= this.y0) {
                if (var10 <= this.y1) {
                    final int var12 = var2 + var9 * this.itemHeight + this.headerHeight;
                    final int var13 = this.itemHeight - 4;
                    final E var14 = this.getEntry(var9);
                    final int var15 = this.getRowWidth();
                    if (this.renderSelection && this.isSelectedItem(var9)) {
                        final int var16 = this.x0 + this.width / 2 - var15 / 2;
                        final int var17 = this.x0 + this.width / 2 + var15 / 2;
                        GlStateManager.disableTexture();
                        final float var18 = this.isFocused() ? 1.0f : 0.5f;
                        GlStateManager.color4f(var18, var18, var18, 1.0f);
                        var8.begin(7, DefaultVertexFormat.POSITION);
                        var8.vertex(var16, var12 + var13 + 2, 0.0).endVertex();
                        var8.vertex(var17, var12 + var13 + 2, 0.0).endVertex();
                        var8.vertex(var17, var12 - 2, 0.0).endVertex();
                        var8.vertex(var16, var12 - 2, 0.0).endVertex();
                        var7.end();
                        GlStateManager.color4f(0.0f, 0.0f, 0.0f, 1.0f);
                        var8.begin(7, DefaultVertexFormat.POSITION);
                        var8.vertex(var16 + 1, var12 + var13 + 1, 0.0).endVertex();
                        var8.vertex(var17 - 1, var12 + var13 + 1, 0.0).endVertex();
                        var8.vertex(var17 - 1, var12 - 1, 0.0).endVertex();
                        var8.vertex(var16 + 1, var12 - 1, 0.0).endVertex();
                        var7.end();
                        GlStateManager.enableTexture();
                    }
                    final int var16 = this.getRowLeft();
                    var14.render(var9, var10, var16, var15, var13, var3, var4, this.isMouseOver(var3, var4) && Objects.equals(this.getEntryAtPosition(var3, var4), var14), var5);
                }
            }
        }
    }
    
    protected int getRowLeft() {
        return this.x0 + this.width / 2 - this.getRowWidth() / 2 + 2;
    }
    
    protected int getRowTop(final int i) {
        return this.y0 + 4 - (int)this.getScrollAmount() + i * this.itemHeight + this.headerHeight;
    }
    
    private int getRowBottom(final int i) {
        return this.getRowTop(i) + this.itemHeight;
    }
    
    protected boolean isFocused() {
        return false;
    }
    
    protected void renderHoleBackground(final int var1, final int var2, final int var3, final int var4) {
        final Tesselator var5 = Tesselator.getInstance();
        final BufferBuilder var6 = var5.getBuilder();
        this.minecraft.getTextureManager().bind(GuiComponent.BACKGROUND_LOCATION);
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        final float var7 = 32.0f;
        var6.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
        var6.vertex(this.x0, var2, 0.0).uv(0.0, var2 / 32.0f).color(64, 64, 64, var4).endVertex();
        var6.vertex(this.x0 + this.width, var2, 0.0).uv(this.width / 32.0f, var2 / 32.0f).color(64, 64, 64, var4).endVertex();
        var6.vertex(this.x0 + this.width, var1, 0.0).uv(this.width / 32.0f, var1 / 32.0f).color(64, 64, 64, var3).endVertex();
        var6.vertex(this.x0, var1, 0.0).uv(0.0, var1 / 32.0f).color(64, 64, 64, var3).endVertex();
        var5.end();
    }
    
    protected E remove(final int i) {
        final E abstractSelectionList$Entry = this.children.get(i);
        if (this.removeEntry(this.children.get(i))) {
            return abstractSelectionList$Entry;
        }
        return null;
    }
    
    protected boolean removeEntry(final E abstractSelectionList$Entry) {
        final boolean var2 = this.children.remove(abstractSelectionList$Entry);
        if (var2 && abstractSelectionList$Entry == this.getSelected()) {
            this.setSelected(null);
        }
        return var2;
    }
    
    @ClientJarOnly
    public abstract static class Entry<E extends Entry<E>> implements GuiEventListener
    {
        @Deprecated
        AbstractSelectionList<E> list;
        
        public abstract void render(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final boolean p7, final float p8);
        
        @Override
        public boolean isMouseOver(final double var1, final double var3) {
            return Objects.equals(this.list.getEntryAtPosition(var1, var3), this);
        }
    }
    
    @ClientJarOnly
    class TrackedList extends AbstractList<E>
    {
        private final List<E> delegate;
        
        private TrackedList() {
            this.delegate = (List<E>)Lists.newArrayList();
        }
        
        @Override
        public E get(final int i) {
            return this.delegate.get(i);
        }
        
        @Override
        public int size() {
            return this.delegate.size();
        }
        
        @Override
        public E set(final int var1, final E var2) {
            final E var3 = this.delegate.set(var1, var2);
            var2.list = (AbstractSelectionList<E>)AbstractSelectionList.this;
            return var3;
        }
        
        @Override
        public void add(final int var1, final E abstractSelectionList$Entry) {
            this.delegate.add(var1, abstractSelectionList$Entry);
            abstractSelectionList$Entry.list = (AbstractSelectionList<E>)AbstractSelectionList.this;
        }
        
        @Override
        public E remove(final int i) {
            return this.delegate.remove(i);
        }
    }
}
