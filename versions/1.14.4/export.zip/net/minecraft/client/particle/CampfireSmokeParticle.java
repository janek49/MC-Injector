package net.minecraft.client.particle;

import com.fox2code.repacker.*;
import net.minecraft.world.level.*;
import net.minecraft.core.particles.*;

@ClientJarOnly
public class CampfireSmokeParticle extends TextureSheetParticle
{
    private CampfireSmokeParticle(final Level level, final double var2, final double var4, final double var6, final double xd, final double var10, final double zd, final boolean var14) {
        super(level, var2, var4, var6);
        this.scale(3.0f);
        this.setSize(0.25f, 0.25f);
        if (var14) {
            this.lifetime = this.random.nextInt(50) + 280;
        }
        else {
            this.lifetime = this.random.nextInt(50) + 80;
        }
        this.gravity = 3.0E-6f;
        this.xd = xd;
        this.yd = var10 + this.random.nextFloat() / 500.0f;
        this.zd = zd;
    }
    
    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime || this.alpha <= 0.0f) {
            this.remove();
            return;
        }
        this.xd += this.random.nextFloat() / 5000.0f * (this.random.nextBoolean() ? 1 : -1);
        this.zd += this.random.nextFloat() / 5000.0f * (this.random.nextBoolean() ? 1 : -1);
        this.yd -= this.gravity;
        this.move(this.xd, this.yd, this.zd);
        if (this.age >= this.lifetime - 60 && this.alpha > 0.01f) {
            this.alpha -= 0.015f;
        }
    }
    
    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }
    
    @ClientJarOnly
    public static class CosyProvider implements ParticleProvider<SimpleParticleType>
    {
        private final SpriteSet sprites;
        
        public CosyProvider(final SpriteSet sprites) {
            this.sprites = sprites;
        }
        
        @Override
        public Particle createParticle(final SimpleParticleType simpleParticleType, final Level level, final double var3, final double var5, final double var7, final double var9, final double var11, final double var13) {
            final CampfireSmokeParticle var14 = new CampfireSmokeParticle(level, var3, var5, var7, var9, var11, var13, false, null);
            var14.setAlpha(0.9f);
            var14.pickSprite(this.sprites);
            return var14;
        }
    }
    
    @ClientJarOnly
    public static class SignalProvider implements ParticleProvider<SimpleParticleType>
    {
        private final SpriteSet sprites;
        
        public SignalProvider(final SpriteSet sprites) {
            this.sprites = sprites;
        }
        
        @Override
        public Particle createParticle(final SimpleParticleType simpleParticleType, final Level level, final double var3, final double var5, final double var7, final double var9, final double var11, final double var13) {
            final CampfireSmokeParticle var14 = new CampfireSmokeParticle(level, var3, var5, var7, var9, var11, var13, true, null);
            var14.setAlpha(0.95f);
            var14.pickSprite(this.sprites);
            return var14;
        }
    }
}
