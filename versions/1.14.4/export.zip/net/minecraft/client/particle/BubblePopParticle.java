package net.minecraft.client.particle;

import com.fox2code.repacker.*;
import net.minecraft.world.level.*;
import net.minecraft.core.particles.*;

@ClientJarOnly
public class BubblePopParticle extends TextureSheetParticle
{
    private final SpriteSet sprites;
    
    private BubblePopParticle(final Level level, final double var2, final double var4, final double var6, final double xd, final double yd, final double zd, final SpriteSet sprites) {
        super(level, var2, var4, var6);
        this.sprites = sprites;
        this.lifetime = 4;
        this.gravity = 0.008f;
        this.xd = xd;
        this.yd = yd;
        this.zd = zd;
        this.setSpriteFromAge(sprites);
    }
    
    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        this.yd -= this.gravity;
        this.move(this.xd, this.yd, this.zd);
        this.setSpriteFromAge(this.sprites);
    }
    
    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_OPAQUE;
    }
    
    @ClientJarOnly
    public static class Provider implements ParticleProvider<SimpleParticleType>
    {
        private final SpriteSet sprites;
        
        public Provider(final SpriteSet sprites) {
            this.sprites = sprites;
        }
        
        @Override
        public Particle createParticle(final SimpleParticleType simpleParticleType, final Level level, final double var3, final double var5, final double var7, final double var9, final double var11, final double var13) {
            return new BubblePopParticle(level, var3, var5, var7, var9, var11, var13, this.sprites, null);
        }
    }
}
