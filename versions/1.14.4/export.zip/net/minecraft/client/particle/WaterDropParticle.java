package net.minecraft.client.particle;

import com.fox2code.repacker.*;
import net.minecraft.world.level.*;
import net.minecraft.core.*;
import net.minecraft.core.particles.*;

@ClientJarOnly
public class WaterDropParticle extends TextureSheetParticle
{
    protected WaterDropParticle(final Level level, final double var2, final double var4, final double var6) {
        super(level, var2, var4, var6, 0.0, 0.0, 0.0);
        this.xd *= 0.30000001192092896;
        this.yd = Math.random() * 0.20000000298023224 + 0.10000000149011612;
        this.zd *= 0.30000001192092896;
        this.setSize(0.01f, 0.01f);
        this.gravity = 0.06f;
        this.lifetime = (int)(8.0 / (Math.random() * 0.8 + 0.2));
    }
    
    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_OPAQUE;
    }
    
    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.lifetime-- <= 0) {
            this.remove();
            return;
        }
        this.yd -= this.gravity;
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.9800000190734863;
        this.yd *= 0.9800000190734863;
        this.zd *= 0.9800000190734863;
        if (this.onGround) {
            if (Math.random() < 0.5) {
                this.remove();
            }
            this.xd *= 0.699999988079071;
            this.zd *= 0.699999988079071;
        }
        final BlockPos var1 = new BlockPos(this.x, this.y, this.z);
        final double var2 = Math.max(this.level.getBlockState(var1).getCollisionShape(this.level, var1).max(Direction.Axis.Y, this.x - var1.getX(), this.z - var1.getZ()), this.level.getFluidState(var1).getHeight(this.level, var1));
        if (var2 > 0.0 && this.y < var1.getY() + var2) {
            this.remove();
        }
    }
    
    @ClientJarOnly
    public static class Provider implements ParticleProvider<SimpleParticleType>
    {
        private final SpriteSet sprite;
        
        public Provider(final SpriteSet sprite) {
            this.sprite = sprite;
        }
        
        @Override
        public Particle createParticle(final SimpleParticleType simpleParticleType, final Level level, final double var3, final double var5, final double var7, final double var9, final double var11, final double var13) {
            final WaterDropParticle var14 = new WaterDropParticle(level, var3, var5, var7);
            var14.pickSprite(this.sprite);
            return var14;
        }
    }
}
