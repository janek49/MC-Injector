package net.minecraft.client.tutorial;

import com.fox2code.repacker.*;
import net.minecraft.client.player.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.world.phys.*;
import net.minecraft.core.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.item.*;

@ClientJarOnly
public interface TutorialStepInstance
{
    default void clear() {
    }
    
    default void tick() {
    }
    
    default void onInput(final Input input) {
    }
    
    default void onMouse(final double var1, final double var3) {
    }
    
    default void onLookAt(final MultiPlayerLevel multiPlayerLevel, final HitResult hitResult) {
    }
    
    default void onDestroyBlock(final MultiPlayerLevel multiPlayerLevel, final BlockPos blockPos, final BlockState blockState, final float var4) {
    }
    
    default void onOpenInventory() {
    }
    
    default void onGetItem(final ItemStack itemStack) {
    }
}
