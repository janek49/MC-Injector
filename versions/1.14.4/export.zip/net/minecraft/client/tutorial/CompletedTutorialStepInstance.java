package net.minecraft.client.tutorial;

import com.fox2code.repacker.*;

@ClientJarOnly
public class CompletedTutorialStepInstance implements TutorialStepInstance
{
    private final Tutorial tutorial;
    
    public CompletedTutorialStepInstance(final Tutorial tutorial) {
        this.tutorial = tutorial;
    }
}
