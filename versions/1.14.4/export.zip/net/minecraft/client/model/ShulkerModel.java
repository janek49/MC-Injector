package net.minecraft.client.model;

import net.minecraft.world.entity.monster.*;
import com.fox2code.repacker.*;
import net.minecraft.client.model.geom.*;
import net.minecraft.util.*;
import net.minecraft.world.entity.*;

@ClientJarOnly
public class ShulkerModel<T extends Shulker> extends EntityModel<T>
{
    private final ModelPart base;
    private final ModelPart lid;
    private final ModelPart head;
    
    public ShulkerModel() {
        this.texHeight = 64;
        this.texWidth = 64;
        this.lid = new ModelPart(this);
        this.base = new ModelPart(this);
        this.head = new ModelPart(this);
        this.lid.texOffs(0, 0).addBox(-8.0f, -16.0f, -8.0f, 16, 12, 16);
        this.lid.setPos(0.0f, 24.0f, 0.0f);
        this.base.texOffs(0, 28).addBox(-8.0f, -8.0f, -8.0f, 16, 8, 16);
        this.base.setPos(0.0f, 24.0f, 0.0f);
        this.head.texOffs(0, 52).addBox(-3.0f, 0.0f, -3.0f, 6, 6, 6);
        this.head.setPos(0.0f, 12.0f, 0.0f);
    }
    
    @Override
    public void setupAnim(final T shulker, final float var2, final float var3, final float var4, final float var5, final float var6, final float var7) {
        final float var8 = var4 - shulker.tickCount;
        final float var9 = (0.5f + shulker.getClientPeekAmount(var8)) * 3.1415927f;
        final float var10 = -1.0f + Mth.sin(var9);
        float var11 = 0.0f;
        if (var9 > 3.1415927f) {
            var11 = Mth.sin(var4 * 0.1f) * 0.7f;
        }
        this.lid.setPos(0.0f, 16.0f + Mth.sin(var9) * 8.0f + var11, 0.0f);
        if (shulker.getClientPeekAmount(var8) > 0.3f) {
            this.lid.yRot = var10 * var10 * var10 * var10 * 3.1415927f * 0.125f;
        }
        else {
            this.lid.yRot = 0.0f;
        }
        this.head.xRot = var6 * 0.017453292f;
        this.head.yRot = var5 * 0.017453292f;
    }
    
    @Override
    public void render(final T shulker, final float var2, final float var3, final float var4, final float var5, final float var6, final float var7) {
        this.base.render(var7);
        this.lid.render(var7);
    }
    
    public ModelPart getBase() {
        return this.base;
    }
    
    public ModelPart getLid() {
        return this.lid;
    }
    
    public ModelPart getHead() {
        return this.head;
    }
}
