package net.minecraft.client.model;

import com.fox2code.repacker.*;
import net.minecraft.client.model.geom.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import net.minecraft.util.*;
import net.minecraft.world.entity.*;

@ClientJarOnly
public class SkeletonModel<T extends Mob> extends HumanoidModel<T>
{
    public SkeletonModel() {
        this(0.0f, false);
    }
    
    public SkeletonModel(final float var1, final boolean var2) {
        super(var1, 0.0f, 64, 32);
        if (!var2) {
            (this.rightArm = new ModelPart(this, 40, 16)).addBox(-1.0f, -2.0f, -1.0f, 2, 12, 2, var1);
            this.rightArm.setPos(-5.0f, 2.0f, 0.0f);
            this.leftArm = new ModelPart(this, 40, 16);
            this.leftArm.mirror = true;
            this.leftArm.addBox(-1.0f, -2.0f, -1.0f, 2, 12, 2, var1);
            this.leftArm.setPos(5.0f, 2.0f, 0.0f);
            (this.rightLeg = new ModelPart(this, 0, 16)).addBox(-1.0f, 0.0f, -1.0f, 2, 12, 2, var1);
            this.rightLeg.setPos(-2.0f, 12.0f, 0.0f);
            this.leftLeg = new ModelPart(this, 0, 16);
            this.leftLeg.mirror = true;
            this.leftLeg.addBox(-1.0f, 0.0f, -1.0f, 2, 12, 2, var1);
            this.leftLeg.setPos(2.0f, 12.0f, 0.0f);
        }
    }
    
    @Override
    public void prepareMobModel(final T mob, final float var2, final float var3, final float var4) {
        this.rightArmPose = ArmPose.EMPTY;
        this.leftArmPose = ArmPose.EMPTY;
        final ItemStack var5 = ((LivingEntity)mob).getItemInHand(InteractionHand.MAIN_HAND);
        if (var5.getItem() == Items.BOW && ((Mob)mob).isAggressive()) {
            if (((Mob)mob).getMainArm() == HumanoidArm.RIGHT) {
                this.rightArmPose = ArmPose.BOW_AND_ARROW;
            }
            else {
                this.leftArmPose = ArmPose.BOW_AND_ARROW;
            }
        }
        super.prepareMobModel(mob, var2, var3, var4);
    }
    
    @Override
    public void setupAnim(final T mob, final float var2, final float var3, final float var4, final float var5, final float var6, final float var7) {
        super.setupAnim(mob, var2, var3, var4, var5, var6, var7);
        final ItemStack var8 = ((LivingEntity)mob).getMainHandItem();
        if (((Mob)mob).isAggressive() && (var8.isEmpty() || var8.getItem() != Items.BOW)) {
            final float var9 = Mth.sin(this.attackTime * 3.1415927f);
            final float var10 = Mth.sin((1.0f - (1.0f - this.attackTime) * (1.0f - this.attackTime)) * 3.1415927f);
            this.rightArm.zRot = 0.0f;
            this.leftArm.zRot = 0.0f;
            this.rightArm.yRot = -(0.1f - var9 * 0.6f);
            this.leftArm.yRot = 0.1f - var9 * 0.6f;
            this.rightArm.xRot = -1.5707964f;
            this.leftArm.xRot = -1.5707964f;
            final ModelPart rightArm = this.rightArm;
            rightArm.xRot -= var9 * 1.2f - var10 * 0.4f;
            final ModelPart leftArm = this.leftArm;
            leftArm.xRot -= var9 * 1.2f - var10 * 0.4f;
            final ModelPart rightArm2 = this.rightArm;
            rightArm2.zRot += Mth.cos(var4 * 0.09f) * 0.05f + 0.05f;
            final ModelPart leftArm2 = this.leftArm;
            leftArm2.zRot -= Mth.cos(var4 * 0.09f) * 0.05f + 0.05f;
            final ModelPart rightArm3 = this.rightArm;
            rightArm3.xRot += Mth.sin(var4 * 0.067f) * 0.05f;
            final ModelPart leftArm3 = this.leftArm;
            leftArm3.xRot -= Mth.sin(var4 * 0.067f) * 0.05f;
        }
    }
    
    @Override
    public void translateToHand(final float var1, final HumanoidArm humanoidArm) {
        final float var2 = (humanoidArm == HumanoidArm.RIGHT) ? 1.0f : -1.0f;
        final ModelPart arm;
        final ModelPart var3 = arm = this.getArm(humanoidArm);
        arm.x += var2;
        var3.translateTo(var1);
        final ModelPart modelPart = var3;
        modelPart.x -= var2;
    }
}
