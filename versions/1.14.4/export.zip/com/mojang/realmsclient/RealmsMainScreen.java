package com.mojang.realmsclient;

import com.fox2code.repacker.*;
import com.google.common.util.concurrent.*;
import java.util.concurrent.locks.*;
import com.google.common.collect.*;
import com.mojang.realmsclient.client.*;
import com.mojang.realmsclient.dto.*;
import java.util.*;
import com.mojang.realmsclient.exception.*;
import java.io.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.screens.*;
import com.mojang.blaze3d.platform.*;
import java.util.concurrent.*;
import org.apache.logging.log4j.*;
import net.minecraft.realms.*;
import com.mojang.realmsclient.gui.*;
import com.mojang.realmsclient.gui.screens.*;
import com.mojang.realmsclient.util.*;

@ClientJarOnly
public class RealmsMainScreen extends RealmsScreen
{
    private static final Logger LOGGER;
    private static boolean overrideConfigure;
    private final RateLimiter inviteNarrationLimiter;
    private boolean dontSetConnectedToRealms;
    private static final String[] IMAGES_LOCATION;
    private static final RealmsDataFetcher realmsDataFetcher;
    private static int lastScrollYPosition;
    private final RealmsScreen lastScreen;
    private volatile RealmSelectionList realmSelectionList;
    private long selectedServerId;
    private RealmsButton playButton;
    private RealmsButton backButton;
    private RealmsButton renewButton;
    private RealmsButton configureButton;
    private RealmsButton leaveButton;
    private String toolTip;
    private List<RealmsServer> realmsServers;
    private volatile int numberOfPendingInvites;
    private int animTick;
    private static volatile boolean hasParentalConsent;
    private static volatile boolean checkedParentalConsent;
    private static volatile boolean checkedClientCompatability;
    private boolean hasFetchedServers;
    private boolean popupOpenedByUser;
    private boolean justClosedPopup;
    private volatile boolean trialsAvailable;
    private volatile boolean createdTrial;
    private volatile boolean showingPopup;
    private volatile boolean hasUnreadNews;
    private volatile String newsLink;
    private int carouselIndex;
    private int carouselTick;
    private boolean hasSwitchedCarouselImage;
    private static RealmsScreen realmsGenericErrorScreen;
    private static boolean regionsPinged;
    private List<KeyCombo> keyCombos;
    private int clicks;
    private ReentrantLock connectLock;
    private boolean expiredHover;
    private ShowPopupButton showPopupButton;
    private PendingInvitesButton pendingInvitesButton;
    private NewsButton newsButton;
    private RealmsButton createTrialButton;
    private RealmsButton buyARealmButton;
    private RealmsButton closeButton;
    
    public RealmsMainScreen(final RealmsScreen lastScreen) {
        this.selectedServerId = -1L;
        this.realmsServers = (List<RealmsServer>)Lists.newArrayList();
        this.connectLock = new ReentrantLock();
        this.lastScreen = lastScreen;
        this.inviteNarrationLimiter = RateLimiter.create(0.01666666753590107);
    }
    
    public boolean shouldShowMessageInList() {
        if (!this.hasParentalConsent() || !this.hasFetchedServers) {
            return false;
        }
        if (this.trialsAvailable && !this.createdTrial) {
            return true;
        }
        for (final RealmsServer var2 : this.realmsServers) {
            if (var2.ownerUUID.equals(Realms.getUUID())) {
                return false;
            }
        }
        return true;
    }
    
    public boolean shouldShowPopup() {
        return this.hasParentalConsent() && this.hasFetchedServers && (this.popupOpenedByUser || (this.trialsAvailable && !this.createdTrial && this.realmsServers.isEmpty()) || this.realmsServers.isEmpty());
    }
    
    @Override
    public void init() {
        this.keyCombos = (List<KeyCombo>)Lists.newArrayList((Object[])new KeyCombo[] { new KeyCombo(new char[] { '3', '2', '1', '4', '5', '6' }, () -> RealmsMainScreen.overrideConfigure = !RealmsMainScreen.overrideConfigure), new KeyCombo(new char[] { '9', '8', '7', '1', '2', '3' }, () -> {
                if (RealmsClient.currentEnvironment.equals(RealmsClient.Environment.STAGE)) {
                    this.switchToProd();
                }
                else {
                    this.switchToStage();
                }
                return;
            }), new KeyCombo(new char[] { '9', '8', '7', '4', '5', '6' }, () -> {
                if (RealmsClient.currentEnvironment.equals(RealmsClient.Environment.LOCAL)) {
                    this.switchToProd();
                }
                else {
                    this.switchToLocal();
                }
                return;
            }) });
        if (RealmsMainScreen.realmsGenericErrorScreen != null) {
            Realms.setScreen(RealmsMainScreen.realmsGenericErrorScreen);
            return;
        }
        this.connectLock = new ReentrantLock();
        if (RealmsMainScreen.checkedClientCompatability && !this.hasParentalConsent()) {
            this.checkParentalConsent();
        }
        this.checkClientCompatability();
        this.checkUnreadNews();
        if (!this.dontSetConnectedToRealms) {
            Realms.setConnectedToRealms(false);
        }
        this.setKeyboardHandlerSendRepeatsToGui(true);
        if (this.hasParentalConsent()) {
            RealmsMainScreen.realmsDataFetcher.forceUpdate();
        }
        this.showingPopup = false;
        this.postInit();
    }
    
    private boolean hasParentalConsent() {
        return RealmsMainScreen.checkedParentalConsent && RealmsMainScreen.hasParentalConsent;
    }
    
    public void addButtons() {
        this.buttonsAdd(this.configureButton = new RealmsButton(1, this.width() / 2 - 190, this.height() - 32, 90, 20, RealmsScreen.getLocalizedString("mco.selectServer.configure")) {
            @Override
            public void onPress() {
                RealmsMainScreen.this.configureClicked(RealmsMainScreen.this.findServer(RealmsMainScreen.this.selectedServerId));
            }
        });
        this.buttonsAdd(this.playButton = new RealmsButton(3, this.width() / 2 - 93, this.height() - 32, 90, 20, RealmsScreen.getLocalizedString("mco.selectServer.play")) {
            @Override
            public void onPress() {
                RealmsMainScreen.this.onPlay();
            }
        });
        this.buttonsAdd(this.backButton = new RealmsButton(2, this.width() / 2 + 4, this.height() - 32, 90, 20, RealmsScreen.getLocalizedString("gui.back")) {
            @Override
            public void onPress() {
                if (!RealmsMainScreen.this.justClosedPopup) {
                    Realms.setScreen(RealmsMainScreen.this.lastScreen);
                }
            }
        });
        this.buttonsAdd(this.renewButton = new RealmsButton(0, this.width() / 2 + 100, this.height() - 32, 90, 20, RealmsScreen.getLocalizedString("mco.selectServer.expiredRenew")) {
            @Override
            public void onPress() {
                RealmsMainScreen.this.onRenew();
            }
        });
        this.buttonsAdd(this.leaveButton = new RealmsButton(7, this.width() / 2 - 202, this.height() - 32, 90, 20, RealmsScreen.getLocalizedString("mco.selectServer.leave")) {
            @Override
            public void onPress() {
                RealmsMainScreen.this.leaveClicked(RealmsMainScreen.this.findServer(RealmsMainScreen.this.selectedServerId));
            }
        });
        this.buttonsAdd(this.pendingInvitesButton = new PendingInvitesButton());
        this.buttonsAdd(this.newsButton = new NewsButton());
        this.buttonsAdd(this.showPopupButton = new ShowPopupButton());
        this.buttonsAdd(this.closeButton = new CloseButton());
        this.buttonsAdd(this.createTrialButton = new RealmsButton(6, this.width() / 2 + 52, this.popupY0() + 137 - 20, 98, 20, RealmsScreen.getLocalizedString("mco.selectServer.trial")) {
            @Override
            public void onPress() {
                RealmsMainScreen.this.createTrial();
            }
        });
        this.buttonsAdd(this.buyARealmButton = new RealmsButton(5, this.width() / 2 + 52, this.popupY0() + 160 - 20, 98, 20, RealmsScreen.getLocalizedString("mco.selectServer.buy")) {
            @Override
            public void onPress() {
                RealmsUtil.browseTo("https://minecraft.net/realms");
            }
        });
        final RealmsServer var1 = this.findServer(this.selectedServerId);
        this.updateButtonStates(var1);
    }
    
    private void updateButtonStates(final RealmsServer realmsServer) {
        this.playButton.active(this.shouldPlayButtonBeActive(realmsServer) && !this.shouldShowPopup());
        this.renewButton.setVisible(this.shouldRenewButtonBeActive(realmsServer));
        this.configureButton.setVisible(this.shouldConfigureButtonBeVisible(realmsServer));
        this.leaveButton.setVisible(this.shouldLeaveButtonBeVisible(realmsServer));
        final boolean var2 = this.shouldShowPopup() && this.trialsAvailable && !this.createdTrial;
        this.createTrialButton.setVisible(var2);
        this.createTrialButton.active(var2);
        this.buyARealmButton.setVisible(this.shouldShowPopup());
        this.closeButton.setVisible(this.shouldShowPopup() && this.popupOpenedByUser);
        this.renewButton.active(!this.shouldShowPopup());
        this.configureButton.active(!this.shouldShowPopup());
        this.leaveButton.active(!this.shouldShowPopup());
        this.newsButton.active(true);
        this.pendingInvitesButton.active(true);
        this.backButton.active(true);
        this.showPopupButton.active(!this.shouldShowPopup());
    }
    
    private boolean shouldShowPopupButton() {
        return (!this.shouldShowPopup() || this.popupOpenedByUser) && this.hasParentalConsent() && this.hasFetchedServers;
    }
    
    private boolean shouldPlayButtonBeActive(final RealmsServer realmsServer) {
        return realmsServer != null && !realmsServer.expired && realmsServer.state == RealmsServer.State.OPEN;
    }
    
    private boolean shouldRenewButtonBeActive(final RealmsServer realmsServer) {
        return realmsServer != null && realmsServer.expired && this.isSelfOwnedServer(realmsServer);
    }
    
    private boolean shouldConfigureButtonBeVisible(final RealmsServer realmsServer) {
        return realmsServer != null && this.isSelfOwnedServer(realmsServer);
    }
    
    private boolean shouldLeaveButtonBeVisible(final RealmsServer realmsServer) {
        return realmsServer != null && !this.isSelfOwnedServer(realmsServer);
    }
    
    public void postInit() {
        if (this.hasParentalConsent() && this.hasFetchedServers) {
            this.addButtons();
        }
        this.realmSelectionList = new RealmSelectionList();
        if (RealmsMainScreen.lastScrollYPosition != -1) {
            this.realmSelectionList.scroll(RealmsMainScreen.lastScrollYPosition);
        }
        this.addWidget(this.realmSelectionList);
        this.focusOn(this.realmSelectionList);
    }
    
    @Override
    public void tick() {
        this.tickButtons();
        this.justClosedPopup = false;
        ++this.animTick;
        --this.clicks;
        if (this.clicks < 0) {
            this.clicks = 0;
        }
        if (this.hasParentalConsent()) {
            RealmsMainScreen.realmsDataFetcher.init();
            if (RealmsMainScreen.realmsDataFetcher.isFetchedSinceLastTry(RealmsDataFetcher.Task.SERVER_LIST)) {
                final List<RealmsServer> var1 = RealmsMainScreen.realmsDataFetcher.getServers();
                this.realmSelectionList.clear();
                final boolean var2 = !this.hasFetchedServers;
                if (var2) {
                    this.hasFetchedServers = true;
                }
                if (var1 != null) {
                    boolean var3 = false;
                    for (final RealmsServer var4 : var1) {
                        if (this.isSelfOwnedNonExpiredServer(var4)) {
                            var3 = true;
                        }
                    }
                    this.realmsServers = var1;
                    if (this.shouldShowMessageInList()) {
                        this.realmSelectionList.addEntry(new RealmSelectionListTrialEntry());
                    }
                    for (final RealmsServer var4 : this.realmsServers) {
                        this.realmSelectionList.addEntry(new RealmSelectionListEntry(var4));
                    }
                    if (!RealmsMainScreen.regionsPinged && var3) {
                        RealmsMainScreen.regionsPinged = true;
                        this.pingRegions();
                    }
                }
                if (var2) {
                    this.addButtons();
                }
            }
            if (RealmsMainScreen.realmsDataFetcher.isFetchedSinceLastTry(RealmsDataFetcher.Task.PENDING_INVITE)) {
                this.numberOfPendingInvites = RealmsMainScreen.realmsDataFetcher.getPendingInvitesCount();
                if (this.numberOfPendingInvites > 0 && this.inviteNarrationLimiter.tryAcquire(1)) {
                    Realms.narrateNow(RealmsScreen.getLocalizedString("mco.configure.world.invite.narration", this.numberOfPendingInvites));
                }
            }
            if (RealmsMainScreen.realmsDataFetcher.isFetchedSinceLastTry(RealmsDataFetcher.Task.TRIAL_AVAILABLE) && !this.createdTrial) {
                final boolean var5 = RealmsMainScreen.realmsDataFetcher.isTrialAvailable();
                if (var5 != this.trialsAvailable && this.shouldShowPopup()) {
                    this.trialsAvailable = var5;
                    this.showingPopup = false;
                }
                else {
                    this.trialsAvailable = var5;
                }
            }
            if (RealmsMainScreen.realmsDataFetcher.isFetchedSinceLastTry(RealmsDataFetcher.Task.LIVE_STATS)) {
                final RealmsServerPlayerLists var6 = RealmsMainScreen.realmsDataFetcher.getLivestats();
                for (final RealmsServerPlayerList var7 : var6.servers) {
                    for (final RealmsServer var4 : this.realmsServers) {
                        if (var4.id == var7.serverId) {
                            var4.updateServerPing(var7);
                            break;
                        }
                    }
                }
            }
            if (RealmsMainScreen.realmsDataFetcher.isFetchedSinceLastTry(RealmsDataFetcher.Task.UNREAD_NEWS)) {
                this.hasUnreadNews = RealmsMainScreen.realmsDataFetcher.hasUnreadNews();
                this.newsLink = RealmsMainScreen.realmsDataFetcher.newsLink();
            }
            RealmsMainScreen.realmsDataFetcher.markClean();
            if (this.shouldShowPopup()) {
                ++this.carouselTick;
            }
            if (this.showPopupButton != null) {
                this.showPopupButton.setVisible(this.shouldShowPopupButton());
            }
        }
    }
    
    private void browseURL(final String string) {
        Realms.setClipboard(string);
        RealmsUtil.browseTo(string);
    }
    
    private void pingRegions() {
        new Thread() {
            @Override
            public void run() {
                final List<RegionPingResult> var1 = Ping.pingAllRegions();
                final RealmsClient var2 = RealmsClient.createRealmsClient();
                final PingResult var3 = new PingResult();
                var3.pingResults = var1;
                var3.worldIds = RealmsMainScreen.this.getOwnedNonExpiredWorldIds();
                try {
                    var2.sendPingResults(var3);
                }
                catch (Throwable var4) {
                    RealmsMainScreen.LOGGER.warn("Could not send ping result to Realms: ", var4);
                }
            }
        }.start();
    }
    
    private List<Long> getOwnedNonExpiredWorldIds() {
        final List<Long> list = new ArrayList<Long>();
        for (final RealmsServer var3 : this.realmsServers) {
            if (this.isSelfOwnedNonExpiredServer(var3)) {
                list.add(var3.id);
            }
        }
        return list;
    }
    
    @Override
    public void removed() {
        this.setKeyboardHandlerSendRepeatsToGui(false);
        this.stopRealmsFetcher();
    }
    
    public void setCreatedTrial(final boolean createdTrial) {
        this.createdTrial = createdTrial;
    }
    
    private void onPlay() {
        final RealmsServer var1 = this.findServer(this.selectedServerId);
        if (var1 == null) {
            return;
        }
        this.play(var1, this);
    }
    
    private void onRenew() {
        final RealmsServer var1 = this.findServer(this.selectedServerId);
        if (var1 == null) {
            return;
        }
        final String var2 = "https://account.mojang.com/buy/realms?sid=" + var1.remoteSubscriptionId + "&pid=" + Realms.getUUID() + "&ref=" + (var1.expiredTrial ? "expiredTrial" : "expiredRealm");
        this.browseURL(var2);
    }
    
    private void createTrial() {
        if (!this.trialsAvailable || this.createdTrial) {
            return;
        }
        Realms.setScreen(new RealmsCreateTrialScreen(this));
    }
    
    private void checkClientCompatability() {
        if (!RealmsMainScreen.checkedClientCompatability) {
            RealmsMainScreen.checkedClientCompatability = true;
            new Thread("MCO Compatability Checker #1") {
                @Override
                public void run() {
                    final RealmsClient var1 = RealmsClient.createRealmsClient();
                    try {
                        final RealmsClient.CompatibleVersionResponse var2 = var1.clientCompatible();
                        if (var2.equals(RealmsClient.CompatibleVersionResponse.OUTDATED)) {
                            RealmsMainScreen.realmsGenericErrorScreen = new RealmsClientOutdatedScreen(RealmsMainScreen.this.lastScreen, true);
                            Realms.setScreen(RealmsMainScreen.realmsGenericErrorScreen);
                            return;
                        }
                        if (var2.equals(RealmsClient.CompatibleVersionResponse.OTHER)) {
                            RealmsMainScreen.realmsGenericErrorScreen = new RealmsClientOutdatedScreen(RealmsMainScreen.this.lastScreen, false);
                            Realms.setScreen(RealmsMainScreen.realmsGenericErrorScreen);
                            return;
                        }
                        RealmsMainScreen.this.checkParentalConsent();
                    }
                    catch (RealmsServiceException var3) {
                        RealmsMainScreen.checkedClientCompatability = false;
                        RealmsMainScreen.LOGGER.error("Couldn't connect to realms: ", (Object)var3.toString());
                        if (var3.httpResultCode == 401) {
                            RealmsMainScreen.realmsGenericErrorScreen = new RealmsGenericErrorScreen(RealmsScreen.getLocalizedString("mco.error.invalid.session.title"), RealmsScreen.getLocalizedString("mco.error.invalid.session.message"), RealmsMainScreen.this.lastScreen);
                            Realms.setScreen(RealmsMainScreen.realmsGenericErrorScreen);
                            return;
                        }
                        Realms.setScreen(new RealmsGenericErrorScreen(var3, RealmsMainScreen.this.lastScreen));
                    }
                    catch (IOException var4) {
                        RealmsMainScreen.checkedClientCompatability = false;
                        RealmsMainScreen.LOGGER.error("Couldn't connect to realms: ", (Object)var4.getMessage());
                        Realms.setScreen(new RealmsGenericErrorScreen(var4.getMessage(), RealmsMainScreen.this.lastScreen));
                    }
                }
            }.start();
        }
    }
    
    private void checkUnreadNews() {
    }
    
    private void checkParentalConsent() {
        new Thread("MCO Compatability Checker #1") {
            @Override
            public void run() {
                final RealmsClient var1 = RealmsClient.createRealmsClient();
                try {
                    final Boolean var2 = var1.mcoEnabled();
                    if (var2) {
                        RealmsMainScreen.LOGGER.info("Realms is available for this user");
                        RealmsMainScreen.hasParentalConsent = true;
                    }
                    else {
                        RealmsMainScreen.LOGGER.info("Realms is not available for this user");
                        RealmsMainScreen.hasParentalConsent = false;
                        Realms.setScreen(new RealmsParentalConsentScreen(RealmsMainScreen.this.lastScreen));
                    }
                    RealmsMainScreen.checkedParentalConsent = true;
                }
                catch (RealmsServiceException var3) {
                    RealmsMainScreen.LOGGER.error("Couldn't connect to realms: ", (Object)var3.toString());
                    Realms.setScreen(new RealmsGenericErrorScreen(var3, RealmsMainScreen.this.lastScreen));
                }
                catch (IOException var4) {
                    RealmsMainScreen.LOGGER.error("Couldn't connect to realms: ", (Object)var4.getMessage());
                    Realms.setScreen(new RealmsGenericErrorScreen(var4.getMessage(), RealmsMainScreen.this.lastScreen));
                }
            }
        }.start();
    }
    
    private void switchToStage() {
        if (!RealmsClient.currentEnvironment.equals(RealmsClient.Environment.STAGE)) {
            new Thread("MCO Stage Availability Checker #1") {
                @Override
                public void run() {
                    final RealmsClient var1 = RealmsClient.createRealmsClient();
                    try {
                        final Boolean var2 = var1.stageAvailable();
                        if (var2) {
                            RealmsClient.switchToStage();
                            RealmsMainScreen.LOGGER.info("Switched to stage");
                            RealmsMainScreen.realmsDataFetcher.forceUpdate();
                        }
                    }
                    catch (RealmsServiceException var3) {
                        RealmsMainScreen.LOGGER.error("Couldn't connect to Realms: " + var3);
                    }
                    catch (IOException var4) {
                        RealmsMainScreen.LOGGER.error("Couldn't parse response connecting to Realms: " + var4.getMessage());
                    }
                }
            }.start();
        }
    }
    
    private void switchToLocal() {
        if (!RealmsClient.currentEnvironment.equals(RealmsClient.Environment.LOCAL)) {
            new Thread("MCO Local Availability Checker #1") {
                @Override
                public void run() {
                    final RealmsClient var1 = RealmsClient.createRealmsClient();
                    try {
                        final Boolean var2 = var1.stageAvailable();
                        if (var2) {
                            RealmsClient.switchToLocal();
                            RealmsMainScreen.LOGGER.info("Switched to local");
                            RealmsMainScreen.realmsDataFetcher.forceUpdate();
                        }
                    }
                    catch (RealmsServiceException var3) {
                        RealmsMainScreen.LOGGER.error("Couldn't connect to Realms: " + var3);
                    }
                    catch (IOException var4) {
                        RealmsMainScreen.LOGGER.error("Couldn't parse response connecting to Realms: " + var4.getMessage());
                    }
                }
            }.start();
        }
    }
    
    private void switchToProd() {
        RealmsClient.switchToProd();
        RealmsMainScreen.realmsDataFetcher.forceUpdate();
    }
    
    private void stopRealmsFetcher() {
        RealmsMainScreen.realmsDataFetcher.stop();
    }
    
    private void configureClicked(final RealmsServer realmsServer) {
        if (Realms.getUUID().equals(realmsServer.ownerUUID) || RealmsMainScreen.overrideConfigure) {
            this.saveListScrollPosition();
            final Minecraft var2 = Minecraft.getInstance();
            var2.execute(() -> var2.setScreen(new RealmsConfigureWorldScreen(this, realmsServer.id).getProxy()));
        }
    }
    
    private void leaveClicked(final RealmsServer realmsServer) {
        if (!Realms.getUUID().equals(realmsServer.ownerUUID)) {
            this.saveListScrollPosition();
            final String var2 = RealmsScreen.getLocalizedString("mco.configure.world.leave.question.line1");
            final String var3 = RealmsScreen.getLocalizedString("mco.configure.world.leave.question.line2");
            Realms.setScreen(new RealmsLongConfirmationScreen(this, RealmsLongConfirmationScreen.Type.Info, var2, var3, true, 4));
        }
    }
    
    private void saveListScrollPosition() {
        RealmsMainScreen.lastScrollYPosition = this.realmSelectionList.getScroll();
    }
    
    private RealmsServer findServer(final long l) {
        for (final RealmsServer var4 : this.realmsServers) {
            if (var4.id == l) {
                return var4;
            }
        }
        return null;
    }
    
    @Override
    public void confirmResult(final boolean var1, final int var2) {
        if (var2 == 4) {
            if (var1) {
                new Thread("Realms-leave-server") {
                    @Override
                    public void run() {
                        try {
                            final RealmsServer var1 = RealmsMainScreen.this.findServer(RealmsMainScreen.this.selectedServerId);
                            if (var1 != null) {
                                final RealmsClient var2 = RealmsClient.createRealmsClient();
                                var2.uninviteMyselfFrom(var1.id);
                                RealmsMainScreen.realmsDataFetcher.removeItem(var1);
                                RealmsMainScreen.this.realmsServers.remove(var1);
                                RealmsMainScreen.this.selectedServerId = -1L;
                                RealmsMainScreen.this.playButton.active(false);
                            }
                        }
                        catch (RealmsServiceException var3) {
                            RealmsMainScreen.LOGGER.error("Couldn't configure world");
                            Realms.setScreen(new RealmsGenericErrorScreen(var3, RealmsMainScreen.this));
                        }
                    }
                }.start();
            }
            Realms.setScreen(this);
        }
    }
    
    public void removeSelection() {
        this.selectedServerId = -1L;
    }
    
    @Override
    public boolean keyPressed(final int var1, final int var2, final int var3) {
        switch (var1) {
            case 256: {
                this.keyCombos.forEach(KeyCombo::reset);
                this.onClosePopup();
                return true;
            }
            default: {
                return super.keyPressed(var1, var2, var3);
            }
        }
    }
    
    private void onClosePopup() {
        if (this.shouldShowPopup() && this.popupOpenedByUser) {
            this.popupOpenedByUser = false;
        }
        else {
            Realms.setScreen(this.lastScreen);
        }
    }
    
    @Override
    public boolean charTyped(final char var1, final int var2) {
        this.keyCombos.forEach(keyCombo -> keyCombo.keyPressed(var1));
        return true;
    }
    
    @Override
    public void render(final int var1, final int var2, final float var3) {
        this.expiredHover = false;
        this.toolTip = null;
        this.renderBackground();
        this.realmSelectionList.render(var1, var2, var3);
        this.drawRealmsLogo(this.width() / 2 - 50, 7);
        if (RealmsClient.currentEnvironment.equals(RealmsClient.Environment.STAGE)) {
            this.renderStage();
        }
        if (RealmsClient.currentEnvironment.equals(RealmsClient.Environment.LOCAL)) {
            this.renderLocal();
        }
        if (this.shouldShowPopup()) {
            this.drawPopup(var1, var2);
        }
        else {
            if (this.showingPopup) {
                this.updateButtonStates(null);
                if (!this.hasWidget(this.realmSelectionList)) {
                    this.addWidget(this.realmSelectionList);
                }
                final RealmsServer var4 = this.findServer(this.selectedServerId);
                this.playButton.active(this.shouldPlayButtonBeActive(var4));
            }
            this.showingPopup = false;
        }
        super.render(var1, var2, var3);
        if (this.toolTip != null) {
            this.renderMousehoverTooltip(this.toolTip, var1, var2);
        }
        if (this.trialsAvailable && !this.createdTrial && this.shouldShowPopup()) {
            RealmsScreen.bind("realms:textures/gui/realms/trial_icon.png");
            GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.pushMatrix();
            final int var5 = 8;
            final int var6 = 8;
            int var7 = 0;
            if ((System.currentTimeMillis() / 800L & 0x1L) == 0x1L) {
                var7 = 8;
            }
            RealmsScreen.blit(this.createTrialButton.x() + this.createTrialButton.getWidth() - 8 - 4, this.createTrialButton.y() + this.createTrialButton.getHeight() / 2 - 4, 0.0f, (float)var7, 8, 8, 8, 16);
            GlStateManager.popMatrix();
        }
    }
    
    private void drawRealmsLogo(final int var1, final int var2) {
        RealmsScreen.bind("realms:textures/gui/title/realms.png");
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        GlStateManager.scalef(0.5f, 0.5f, 0.5f);
        RealmsScreen.blit(var1 * 2, var2 * 2 - 5, 0.0f, 0.0f, 200, 50, 200, 50);
        GlStateManager.popMatrix();
    }
    
    @Override
    public boolean mouseClicked(final double var1, final double var3, final int var5) {
        if (this.isOutsidePopup(var1, var3) && this.popupOpenedByUser) {
            this.popupOpenedByUser = false;
            return this.justClosedPopup = true;
        }
        return super.mouseClicked(var1, var3, var5);
    }
    
    private boolean isOutsidePopup(final double var1, final double var3) {
        final int var4 = this.popupX0();
        final int var5 = this.popupY0();
        return var1 < var4 - 5 || var1 > var4 + 315 || var3 < var5 - 5 || var3 > var5 + 171;
    }
    
    private void drawPopup(final int var1, final int var2) {
        final int var3 = this.popupX0();
        final int var4 = this.popupY0();
        final String var5 = RealmsScreen.getLocalizedString("mco.selectServer.popup");
        final List<String> var6 = this.fontSplit(var5, 100);
        if (!this.showingPopup) {
            this.carouselIndex = 0;
            this.carouselTick = 0;
            this.hasSwitchedCarouselImage = true;
            this.updateButtonStates(null);
            if (this.hasWidget(this.realmSelectionList)) {
                this.removeWidget(this.realmSelectionList);
            }
            Realms.narrateNow(var5);
        }
        if (this.hasFetchedServers) {
            this.showingPopup = true;
        }
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 0.7f);
        GlStateManager.enableBlend();
        RealmsScreen.bind("realms:textures/gui/realms/darken.png");
        GlStateManager.pushMatrix();
        final int var7 = 0;
        final int var8 = 32;
        RealmsScreen.blit(0, 32, 0.0f, 0.0f, this.width(), this.height() - 40 - 32, 310, 166);
        GlStateManager.popMatrix();
        GlStateManager.disableBlend();
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        RealmsScreen.bind("realms:textures/gui/realms/popup.png");
        GlStateManager.pushMatrix();
        RealmsScreen.blit(var3, var4, 0.0f, 0.0f, 310, 166, 310, 166);
        GlStateManager.popMatrix();
        RealmsScreen.bind(RealmsMainScreen.IMAGES_LOCATION[this.carouselIndex]);
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        RealmsScreen.blit(var3 + 7, var4 + 7, 0.0f, 0.0f, 195, 152, 195, 152);
        GlStateManager.popMatrix();
        if (this.carouselTick % 95 < 5) {
            if (!this.hasSwitchedCarouselImage) {
                if (this.carouselIndex == RealmsMainScreen.IMAGES_LOCATION.length - 1) {
                    this.carouselIndex = 0;
                }
                else {
                    ++this.carouselIndex;
                }
                this.hasSwitchedCarouselImage = true;
            }
        }
        else {
            this.hasSwitchedCarouselImage = false;
        }
        int var9 = 0;
        for (final String var10 : var6) {
            this.drawString(var10, this.width() / 2 + 52, var4 + 10 * ++var9 - 3, 5000268, false);
        }
    }
    
    private int popupX0() {
        return (this.width() - 310) / 2;
    }
    
    private int popupY0() {
        return this.height() / 2 - 80;
    }
    
    private void drawInvitationPendingIcon(final int var1, final int var2, final int var3, final int var4, final boolean var5, final boolean var6) {
        final int var7 = this.numberOfPendingInvites;
        final boolean var8 = this.inPendingInvitationArea(var1, var2);
        final boolean var9 = var6 && var5;
        if (var9) {
            final float var10 = 0.25f + (1.0f + RealmsMth.sin(this.animTick * 0.5f)) * 0.25f;
            int var11 = 0xFF000000 | (int)(var10 * 64.0f) << 16 | (int)(var10 * 64.0f) << 8 | (int)(var10 * 64.0f) << 0;
            this.fillGradient(var3 - 2, var4 - 2, var3 + 18, var4 + 18, var11, var11);
            var11 = (0xFF000000 | (int)(var10 * 255.0f) << 16 | (int)(var10 * 255.0f) << 8 | (int)(var10 * 255.0f) << 0);
            this.fillGradient(var3 - 2, var4 - 2, var3 + 18, var4 - 1, var11, var11);
            this.fillGradient(var3 - 2, var4 - 2, var3 - 1, var4 + 18, var11, var11);
            this.fillGradient(var3 + 17, var4 - 2, var3 + 18, var4 + 18, var11, var11);
            this.fillGradient(var3 - 2, var4 + 17, var3 + 18, var4 + 18, var11, var11);
        }
        RealmsScreen.bind("realms:textures/gui/realms/invite_icon.png");
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        final boolean var12 = var6 && var5;
        RealmsScreen.blit(var3, var4 - 6, var12 ? 16.0f : 0.0f, 0.0f, 15, 25, 31, 25);
        GlStateManager.popMatrix();
        final boolean var13 = var6 && var7 != 0;
        if (var13) {
            final int var14 = (Math.min(var7, 6) - 1) * 8;
            final int var15 = (int)(Math.max(0.0f, Math.max(RealmsMth.sin((10 + this.animTick) * 0.57f), RealmsMth.cos(this.animTick * 0.35f))) * -6.0f);
            RealmsScreen.bind("realms:textures/gui/realms/invitation_icons.png");
            GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.pushMatrix();
            RealmsScreen.blit(var3 + 4, var4 + 4 + var15, (float)var14, var8 ? 8.0f : 0.0f, 8, 8, 48, 16);
            GlStateManager.popMatrix();
        }
        final int var14 = var1 + 12;
        final int var15 = var2;
        final boolean var16 = var6 && var8;
        if (var16) {
            final String var17 = RealmsScreen.getLocalizedString((var7 == 0) ? "mco.invites.nopending" : "mco.invites.pending");
            final int var18 = this.fontWidth(var17);
            this.fillGradient(var14 - 3, var15 - 3, var14 + var18 + 3, var15 + 8 + 3, -1073741824, -1073741824);
            this.fontDrawShadow(var17, var14, var15, -1);
        }
    }
    
    private boolean inPendingInvitationArea(final double var1, final double var3) {
        int var4 = this.width() / 2 + 50;
        int var5 = this.width() / 2 + 66;
        int var6 = 11;
        int var7 = 23;
        if (this.numberOfPendingInvites != 0) {
            var4 -= 3;
            var5 += 3;
            var6 -= 5;
            var7 += 5;
        }
        return var4 <= var1 && var1 <= var5 && var6 <= var3 && var3 <= var7;
    }
    
    public void play(final RealmsServer realmsServer, final RealmsScreen realmsScreen) {
        if (realmsServer != null) {
            try {
                if (!this.connectLock.tryLock(1L, TimeUnit.SECONDS)) {
                    return;
                }
                if (this.connectLock.getHoldCount() > 1) {
                    return;
                }
            }
            catch (InterruptedException var3) {
                return;
            }
            this.dontSetConnectedToRealms = true;
            this.connectToServer(realmsServer, realmsScreen);
        }
    }
    
    private void connectToServer(final RealmsServer realmsServer, final RealmsScreen realmsScreen) {
        final RealmsLongRunningMcoTaskScreen var3 = new RealmsLongRunningMcoTaskScreen(realmsScreen, new RealmsTasks.RealmsGetServerDetailsTask(this, realmsScreen, realmsServer, this.connectLock));
        var3.start();
        Realms.setScreen(var3);
    }
    
    private boolean isSelfOwnedServer(final RealmsServer realmsServer) {
        return realmsServer.ownerUUID != null && realmsServer.ownerUUID.equals(Realms.getUUID());
    }
    
    private boolean isSelfOwnedNonExpiredServer(final RealmsServer realmsServer) {
        return realmsServer.ownerUUID != null && realmsServer.ownerUUID.equals(Realms.getUUID()) && !realmsServer.expired;
    }
    
    private void drawExpired(final int var1, final int var2, final int var3, final int var4) {
        RealmsScreen.bind("realms:textures/gui/realms/expired_icon.png");
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        RealmsScreen.blit(var1, var2, 0.0f, 0.0f, 10, 28, 10, 28);
        GlStateManager.popMatrix();
        if (var3 >= var1 && var3 <= var1 + 9 && var4 >= var2 && var4 <= var2 + 27 && var4 < this.height() - 40 && var4 > 32 && !this.shouldShowPopup()) {
            this.toolTip = RealmsScreen.getLocalizedString("mco.selectServer.expired");
        }
    }
    
    private void drawExpiring(final int var1, final int var2, final int var3, final int var4, final int var5) {
        RealmsScreen.bind("realms:textures/gui/realms/expires_soon_icon.png");
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        if (this.animTick % 20 < 10) {
            RealmsScreen.blit(var1, var2, 0.0f, 0.0f, 10, 28, 20, 28);
        }
        else {
            RealmsScreen.blit(var1, var2, 10.0f, 0.0f, 10, 28, 20, 28);
        }
        GlStateManager.popMatrix();
        if (var3 >= var1 && var3 <= var1 + 9 && var4 >= var2 && var4 <= var2 + 27 && var4 < this.height() - 40 && var4 > 32 && !this.shouldShowPopup()) {
            if (var5 <= 0) {
                this.toolTip = RealmsScreen.getLocalizedString("mco.selectServer.expires.soon");
            }
            else if (var5 == 1) {
                this.toolTip = RealmsScreen.getLocalizedString("mco.selectServer.expires.day");
            }
            else {
                this.toolTip = RealmsScreen.getLocalizedString("mco.selectServer.expires.days", var5);
            }
        }
    }
    
    private void drawOpen(final int var1, final int var2, final int var3, final int var4) {
        RealmsScreen.bind("realms:textures/gui/realms/on_icon.png");
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        RealmsScreen.blit(var1, var2, 0.0f, 0.0f, 10, 28, 10, 28);
        GlStateManager.popMatrix();
        if (var3 >= var1 && var3 <= var1 + 9 && var4 >= var2 && var4 <= var2 + 27 && var4 < this.height() - 40 && var4 > 32 && !this.shouldShowPopup()) {
            this.toolTip = RealmsScreen.getLocalizedString("mco.selectServer.open");
        }
    }
    
    private void drawClose(final int var1, final int var2, final int var3, final int var4) {
        RealmsScreen.bind("realms:textures/gui/realms/off_icon.png");
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        RealmsScreen.blit(var1, var2, 0.0f, 0.0f, 10, 28, 10, 28);
        GlStateManager.popMatrix();
        if (var3 >= var1 && var3 <= var1 + 9 && var4 >= var2 && var4 <= var2 + 27 && var4 < this.height() - 40 && var4 > 32 && !this.shouldShowPopup()) {
            this.toolTip = RealmsScreen.getLocalizedString("mco.selectServer.closed");
        }
    }
    
    private void drawLeave(final int var1, final int var2, final int var3, final int var4) {
        boolean var5 = false;
        if (var3 >= var1 && var3 <= var1 + 28 && var4 >= var2 && var4 <= var2 + 28 && var4 < this.height() - 40 && var4 > 32 && !this.shouldShowPopup()) {
            var5 = true;
        }
        RealmsScreen.bind("realms:textures/gui/realms/leave_icon.png");
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        RealmsScreen.blit(var1, var2, var5 ? 28.0f : 0.0f, 0.0f, 28, 28, 56, 28);
        GlStateManager.popMatrix();
        if (var5) {
            this.toolTip = RealmsScreen.getLocalizedString("mco.selectServer.leave");
        }
    }
    
    private void drawConfigure(final int var1, final int var2, final int var3, final int var4) {
        boolean var5 = false;
        if (var3 >= var1 && var3 <= var1 + 28 && var4 >= var2 && var4 <= var2 + 28 && var4 < this.height() - 40 && var4 > 32 && !this.shouldShowPopup()) {
            var5 = true;
        }
        RealmsScreen.bind("realms:textures/gui/realms/configure_icon.png");
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        RealmsScreen.blit(var1, var2, var5 ? 28.0f : 0.0f, 0.0f, 28, 28, 56, 28);
        GlStateManager.popMatrix();
        if (var5) {
            this.toolTip = RealmsScreen.getLocalizedString("mco.selectServer.configure");
        }
    }
    
    protected void renderMousehoverTooltip(final String string, final int var2, final int var3) {
        if (string == null) {
            return;
        }
        int var4 = 0;
        int var5 = 0;
        for (final String var6 : string.split("\n")) {
            final int var7 = this.fontWidth(var6);
            if (var7 > var5) {
                var5 = var7;
            }
        }
        int var8 = var2 - var5 - 5;
        final int var9 = var3;
        if (var8 < 0) {
            var8 = var2 + 12;
        }
        for (final String var10 : string.split("\n")) {
            this.fillGradient(var8 - 3, var9 - ((var4 == 0) ? 3 : 0) + var4, var8 + var5 + 3, var9 + 8 + 3 + var4, -1073741824, -1073741824);
            this.fontDrawShadow(var10, var8, var9 + var4, 16777215);
            var4 += 10;
        }
    }
    
    private void renderMoreInfo(final int var1, final int var2, final int var3, final int var4, final boolean var5) {
        boolean var6 = false;
        if (var1 >= var3 && var1 <= var3 + 20 && var2 >= var4 && var2 <= var4 + 20) {
            var6 = true;
        }
        RealmsScreen.bind("realms:textures/gui/realms/questionmark.png");
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        RealmsScreen.blit(var3, var4, var5 ? 20.0f : 0.0f, 0.0f, 20, 20, 40, 20);
        GlStateManager.popMatrix();
        if (var6) {
            this.toolTip = RealmsScreen.getLocalizedString("mco.selectServer.info");
        }
    }
    
    private void renderNews(final int var1, final int var2, final boolean var3, final int var4, final int var5, final boolean var6, final boolean var7) {
        boolean var8 = false;
        if (var1 >= var4 && var1 <= var4 + 20 && var2 >= var5 && var2 <= var5 + 20) {
            var8 = true;
        }
        RealmsScreen.bind("realms:textures/gui/realms/news_icon.png");
        if (var7) {
            GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        }
        else {
            GlStateManager.color4f(0.5f, 0.5f, 0.5f, 1.0f);
        }
        GlStateManager.pushMatrix();
        final boolean var9 = var7 && var6;
        RealmsScreen.blit(var4, var5, var9 ? 20.0f : 0.0f, 0.0f, 20, 20, 40, 20);
        GlStateManager.popMatrix();
        if (var8 && var7) {
            this.toolTip = RealmsScreen.getLocalizedString("mco.news");
        }
        if (var3 && var7) {
            final int var10 = var8 ? 0 : ((int)(Math.max(0.0f, Math.max(RealmsMth.sin((10 + this.animTick) * 0.57f), RealmsMth.cos(this.animTick * 0.35f))) * -6.0f));
            RealmsScreen.bind("realms:textures/gui/realms/invitation_icons.png");
            GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.pushMatrix();
            RealmsScreen.blit(var4 + 10, var5 + 2 + var10, 40.0f, 0.0f, 8, 8, 48, 16);
            GlStateManager.popMatrix();
        }
    }
    
    private void renderLocal() {
        final String var1 = "LOCAL!";
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        GlStateManager.translatef((float)(this.width() / 2 - 25), 20.0f, 0.0f);
        GlStateManager.rotatef(-20.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.scalef(1.5f, 1.5f, 1.5f);
        this.drawString("LOCAL!", 0, 0, 8388479);
        GlStateManager.popMatrix();
    }
    
    private void renderStage() {
        final String var1 = "STAGE!";
        GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.pushMatrix();
        GlStateManager.translatef((float)(this.width() / 2 - 25), 20.0f, 0.0f);
        GlStateManager.rotatef(-20.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.scalef(1.5f, 1.5f, 1.5f);
        this.drawString("STAGE!", 0, 0, -256);
        GlStateManager.popMatrix();
    }
    
    public RealmsMainScreen newScreen() {
        return new RealmsMainScreen(this.lastScreen);
    }
    
    public void closePopup() {
        if (this.shouldShowPopup() && this.popupOpenedByUser) {
            this.popupOpenedByUser = false;
        }
    }
    
    static {
        LOGGER = LogManager.getLogger();
        IMAGES_LOCATION = new String[] { "realms:textures/gui/realms/images/sand_castle.png", "realms:textures/gui/realms/images/factory_floor.png", "realms:textures/gui/realms/images/escher_tunnel.png", "realms:textures/gui/realms/images/tree_houses.png", "realms:textures/gui/realms/images/balloon_trip.png", "realms:textures/gui/realms/images/halloween_woods.png", "realms:textures/gui/realms/images/flower_mountain.png", "realms:textures/gui/realms/images/dornenstein_estate.png", "realms:textures/gui/realms/images/desert.png", "realms:textures/gui/realms/images/gray.png", "realms:textures/gui/realms/images/imperium.png", "realms:textures/gui/realms/images/ludo.png", "realms:textures/gui/realms/images/makersspleef.png", "realms:textures/gui/realms/images/negentropy.png", "realms:textures/gui/realms/images/pumpkin_party.png", "realms:textures/gui/realms/images/sparrenhout.png", "realms:textures/gui/realms/images/spindlewood.png" };
        realmsDataFetcher = new RealmsDataFetcher();
        RealmsMainScreen.lastScrollYPosition = -1;
    }
    
    @ClientJarOnly
    class RealmSelectionList extends RealmsObjectSelectionList
    {
        public RealmSelectionList() {
            super(RealmsMainScreen.this.width(), RealmsMainScreen.this.height(), 32, RealmsMainScreen.this.height() - 40, 36);
        }
        
        @Override
        public boolean isFocused() {
            return RealmsMainScreen.this.isFocused(this);
        }
        
        @Override
        public boolean keyPressed(final int var1, final int var2, final int var3) {
            if (var1 != 257 && var1 != 32 && var1 != 335) {
                return false;
            }
            final RealmListEntry var4 = this.getSelected();
            if (var4 == null) {
                return super.keyPressed(var1, var2, var3);
            }
            return var4.mouseClicked(0.0, 0.0, 0);
        }
        
        @Override
        public boolean mouseClicked(final double var1, final double var3, final int var5) {
            if (var5 == 0 && var1 < this.getScrollbarPosition() && var3 >= this.y0() && var3 <= this.y1()) {
                final int var6 = RealmsMainScreen.this.realmSelectionList.getRowLeft();
                final int var7 = this.getScrollbarPosition();
                final int var8 = (int)Math.floor(var3 - this.y0()) - this.headerHeight() + this.getScroll() - 4;
                final int var9 = var8 / this.itemHeight();
                if (var1 >= var6 && var1 <= var7 && var9 >= 0 && var8 >= 0 && var9 < this.getItemCount()) {
                    this.itemClicked(var8, var9, var1, var3, this.width());
                    RealmsMainScreen.this.clicks += 7;
                    this.selectItem(var9);
                }
                return true;
            }
            return super.mouseClicked(var1, var3, var5);
        }
        
        @Override
        public void selectItem(final int selected) {
            this.setSelected(selected);
            if (selected == -1) {
                return;
            }
            RealmsServer var2;
            if (RealmsMainScreen.this.shouldShowMessageInList()) {
                if (selected == 0) {
                    Realms.narrateNow(RealmsScreen.getLocalizedString("mco.trial.message.line1"), RealmsScreen.getLocalizedString("mco.trial.message.line2"));
                    var2 = null;
                }
                else {
                    var2 = RealmsMainScreen.this.realmsServers.get(selected - 1);
                }
            }
            else {
                var2 = RealmsMainScreen.this.realmsServers.get(selected);
            }
            RealmsMainScreen.this.updateButtonStates(var2);
            if (var2 == null) {
                RealmsMainScreen.this.selectedServerId = -1L;
                return;
            }
            if (var2.state == RealmsServer.State.UNINITIALIZED) {
                Realms.narrateNow(RealmsScreen.getLocalizedString("mco.selectServer.uninitialized") + RealmsScreen.getLocalizedString("mco.gui.button"));
                RealmsMainScreen.this.selectedServerId = -1L;
                return;
            }
            RealmsMainScreen.this.selectedServerId = var2.id;
            if (RealmsMainScreen.this.clicks >= 10 && RealmsMainScreen.this.playButton.active()) {
                RealmsMainScreen.this.play(RealmsMainScreen.this.findServer(RealmsMainScreen.this.selectedServerId), RealmsMainScreen.this);
            }
            Realms.narrateNow(RealmsScreen.getLocalizedString("narrator.select", var2.name));
        }
        
        @Override
        public void itemClicked(final int var1, int var2, final double var3, final double var5, final int var7) {
            if (RealmsMainScreen.this.shouldShowMessageInList()) {
                if (var2 == 0) {
                    RealmsMainScreen.this.popupOpenedByUser = true;
                    return;
                }
                --var2;
            }
            if (var2 >= RealmsMainScreen.this.realmsServers.size()) {
                return;
            }
            final RealmsServer var8 = RealmsMainScreen.this.realmsServers.get(var2);
            if (var8 == null) {
                return;
            }
            if (var8.state == RealmsServer.State.UNINITIALIZED) {
                RealmsMainScreen.this.selectedServerId = -1L;
                Realms.setScreen(new RealmsCreateRealmScreen(var8, RealmsMainScreen.this));
            }
            else {
                RealmsMainScreen.this.selectedServerId = var8.id;
            }
            if (RealmsMainScreen.this.toolTip != null && RealmsMainScreen.this.toolTip.equals(RealmsScreen.getLocalizedString("mco.selectServer.configure"))) {
                RealmsMainScreen.this.selectedServerId = var8.id;
                RealmsMainScreen.this.configureClicked(var8);
            }
            else if (RealmsMainScreen.this.toolTip != null && RealmsMainScreen.this.toolTip.equals(RealmsScreen.getLocalizedString("mco.selectServer.leave"))) {
                RealmsMainScreen.this.selectedServerId = var8.id;
                RealmsMainScreen.this.leaveClicked(var8);
            }
            else if (RealmsMainScreen.this.isSelfOwnedServer(var8) && var8.expired && RealmsMainScreen.this.expiredHover) {
                RealmsMainScreen.this.onRenew();
            }
        }
        
        @Override
        public int getMaxPosition() {
            return this.getItemCount() * 36;
        }
        
        @Override
        public int getRowWidth() {
            return 300;
        }
    }
    
    @ClientJarOnly
    class RealmSelectionListTrialEntry extends RealmListEntry
    {
        public RealmSelectionListTrialEntry() {
        }
        
        @Override
        public void render(final int var1, final int var2, final int var3, final int var4, final int var5, final int var6, final int var7, final boolean var8, final float var9) {
            this.renderTrialItem(var1, var3, var2, var6, var7);
        }
        
        @Override
        public boolean mouseClicked(final double var1, final double var3, final int var5) {
            RealmsMainScreen.this.popupOpenedByUser = true;
            return true;
        }
        
        private void renderTrialItem(final int var1, final int var2, final int var3, final int var4, final int var5) {
            final int var6 = var3 + 8;
            int var7 = 0;
            final String var8 = RealmsScreen.getLocalizedString("mco.trial.message.line1") + "\\n" + RealmsScreen.getLocalizedString("mco.trial.message.line2");
            boolean var9 = false;
            if (var2 <= var4 && var4 <= RealmsMainScreen.this.realmSelectionList.getScroll() && var3 <= var5 && var5 <= var3 + 32) {
                var9 = true;
            }
            int var10 = 8388479;
            if (var9 && !RealmsMainScreen.this.shouldShowPopup()) {
                var10 = 6077788;
            }
            for (final String var11 : var8.split("\\\\n")) {
                RealmsMainScreen.this.drawCenteredString(var11, RealmsMainScreen.this.width() / 2, var6 + var7, var10);
                var7 += 10;
            }
        }
    }
    
    @ClientJarOnly
    class RealmSelectionListEntry extends RealmListEntry
    {
        final RealmsServer mServerData;
        
        public RealmSelectionListEntry(final RealmsServer mServerData) {
            this.mServerData = mServerData;
        }
        
        @Override
        public void render(final int var1, final int var2, final int var3, final int var4, final int var5, final int var6, final int var7, final boolean var8, final float var9) {
            this.renderMcoServerItem(this.mServerData, var3, var2, var6, var7);
        }
        
        @Override
        public boolean mouseClicked(final double var1, final double var3, final int var5) {
            if (this.mServerData.state == RealmsServer.State.UNINITIALIZED) {
                RealmsMainScreen.this.selectedServerId = -1L;
                Realms.setScreen(new RealmsCreateRealmScreen(this.mServerData, RealmsMainScreen.this));
            }
            else {
                RealmsMainScreen.this.selectedServerId = this.mServerData.id;
            }
            return true;
        }
        
        private void renderMcoServerItem(final RealmsServer realmsServer, final int var2, final int var3, final int var4, final int var5) {
            this.renderLegacy(realmsServer, var2 + 36, var3, var4, var5);
        }
        
        private void renderLegacy(final RealmsServer realmsServer, final int var2, final int var3, final int var4, final int var5) {
            if (realmsServer.state == RealmsServer.State.UNINITIALIZED) {
                RealmsScreen.bind("realms:textures/gui/realms/world_icon.png");
                GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.enableAlphaTest();
                GlStateManager.pushMatrix();
                RealmsScreen.blit(var2 + 10, var3 + 6, 0.0f, 0.0f, 40, 20, 40, 20);
                GlStateManager.popMatrix();
                final float var6 = 0.5f + (1.0f + RealmsMth.sin(RealmsMainScreen.this.animTick * 0.25f)) * 0.25f;
                final int var7 = 0xFF000000 | (int)(127.0f * var6) << 16 | (int)(255.0f * var6) << 8 | (int)(127.0f * var6);
                RealmsMainScreen.this.drawCenteredString(RealmsScreen.getLocalizedString("mco.selectServer.uninitialized"), var2 + 10 + 40 + 75, var3 + 12, var7);
                return;
            }
            final int var8 = 225;
            final int var7 = 2;
            if (realmsServer.expired) {
                RealmsMainScreen.this.drawExpired(var2 + 225 - 14, var3 + 2, var4, var5);
            }
            else if (realmsServer.state == RealmsServer.State.CLOSED) {
                RealmsMainScreen.this.drawClose(var2 + 225 - 14, var3 + 2, var4, var5);
            }
            else if (RealmsMainScreen.this.isSelfOwnedServer(realmsServer) && realmsServer.daysLeft < 7) {
                RealmsMainScreen.this.drawExpiring(var2 + 225 - 14, var3 + 2, var4, var5, realmsServer.daysLeft);
            }
            else if (realmsServer.state == RealmsServer.State.OPEN) {
                RealmsMainScreen.this.drawOpen(var2 + 225 - 14, var3 + 2, var4, var5);
            }
            if (!RealmsMainScreen.this.isSelfOwnedServer(realmsServer) && !RealmsMainScreen.overrideConfigure) {
                RealmsMainScreen.this.drawLeave(var2 + 225, var3 + 2, var4, var5);
            }
            else {
                RealmsMainScreen.this.drawConfigure(var2 + 225, var3 + 2, var4, var5);
            }
            if (!"0".equals(realmsServer.serverPing.nrOfPlayers)) {
                final String var9 = ChatFormatting.GRAY + "" + realmsServer.serverPing.nrOfPlayers;
                RealmsMainScreen.this.drawString(var9, var2 + 207 - RealmsMainScreen.this.fontWidth(var9), var3 + 3, 8421504);
                if (var4 >= var2 + 207 - RealmsMainScreen.this.fontWidth(var9) && var4 <= var2 + 207 && var5 >= var3 + 1 && var5 <= var3 + 10 && var5 < RealmsMainScreen.this.height() - 40 && var5 > 32 && !RealmsMainScreen.this.shouldShowPopup()) {
                    RealmsMainScreen.this.toolTip = realmsServer.serverPing.playerList;
                }
            }
            if (RealmsMainScreen.this.isSelfOwnedServer(realmsServer) && realmsServer.expired) {
                boolean var10 = false;
                GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.enableBlend();
                RealmsScreen.bind("minecraft:textures/gui/widgets.png");
                GlStateManager.pushMatrix();
                GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
                String var11 = RealmsScreen.getLocalizedString("mco.selectServer.expiredList");
                String var12 = RealmsScreen.getLocalizedString("mco.selectServer.expiredRenew");
                if (realmsServer.expiredTrial) {
                    var11 = RealmsScreen.getLocalizedString("mco.selectServer.expiredTrial");
                    var12 = RealmsScreen.getLocalizedString("mco.selectServer.expiredSubscribe");
                }
                final int var13 = RealmsMainScreen.this.fontWidth(var12) + 17;
                final int var14 = 16;
                final int var15 = var2 + RealmsMainScreen.this.fontWidth(var11) + 8;
                final int var16 = var3 + 13;
                if (var4 >= var15 && var4 < var15 + var13 && var5 > var16 && (var5 <= var16 + 16 & var5 < RealmsMainScreen.this.height() - 40) && var5 > 32 && !RealmsMainScreen.this.shouldShowPopup()) {
                    var10 = true;
                    RealmsMainScreen.this.expiredHover = true;
                }
                final int var17 = var10 ? 2 : 1;
                RealmsScreen.blit(var15, var16, 0.0f, (float)(46 + var17 * 20), var13 / 2, 8, 256, 256);
                RealmsScreen.blit(var15 + var13 / 2, var16, (float)(200 - var13 / 2), (float)(46 + var17 * 20), var13 / 2, 8, 256, 256);
                RealmsScreen.blit(var15, var16 + 8, 0.0f, (float)(46 + var17 * 20 + 12), var13 / 2, 8, 256, 256);
                RealmsScreen.blit(var15 + var13 / 2, var16 + 8, (float)(200 - var13 / 2), (float)(46 + var17 * 20 + 12), var13 / 2, 8, 256, 256);
                GlStateManager.popMatrix();
                GlStateManager.disableBlend();
                final int var18 = var3 + 11 + 5;
                final int var19 = var10 ? 16777120 : 16777215;
                RealmsMainScreen.this.drawString(var11, var2 + 2, var18 + 1, 15553363);
                RealmsMainScreen.this.drawCenteredString(var12, var15 + var13 / 2, var18 + 1, var19);
            }
            else {
                if (realmsServer.worldType.equals(RealmsServer.WorldType.MINIGAME)) {
                    final int var20 = 13413468;
                    final String var11 = RealmsScreen.getLocalizedString("mco.selectServer.minigame") + " ";
                    final int var21 = RealmsMainScreen.this.fontWidth(var11);
                    RealmsMainScreen.this.drawString(var11, var2 + 2, var3 + 12, 13413468);
                    RealmsMainScreen.this.drawString(realmsServer.getMinigameName(), var2 + 2 + var21, var3 + 12, 7105644);
                }
                else {
                    RealmsMainScreen.this.drawString(realmsServer.getDescription(), var2 + 2, var3 + 12, 7105644);
                }
                if (!RealmsMainScreen.this.isSelfOwnedServer(realmsServer)) {
                    RealmsMainScreen.this.drawString(realmsServer.owner, var2 + 2, var3 + 12 + 11, 5000268);
                }
            }
            RealmsMainScreen.this.drawString(realmsServer.getName(), var2 + 2, var3 + 1, 16777215);
            RealmsTextureManager.withBoundFace(realmsServer.ownerUUID, () -> {
                GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
                RealmsScreen.blit(var2 - 36, var3, 8.0f, 8.0f, 8, 8, 32, 32, 64, 64);
                RealmsScreen.blit(var2 - 36, var3, 40.0f, 8.0f, 8, 8, 32, 32, 64, 64);
            });
        }
    }
    
    @ClientJarOnly
    class PendingInvitesButton extends RealmsButton
    {
        public PendingInvitesButton() {
            super(8, RealmsMainScreen.this.width() / 2 + 47, 6, 22, 22, "");
        }
        
        @Override
        public void tick() {
            this.setMessage(Realms.getLocalizedString((RealmsMainScreen.this.numberOfPendingInvites == 0) ? "mco.invites.nopending" : "mco.invites.pending", new Object[0]));
        }
        
        @Override
        public void render(final int var1, final int var2, final float var3) {
            super.render(var1, var2, var3);
        }
        
        @Override
        public void onPress() {
            final RealmsPendingInvitesScreen var1 = new RealmsPendingInvitesScreen(RealmsMainScreen.this.lastScreen);
            Realms.setScreen(var1);
        }
        
        @Override
        public void renderButton(final int var1, final int var2, final float var3) {
            RealmsMainScreen.this.drawInvitationPendingIcon(var1, var2, this.x(), this.y(), this.getProxy().isHovered(), this.active());
        }
    }
    
    @ClientJarOnly
    class NewsButton extends RealmsButton
    {
        public NewsButton() {
            super(9, RealmsMainScreen.this.width() - 62, 6, 20, 20, "");
        }
        
        @Override
        public void tick() {
            this.setMessage(Realms.getLocalizedString("mco.news", new Object[0]));
        }
        
        @Override
        public void render(final int var1, final int var2, final float var3) {
            super.render(var1, var2, var3);
        }
        
        @Override
        public void onPress() {
            if (RealmsMainScreen.this.newsLink == null) {
                return;
            }
            RealmsUtil.browseTo(RealmsMainScreen.this.newsLink);
            if (RealmsMainScreen.this.hasUnreadNews) {
                final RealmsPersistence.RealmsPersistenceData var1 = RealmsPersistence.readFile();
                var1.hasUnreadNews = false;
                RealmsMainScreen.this.hasUnreadNews = false;
                RealmsPersistence.writeFile(var1);
            }
        }
        
        @Override
        public void renderButton(final int var1, final int var2, final float var3) {
            RealmsMainScreen.this.renderNews(var1, var2, RealmsMainScreen.this.hasUnreadNews, this.x(), this.y(), this.getProxy().isHovered(), this.active());
        }
    }
    
    @ClientJarOnly
    class ShowPopupButton extends RealmsButton
    {
        public ShowPopupButton() {
            super(10, RealmsMainScreen.this.width() - 37, 6, 20, 20, RealmsScreen.getLocalizedString("mco.selectServer.info"));
        }
        
        @Override
        public void tick() {
            super.tick();
        }
        
        @Override
        public void render(final int var1, final int var2, final float var3) {
            super.render(var1, var2, var3);
        }
        
        @Override
        public void renderButton(final int var1, final int var2, final float var3) {
            RealmsMainScreen.this.renderMoreInfo(var1, var2, this.x(), this.y(), this.getProxy().isHovered());
        }
        
        @Override
        public void onPress() {
            RealmsMainScreen.this.popupOpenedByUser = !RealmsMainScreen.this.popupOpenedByUser;
        }
    }
    
    @ClientJarOnly
    class CloseButton extends RealmsButton
    {
        public CloseButton() {
            super(11, RealmsMainScreen.this.popupX0() + 4, RealmsMainScreen.this.popupY0() + 4, 12, 12, RealmsScreen.getLocalizedString("mco.selectServer.close"));
        }
        
        @Override
        public void tick() {
            super.tick();
        }
        
        @Override
        public void render(final int var1, final int var2, final float var3) {
            super.render(var1, var2, var3);
        }
        
        @Override
        public void renderButton(final int var1, final int var2, final float var3) {
            RealmsScreen.bind("realms:textures/gui/realms/cross_icon.png");
            GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.pushMatrix();
            RealmsScreen.blit(this.x(), this.y(), 0.0f, this.getProxy().isHovered() ? 12.0f : 0.0f, 12, 12, 12, 24);
            GlStateManager.popMatrix();
            if (this.getProxy().isMouseOver(var1, var2)) {
                RealmsMainScreen.this.toolTip = this.getProxy().getMessage();
            }
        }
        
        @Override
        public void onPress() {
            RealmsMainScreen.this.onClosePopup();
        }
    }
}
