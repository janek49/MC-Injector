package com.mojang.realmsclient.exception;

import com.fox2code.repacker.*;

@ClientJarOnly
public class RealmsHttpException extends RuntimeException
{
    public RealmsHttpException(final String string, final Exception exception) {
        super(string, exception);
    }
}
