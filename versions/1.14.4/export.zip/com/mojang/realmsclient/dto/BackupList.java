package com.mojang.realmsclient.dto;

import com.fox2code.repacker.*;
import com.google.gson.*;
import java.util.*;
import org.apache.logging.log4j.*;

@ClientJarOnly
public class BackupList extends ValueObject
{
    private static final Logger LOGGER;
    public List<Backup> backups;
    
    public static BackupList parse(final String string) {
        final JsonParser var1 = new JsonParser();
        final BackupList var2 = new BackupList();
        var2.backups = new ArrayList<Backup>();
        try {
            final JsonElement var3 = var1.parse(string).getAsJsonObject().get("backups");
            if (var3.isJsonArray()) {
                final Iterator<JsonElement> var4 = (Iterator<JsonElement>)var3.getAsJsonArray().iterator();
                while (var4.hasNext()) {
                    var2.backups.add(Backup.parse(var4.next()));
                }
            }
        }
        catch (Exception var5) {
            BackupList.LOGGER.error("Could not parse BackupList: " + var5.getMessage());
        }
        return var2;
    }
    
    static {
        LOGGER = LogManager.getLogger();
    }
}
