package com.mojang.realmsclient.dto;

import com.fox2code.repacker.*;
import com.google.gson.*;
import com.mojang.realmsclient.util.*;

@ClientJarOnly
public class ServerActivity extends ValueObject
{
    public String profileUuid;
    public long joinTime;
    public long leaveTime;
    
    public static ServerActivity parse(final JsonObject jsonObject) {
        final ServerActivity serverActivity = new ServerActivity();
        try {
            serverActivity.profileUuid = JsonUtils.getStringOr("profileUuid", jsonObject, null);
            serverActivity.joinTime = JsonUtils.getLongOr("joinTime", jsonObject, Long.MIN_VALUE);
            serverActivity.leaveTime = JsonUtils.getLongOr("leaveTime", jsonObject, Long.MIN_VALUE);
        }
        catch (Exception ex) {}
        return serverActivity;
    }
}
