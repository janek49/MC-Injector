package com.mojang.realmsclient.dto;

import com.fox2code.repacker.*;
import com.mojang.realmsclient.util.*;
import com.google.gson.*;
import java.util.*;

@ClientJarOnly
public class ServerActivityList extends ValueObject
{
    public long periodInMillis;
    public List<ServerActivity> serverActivities;
    
    public ServerActivityList() {
        this.serverActivities = new ArrayList<ServerActivity>();
    }
    
    public static ServerActivityList parse(final String string) {
        final ServerActivityList serverActivityList = new ServerActivityList();
        final JsonParser var2 = new JsonParser();
        try {
            final JsonElement var3 = var2.parse(string);
            final JsonObject var4 = var3.getAsJsonObject();
            serverActivityList.periodInMillis = JsonUtils.getLongOr("periodInMillis", var4, -1L);
            final JsonElement var5 = var4.get("playerActivityDto");
            if (var5 != null && var5.isJsonArray()) {
                final JsonArray var6 = var5.getAsJsonArray();
                for (final JsonElement var7 : var6) {
                    final ServerActivity var8 = ServerActivity.parse(var7.getAsJsonObject());
                    serverActivityList.serverActivities.add(var8);
                }
            }
        }
        catch (Exception ex) {}
        return serverActivityList;
    }
}
