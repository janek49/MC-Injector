package com.mojang.realmsclient.client;

import com.fox2code.repacker.*;
import net.minecraft.realms.*;
import java.io.*;
import com.google.gson.*;
import com.mojang.realmsclient.dto.*;
import java.net.*;
import com.mojang.realmsclient.exception.*;
import org.apache.logging.log4j.*;

@ClientJarOnly
public class RealmsClient
{
    public static Environment currentEnvironment;
    private static boolean initialized;
    private static final Logger LOGGER;
    private final String sessionId;
    private final String username;
    private static final Gson gson;
    
    public static RealmsClient createRealmsClient() {
        final String var0 = Realms.userName();
        final String var2 = Realms.sessionId();
        if (var0 == null || var2 == null) {
            return null;
        }
        if (!RealmsClient.initialized) {
            RealmsClient.initialized = true;
            String var3 = System.getenv("realms.environment");
            if (var3 == null) {
                var3 = System.getProperty("realms.environment");
            }
            if (var3 != null) {
                if ("LOCAL".equals(var3)) {
                    switchToLocal();
                }
                else if ("STAGE".equals(var3)) {
                    switchToStage();
                }
            }
        }
        return new RealmsClient(var2, var0, Realms.getProxy());
    }
    
    public static void switchToStage() {
        RealmsClient.currentEnvironment = Environment.STAGE;
    }
    
    public static void switchToProd() {
        RealmsClient.currentEnvironment = Environment.PRODUCTION;
    }
    
    public static void switchToLocal() {
        RealmsClient.currentEnvironment = Environment.LOCAL;
    }
    
    public RealmsClient(final String sessionId, final String username, final Proxy proxy) {
        this.sessionId = sessionId;
        this.username = username;
        RealmsClientConfig.setProxy(proxy);
    }
    
    public RealmsServerList listWorlds() throws RealmsServiceException, IOException {
        final String var1 = this.url("worlds");
        final String var2 = this.execute(Request.get(var1));
        return RealmsServerList.parse(var2);
    }
    
    public RealmsServer getOwnWorld(final long l) throws RealmsServiceException, IOException {
        final String var3 = this.url("worlds" + "/$ID".replace("$ID", String.valueOf(l)));
        final String var4 = this.execute(Request.get(var3));
        return RealmsServer.parse(var4);
    }
    
    public RealmsServerPlayerLists getLiveStats() throws RealmsServiceException {
        final String var1 = this.url("activities/liveplayerlist");
        final String var2 = this.execute(Request.get(var1));
        return RealmsServerPlayerLists.parse(var2);
    }
    
    public RealmsServerAddress join(final long l) throws RealmsServiceException, IOException {
        final String var3 = this.url("worlds" + "/v1/$ID/join/pc".replace("$ID", "" + l));
        final String var4 = this.execute(Request.get(var3, 5000, 30000));
        return RealmsServerAddress.parse(var4);
    }
    
    public void initializeWorld(final long var1, final String var3, final String var4) throws RealmsServiceException, IOException {
        final RealmsDescriptionDto var5 = new RealmsDescriptionDto(var3, var4);
        final String var6 = this.url("worlds" + "/$WORLD_ID/initialize".replace("$WORLD_ID", String.valueOf(var1)));
        final String var7 = RealmsClient.gson.toJson((Object)var5);
        this.execute(Request.post(var6, var7, 5000, 10000));
    }
    
    public Boolean mcoEnabled() throws RealmsServiceException, IOException {
        final String var1 = this.url("mco/available");
        final String var2 = this.execute(Request.get(var1));
        return Boolean.valueOf(var2);
    }
    
    public Boolean stageAvailable() throws RealmsServiceException, IOException {
        final String var1 = this.url("mco/stageAvailable");
        final String var2 = this.execute(Request.get(var1));
        return Boolean.valueOf(var2);
    }
    
    public CompatibleVersionResponse clientCompatible() throws RealmsServiceException, IOException {
        final String var1 = this.url("mco/client/compatible");
        final String var2 = this.execute(Request.get(var1));
        CompatibleVersionResponse var3;
        try {
            var3 = CompatibleVersionResponse.valueOf(var2);
        }
        catch (IllegalArgumentException var4) {
            throw new RealmsServiceException(500, "Could not check compatible version, got response: " + var2, -1, "");
        }
        return var3;
    }
    
    public void uninvite(final long var1, final String string) throws RealmsServiceException {
        final String string2 = this.url("invites" + "/$WORLD_ID/invite/$UUID".replace("$WORLD_ID", String.valueOf(var1)).replace("$UUID", string));
        this.execute(Request.delete(string2));
    }
    
    public void uninviteMyselfFrom(final long l) throws RealmsServiceException {
        final String var3 = this.url("invites" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(l)));
        this.execute(Request.delete(var3));
    }
    
    public RealmsServer invite(final long var1, final String string) throws RealmsServiceException, IOException {
        final PlayerInfo var2 = new PlayerInfo();
        var2.setName(string);
        final String var3 = this.url("invites" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(var1)));
        final String var4 = this.execute(Request.post(var3, RealmsClient.gson.toJson((Object)var2)));
        return RealmsServer.parse(var4);
    }
    
    public BackupList backupsFor(final long l) throws RealmsServiceException {
        final String var3 = this.url("worlds" + "/$WORLD_ID/backups".replace("$WORLD_ID", String.valueOf(l)));
        final String var4 = this.execute(Request.get(var3));
        return BackupList.parse(var4);
    }
    
    public void update(final long var1, final String var3, final String var4) throws RealmsServiceException, UnsupportedEncodingException {
        final RealmsDescriptionDto var5 = new RealmsDescriptionDto(var3, var4);
        final String var6 = this.url("worlds" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(var1)));
        this.execute(Request.post(var6, RealmsClient.gson.toJson((Object)var5)));
    }
    
    public void updateSlot(final long var1, final int var3, final RealmsWorldOptions realmsWorldOptions) throws RealmsServiceException, UnsupportedEncodingException {
        final String var4 = this.url("worlds" + "/$WORLD_ID/slot/$SLOT_ID".replace("$WORLD_ID", String.valueOf(var1)).replace("$SLOT_ID", String.valueOf(var3)));
        final String var5 = realmsWorldOptions.toJson();
        this.execute(Request.post(var4, var5));
    }
    
    public boolean switchSlot(final long var1, final int var3) throws RealmsServiceException {
        final String var4 = this.url("worlds" + "/$WORLD_ID/slot/$SLOT_ID".replace("$WORLD_ID", String.valueOf(var1)).replace("$SLOT_ID", String.valueOf(var3)));
        final String var5 = this.execute(Request.put(var4, ""));
        return Boolean.valueOf(var5);
    }
    
    public void restoreWorld(final long var1, final String string) throws RealmsServiceException {
        final String string2 = this.url("worlds" + "/$WORLD_ID/backups".replace("$WORLD_ID", String.valueOf(var1)), "backupId=" + string);
        this.execute(Request.put(string2, "", 40000, 600000));
    }
    
    public WorldTemplatePaginatedList fetchWorldTemplates(final int var1, final int var2, final RealmsServer.WorldType realmsServer$WorldType) throws RealmsServiceException {
        final String var3 = this.url("worlds" + "/templates/$WORLD_TYPE".replace("$WORLD_TYPE", realmsServer$WorldType.toString()), String.format("page=%d&pageSize=%d", var1, var2));
        final String var4 = this.execute(Request.get(var3));
        return WorldTemplatePaginatedList.parse(var4);
    }
    
    public Boolean putIntoMinigameMode(final long var1, final String string) throws RealmsServiceException {
        final String string2 = "/minigames/$MINIGAME_ID/$WORLD_ID".replace("$MINIGAME_ID", string).replace("$WORLD_ID", String.valueOf(var1));
        final String var2 = this.url("worlds" + string2);
        return Boolean.valueOf(this.execute(Request.put(var2, "")));
    }
    
    public Ops op(final long var1, final String string) throws RealmsServiceException {
        final String string2 = "/$WORLD_ID/$PROFILE_UUID".replace("$WORLD_ID", String.valueOf(var1)).replace("$PROFILE_UUID", string);
        final String var2 = this.url("ops" + string2);
        return Ops.parse(this.execute(Request.post(var2, "")));
    }
    
    public Ops deop(final long var1, final String string) throws RealmsServiceException {
        final String string2 = "/$WORLD_ID/$PROFILE_UUID".replace("$WORLD_ID", String.valueOf(var1)).replace("$PROFILE_UUID", string);
        final String var2 = this.url("ops" + string2);
        return Ops.parse(this.execute(Request.delete(var2)));
    }
    
    public Boolean open(final long l) throws RealmsServiceException, IOException {
        final String var3 = this.url("worlds" + "/$WORLD_ID/open".replace("$WORLD_ID", String.valueOf(l)));
        final String var4 = this.execute(Request.put(var3, ""));
        return Boolean.valueOf(var4);
    }
    
    public Boolean close(final long l) throws RealmsServiceException, IOException {
        final String var3 = this.url("worlds" + "/$WORLD_ID/close".replace("$WORLD_ID", String.valueOf(l)));
        final String var4 = this.execute(Request.put(var3, ""));
        return Boolean.valueOf(var4);
    }
    
    public Boolean resetWorldWithSeed(final long var1, final String string, final Integer integer, final boolean var5) throws RealmsServiceException, IOException {
        final RealmsWorldResetDto var6 = new RealmsWorldResetDto(string, -1L, integer, var5);
        final String var7 = this.url("worlds" + "/$WORLD_ID/reset".replace("$WORLD_ID", String.valueOf(var1)));
        final String var8 = this.execute(Request.post(var7, RealmsClient.gson.toJson((Object)var6), 30000, 80000));
        return Boolean.valueOf(var8);
    }
    
    public Boolean resetWorldWithTemplate(final long var1, final String string) throws RealmsServiceException, IOException {
        final RealmsWorldResetDto var2 = new RealmsWorldResetDto(null, Long.valueOf(string), -1, false);
        final String var3 = this.url("worlds" + "/$WORLD_ID/reset".replace("$WORLD_ID", String.valueOf(var1)));
        final String var4 = this.execute(Request.post(var3, RealmsClient.gson.toJson((Object)var2), 30000, 80000));
        return Boolean.valueOf(var4);
    }
    
    public Subscription subscriptionFor(final long l) throws RealmsServiceException, IOException {
        final String var3 = this.url("subscriptions" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(l)));
        final String var4 = this.execute(Request.get(var3));
        return Subscription.parse(var4);
    }
    
    public int pendingInvitesCount() throws RealmsServiceException {
        final String var1 = this.url("invites/count/pending");
        final String var2 = this.execute(Request.get(var1));
        return Integer.parseInt(var2);
    }
    
    public PendingInvitesList pendingInvites() throws RealmsServiceException {
        final String var1 = this.url("invites/pending");
        final String var2 = this.execute(Request.get(var1));
        return PendingInvitesList.parse(var2);
    }
    
    public void acceptInvitation(final String string) throws RealmsServiceException {
        final String string2 = this.url("invites" + "/accept/$INVITATION_ID".replace("$INVITATION_ID", string));
        this.execute(Request.put(string2, ""));
    }
    
    public WorldDownload download(final long var1, final int var3) throws RealmsServiceException {
        final String var4 = this.url("worlds" + "/$WORLD_ID/slot/$SLOT_ID/download".replace("$WORLD_ID", String.valueOf(var1)).replace("$SLOT_ID", String.valueOf(var3)));
        final String var5 = this.execute(Request.get(var4));
        return WorldDownload.parse(var5);
    }
    
    public UploadInfo upload(final long var1, final String string) throws RealmsServiceException {
        final String string2 = this.url("worlds" + "/$WORLD_ID/backups/upload".replace("$WORLD_ID", String.valueOf(var1)));
        final UploadInfo var2 = new UploadInfo();
        if (string != null) {
            var2.setToken(string);
        }
        final GsonBuilder var3 = new GsonBuilder();
        var3.excludeFieldsWithoutExposeAnnotation();
        final Gson var4 = var3.create();
        final String var5 = var4.toJson((Object)var2);
        return UploadInfo.parse(this.execute(Request.put(string2, var5)));
    }
    
    public void rejectInvitation(final String string) throws RealmsServiceException {
        final String string2 = this.url("invites" + "/reject/$INVITATION_ID".replace("$INVITATION_ID", string));
        this.execute(Request.put(string2, ""));
    }
    
    public void agreeToTos() throws RealmsServiceException {
        final String var1 = this.url("mco/tos/agreed");
        this.execute(Request.post(var1, ""));
    }
    
    public RealmsNews getNews() throws RealmsServiceException, IOException {
        final String var1 = this.url("mco/v1/news");
        final String var2 = this.execute(Request.get(var1, 5000, 10000));
        return RealmsNews.parse(var2);
    }
    
    public void sendPingResults(final PingResult pingResult) throws RealmsServiceException {
        final String var2 = this.url("regions/ping/stat");
        this.execute(Request.post(var2, RealmsClient.gson.toJson((Object)pingResult)));
    }
    
    public Boolean trialAvailable() throws RealmsServiceException, IOException {
        final String var1 = this.url("trial");
        final String var2 = this.execute(Request.get(var1));
        return Boolean.valueOf(var2);
    }
    
    public RealmsServer createTrial(final String var1, final String var2) throws RealmsServiceException, IOException {
        final RealmsDescriptionDto var3 = new RealmsDescriptionDto(var1, var2);
        final String var4 = RealmsClient.gson.toJson((Object)var3);
        final String var5 = this.url("trial");
        final String var6 = this.execute(Request.post(var5, var4, 5000, 10000));
        return RealmsServer.parse(var6);
    }
    
    public void deleteWorld(final long l) throws RealmsServiceException, IOException {
        final String var3 = this.url("worlds" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(l)));
        this.execute(Request.delete(var3));
    }
    
    private String url(final String string) {
        return this.url(string, null);
    }
    
    private String url(final String var1, final String var2) {
        try {
            final URI var3 = new URI(RealmsClient.currentEnvironment.protocol, RealmsClient.currentEnvironment.baseUrl, "/" + var1, var2, null);
            return var3.toASCIIString();
        }
        catch (URISyntaxException var4) {
            var4.printStackTrace();
            return null;
        }
    }
    
    private String execute(final Request<?> request) throws RealmsServiceException {
        request.cookie("sid", this.sessionId);
        request.cookie("user", this.username);
        request.cookie("version", Realms.getMinecraftVersionString());
        try {
            final int var2 = request.responseCode();
            if (var2 == 503) {
                final int var3 = request.getRetryAfterHeader();
                throw new RetryCallException(var3);
            }
            final String var4 = request.text();
            if (var2 >= 200 && var2 < 300) {
                return var4;
            }
            if (var2 == 401) {
                final String var5 = request.getHeader("WWW-Authenticate");
                RealmsClient.LOGGER.info("Could not authorize you against Realms server: " + var5);
                throw new RealmsServiceException(var2, var5, -1, var5);
            }
            if (var4 == null || var4.length() == 0) {
                RealmsClient.LOGGER.error("Realms error code: " + var2 + " message: " + var4);
                throw new RealmsServiceException(var2, var4, var2, "");
            }
            final RealmsError var6 = new RealmsError(var4);
            RealmsClient.LOGGER.error("Realms http code: " + var2 + " -  error code: " + var6.getErrorCode() + " -  message: " + var6.getErrorMessage() + " - raw body: " + var4);
            throw new RealmsServiceException(var2, var4, var6);
        }
        catch (RealmsHttpException var7) {
            throw new RealmsServiceException(500, "Could not connect to Realms: " + var7.getMessage(), -1, "");
        }
    }
    
    static {
        RealmsClient.currentEnvironment = Environment.PRODUCTION;
        LOGGER = LogManager.getLogger();
        gson = new Gson();
    }
    
    @ClientJarOnly
    public enum Environment
    {
        PRODUCTION("PRODUCTION", 0, "pc.realms.minecraft.net", "https"), 
        STAGE("STAGE", 1, "pc-stage.realms.minecraft.net", "https"), 
        LOCAL("LOCAL", 2, "localhost:8080", "http");
        
        public String baseUrl;
        public String protocol;
        
        private Environment(final String s, final int n, final String baseUrl, final String protocol) {
            this.baseUrl = baseUrl;
            this.protocol = protocol;
        }
    }
    
    @ClientJarOnly
    public enum CompatibleVersionResponse
    {
        COMPATIBLE("COMPATIBLE", 0), 
        OUTDATED("OUTDATED", 1), 
        OTHER("OTHER", 2);
        
        private CompatibleVersionResponse(final String s, final int n) {
        }
    }
}
