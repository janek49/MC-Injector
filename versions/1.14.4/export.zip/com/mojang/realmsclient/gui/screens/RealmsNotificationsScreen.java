package com.mojang.realmsclient.gui.screens;

import com.fox2code.repacker.*;
import com.mojang.realmsclient.gui.*;
import net.minecraft.realms.*;
import com.mojang.realmsclient.client.*;
import com.mojang.realmsclient.exception.*;
import java.io.*;
import com.mojang.blaze3d.platform.*;
import java.util.*;

@ClientJarOnly
public class RealmsNotificationsScreen extends RealmsScreen
{
    private static final RealmsDataFetcher realmsDataFetcher;
    private volatile int numberOfPendingInvites;
    private static boolean checkedMcoAvailability;
    private static boolean trialAvailable;
    private static boolean validClient;
    private static boolean hasUnreadNews;
    private static final List<RealmsDataFetcher.Task> tasks;
    
    public RealmsNotificationsScreen(final RealmsScreen realmsScreen) {
    }
    
    @Override
    public void init() {
        this.checkIfMcoEnabled();
        this.setKeyboardHandlerSendRepeatsToGui(true);
    }
    
    @Override
    public void tick() {
        if ((!Realms.getRealmsNotificationsEnabled() || !Realms.inTitleScreen() || !RealmsNotificationsScreen.validClient) && !RealmsNotificationsScreen.realmsDataFetcher.isStopped()) {
            RealmsNotificationsScreen.realmsDataFetcher.stop();
            return;
        }
        if (RealmsNotificationsScreen.validClient && Realms.getRealmsNotificationsEnabled()) {
            RealmsNotificationsScreen.realmsDataFetcher.initWithSpecificTaskList(RealmsNotificationsScreen.tasks);
            if (RealmsNotificationsScreen.realmsDataFetcher.isFetchedSinceLastTry(RealmsDataFetcher.Task.PENDING_INVITE)) {
                this.numberOfPendingInvites = RealmsNotificationsScreen.realmsDataFetcher.getPendingInvitesCount();
            }
            if (RealmsNotificationsScreen.realmsDataFetcher.isFetchedSinceLastTry(RealmsDataFetcher.Task.TRIAL_AVAILABLE)) {
                RealmsNotificationsScreen.trialAvailable = RealmsNotificationsScreen.realmsDataFetcher.isTrialAvailable();
            }
            if (RealmsNotificationsScreen.realmsDataFetcher.isFetchedSinceLastTry(RealmsDataFetcher.Task.UNREAD_NEWS)) {
                RealmsNotificationsScreen.hasUnreadNews = RealmsNotificationsScreen.realmsDataFetcher.hasUnreadNews();
            }
            RealmsNotificationsScreen.realmsDataFetcher.markClean();
        }
    }
    
    private void checkIfMcoEnabled() {
        if (!RealmsNotificationsScreen.checkedMcoAvailability) {
            RealmsNotificationsScreen.checkedMcoAvailability = true;
            new Thread("Realms Notification Availability checker #1") {
                @Override
                public void run() {
                    final RealmsClient var1 = RealmsClient.createRealmsClient();
                    try {
                        final RealmsClient.CompatibleVersionResponse var2 = var1.clientCompatible();
                        if (!var2.equals(RealmsClient.CompatibleVersionResponse.COMPATIBLE)) {
                            return;
                        }
                    }
                    catch (RealmsServiceException var3) {
                        if (var3.httpResultCode != 401) {
                            RealmsNotificationsScreen.checkedMcoAvailability = false;
                        }
                        return;
                    }
                    catch (IOException var4) {
                        RealmsNotificationsScreen.checkedMcoAvailability = false;
                        return;
                    }
                    RealmsNotificationsScreen.validClient = true;
                }
            }.start();
        }
    }
    
    @Override
    public void render(final int var1, final int var2, final float var3) {
        if (RealmsNotificationsScreen.validClient) {
            this.drawIcons(var1, var2);
        }
        super.render(var1, var2, var3);
    }
    
    @Override
    public boolean mouseClicked(final double var1, final double var3, final int var5) {
        return super.mouseClicked(var1, var3, var5);
    }
    
    private void drawIcons(final int var1, final int var2) {
        final int var3 = this.numberOfPendingInvites;
        final int var4 = 24;
        final int var5 = this.height() / 4 + 48;
        final int var6 = this.width() / 2 + 80;
        final int var7 = var5 + 48 + 2;
        int var8 = 0;
        if (RealmsNotificationsScreen.hasUnreadNews) {
            RealmsScreen.bind("realms:textures/gui/realms/news_notification_mainscreen.png");
            GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.pushMatrix();
            GlStateManager.scalef(0.4f, 0.4f, 0.4f);
            RealmsScreen.blit((int)((var6 + 2 - var8) * 2.5), (int)(var7 * 2.5), 0.0f, 0.0f, 40, 40, 40, 40);
            GlStateManager.popMatrix();
            var8 += 14;
        }
        if (var3 != 0) {
            RealmsScreen.bind("realms:textures/gui/realms/invite_icon.png");
            GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.pushMatrix();
            RealmsScreen.blit(var6 - var8, var7 - 6, 0.0f, 0.0f, 15, 25, 31, 25);
            GlStateManager.popMatrix();
            var8 += 16;
        }
        if (RealmsNotificationsScreen.trialAvailable) {
            RealmsScreen.bind("realms:textures/gui/realms/trial_icon.png");
            GlStateManager.color4f(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.pushMatrix();
            int var9 = 0;
            if ((System.currentTimeMillis() / 800L & 0x1L) == 0x1L) {
                var9 = 8;
            }
            RealmsScreen.blit(var6 + 4 - var8, var7 + 4, 0.0f, (float)var9, 8, 8, 8, 16);
            GlStateManager.popMatrix();
        }
    }
    
    @Override
    public void removed() {
        RealmsNotificationsScreen.realmsDataFetcher.stop();
    }
    
    static {
        realmsDataFetcher = new RealmsDataFetcher();
        tasks = Arrays.asList(RealmsDataFetcher.Task.PENDING_INVITE, RealmsDataFetcher.Task.TRIAL_AVAILABLE, RealmsDataFetcher.Task.UNREAD_NEWS);
    }
}
