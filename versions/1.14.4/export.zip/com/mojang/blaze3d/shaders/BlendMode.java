package com.mojang.blaze3d.shaders;

import com.fox2code.repacker.*;
import com.mojang.blaze3d.platform.*;
import java.util.*;

@ClientJarOnly
public class BlendMode
{
    private static BlendMode lastApplied;
    private final int srcColorFactor;
    private final int srcAlphaFactor;
    private final int dstColorFactor;
    private final int dstAlphaFactor;
    private final int blendFunc;
    private final boolean separateBlend;
    private final boolean opaque;
    
    private BlendMode(final boolean separateBlend, final boolean opaque, final int srcColorFactor, final int dstColorFactor, final int srcAlphaFactor, final int dstAlphaFactor, final int blendFunc) {
        this.separateBlend = separateBlend;
        this.srcColorFactor = srcColorFactor;
        this.dstColorFactor = dstColorFactor;
        this.srcAlphaFactor = srcAlphaFactor;
        this.dstAlphaFactor = dstAlphaFactor;
        this.opaque = opaque;
        this.blendFunc = blendFunc;
    }
    
    public BlendMode() {
        this(false, true, 1, 0, 1, 0, 32774);
    }
    
    public BlendMode(final int var1, final int var2, final int var3) {
        this(false, false, var1, var2, var1, var2, var3);
    }
    
    public BlendMode(final int var1, final int var2, final int var3, final int var4, final int var5) {
        this(true, false, var1, var2, var3, var4, var5);
    }
    
    public void apply() {
        if (this.equals(BlendMode.lastApplied)) {
            return;
        }
        if (BlendMode.lastApplied == null || this.opaque != BlendMode.lastApplied.isOpaque()) {
            BlendMode.lastApplied = this;
            if (this.opaque) {
                GlStateManager.disableBlend();
                return;
            }
            GlStateManager.enableBlend();
        }
        GlStateManager.blendEquation(this.blendFunc);
        if (this.separateBlend) {
            GlStateManager.blendFuncSeparate(this.srcColorFactor, this.dstColorFactor, this.srcAlphaFactor, this.dstAlphaFactor);
        }
        else {
            GlStateManager.blendFunc(this.srcColorFactor, this.dstColorFactor);
        }
    }
    
    @Override
    public boolean equals(final Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof BlendMode)) {
            return false;
        }
        final BlendMode var2 = (BlendMode)object;
        return this.blendFunc == var2.blendFunc && this.dstAlphaFactor == var2.dstAlphaFactor && this.dstColorFactor == var2.dstColorFactor && this.opaque == var2.opaque && this.separateBlend == var2.separateBlend && this.srcAlphaFactor == var2.srcAlphaFactor && this.srcColorFactor == var2.srcColorFactor;
    }
    
    @Override
    public int hashCode() {
        int var1 = this.srcColorFactor;
        var1 = 31 * var1 + this.srcAlphaFactor;
        var1 = 31 * var1 + this.dstColorFactor;
        var1 = 31 * var1 + this.dstAlphaFactor;
        var1 = 31 * var1 + this.blendFunc;
        var1 = 31 * var1 + (this.separateBlend ? 1 : 0);
        var1 = 31 * var1 + (this.opaque ? 1 : 0);
        return var1;
    }
    
    public boolean isOpaque() {
        return this.opaque;
    }
    
    public static int stringToBlendFunc(final String string) {
        final String string2 = string.trim().toLowerCase(Locale.ROOT);
        if ("add".equals(string2)) {
            return 32774;
        }
        if ("subtract".equals(string2)) {
            return 32778;
        }
        if ("reversesubtract".equals(string2)) {
            return 32779;
        }
        if ("reverse_subtract".equals(string2)) {
            return 32779;
        }
        if ("min".equals(string2)) {
            return 32775;
        }
        if ("max".equals(string2)) {
            return 32776;
        }
        return 32774;
    }
    
    public static int stringToBlendFactor(final String string) {
        String string2 = string.trim().toLowerCase(Locale.ROOT);
        string2 = string2.replaceAll("_", "");
        string2 = string2.replaceAll("one", "1");
        string2 = string2.replaceAll("zero", "0");
        string2 = string2.replaceAll("minus", "-");
        if ("0".equals(string2)) {
            return 0;
        }
        if ("1".equals(string2)) {
            return 1;
        }
        if ("srccolor".equals(string2)) {
            return 768;
        }
        if ("1-srccolor".equals(string2)) {
            return 769;
        }
        if ("dstcolor".equals(string2)) {
            return 774;
        }
        if ("1-dstcolor".equals(string2)) {
            return 775;
        }
        if ("srcalpha".equals(string2)) {
            return 770;
        }
        if ("1-srcalpha".equals(string2)) {
            return 771;
        }
        if ("dstalpha".equals(string2)) {
            return 772;
        }
        if ("1-dstalpha".equals(string2)) {
            return 773;
        }
        return -1;
    }
}
