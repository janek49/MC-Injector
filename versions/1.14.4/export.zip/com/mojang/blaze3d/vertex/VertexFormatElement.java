package com.mojang.blaze3d.vertex;

import com.fox2code.repacker.*;
import org.apache.logging.log4j.*;

@ClientJarOnly
public class VertexFormatElement
{
    private static final Logger LOGGER;
    private final Type type;
    private final Usage usage;
    private final int index;
    private final int count;
    
    public VertexFormatElement(final int index, final Type type, final Usage usage, final int count) {
        if (this.supportsUsage(index, usage)) {
            this.usage = usage;
        }
        else {
            VertexFormatElement.LOGGER.warn("Multiple vertex elements of the same type other than UVs are not supported. Forcing type to UV.");
            this.usage = Usage.UV;
        }
        this.type = type;
        this.index = index;
        this.count = count;
    }
    
    private final boolean supportsUsage(final int var1, final Usage vertexFormatElement$Usage) {
        return var1 == 0 || vertexFormatElement$Usage == Usage.UV;
    }
    
    public final Type getType() {
        return this.type;
    }
    
    public final Usage getUsage() {
        return this.usage;
    }
    
    public final int getCount() {
        return this.count;
    }
    
    public final int getIndex() {
        return this.index;
    }
    
    @Override
    public String toString() {
        return this.count + "," + this.usage.getName() + "," + this.type.getName();
    }
    
    public final int getByteSize() {
        return this.type.getSize() * this.count;
    }
    
    public final boolean isPosition() {
        return this.usage == Usage.POSITION;
    }
    
    @Override
    public boolean equals(final Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        final VertexFormatElement var2 = (VertexFormatElement)object;
        return this.count == var2.count && this.index == var2.index && this.type == var2.type && this.usage == var2.usage;
    }
    
    @Override
    public int hashCode() {
        int var1 = this.type.hashCode();
        var1 = 31 * var1 + this.usage.hashCode();
        var1 = 31 * var1 + this.index;
        var1 = 31 * var1 + this.count;
        return var1;
    }
    
    static {
        LOGGER = LogManager.getLogger();
    }
    
    @ClientJarOnly
    public enum Usage
    {
        POSITION("POSITION", 0, "Position"), 
        NORMAL("NORMAL", 1, "Normal"), 
        COLOR("COLOR", 2, "Vertex Color"), 
        UV("UV", 3, "UV"), 
        MATRIX("MATRIX", 4, "Bone Matrix"), 
        BLEND_WEIGHT("BLEND_WEIGHT", 5, "Blend Weight"), 
        PADDING("PADDING", 6, "Padding");
        
        private final String name;
        
        private Usage(final String s, final int n, final String name) {
            this.name = name;
        }
        
        public String getName() {
            return this.name;
        }
    }
    
    @ClientJarOnly
    public enum Type
    {
        FLOAT("FLOAT", 0, 4, "Float", 5126), 
        UBYTE("UBYTE", 1, 1, "Unsigned Byte", 5121), 
        BYTE("BYTE", 2, 1, "Byte", 5120), 
        USHORT("USHORT", 3, 2, "Unsigned Short", 5123), 
        SHORT("SHORT", 4, 2, "Short", 5122), 
        UINT("UINT", 5, 4, "Unsigned Int", 5125), 
        INT("INT", 6, 4, "Int", 5124);
        
        private final int size;
        private final String name;
        private final int glType;
        
        private Type(final String s, final int n, final int size, final String name, final int glType) {
            this.size = size;
            this.name = name;
            this.glType = glType;
        }
        
        public int getSize() {
            return this.size;
        }
        
        public String getName() {
            return this.name;
        }
        
        public int getGlType() {
            return this.glType;
        }
    }
}
