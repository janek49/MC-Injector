package com.mojang.blaze3d.platform;

import com.fox2code.repacker.*;
import java.util.*;

@ClientJarOnly
public class DisplayData
{
    public final int width;
    public final int height;
    public final OptionalInt fullscreenWidth;
    public final OptionalInt fullscreenHeight;
    public final boolean isFullscreen;
    
    public DisplayData(final int width, final int height, final OptionalInt fullscreenWidth, final OptionalInt fullscreenHeight, final boolean isFullscreen) {
        this.width = width;
        this.height = height;
        this.fullscreenWidth = fullscreenWidth;
        this.fullscreenHeight = fullscreenHeight;
        this.isFullscreen = isFullscreen;
    }
}
